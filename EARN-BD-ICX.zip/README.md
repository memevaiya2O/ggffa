╔══════════════════════════════╗
        LICENSE & CREDITS
╚══════════════════════════════╝

This project is an original creation developed and maintained by:

👨‍💻 DEVELOPER / CREATOR ✨ 
   🔰 SHADOW RIAD 🔰

━━━━━━━━━━━━━━━━━━━━━━

📩 CONTACT
https://t.me/zerox6t9

📢 OFFICIAL CHANNEL
https://t.me/infinity_codex

━━━━━━━━━━━━━━━━━━━━━━

⚖️ LICENSE NOTICE

This project is provided for personal and legitimate use only.
You may use and customize the project according to your needs,
but the original developer credit must remain intact.

❌ Do not claim this project as your own.
❌ Do not remove or modify the original developer credits.
❌ Do not redistribute or resell this project without permission.

For permissions, support, or other inquiries, please contact
the developer through the official contact link above.

━━━━━━━━━━━━━━━━━━━━━━

✨ A Creation Of
Infinity Codex </>
━━━━━━━━━━━━━━━━━━━━━━