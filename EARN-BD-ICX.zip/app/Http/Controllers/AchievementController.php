<?php

namespace App\Http\Controllers;

use App\Models\Achievement;
use Illuminate\Http\Request;

/** Original achievements.php — badge grid. */
class AchievementController extends Controller
{
    public function index(Request $request)
    {
        $user = requireLoginUser();
        if ($user instanceof \Illuminate\Http\RedirectResponse) {
            return $user;
        }

        $notifCount = getUnreadNotificationCount((int) $user->id);

        $achievements = Achievement::query()
            ->selectRaw('achievements.*, user_achievements.unlocked_at')
            ->leftJoin('user_achievements', function ($join) use ($user) {
                $join->on('user_achievements.achievement_id', '=', 'achievements.id')
                    ->where('user_achievements.user_id', '=', $user->id);
            })
            ->orderByRaw('user_achievements.unlocked_at IS NULL, user_achievements.unlocked_at DESC, achievements.id')
            ->get();

        $unlockedCount = count(array_filter($achievements->all(), fn ($a) => $a->unlocked_at));

        return view('achievements', [
            'user' => $user,
            'notifCount' => $notifCount,
            'achievements' => $achievements,
            'unlockedCount' => $unlockedCount,
        ]);
    }
}
