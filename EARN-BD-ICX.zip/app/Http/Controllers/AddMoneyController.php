<?php

namespace App\Http\Controllers;

use App\Models\Deposit;
use App\Models\DepositMethod;
use Illuminate\Http\Request;

/**
 * Add Money — the user sends money to an admin account, submits the TrxID and
 * waits for approval. The first approved deposit(s) that reach the admin-set
 * minimum activate the wallet, which unlocks withdrawals.
 */
class AddMoneyController extends Controller
{
    public function index(Request $request)
    {
        $user = requireLoginUser();
        if ($user instanceof \Illuminate\Http\RedirectResponse) {
            return $user;
        }

        return $this->render($user, '', session()->pull('add_money_success') ?? '');
    }

    public function store(Request $request)
    {
        $user = requireLoginUser();
        if ($user instanceof \Illuminate\Http\RedirectResponse) {
            return $user;
        }

        $methodId = (int) $request->input('method_id', 0);
        $amount = round((float) $request->input('amount', 0), 2);
        $sender = trim((string) $request->input('sender_number', ''));
        $trx = strtoupper(trim((string) $request->input('transaction_id', '')));

        $method = DepositMethod::query()->where('id', $methodId)->where('status', 'active')->first();
        $min = $this->minimumFor($user, $method);

        $error = '';
        if (!$method) {
            $error = 'Please select a payment method.';
        } elseif ($amount < $min) {
            $error = 'Minimum amount is ' . formatAmount($min) . '.';
        } elseif ($amount > 1000000) {
            $error = 'Amount is too large.';
        } elseif ($sender === '' || mb_strlen($sender) > 64) {
            $error = 'Please enter the number/account you sent money from.';
        } elseif (mb_strlen($trx) < 4 || mb_strlen($trx) > 128) {
            $error = 'Please enter a valid Transaction ID.';
        } elseif (Deposit::query()->where('transaction_id', $trx)->where('status', '!=', 'rejected')->exists()) {
            $error = 'This Transaction ID has already been submitted.';
        } elseif (Deposit::query()->where('user_id', $user->id)->where('status', 'pending')->exists()) {
            $error = 'You already have a deposit waiting for approval.';
        }

        // Payment screenshot (required)
        $screenshot = null;
        if ($error === '') {
            if (empty($_FILES['screenshot']['name'])) {
                $error = 'Please upload the payment screenshot.';
            } else {
                $up = handleUpload('screenshot', 'uploads/deposits');
                if ($up['success']) {
                    $screenshot = $up['path'];
                } else {
                    $error = $up['message'];
                }
            }
        }

        if ($error !== '') {
            return $this->render($user, $error, '');
        }

        $deposit = Deposit::query()->create([
            'user_id' => $user->id,
            'method_id' => $method->id,
            'amount' => $amount,
            'sender_number' => $sender,
            'transaction_id' => $trx,
            'screenshot' => $screenshot,
            'status' => 'pending',
        ]);
        // Telegram bot → admin (user details + amount + TrxID + screenshot)
        notifyTelegramDeposit($user, $deposit, (string) $method->name, (string) $method->account_number);
        createNotification((int) $user->id, 'deposit', 'Deposit Submitted', 'Your deposit of ' . formatAmount($amount) . ' via ' . $method->name . ' is waiting for approval.');

        session(['add_money_success' => 'Deposit submitted! We will review it shortly.']);
        return redirect('/add-money');
    }

    /** Smallest amount the user may add right now. */
    protected function minimumFor($user, $method): float
    {
        $min = $method ? (float) $method->min_amount : 0;
        if (walletActivationRequired() && empty($user->wallet_active)) {
            $approved = (float) Deposit::query()->where('user_id', $user->id)->where('status', 'approved')->sum('amount');
            $min = max($min, walletActivationMin() - $approved);
        }
        return max(1, round($min, 2));
    }

    protected function render($user, string $error, string $success)
    {
        $methods = DepositMethod::query()->where('status', 'active')->orderBy('id')->get();
        $history = Deposit::query()
            ->select('deposits.*', 'deposit_methods.name as method_name', 'deposit_methods.icon as method_icon')
            ->leftJoin('deposit_methods', 'deposit_methods.id', '=', 'deposits.method_id')
            ->where('deposits.user_id', $user->id)
            ->orderByDesc('deposits.id')->limit(20)->get();

        return view('add-money', [
            'user' => $user,
            'notifCount' => getUnreadNotificationCount((int) $user->id),
            'methods' => $methods,
            'history' => $history,
            'hasPending' => $history->contains(fn ($d) => $d->status === 'pending'),
            'walletActive' => (bool) $user->wallet_active,
            'required' => walletActivationRequired(),
            'activationMin' => walletActivationMin(),
            'minNow' => $this->minimumFor($user, null),
            'error' => $error,
            'success' => $success,
        ]);
    }
}
