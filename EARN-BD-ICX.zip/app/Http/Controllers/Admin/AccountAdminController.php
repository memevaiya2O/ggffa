<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AdminUser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

/** Admin: change my username / password. */
class AccountAdminController extends Controller
{
    public function index(Request $request)
    {
        $admin = AdminUser::query()->where('id', session('admin_id'))->first();
        if (!$admin) {
            session()->flush();
            return redirect('/Icxpanel/login');
        }

        $error = '';
        $flash = session()->pull('flash') ?? '';

        if ($request->isMethod('POST')) {
            $current = (string) $request->input('current_password', '');
            $newUser = trim((string) $request->input('username', ''));
            $newPass = (string) $request->input('new_password', '');
            $confirm = (string) $request->input('confirm_password', '');

            if (!Hash::check($current, $admin->password)) {
                $error = 'Current password is incorrect.';
            } elseif ($newUser === '' || mb_strlen($newUser) < 3 || mb_strlen($newUser) > 60) {
                $error = 'Username must be 3–60 characters.';
            } elseif (AdminUser::query()->where('username', $newUser)->where('id', '!=', $admin->id)->exists()) {
                $error = 'That username is already taken.';
            } elseif ($newPass !== '' && strlen($newPass) < 8) {
                $error = 'New password must be at least 8 characters.';
            } elseif ($newPass !== $confirm) {
                $error = 'New password and confirmation do not match.';
            } else {
                $data = ['username' => $newUser];
                if ($newPass !== '') {
                    $data['password'] = Hash::make($newPass);
                }
                $admin->update($data);
                // New session id after a credential change; stay logged in.
                $request->session()->regenerate();
                session(['admin_id' => $admin->id, 'admin_username' => $newUser]);
                session(['flash' => $newPass !== '' ? 'Password updated successfully.' : 'Account updated.']);
                return redirect('/Icxpanel/account');
            }
        }

        return view('admin.account', [
            'pageTitle' => 'My Account',
            'adminPage' => 'account',
            'flash' => $flash,
            'error' => $error,
            'admin' => $admin,
        ]);
    }
}
