<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

/** Original admin/login and admin/logout. */
class AdminAuthController extends Controller
{
    public function showLogin()
    {
        if (!empty(session('admin_id'))) {
            return redirect('/Icxpanel/');
        }

        return view('admin.login', ['error' => '']);
    }

    public function login(Request $request)
    {
        if (!empty(session('admin_id'))) {
            return redirect('/Icxpanel/');
        }

        $error = '';
        $username = trim($request->input('username', ''));
        $password = $request->input('password', '');
        if (!$username || !$password) {
            $error = 'Please fill in all fields.';
        } elseif (loginAdmin($username, $password)) {
            return redirect('/Icxpanel/');
        } else {
            $error = 'Invalid credentials.';
        }

        return view('admin.login', ['error' => $error]);
    }

    public function logout()
    {
        session()->flush();
        return redirect('/Icxpanel/login');
    }
}
