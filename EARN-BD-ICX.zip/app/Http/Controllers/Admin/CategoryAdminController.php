<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\TaskCategory;
use Illuminate\Http\Request;

/** Original admin/categories — CRUD + drag-drop reorder. */
class CategoryAdminController extends Controller
{
    public function index(Request $request)
    {
        if ($request->isMethod('POST')) {
            // Drag & drop reorder posts JSON: { order: [{id, order}], csrf_token }
            $jsonOrder = $request->isJson() ? $request->json('order') : null;
            $action = $request->input('action', $jsonOrder !== null ? 'reorder' : '');

            if ($action === 'reorder') {
                if (is_array($jsonOrder)) {
                    foreach ($jsonOrder as $item) {
                        TaskCategory::query()->where('id', (int) $item['id'])->update(['sort_order' => (int) $item['order']]);
                    }
                }
                return response()->json(['success' => true, 'message' => 'Order saved']);
            }

            if ($action === 'add' || $action === 'edit') {
                $id = (int) $request->input('cat_id', 0);
                $name = trim($request->input('name', ''));
                $icon = trim($request->input('icon', 'fa-tag'));
                $color = trim($request->input('color', '#00C896'));
                $st = $request->input('status', 'active');
                if (!$name) {
                    session(['flash_err' => 'Name required.']);
                    return redirect('/Icxpanel/categories');
                }
                if ($action === 'add') {
                    TaskCategory::query()->create(['name' => $name, 'icon' => $icon, 'color' => $color, 'status' => $st]);
                } else {
                    TaskCategory::query()->where('id', $id)->update(['name' => $name, 'icon' => $icon, 'color' => $color, 'status' => $st]);
                }
                session(['flash' => 'Category saved.']);
            } elseif ($action === 'delete') {
                TaskCategory::query()->where('id', (int) $request->input('cat_id', 0))->delete();
                session(['flash' => 'Category deleted.']);
            }
            return redirect('/Icxpanel/categories');
        }

        $flash = session()->pull('flash') ?? '';
        $flashErr = session()->pull('flash_err') ?? '';
        $cats = TaskCategory::query()
            ->selectRaw('task_categories.*, (SELECT COUNT(*) FROM tasks WHERE category_id = task_categories.id) as task_count')
            ->orderBy('task_categories.sort_order')->orderBy('task_categories.id')
            ->get();

        return view('admin.categories', [
            'pageTitle' => 'Categories',
            'adminPage' => 'categories',
            'flash' => $flash,
            'flashErr' => $flashErr,
            'cats' => $cats,
        ]);
    }
}
