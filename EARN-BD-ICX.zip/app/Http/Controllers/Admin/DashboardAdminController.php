<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Submission;
use App\Models\Task;
use App\Models\TaskCategory;
use App\Models\Transaction;
use App\Models\User;
use App\Models\Withdrawal;
use Illuminate\Support\Facades\DB;

/** Original admin/index.php — KPI cards, monthly charts, recent records. */
class DashboardAdminController extends Controller
{
    public function index()
    {
        // KPI data
        $totalUsers = (int) User::query()->count();
        $todayUsers = (int) User::query()->whereRaw('DATE(created_at) = CURRENT_DATE')->count();
        $activeUsers = (int) User::query()->where('last_login', '>=', DB::raw('NOW() - INTERVAL 7 DAY'))->count();
        $bannedUsers = (int) User::query()->where('status', 'banned')->count();
        $pendingSubs = (int) Submission::query()->where('status', 'pending')->count();
        $todayApproved = (int) Submission::query()->where('status', 'approved')->whereRaw('DATE(reviewed_at) = CURRENT_DATE')->count();
        $totalTasks = (int) Task::query()->count();
        $totalCats = (int) TaskCategory::query()->count();
        $pendingWith = (int) Withdrawal::query()->where('status', 'pending')->count();
        $todayPaid = (int) Withdrawal::query()->where('status', 'paid')->whereRaw('DATE(paid_at) = CURRENT_DATE')->count();
        $totalPayout = (float) Withdrawal::query()->where('status', 'paid')->sum('amount');
        $totalBalance = (float) User::query()->sum('balance');

        // Charts (TO_CHAR/DATE_TRUNC → DATE_FORMAT)
        $monthlyUsers = User::query()
            ->selectRaw("DATE_FORMAT(created_at, '%b') as month, COUNT(*) as cnt")
            ->where('created_at', '>=', DB::raw('NOW() - INTERVAL 12 MONTH'))
            ->groupByRaw("DATE_FORMAT(created_at, '%Y-%m'), DATE_FORMAT(created_at, '%b')")
            ->orderByRaw("DATE_FORMAT(created_at, '%Y-%m')")
            ->get();
        $monthlyPayout = Withdrawal::query()
            ->selectRaw("DATE_FORMAT(paid_at, '%b') as month, COALESCE(SUM(amount),0) as total")
            ->where('status', 'paid')
            ->where('paid_at', '>=', DB::raw('NOW() - INTERVAL 12 MONTH'))
            ->groupByRaw("DATE_FORMAT(paid_at, '%Y-%m'), DATE_FORMAT(paid_at, '%b')")
            ->orderByRaw("DATE_FORMAT(paid_at, '%Y-%m')")
            ->get();

        // Recent records
        $recentUsers = User::query()
            ->select('users.*', 'levels.name as level_name', 'levels.color as level_color')
            ->leftJoin('levels', 'levels.id', '=', 'users.level_id')
            ->orderByDesc('users.created_at')->limit(10)->get();
        $recentSubs = Submission::query()
            ->select('submissions.*', 'users.name as user_name', 'tasks.title as task_title')
            ->join('users', 'users.id', '=', 'submissions.user_id')
            ->join('tasks', 'tasks.id', '=', 'submissions.task_id')
            ->orderByDesc('submissions.created_at')->limit(10)->get();
        $recentWith = Withdrawal::query()
            ->select('withdrawals.*', 'users.name as user_name', 'withdraw_methods.name as method_name')
            ->join('users', 'users.id', '=', 'withdrawals.user_id')
            ->join('withdraw_methods', 'withdraw_methods.id', '=', 'withdrawals.method_id')
            ->orderByDesc('withdrawals.created_at')->limit(10)->get();
        $topMonth = User::query()
            ->selectRaw('users.name, users.avatar, COALESCE(SUM(t.amount),0) as earned')
            ->leftJoin('transactions as t', function ($join) {
                $join->on('t.user_id', '=', 'users.id')
                    ->where('t.amount', '>', 0)
                    ->where('t.created_at', '>=', DB::raw("DATE_FORMAT(NOW(), '%Y-%m-01')"));
            })
            ->groupBy('users.id', 'users.name', 'users.avatar')
            ->orderByDesc('earned')
            ->limit(5)->get();

        return view('admin.index', [
            'pageTitle' => 'Analytics Dashboard',
            'adminPage' => 'dashboard',
            'totalUsers' => $totalUsers,
            'todayUsers' => $todayUsers,
            'activeUsers' => $activeUsers,
            'bannedUsers' => $bannedUsers,
            'pendingSubs' => $pendingSubs,
            'todayApproved' => $todayApproved,
            'totalTasks' => $totalTasks,
            'totalCats' => $totalCats,
            'pendingWith' => $pendingWith,
            'todayPaid' => $todayPaid,
            'totalPayout' => $totalPayout,
            'totalBalance' => $totalBalance,
            'monthlyUsers' => $monthlyUsers,
            'monthlyPayout' => $monthlyPayout,
            'recentUsers' => $recentUsers,
            'recentSubs' => $recentSubs,
            'recentWith' => $recentWith,
            'topMonth' => $topMonth,
        ]);
    }
}
