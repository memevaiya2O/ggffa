<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Deposit;
use App\Models\Setting;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/** Admin: review Add-Money deposits + wallet-activation settings. */
class DepositAdminController extends Controller
{
    public function index(Request $request)
    {
        if ($request->isMethod('POST')) {
            $action = $request->input('action', '');

            if ($action === 'save_settings') {
                $min = max(0, round((float) $request->input('wallet_activation_min', 0), 2));
                $this->put('wallet_activation_required', $request->input('wallet_activation_required') ? '1' : '0');
                $this->put('wallet_activation_min', (string) $min);
                $this->put('deposit_credit_balance', $request->input('deposit_credit_balance') ? '1' : '0');
                session(['flash' => 'Wallet settings saved.']);
            } elseif ($action === 'save_telegram') {
                $this->put('telegram_enabled', $request->input('telegram_enabled') ? '1' : '0', 'telegram');
                $this->put('telegram_notify_tasks', $request->input('telegram_notify_tasks') ? '1' : '0', 'telegram');
                $this->put('telegram_chat_id', trim((string) $request->input('telegram_chat_id', '')), 'telegram');
                $token = trim((string) $request->input('telegram_bot_token', ''));
                if ($request->input('clear_telegram_token')) {
                    $this->put('telegram_bot_token', '', 'telegram');
                } elseif ($token !== '') { // blank = keep the saved token
                    $this->put('telegram_bot_token', $token, 'telegram');
                }
                session(['flash' => 'Telegram bot settings saved.']);
            } elseif ($action === 'telegram_test') {
                session(['flash' => $this->telegramTest()]);
            } elseif ($action === 'approve') {
                session(['flash' => $this->approve((int) $request->input('id', 0))]);
            } elseif ($action === 'reject') {
                session(['flash' => $this->reject((int) $request->input('id', 0), trim((string) $request->input('note', '')))]);
            }

            return redirect('/Icxpanel/deposits' . ($request->query('status') ? '?status=' . urlencode($request->query('status')) : ''));
        }

        $flash = session()->pull('flash') ?? '';
        $status = $request->query('status', 'pending');
        if (!in_array($status, ['pending', 'approved', 'rejected', 'all'], true)) {
            $status = 'pending';
        }
        $page = max(1, (int) $request->query('page', 1));
        $limit = 25;

        $query = Deposit::query()
            ->select('deposits.*', 'users.name as user_name', 'users.email as user_email', 'users.phone as user_phone', 'users.wallet_active', 'deposit_methods.name as method_name', 'deposit_methods.icon as method_icon')
            ->join('users', 'users.id', '=', 'deposits.user_id')
            ->leftJoin('deposit_methods', 'deposit_methods.id', '=', 'deposits.method_id');
        if ($status !== 'all') {
            $query->where('deposits.status', $status);
        }
        $total = (int) (clone $query)->count();
        $deposits = $query->orderByDesc('deposits.id')->limit($limit)->offset(($page - 1) * $limit)->get();

        return view('admin.deposits', [
            'pageTitle' => 'Deposits',
            'adminPage' => 'deposits',
            'flash' => $flash,
            'deposits' => $deposits,
            'status' => $status,
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'pendingSum' => (float) Deposit::query()->where('status', 'pending')->sum('amount'),
            'approvedSum' => (float) Deposit::query()->where('status', 'approved')->sum('amount'),
        ]);
    }

    protected function put(string $key, string $value, string $group = 'wallet'): void
    {
        Setting::query()->updateOrInsert(
            ['key' => $key],
            ['value' => $value, 'group_name' => $group, 'updated_at' => date('Y-m-d H:i:s')]
        );
    }

    /** Sends a test message right now and reports Telegram's answer. */
    protected function telegramTest(): string
    {
        [$token, $ids] = telegramCreds();
        if ($token === '' || !$ids) {
            return 'Save the bot token and chat ID first.';
        }
        $ok = 0;
        $err = '';
        foreach ($ids as $id) {
            if (telegramCall($token, 'sendMessage', ['chat_id' => $id, 'text' => '✅ ' . getSetting('site_name', 'EarnBD') . ' — Telegram bot connected. Deposit alerts will arrive here.'])) {
                $ok++;
            } else {
                $err = $GLOBALS['_TG_ERR'] ?? 'unknown error';
            }
        }
        return $ok === count($ids) ? 'Test message sent ✅ — check your Telegram.' : 'Telegram error: ' . $err;
    }

    protected function approve(int $id): string
    {
        $msg = 'Deposit not found or already processed.';

        DB::transaction(function () use ($id, &$msg) {
            $dep = Deposit::query()->where('id', $id)->where('status', 'pending')->lockForUpdate()->first();
            if (!$dep) {
                return;
            }
            $dep->update(['status' => 'approved', 'processed_at' => date('Y-m-d H:i:s')]);

            $amount = (float) $dep->amount;
            if (getSetting('deposit_credit_balance', '1') === '1') {
                User::query()->where('id', $dep->user_id)->update(['balance' => DB::raw('balance + ' . $amount)]);
                addTransaction((int) $dep->user_id, 'deposit', $amount, 'Money added (TrxID ' . $dep->transaction_id . ')', (int) $dep->id);
            }

            $approvedTotal = (float) Deposit::query()->where('user_id', $dep->user_id)->where('status', 'approved')->sum('amount');
            $activated = false;
            if ($approvedTotal >= walletActivationMin()) {
                $activated = User::query()->where('id', $dep->user_id)->where('wallet_active', 0)
                    ->update(['wallet_active' => 1, 'wallet_activated_at' => date('Y-m-d H:i:s')]) > 0;
            }

            createNotification((int) $dep->user_id, 'deposit', $activated ? 'Wallet Activated 🎉' : 'Deposit Approved',
                $activated
                    ? 'Your deposit of ' . formatAmount($amount) . ' was approved and your wallet is now active. You can withdraw now.'
                    : 'Your deposit of ' . formatAmount($amount) . ' was approved.');

            $msg = 'Deposit approved' . ($activated ? ' — wallet activated.' : '.');
        });

        return $msg;
    }

    protected function reject(int $id, string $note): string
    {
        $dep = Deposit::query()->where('id', $id)->where('status', 'pending')->first();
        if (!$dep) {
            return 'Deposit not found or already processed.';
        }
        $note = $note !== '' ? mb_substr($note, 0, 250) : 'Payment could not be verified.';
        $dep->update(['status' => 'rejected', 'admin_note' => $note, 'processed_at' => date('Y-m-d H:i:s')]);
        createNotification((int) $dep->user_id, 'deposit', 'Deposit Rejected', 'Your deposit of ' . formatAmount((float) $dep->amount) . ' was rejected: ' . $note);
        return 'Deposit rejected.';
    }
}
