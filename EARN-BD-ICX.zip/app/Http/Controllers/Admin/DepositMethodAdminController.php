<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\DepositMethod;
use Illuminate\Http\Request;

/** Admin: payment accounts users send money to when adding money. */
class DepositMethodAdminController extends Controller
{
    public function index(Request $request)
    {
        if ($request->isMethod('POST')) {
            $action = $request->input('action', '');

            if ($action === 'save') {
                $id = (int) $request->input('id', 0);
                $data = [
                    'name' => trim((string) $request->input('name', '')),
                    'icon' => trim((string) $request->input('icon', '')) ?: 'fa-wallet',
                    'account_number' => trim((string) $request->input('account_number', '')),
                    'account_type' => trim((string) $request->input('account_type', '')) ?: 'Personal',
                    'instructions' => trim((string) $request->input('instructions', '')),
                    'min_amount' => max(0, (float) $request->input('min_amount', 0)),
                    'status' => $request->input('status') === 'inactive' ? 'inactive' : 'active',
                ];
                if ($data['name'] !== '' && $data['account_number'] !== '') {
                    $id ? DepositMethod::query()->where('id', $id)->update($data) : DepositMethod::query()->create($data);
                    session(['flash' => 'Method saved.']);
                } else {
                    session(['flash' => 'Name and account number are required.']);
                }
            } elseif ($action === 'delete') {
                DepositMethod::query()->where('id', (int) $request->input('id', 0))->delete();
                session(['flash' => 'Method deleted.']);
            } elseif ($action === 'toggle') {
                $id = (int) $request->input('id', 0);
                $cur = DepositMethod::query()->where('id', $id)->value('status');
                DepositMethod::query()->where('id', $id)->update(['status' => $cur === 'active' ? 'inactive' : 'active']);
                session(['flash' => 'Status updated.']);
            }
            return redirect('/Icxpanel/deposit-methods');
        }

        return view('admin.deposit-methods', [
            'pageTitle' => 'Deposit Methods',
            'adminPage' => 'deposit-methods',
            'flash' => session()->pull('flash') ?? '',
            'methods' => DepositMethod::query()->orderBy('id')->get(),
        ]);
    }
}
