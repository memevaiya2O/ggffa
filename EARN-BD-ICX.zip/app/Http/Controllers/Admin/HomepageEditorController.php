<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Http\Request;

/** Original admin/homepage-editor — homepage copy settings (settings keys, group 'homepage'). */
class HomepageEditorController extends Controller
{
    public function index(Request $request)
    {
        if ($request->isMethod('POST')) {
            $fields = [
                'hero_title', 'hero_subtitle', 'hero_btn_text', 'hero_btn_link',
                'stats_show', 'stat1_number', 'stat1_label', 'stat2_number', 'stat2_label', 'stat3_number', 'stat3_label', 'stat4_number', 'stat4_label',
                'features_show', 'features_title',
                'how_show', 'how_title',
                'testimonials_show', 'testimonials_title',
                'cta_show', 'cta_title', 'cta_subtitle', 'cta_btn_text', 'cta_btn_link',
                'hero_bg_color', 'hero_text_color',
            ];
            foreach ($fields as $k) {
                $this->upsertSetting($k, trim($request->input($k, '')));
            }
            // Handle feature blocks (6)
            for ($i = 1; $i <= 6; $i++) {
                foreach (['feat_icon_', 'feat_title_', 'feat_desc_'] as $prefix) {
                    $this->upsertSetting($prefix . $i, trim($request->input($prefix . $i, '')));
                }
            }
            session(['flash' => 'Homepage updated.']);
            return redirect('/Icxpanel/homepage-editor');
        }

        $flash = session()->pull('flash') ?? '';
        $s = [];
        foreach (Setting::query()->where('group_name', 'homepage')->orWhere('key', 'like', 'hero_%')
            ->orWhere('key', 'like', 'stat%')->orWhere('key', 'like', 'feat%')
            ->orWhere('key', 'like', 'how_%')->orWhere('key', 'like', 'cta_%')
            ->orWhere('key', 'like', 'testimonials_%')->get() as $r) {
            $s[$r->key] = $r->value;
        }

        return view('admin.homepage-editor', [
            'pageTitle' => 'Homepage Editor',
            'adminPage' => 'homepage-editor',
            'flash' => $flash,
            's' => $s,
        ]);
    }

    protected function upsertSetting(string $key, string $value): void
    {
        $existing = Setting::query()->where('key', $key)->first();
        if ($existing) {
            Setting::query()->where('key', $key)->update(['value' => $value]);
        } else {
            Setting::query()->create(['key' => $key, 'value' => $value, 'group_name' => 'homepage']);
        }
    }
}
