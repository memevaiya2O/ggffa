<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/** Original admin/leaderboard — settings + live rankings. */
class LeaderboardAdminController extends Controller
{
    public function index(Request $request)
    {
        if ($request->isMethod('POST')) {
            foreach ([
                'leaderboard_enabled', 'leaderboard_period', 'leaderboard_top_n',
                'leaderboard_prize_1', 'leaderboard_prize_2', 'leaderboard_prize_3',
            ] as $k) {
                Setting::query()->where('key', $k)->update(['value' => trim($request->input($k, ''))]);
            }
            session(['flash' => 'Settings saved.']);
            return redirect('/Icxpanel/leaderboard');
        }

        $flash = session()->pull('flash') ?? '';
        $s = [];
        foreach (Setting::query()->where('key', 'like', 'leaderboard_%')->get() as $r) {
            $s[$r->key] = $r->value;
        }

        $period = $request->query('period', 'alltime');
        // Date filter goes into the JOIN ON clause (same as the original LEFT JOIN ... AND t2.created_at ...).
        $periodSQL = match ($period) {
            'today' => 't2.created_at >= CURRENT_DATE',
            'week' => 't2.created_at >= DATE_SUB(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY)',
            'month' => "t2.created_at >= DATE_FORMAT(NOW(), '%Y-%m-01')",
            default => '',
        };
        $leaders = User::query()
            ->selectRaw('users.id, users.name, users.avatar, levels.name as level_name, levels.color as level_color,
                COALESCE(SUM(t2.amount),0) as earned')
            ->leftJoin('transactions as t2', function ($join) use ($periodSQL) {
                $join->on('t2.user_id', '=', 'users.id')->where('t2.amount', '>', 0);
                if ($periodSQL !== '') {
                    $join->whereRaw($periodSQL);
                }
            })
            ->leftJoin('levels', 'levels.id', '=', 'users.level_id')
            ->where('users.status', 'active')
            ->groupBy('users.id', 'users.name', 'users.avatar', 'levels.name', 'levels.color')
            ->orderByDesc('earned')
            ->limit(50)
            ->get();

        return view('admin.leaderboard', [
            'pageTitle' => 'Leaderboard',
            'adminPage' => 'leaderboard',
            'flash' => $flash,
            's' => $s,
            'period' => $period,
            'leaders' => $leaders,
        ]);
    }
}
