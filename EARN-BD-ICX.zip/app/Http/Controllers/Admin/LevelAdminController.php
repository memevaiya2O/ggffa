<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Level;
use Illuminate\Http\Request;

/** Original admin/levels — bulk save / add / delete levels. */
class LevelAdminController extends Controller
{
    public function index(Request $request)
    {
        if ($request->isMethod('POST')) {
            $action = $request->input('action', '');
            if ($action === 'save_all') {
                $ids = $request->input('level_id', []);
                foreach ($ids as $i => $lid) {
                    Level::query()->where('id', (int) $lid)->update([
                        'name' => $request->input('name')[$i],
                        'icon' => $request->input('icon')[$i],
                        'color' => $request->input('color')[$i],
                        'required_points' => (int) $request->input('required_points')[$i],
                        'levelup_bonus' => (float) $request->input('levelup_bonus')[$i],
                        'daily_withdraw_limit' => (float) $request->input('daily_withdraw_limit')[$i],
                        'can_access_vip' => isset($request->input('can_access_vip')[$i]) ? 1 : 0,
                    ]);
                }
                session(['flash' => 'Levels saved!']);
            } elseif ($action === 'add') {
                $nextSort = (int) Level::query()->max('sort_order') + 1;
                Level::query()->create([
                    'name' => trim($request->input('name')[0] ?? '') ?: 'New Level',
                    'icon' => 'fa-medal', 'color' => '#00C896', 'required_points' => 0,
                    'levelup_bonus' => 0, 'daily_withdraw_limit' => 100, 'can_access_vip' => 0,
                    'sort_order' => $nextSort,
                ]);
                session(['flash' => 'Level added!']);
            } elseif ($action === 'delete') {
                Level::query()->where('id', (int) $request->input('level_id_del', 0))->delete();
                session(['flash' => 'Level deleted.']);
            }
            return redirect('/Icxpanel/levels');
        }

        $flash = session()->pull('flash') ?? '';
        $levels = Level::query()->orderBy('sort_order')->orderBy('required_points')->get();

        return view('admin.levels', [
            'pageTitle' => 'Level System',
            'adminPage' => 'levels',
            'flash' => $flash,
            'levels' => $levels,
        ]);
    }
}
