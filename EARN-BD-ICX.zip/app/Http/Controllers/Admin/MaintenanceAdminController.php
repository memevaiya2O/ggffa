<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SessionEntry;
use App\Models\SpinHistory;
use App\Models\Transaction;
use App\Models\User;
use Illuminate\Http\Request;

/** Original admin/maintenance — maintenance settings, DB stats, tools. */
class MaintenanceAdminController extends Controller
{
    public function index(Request $request)
    {
        if ($request->isMethod('POST')) {
            $action = $request->input('action', '');

            if ($action === 'save') {
                foreach (['maintenance_mode', 'maintenance_title', 'maintenance_message', 'maintenance_end_time', 'maintenance_allow_admin'] as $k) {
                    \App\Models\Setting::query()->where('key', $k)->update(['value' => trim($request->input($k, ''))]);
                }
                session(['flash' => 'Maintenance settings saved.']);
            } elseif ($action === 'clear_cache') {
                // Clear any cached data
                SessionEntry::query()->where('last_activity', '<', time() - 86400)->delete();
                session(['flash' => 'Old sessions cleared.']);
            } elseif ($action === 'reset_spins') {
                // Original referenced created_at (no such column on spin_history); spin_date is the date column.
                SpinHistory::query()->where('spin_date', '<', date('Y-m-d', strtotime('-7 days')))->delete();
                session(['flash' => 'Old spin history cleared.']);
            } elseif ($action === 'fix_balances') {
                // Recalculate balances from transactions
                $users = User::query()->pluck('id')->all();
                foreach ($users as $uid) {
                    $bal = (float) Transaction::query()->where('user_id', $uid)->sum('amount');
                    User::query()->where('id', $uid)->update(['balance' => $bal]);
                }
                session(['flash' => 'Balances recalculated for ' . count($users) . ' users.']);
            }
            return redirect('/Icxpanel/maintenance');
        }

        $flash = session()->pull('flash') ?? '';
        $s = [];
        foreach (\App\Models\Setting::query()->where('key', 'like', 'maintenance_%')->get() as $r) {
            $s[$r->key] = $r->value;
        }

        // DB stats
        $dbStats = [
            'users' => (int) User::query()->count(),
            'submissions' => (int) \App\Models\Submission::query()->count(),
            'transactions' => (int) Transaction::query()->count(),
            'notifications' => (int) \App\Models\Notification::query()->count(),
            'spin_history' => (int) SpinHistory::query()->count(),
        ];

        return view('admin.maintenance', [
            'pageTitle' => 'Maintenance Mode',
            'adminPage' => 'maintenance',
            'flash' => $flash,
            's' => $s,
            'dbStats' => $dbStats,
        ]);
    }
}
