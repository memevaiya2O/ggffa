<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Notification;
use App\Models\User;
use Illuminate\Http\Request;

/** Original admin/notifications — broadcast, list, delete, clear, mark read. */
class NotificationAdminController extends Controller
{
    public function index(Request $request)
    {
        if ($request->isMethod('POST')) {
            $action = $request->input('action', '');

            if ($action === 'broadcast') {
                $title = trim($request->input('title', ''));
                $message = trim($request->input('message', ''));
                $target = $request->input('target', 'all');
                if ($title && $message) {
                    if ($target === 'all') {
                        $uids = User::query()->where('status', 'active')->pluck('id')->all();
                    } else {
                        $uids = [(int) $target];
                    }
                    foreach ($uids as $uid) {
                        createNotification((int) $uid, 'broadcast', $title, $message);
                    }
                    session(['flash' => 'Broadcast sent to ' . count($uids) . ' user(s).']);
                }
            } elseif ($action === 'delete') {
                Notification::query()->where('id', (int) $request->input('id', 0))->delete();
                session(['flash' => 'Notification deleted.']);
            } elseif ($action === 'delete_all') {
                Notification::query()->delete();
                session(['flash' => 'All notifications cleared.']);
            } elseif ($action === 'mark_read') {
                Notification::query()->update(['is_read' => true]);
                session(['flash' => 'All marked as read.']);
            }
            return redirect('/Icxpanel/notifications');
        }

        $flash = session()->pull('flash') ?? '';
        $page = max(1, (int) $request->query('page', 1));
        $limit = 30;
        $offset = ($page - 1) * $limit;

        $total = (int) Notification::query()->count();
        $notifs = Notification::query()
            ->select('notifications.*', 'users.name as user_name')
            ->leftJoin('users', 'users.id', '=', 'notifications.user_id')
            ->orderByDesc('notifications.created_at')
            ->limit($limit)->offset($offset)->get();
        $users = User::query()->select('id', 'name')->where('status', 'active')->orderBy('name')->limit(500)->get();

        return view('admin.notifications', [
            'pageTitle' => 'Notifications',
            'adminPage' => 'notifications',
            'flash' => $flash,
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'notifs' => $notifs,
            'users' => $users,
        ]);
    }
}
