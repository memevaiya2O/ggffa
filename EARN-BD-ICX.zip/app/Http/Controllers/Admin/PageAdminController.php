<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Page;
use Illuminate\Http\Request;

/** Original admin/pages — static page CRUD (pages table). */
class PageAdminController extends Controller
{
    public function index(Request $request)
    {
        if ($request->isMethod('POST')) {
            $action = $request->input('action', '');

            if ($action === 'save') {
                $id = (int) $request->input('id', 0);
                $title = trim($request->input('title', ''));
                $slug = trim($request->input('slug', ''));
                $content = $request->input('content', '');
                $status = $request->input('status', 'published');
                $slug = preg_replace('/[^a-z0-9\-]/', '', strtolower($slug));
                if ($title && $slug) {
                    if ($id) {
                        Page::query()->where('id', $id)->update([
                            'title' => $title, 'slug' => $slug, 'content' => $content, 'status' => $status,
                        ]);
                    } else {
                        Page::query()->create([
                            'title' => $title, 'slug' => $slug, 'content' => $content, 'status' => $status,
                        ]);
                    }
                    session(['flash' => 'Page saved.']);
                }
            } elseif ($action === 'delete') {
                Page::query()->where('id', (int) $request->input('id', 0))->delete();
                session(['flash' => 'Page deleted.']);
            } elseif ($action === 'toggle') {
                $id = (int) $request->input('id', 0);
                $cur = Page::query()->where('id', $id)->value('status');
                Page::query()->where('id', $id)->update(['status' => $cur === 'published' ? 'draft' : 'published']);
                session(['flash' => 'Status toggled.']);
            }
            return redirect('/Icxpanel/pages');
        }

        $flash = session()->pull('flash') ?? '';
        $editId = (int) $request->query('edit', 0);
        $editPage = $editId ? Page::query()->find($editId) : null;
        $pages = Page::query()->orderByDesc('created_at')->get();

        return view('admin.pages', [
            'pageTitle' => 'Static Pages',
            'adminPage' => 'pages',
            'flash' => $flash,
            'editPage' => $editPage,
            'pages' => $pages,
        ]);
    }
}
