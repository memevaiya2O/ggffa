<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Popup;
use Illuminate\Http\Request;

/** Original admin/popup-manager — popup CRUD (JSON data blob). */
class PopupAdminController extends Controller
{
    public function index(Request $request)
    {
        if ($request->isMethod('POST')) {
            $action = $request->input('action', '');

            if ($action === 'save') {
                $id = (int) $request->input('id', 0);
                $title = trim($request->input('title', ''));
                $content = $request->input('content', '');
                $type = $request->input('type', 'info');
                $trigger = $request->input('trigger', 'pageload');
                $delay = (int) $request->input('delay', 0);
                $pages = trim($request->input('show_pages', ''));
                $btnText = trim($request->input('btn_text', ''));
                $btnLink = trim($request->input('btn_link', ''));
                $status = $request->input('status', 'active');
                $startDate = $request->input('start_date') ?: null;
                $endDate = $request->input('end_date') ?: null;

                $data = json_encode([
                    'title' => $title, 'content' => $content, 'type' => $type, 'trigger' => $trigger,
                    'delay' => $delay, 'pages' => $pages, 'btn_text' => $btnText, 'btn_link' => $btnLink,
                    'start_date' => $startDate, 'end_date' => $endDate,
                ]);
                if ($id) {
                    Popup::query()->where('id', $id)->update(['title' => $title, 'data' => $data, 'status' => $status]);
                } else {
                    Popup::query()->create(['title' => $title, 'data' => $data, 'status' => $status]);
                }
                session(['flash' => 'Popup saved.']);
            } elseif ($action === 'delete') {
                Popup::query()->where('id', (int) $request->input('id', 0))->delete();
                session(['flash' => 'Popup deleted.']);
            } elseif ($action === 'toggle') {
                $id = (int) $request->input('id', 0);
                $cur = Popup::query()->where('id', $id)->value('status');
                Popup::query()->where('id', $id)->update(['status' => $cur === 'active' ? 'inactive' : 'active']);
                session(['flash' => 'Status updated.']);
            }
            return redirect('/Icxpanel/popup-manager');
        }

        $flash = session()->pull('flash') ?? '';
        $editId = (int) $request->query('edit', 0);
        $editPop = null;
        if ($editId) {
            $row = Popup::query()->find($editId);
            if ($row) {
                $editPop = $row;
                $editPop->_data = json_decode($row->data, true) ?? [];
            }
        }
        $popups = Popup::query()->orderByDesc('created_at')->get();

        return view('admin.popup-manager', [
            'pageTitle' => 'Popup Manager',
            'adminPage' => 'popup-manager',
            'flash' => $flash,
            'editPop' => $editPop,
            'popups' => $popups,
        ]);
    }
}
