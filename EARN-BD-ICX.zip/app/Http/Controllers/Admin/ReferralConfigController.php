<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use App\Models\User;
use Illuminate\Http\Request;

/** Original admin/referral-config — referral settings + top referrers. */
class ReferralConfigController extends Controller
{
    public function index(Request $request)
    {
        if ($request->isMethod('POST')) {
            foreach ([
                'referral_enabled', 'referral_bonus_referrer', 'referral_bonus_referee',
                'referral_min_withdraw', 'referral_max_per_user', 'referral_bonus_on',
            ] as $k) {
                Setting::query()->where('key', $k)->update(['value' => trim($request->input($k, ''))]);
            }
            session(['flash' => 'Referral settings saved.']);
            return redirect('/Icxpanel/referral-config');
        }

        $flash = session()->pull('flash') ?? '';
        $s = [];
        foreach (Setting::query()->where('key', 'like', 'referral_%')->get() as $r) {
            $s[$r->key] = $r->value;
        }

        // Stats
        $totalReferrals = (int) User::query()->whereNotNull('referred_by')->count();
        $topReferrers = User::query()
            ->selectRaw('users.name, COUNT(r.id) as cnt')
            ->join('users as r', 'r.referred_by', '=', 'users.id')
            ->groupBy('users.id', 'users.name')
            ->orderByDesc('cnt')
            ->limit(10)->get();

        return view('admin.referral-config', [
            'pageTitle' => 'Referral Config',
            'adminPage' => 'referral-config',
            'flash' => $flash,
            's' => $s,
            'totalReferrals' => $totalReferrals,
            'topReferrers' => $topReferrers,
        ]);
    }
}
