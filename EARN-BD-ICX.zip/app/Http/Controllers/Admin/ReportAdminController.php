<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SpinHistory;
use App\Models\Submission;
use App\Models\Task;
use App\Models\User;
use App\Models\Withdrawal;
use Illuminate\Support\Facades\DB;

/** Original admin/reports — summary + charts + top lists. */
class ReportAdminController extends Controller
{
    public function index()
    {
        $range = request()->query('range', '30');
        $days = in_array($range, ['7', '30', '90', '365']) ? (int) $range : 30;

        // Summary stats
        $totalUsers = (int) User::query()->count();
        $newUsers = (int) User::query()->where('created_at', '>=', DB::raw("NOW() - INTERVAL $days DAY"))->count();
        $totalTasks = (int) Task::query()->where('status', 'active')->count();
        $totalSubs = (int) Submission::query()->count();
        $pendingSubs = (int) Submission::query()->where('status', 'pending')->count();
        $approvedSubs = (int) Submission::query()->where('status', 'approved')->count();
        $totalWithdrawn = (float) Withdrawal::query()->where('status', 'approved')->sum('amount');
        $pendingWithdraw = (float) Withdrawal::query()->where('status', 'pending')->sum('amount');
        $totalEarned = (float) \App\Models\Transaction::query()
            ->whereIn('type', ['task_reward', 'referral_bonus', 'spin_reward'])
            ->where('amount', '>', 0)->sum('amount');
        // Original referenced spin_history.created_at (no such column); spin_date is the date column.
        $totalSpins = (int) SpinHistory::query()->where('spin_date', '>=', date('Y-m-d', strtotime("-$days days")))->count();

        // Daily registrations
        $dailyRegs = User::query()
            ->selectRaw('DATE(created_at) as d, COUNT(*) as cnt')
            ->where('created_at', '>=', DB::raw("NOW() - INTERVAL $days DAY"))
            ->groupByRaw('DATE(created_at)')
            ->orderByRaw('DATE(created_at)')
            ->get();
        // Daily submissions
        $dailySubs = Submission::query()
            ->selectRaw('DATE(created_at) as d, COUNT(*) as cnt')
            ->where('created_at', '>=', DB::raw("NOW() - INTERVAL $days DAY"))
            ->groupByRaw('DATE(created_at)')
            ->orderByRaw('DATE(created_at)')
            ->get();
        // Top tasks
        $topTasks = Submission::query()
            ->selectRaw('tasks.title, COUNT(submissions.id) as cnt')
            ->join('tasks', 'tasks.id', '=', 'submissions.task_id')
            ->where('submissions.status', 'approved')
            ->groupBy('tasks.id', 'tasks.title')
            ->orderByDesc('cnt')
            ->limit(10)->get();
        // Top earners
        $topEarners = User::query()->select('name', 'email', 'balance')->orderByDesc('balance')->limit(10)->get();
        // Withdrawal by method
        $wByMethod = Withdrawal::query()
            ->selectRaw('method, COUNT(*) as cnt, SUM(amount) as total')
            ->where('status', 'approved')
            ->groupBy('method')
            ->orderByDesc('total')
            ->get();

        return view('admin.reports', [
            'pageTitle' => 'Reports & Analytics',
            'adminPage' => 'reports',
            'range' => $range,
            'days' => $days,
            'totalUsers' => $totalUsers,
            'newUsers' => $newUsers,
            'totalTasks' => $totalTasks,
            'totalSubs' => $totalSubs,
            'pendingSubs' => $pendingSubs,
            'approvedSubs' => $approvedSubs,
            'totalWithdrawn' => $totalWithdrawn,
            'pendingWithdraw' => $pendingWithdraw,
            'totalEarned' => $totalEarned,
            'totalSpins' => $totalSpins,
            'dailyRegs' => $dailyRegs,
            'dailySubs' => $dailySubs,
            'topTasks' => $topTasks,
            'topEarners' => $topEarners,
            'wByMethod' => $wByMethod,
        ]);
    }
}
