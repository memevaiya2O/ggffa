<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Http\Request;

/** Original admin/seo — SEO / analytics / robots / custom code settings. */
class SeoAdminController extends Controller
{
    public function index(Request $request)
    {
        if ($request->isMethod('POST')) {
            $fields = [
                'seo_title', 'seo_description', 'seo_keywords', 'seo_og_image',
                'seo_twitter_card', 'seo_canonical_url',
                'google_analytics_id', 'google_tag_manager_id', 'facebook_pixel_id',
                'robots_txt', 'google_site_verification', 'custom_head_code', 'custom_body_code',
            ];
            foreach ($fields as $k) {
                $v = $request->input($k, '');
                $existing = Setting::query()->where('key', $k)->first();
                if ($existing) {
                    Setting::query()->where('key', $k)->update(['value' => $v]);
                } else {
                    Setting::query()->create(['key' => $k, 'value' => $v, 'group_name' => 'seo']);
                }
            }
            session(['flash' => 'SEO settings saved.']);
            return redirect('/Icxpanel/seo');
        }

        $flash = session()->pull('flash') ?? '';
        $s = [];
        foreach (Setting::query()->where('group_name', 'seo')->get() as $r) {
            $s[$r->key] = $r->value;
        }

        return view('admin.seo', [
            'pageTitle' => 'SEO Settings',
            'adminPage' => 'seo',
            'flash' => $flash,
            's' => $s,
        ]);
    }
}
