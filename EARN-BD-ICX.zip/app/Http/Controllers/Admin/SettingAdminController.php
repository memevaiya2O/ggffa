<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Http\Request;

/** Original admin/settings — general settings + logo/favicon upload. */
class SettingAdminController extends Controller
{
    public function index(Request $request)
    {
        if ($request->isMethod('POST')) {
            $fields = ['site_name', 'site_tagline', 'admin_email', 'contact_email', 'currency_symbol', 'currency_name', 'daily_bonus_amount', 'welcome_bonus', 'min_withdraw', 'registration_open', 'maintenance_mode', 'maintenance_message', 'footer_description', 'footer_copyright'];
            foreach ($fields as $f) {
                $val = trim($request->input($f, ''));
                Setting::query()->updateOrInsert(['key' => $f], ['value' => $val, 'updated_at' => date('Y-m-d H:i:s')]);
            }
            // Logo / site icon (favicon): upload a new file or remove the current one.
            foreach (['logo' => 'site_logo', 'favicon' => 'favicon'] as $field => $key) {
                if (!empty($_FILES[$field]['name'])) {
                    $up = handleUpload($field, 'uploads/logos', true);
                    if ($up['success']) {
                        Setting::query()->updateOrInsert(['key' => $key], ['value' => $up['path'], 'updated_at' => date('Y-m-d H:i:s')]);
                    } else {
                        $uploadErr = ($uploadErr ?? '') . ucfirst($field) . ': ' . $up['message'] . ' ';
                    }
                } elseif ($request->input('remove_' . $field)) {
                    Setting::query()->updateOrInsert(['key' => $key], ['value' => '', 'updated_at' => date('Y-m-d H:i:s')]);
                }
            }
            session(['flash' => isset($uploadErr) ? 'Settings saved, but: ' . trim($uploadErr) : 'Settings saved!']);
            return redirect('/Icxpanel/settings');
        }

        $flash = session()->pull('flash') ?? '';

        return view('admin.settings', [
            'pageTitle' => 'General Settings',
            'adminPage' => 'settings',
            'flash' => $flash,
        ]);
    }
}
