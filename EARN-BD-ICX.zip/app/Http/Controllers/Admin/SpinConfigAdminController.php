<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use App\Models\SpinSegment;
use Illuminate\Http\Request;

/** Original admin/spin-config — wheel segments CRUD + spin settings. */
class SpinConfigAdminController extends Controller
{
    public function index(Request $request)
    {
        if ($request->isMethod('POST')) {
            $action = $request->input('action', '');

            if ($action === 'save_segment') {
                $id = (int) $request->input('id', 0);
                $label = trim($request->input('label', ''));
                $type = $request->input('prize_type', 'coins');
                $value = (float) $request->input('prize_value', 0);
                $weight = max(1, (int) $request->input('weight', 1));
                $color = trim($request->input('color', '#4CAF50'));
                if ($label) {
                    if ($id) {
                        SpinSegment::query()->where('id', $id)->update([
                            'label' => $label, 'prize_type' => $type, 'prize_value' => $value,
                            'weight' => $weight, 'color' => $color,
                        ]);
                    } else {
                        SpinSegment::query()->create([
                            'label' => $label, 'prize_type' => $type, 'prize_value' => $value,
                            'weight' => $weight, 'color' => $color,
                        ]);
                    }
                    session(['flash' => 'Segment saved.']);
                }
            } elseif ($action === 'delete_segment') {
                SpinSegment::query()->where('id', (int) $request->input('id', 0))->delete();
                session(['flash' => 'Segment deleted.']);
            } elseif ($action === 'save_settings') {
                foreach (['spin_enabled', 'spin_daily_limit', 'spin_cooldown_hours'] as $k) {
                    Setting::query()->where('key', $k)->update(['value' => trim($request->input($k, ''))]);
                }
                session(['flash' => 'Settings saved.']);
            }
            return redirect('/Icxpanel/spin-config');
        }

        $flash = session()->pull('flash') ?? '';
        $segments = SpinSegment::query()->orderBy('id')->get();
        $settings = [];
        foreach (Setting::query()->whereIn('key', ['spin_enabled', 'spin_daily_limit', 'spin_cooldown_hours'])->get() as $r) {
            $settings[$r->key] = $r->value;
        }

        return view('admin.spin-config', [
            'pageTitle' => 'Spin Wheel Config',
            'adminPage' => 'spin-config',
            'flash' => $flash,
            'segments' => $segments,
            'settings' => $settings,
        ]);
    }
}
