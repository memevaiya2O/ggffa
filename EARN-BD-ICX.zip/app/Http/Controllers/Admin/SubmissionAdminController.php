<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\RejectTemplate;
use App\Models\Submission;
use App\Models\Task;
use Illuminate\Http\Request;

/** Original admin/submissions — review queue, approve/reject, bulk actions. */
class SubmissionAdminController extends Controller
{
    public function index(Request $request)
    {
        if ($request->isMethod('POST')) {
            $action = $request->input('action', '');
            $sid = (int) $request->input('sub_id', 0);
            $msg = '';

            if ($action === 'approve' && $sid) {
                $sub = Submission::query()->where('id', $sid)->where('status', 'pending')->first();
                if ($sub) {
                    $task = Task::query()->find($sub->task_id);
                    Submission::query()->where('id', $sid)->update(['status' => 'approved', 'reviewed_at' => date('Y-m-d H:i:s')]);
                    creditUser((int) $sub->user_id, (float) $task->reward, 'task_reward', 'Task approved: ' . $task->title, $task->id);
                    addPoints((int) $sub->user_id, 50);
                    createNotification((int) $sub->user_id, 'task_approved', 'Task Approved! ✅', 'Your submission for "' . $task->title . '" was approved. Reward: ' . formatAmount((float) $task->reward));
                    $msg = 'Submission approved.';
                }
            } elseif ($action === 'reject' && $sid) {
                $reason = trim($request->input('reason', '')) ?: 'Submission rejected.';
                Submission::query()->where('id', $sid)->update([
                    'status' => 'rejected', 'reject_reason' => $reason, 'reviewed_at' => date('Y-m-d H:i:s'),
                ]);
                $sub = Submission::query()->find($sid);
                if ($sub) {
                    $task = Task::query()->find($sub->task_id);
                    createNotification((int) $sub->user_id, 'task_rejected', 'Task Rejected ❌', 'Your submission for "' . ($task->title ?? 'task') . '" was rejected. Reason: ' . $reason);
                }
                $msg = 'Submission rejected.';
            } elseif ($action === 'bulk_approve') {
                $ids = array_map('intval', $request->input('ids', []));
                foreach ($ids as $id) {
                    $sub = Submission::query()
                        ->select('submissions.*', 'tasks.reward', 'tasks.title')
                        ->join('tasks', 'tasks.id', '=', 'submissions.task_id')
                        ->where('submissions.id', $id)
                        ->where('submissions.status', 'pending')
                        ->first();
                    if ($sub) {
                        Submission::query()->where('id', $id)->update(['status' => 'approved', 'reviewed_at' => date('Y-m-d H:i:s')]);
                        creditUser((int) $sub->user_id, (float) $sub->reward, 'task_reward', 'Task approved: ' . $sub->title, $sub->task_id);
                        addPoints((int) $sub->user_id, 50);
                        createNotification((int) $sub->user_id, 'task_approved', 'Task Approved!', 'Reward: ' . formatAmount((float) $sub->reward));
                    }
                }
                if ($request->ajax()) {
                    return response()->json(['success' => true, 'message' => count($ids) . ' submissions approved.']);
                }
                $msg = count($ids) . ' submissions approved.';
            } elseif ($action === 'bulk_reject') {
                $ids = array_map('intval', $request->input('ids', []));
                $reason = trim($request->input('reason', '')) ?: 'Rejected';
                foreach ($ids as $id) {
                    Submission::query()->where('id', $id)->update([
                        'status' => 'rejected', 'reject_reason' => $reason, 'reviewed_at' => date('Y-m-d H:i:s'),
                    ]);
                }
                if ($request->ajax()) {
                    return response()->json(['success' => true, 'message' => count($ids) . ' submissions rejected.']);
                }
                $msg = count($ids) . ' submissions rejected.';
            }
            if ($msg) {
                session(['flash' => $msg]);
                return redirect('/Icxpanel/submissions');
            }
        }

        $flash = session()->pull('flash') ?? '';
        $status = in_array($request->query('status', ''), ['pending', 'approved', 'rejected', 'all']) ? $request->query('status') : 'pending';
        $taskId = (int) $request->query('task', 0);
        $page = max(1, (int) $request->query('page', 1));
        $limit = 20;
        $offset = ($page - 1) * $limit;

        $query = Submission::query()
            ->select('submissions.*', 'users.name as user_name', 'users.avatar', 'tasks.title as task_title', 'tasks.reward')
            ->join('users', 'users.id', '=', 'submissions.user_id')
            ->join('tasks', 'tasks.id', '=', 'submissions.task_id');
        if ($status !== 'all') {
            $query->where('submissions.status', $status);
        }
        if ($taskId) {
            $query->where('submissions.task_id', $taskId);
        }

        $total = (int) (clone $query)->count();
        $submissions = (clone $query)->orderByDesc('submissions.created_at')->limit($limit)->offset($offset)->get();
        $templates = RejectTemplate::query()->get();

        return view('admin.submissions', [
            'pageTitle' => 'Submissions',
            'adminPage' => 'submissions',
            'flash' => $flash,
            'status' => $status,
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'submissions' => $submissions,
            'templates' => $templates,
        ]);
    }
}
