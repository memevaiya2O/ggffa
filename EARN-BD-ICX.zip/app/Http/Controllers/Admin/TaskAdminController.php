<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Task;
use App\Models\TaskCategory;
use Illuminate\Http\Request;

/** Original admin/tasks — list, filters, toggles, delete, drag-drop reorder. */
class TaskAdminController extends Controller
{
    public function index(Request $request)
    {
        if ($request->isMethod('POST')) {
            // Drag & drop reorder posts JSON: { order: [{id, order}], csrf_token }
            $jsonOrder = $request->isJson() ? $request->json('order') : null;
            $action = $request->input('action', $jsonOrder !== null ? 'reorder' : '');

            if ($action === 'reorder' && is_array($jsonOrder)) {
                foreach ($jsonOrder as $item) {
                    Task::query()->where('id', (int) $item['id'])->update(['sort_order' => (int) $item['order']]);
                }
                return response()->json(['success' => true, 'message' => 'Order saved']);
            }

            $tid = (int) $request->input('task_id', 0);
            if ($action === 'delete' && $tid) {
                Task::query()->where('id', $tid)->delete();
                session(['flash' => 'Task deleted.']);
            } elseif (in_array($action, ['toggle_featured', 'toggle_hot', 'toggle_new', 'toggle_status']) && $tid) {
                $col = str_replace('toggle_', '', $action);
                if ($col === 'status') {
                    $cur = Task::query()->where('id', $tid)->value('status');
                    Task::query()->where('id', $tid)->update(['status' => $cur === 'active' ? 'inactive' : 'active']);
                } else {
                    $cur = (int) Task::query()->where('id', $tid)->value('is_' . $col);
                    Task::query()->where('id', $tid)->update(['is_' . $col => $cur ? 0 : 1]);
                }
                session(['flash' => 'Task updated.']);
            }
            return redirect('/Icxpanel/tasks');
        }

        $flash = session()->pull('flash') ?? '';
        $cat = (int) $request->query('cat', 0);
        $status = $request->query('status', 'active');
        $page = max(1, (int) $request->query('page', 1));
        $limit = 20;
        $offset = ($page - 1) * $limit;

        $query = Task::query()
            ->select('tasks.*', 'task_categories.name as cat_name')
            ->selectRaw('(SELECT COUNT(*) FROM submissions WHERE task_id = tasks.id AND status = \'approved\') as approved_count')
            ->selectRaw('(SELECT COUNT(*) FROM submissions WHERE task_id = tasks.id AND status = \'pending\') as pending_count')
            ->leftJoin('task_categories', 'task_categories.id', '=', 'tasks.category_id');
        if ($cat) {
            $query->where('tasks.category_id', $cat);
        }
        if ($status !== 'all') {
            $query->where('tasks.status', $status);
        }

        $total = (int) (clone $query)->count();
        $tasks = (clone $query)->orderBy('tasks.sort_order')->orderByDesc('tasks.created_at')
            ->limit($limit)->offset($offset)->get();
        $cats = TaskCategory::query()->orderBy('sort_order')->get();

        return view('admin.tasks', [
            'pageTitle' => 'Task Management',
            'adminPage' => 'tasks',
            'flash' => $flash,
            'cat' => $cat,
            'status' => $status,
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'tasks' => $tasks,
            'cats' => $cats,
        ]);
    }
}
