<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Task;
use App\Models\TaskCategory;
use Illuminate\Http\Request;

/** Original admin/task-add and admin/task-edit. */
class TaskFormAdminController extends Controller
{
    public function create(Request $request)
    {
        $error = '';
        if ($request->isMethod('POST')) {
            $data = $this->readForm($request);
            if (!$data['title']) {
                $error = 'Task title is required.';
            } elseif ($data['reward'] <= 0) {
                $error = 'Reward must be greater than 0.';
            } else {
                if (!empty($_FILES['thumbnail']['name'])) {
                    $up = handleUpload('thumbnail', 'uploads/tasks');
                    if ($up['success']) {
                        $data['thumbnail'] = $up['path'];
                    }
                }
                Task::query()->create($data);
                session(['flash' => 'Task added!']);
                return redirect('/Icxpanel/tasks');
            }
        }

        $cats = TaskCategory::query()->where('status', 'active')->orderBy('sort_order')->get();

        return view('admin.task-add', [
            'pageTitle' => 'Add Task',
            'adminPage' => 'task-add',
            'error' => $error,
            'cats' => $cats,
        ]);
    }

    public function edit(Request $request)
    {
        $taskId = (int) $request->query('id', 0);
        if (!$taskId) {
            return redirect('/Icxpanel/tasks');
        }
        $task = Task::query()->find($taskId);
        if (!$task) {
            return redirect('/Icxpanel/tasks');
        }

        $error = '';
        if ($request->isMethod('POST')) {
            $data = $this->readForm($request);
            if (!$data['title']) {
                $error = 'Task title is required.';
            } elseif ($data['reward'] <= 0) {
                $error = 'Reward must be greater than 0.';
            } else {
                if (!empty($_FILES['thumbnail']['name'])) {
                    $up = handleUpload('thumbnail', 'uploads/tasks');
                    if ($up['success']) {
                        $data['thumbnail'] = $up['path'];
                    }
                }
                if (!array_key_exists('thumbnail', $data) || $data['thumbnail'] === null) {
                    unset($data['thumbnail']); // keep existing thumbnail when no new upload (matches original)
                }
                Task::query()->where('id', $taskId)->update($data);
                session(['flash' => 'Task updated!']);
                return redirect('/Icxpanel/tasks');
            }
        }

        $cats = TaskCategory::query()->where('status', 'active')->orderBy('sort_order')->get();

        return view('admin.task-edit', [
            'pageTitle' => 'Edit Task',
            'adminPage' => 'tasks',
            'error' => $error,
            'task' => $task,
            'cats' => $cats,
        ]);
    }

    protected function readForm(Request $request): array
    {
        return [
            'category_id' => (int) $request->input('category_id', 0) ?: null,
            'title' => trim($request->input('title', '')),
            'type' => trim($request->input('type', 'standard')),
            'reward' => (float) $request->input('reward', 0),
            'thumbnail' => null,
            'instructions' => trim($request->input('instructions', '')),
            'rules' => trim($request->input('rules', '')),
            'screenshot_required' => $request->has('screenshot_required') ? 1 : 0,
            'max_per_user' => max(1, (int) $request->input('max_per_user', 1)),
            'max_total' => max(1, (int) $request->input('max_total', 1000)),
            'is_vip' => $request->has('is_vip') ? 1 : 0,
            'is_featured' => $request->has('is_featured') ? 1 : 0,
            'is_hot' => $request->has('is_hot') ? 1 : 0,
            'is_new' => $request->has('is_new') ? 1 : 0,
            'status' => $request->input('status', 'active'),
        ];
    }
}
