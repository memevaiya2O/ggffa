<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Http\Request;

/** Original admin/theme — colors, font, radius, button style. */
class ThemeAdminController extends Controller
{
    public function index(Request $request)
    {
        if ($request->isMethod('POST')) {
            $colors = ['color_primary', 'color_secondary', 'color_bg', 'color_card', 'color_text', 'color_accent', 'color_danger', 'color_warning'];
            $fontsOk = ['Nunito', 'Poppins', 'Roboto', 'Inter', 'Lato', 'Open Sans', 'Montserrat', 'Raleway', 'Source Sans Pro', 'Ubuntu'];
            $save = function (string $k, string $v) {
                Setting::query()->updateOrInsert(['key' => $k], ['value' => $v, 'group_name' => 'theme', 'updated_at' => date('Y-m-d H:i:s')]);
            };
            foreach ($colors as $k) {
                $v = trim((string) $request->input($k, ''));
                if (preg_match('/^#[0-9A-Fa-f]{6}$/', $v)) {
                    $save($k, strtoupper($v));
                }
            }
            $font = (string) $request->input('font_family', 'Nunito');
            $save('font_family', in_array($font, $fontsOk, true) ? $font : 'Nunito');
            $save('border_radius', (string) max(0, min(32, (int) $request->input('border_radius', 12))));
            $btn = (string) $request->input('button_style', 'filled');
            $save('button_style', in_array($btn, ['filled', 'outlined', 'gradient'], true) ? $btn : 'filled');
            session(['flash' => 'Theme saved!']);
            return redirect('/Icxpanel/theme');
        }

        $flash = session()->pull('flash') ?? '';
        $fonts = ['Nunito', 'Poppins', 'Roboto', 'Inter', 'Lato', 'Open Sans', 'Montserrat', 'Raleway', 'Source Sans Pro', 'Ubuntu'];

        return view('admin.theme', [
            'pageTitle' => 'Theme Customizer',
            'adminPage' => 'theme',
            'flash' => $flash,
            'fonts' => $fonts,
        ]);
    }
}
