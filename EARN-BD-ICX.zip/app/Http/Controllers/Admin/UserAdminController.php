<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Level;
use App\Models\User;
use Illuminate\Http\Request;

/** Original admin/users — list, search, filters, ban/unban/delete/credit/level/notify. */
class UserAdminController extends Controller
{
    public function index(Request $request)
    {
        if ($request->isMethod('POST')) {
            $action = $request->input('action', '');
            $uid = (int) $request->input('user_id', 0);
            $msg = '';
            if ($action === 'ban') {
                User::query()->where('id', $uid)->update(['status' => 'banned']);
                $msg = 'User banned.';
            } elseif ($action === 'unban') {
                User::query()->where('id', $uid)->update(['status' => 'active']);
                $msg = 'User unbanned.';
            } elseif ($action === 'delete') {
                User::query()->where('id', $uid)->delete();
                $msg = 'User deleted.';
            } elseif ($action === 'credit') {
                $amount = (float) $request->input('amount', 0);
                if ($amount != 0) {
                    creditUser($uid, $amount, 'admin_credit', 'Admin credit');
                    $msg = 'Balance updated.';
                }
            } elseif ($action === 'change_level') {
                $lvl = (int) $request->input('level_id', 1);
                User::query()->where('id', $uid)->update(['level_id' => $lvl]);
                $msg = 'Level changed.';
            } elseif ($action === 'notify') {
                $title = trim($request->input('notif_title', ''));
                $notifMsg = trim($request->input('notif_msg', ''));
                if ($title && $notifMsg) {
                    createNotification($uid, 'broadcast', $title, $notifMsg);
                    $msg = 'Notification sent.';
                }
            }
            if ($msg) {
                session(['flash' => $msg]);
                return redirect('/Icxpanel/users');
            }
        }

        $flash = session()->pull('flash') ?? '';

        // Filters
        $search = trim($request->query('search', ''));
        $level = (int) $request->query('level', 0);
        $status = $request->query('status', '');
        $page = max(1, (int) $request->query('page', 1));
        $limit = 20;
        $offset = ($page - 1) * $limit;

        $query = User::query()
            ->select('users.*', 'levels.name as level_name', 'levels.color as level_color')
            ->leftJoin('levels', 'levels.id', '=', 'users.level_id');

        if ($search) {
            $query->where(function ($q) use ($search) {
                $q->where('users.name', 'like', "%$search%")
                    ->orWhere('users.email', 'like', "%$search%");
            });
        }
        if ($level) {
            $query->where('users.level_id', $level);
        }
        if ($status) {
            $query->where('users.status', $status);
        }

        $total = (int) (clone $query)->count();
        $users = (clone $query)->orderByDesc('users.created_at')->limit($limit)->offset($offset)->get();

        $levels = Level::query()->orderBy('sort_order')->get();

        return view('admin.users', [
            'pageTitle' => 'User Management',
            'adminPage' => 'users',
            'flash' => $flash,
            'search' => $search,
            'level' => $level,
            'status' => $status,
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'users' => $users,
            'levels' => $levels,
        ]);
    }
}
