<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Level;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

/** Original admin/user-detail — full user management + history tabs. */
class UserDetailAdminController extends Controller
{
    public function index(Request $request)
    {
        $uid = (int) $request->query('id', 0);
        if (!$uid) {
            return redirect('/Icxpanel/users');
        }

        if ($request->isMethod('POST')) {
            $action = $request->input('action', '');

            if ($action === 'update_profile') {
                $name = trim($request->input('name', ''));
                $email = trim($request->input('email', ''));
                $phone = trim($request->input('phone', ''));
                $status = $request->input('status', 'active');
                $lvl = (int) $request->input('level_id', 1);
                if ($name && $email) {
                    User::query()->where('id', $uid)->update([
                        'name' => $name, 'email' => $email, 'phone' => $phone,
                        'status' => $status, 'level_id' => $lvl,
                    ]);
                    session(['flash' => 'Profile updated.']);
                }
            } elseif ($action === 'change_password') {
                $pw = trim($request->input('new_password', ''));
                if (strlen($pw) >= 6) {
                    User::query()->where('id', $uid)->update(['password' => Hash::make($pw)]);
                    session(['flash' => 'Password changed.']);
                }
            } elseif ($action === 'credit') {
                $amount = (float) $request->input('amount', 0);
                $note = trim($request->input('note', '')) ?: 'Admin credit';
                if ($amount != 0) {
                    creditUser($uid, $amount, 'admin_credit', $note);
                    session(['flash' => 'Balance ' . ($amount > 0 ? 'credited' : 'debited') . '.']);
                }
            } elseif ($action === 'toggle_wallet') {
                $activate = $request->input('activate') === '1';
                User::query()->where('id', $uid)->update([
                    'wallet_active' => $activate ? 1 : 0,
                    'wallet_activated_at' => $activate ? date('Y-m-d H:i:s') : null,
                ]);
                session(['flash' => $activate ? 'Wallet activated.' : 'Wallet deactivated.']);
            } elseif ($action === 'notify') {
                $title = trim($request->input('notif_title', ''));
                $msg = trim($request->input('notif_msg', ''));
                if ($title && $msg) {
                    createNotification($uid, 'broadcast', $title, $msg);
                    session(['flash' => 'Notification sent.']);
                }
            } elseif ($action === 'delete') {
                User::query()->where('id', $uid)->delete();
                session(['flash' => 'User deleted.']);
                return redirect('/Icxpanel/users');
            }
            return redirect('/Icxpanel/user-detail?id=' . $uid);
        }

        $flash = session()->pull('flash') ?? '';
        $user = User::query()
            ->select('users.*', 'levels.name as level_name', 'levels.color as level_color')
            ->leftJoin('levels', 'levels.id', '=', 'users.level_id')
            ->where('users.id', $uid)
            ->first();
        if (!$user) {
            return redirect('/Icxpanel/users');
        }

        $levels = Level::query()->orderBy('sort_order')->get();
        $txs = \App\Models\Transaction::query()->where('user_id', $uid)->orderByDesc('created_at')->limit(30)->get();
        $subs = \App\Models\Submission::query()
            ->select('submissions.*', 'tasks.title as task_title')
            ->join('tasks', 'tasks.id', '=', 'submissions.task_id')
            ->where('submissions.user_id', $uid)
            ->orderByDesc('submissions.created_at')->limit(20)->get();
        $withs = \App\Models\Withdrawal::query()->where('user_id', $uid)->orderByDesc('created_at')->limit(20)->get();
        $notifs = \App\Models\Notification::query()->where('user_id', $uid)->orderByDesc('created_at')->limit(20)->get();
        $referrals = User::query()->select('name', 'email', 'created_at')->where('referred_by', $uid)->orderByDesc('created_at')->get();
        $totalEarned = (float) \App\Models\Transaction::query()->where('user_id', $uid)->where('amount', '>', 0)->sum('amount');
        $totalWithdrawn = (float) \App\Models\Withdrawal::query()->where('user_id', $uid)->where('status', 'approved')->sum('amount');
        $tasksDone = (int) \App\Models\Submission::query()->where('user_id', $uid)->where('status', 'approved')->count();

        return view('admin.user-detail', [
            'pageTitle' => 'User Detail',
            'adminPage' => 'users',
            'flash' => $flash,
            'user' => $user,
            'levels' => $levels,
            'txs' => $txs,
            'subs' => $subs,
            'withs' => $withs,
            'notifs' => $notifs,
            'referrals' => $referrals,
            'totalEarned' => $totalEarned,
            'totalWithdrawn' => $totalWithdrawn,
            'tasksDone' => $tasksDone,
        ]);
    }
}
