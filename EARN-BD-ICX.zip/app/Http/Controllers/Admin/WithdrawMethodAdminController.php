<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\WithdrawalMethod;
use Illuminate\Http\Request;

/** Original admin/withdraw-methods — CRUD for the withdrawal_methods table. */
class WithdrawMethodAdminController extends Controller
{
    public function index(Request $request)
    {
        if ($request->isMethod('POST')) {
            $action = $request->input('action', '');

            if ($action === 'save') {
                $id = (int) $request->input('id', 0);
                $name = trim($request->input('name', ''));
                $minAmt = (float) $request->input('min_amount', 0);
                $maxAmt = (float) $request->input('max_amount', 0);
                $charge = (float) $request->input('charge_pct', 0);
                $instruc = trim($request->input('instructions', ''));
                $fields = trim($request->input('required_fields', ''));
                $status = $request->input('status', 'active');
                if ($name) {
                    if ($id) {
                        WithdrawalMethod::query()->where('id', $id)->update([
                            'name' => $name, 'min_amount' => $minAmt, 'max_amount' => $maxAmt,
                            'charge_pct' => $charge, 'instructions' => $instruc,
                            'required_fields' => $fields ?: 'Account Number', 'status' => $status,
                        ]);
                    } else {
                        WithdrawalMethod::query()->create([
                            'name' => $name, 'min_amount' => $minAmt, 'max_amount' => $maxAmt,
                            'charge_pct' => $charge, 'instructions' => $instruc,
                            'required_fields' => $fields ?: 'Account Number', 'status' => $status,
                        ]);
                    }
                    session(['flash' => 'Method saved.']);
                }
            } elseif ($action === 'delete') {
                WithdrawalMethod::query()->where('id', (int) $request->input('id', 0))->delete();
                session(['flash' => 'Method deleted.']);
            } elseif ($action === 'toggle') {
                $id = (int) $request->input('id', 0);
                $cur = WithdrawalMethod::query()->where('id', $id)->value('status');
                WithdrawalMethod::query()->where('id', $id)->update(['status' => $cur === 'active' ? 'inactive' : 'active']);
                session(['flash' => 'Status updated.']);
            }
            return redirect('/Icxpanel/withdraw-methods');
        }

        $flash = session()->pull('flash') ?? '';
        $methods = WithdrawalMethod::query()->orderBy('id')->get();

        return view('admin.withdraw-methods', [
            'pageTitle' => 'Withdraw Methods',
            'adminPage' => 'withdraw-methods',
            'flash' => $flash,
            'methods' => $methods,
        ]);
    }
}
