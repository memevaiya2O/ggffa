<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Withdrawal;
use Illuminate\Http\Request;

/** Original admin/withdraw-proof — approve/reject withdrawals with tx reference. */
class WithdrawProofAdminController extends Controller
{
    public function index(Request $request)
    {
        if ($request->isMethod('POST')) {
            $action = $request->input('action', '');
            $wid = (int) $request->input('withdrawal_id', 0);

            if ($action === 'approve' && $wid) {
                $w = Withdrawal::query()->where('id', $wid)->where('status', 'pending')->first();
                if ($w) {
                    $txRef = trim($request->input('tx_ref', ''));
                    $note = trim($request->input('note', ''));
                    Withdrawal::query()->where('id', $wid)->update([
                        'status' => 'approved', 'admin_note' => $note,
                        'tx_reference' => $txRef, 'processed_at' => date('Y-m-d H:i:s'),
                    ]);
                    createNotification((int) $w->user_id, 'withdrawal', 'Withdrawal Approved', 'Your withdrawal of ৳' . number_format($w->amount, 2) . ' has been approved. Transaction ref: ' . ($txRef ?: 'N/A'));
                    session(['flash' => 'Withdrawal approved.']);
                }
            } elseif ($action === 'reject' && $wid) {
                $w = Withdrawal::query()->where('id', $wid)->where('status', 'pending')->first();
                if ($w) {
                    $reason = trim($request->input('reject_reason', '')) ?: 'Rejected by admin';
                    // Refund
                    creditUser((int) $w->user_id, (float) $w->amount, 'refund', 'Withdrawal rejected — refunded');
                    Withdrawal::query()->where('id', $wid)->update([
                        'status' => 'rejected', 'admin_note' => $reason, 'processed_at' => date('Y-m-d H:i:s'),
                    ]);
                    createNotification((int) $w->user_id, 'withdrawal', 'Withdrawal Rejected', 'Your withdrawal of ৳' . number_format($w->amount, 2) . ' was rejected. Reason: ' . $reason . '. Amount has been refunded.');
                    session(['flash' => 'Withdrawal rejected and amount refunded.']);
                }
            }
            return redirect('/Icxpanel/withdraw-proof');
        }

        $flash = session()->pull('flash') ?? '';
        $filter = $request->query('status', 'pending');
        $page = max(1, (int) $request->query('page', 1));
        $limit = 15;
        $offset = ($page - 1) * $limit;

        $query = Withdrawal::query()
            ->select('withdrawals.*', 'users.name as user_name', 'users.email as user_email')
            ->join('users', 'users.id', '=', 'withdrawals.user_id');
        if ($filter !== 'all') {
            $query->where('withdrawals.status', $filter);
        }

        $total = (int) (clone $query)->count();
        $withdrawals = (clone $query)->orderByDesc('withdrawals.created_at')->limit($limit)->offset($offset)->get();

        return view('admin.withdraw-proof', [
            'pageTitle' => 'Withdrawal Proofs',
            'adminPage' => 'withdraw-proof',
            'flash' => $flash,
            'filter' => $filter,
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'withdrawals' => $withdrawals,
        ]);
    }
}
