<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Transaction;
use App\Models\User;
use App\Models\WithdrawMethod;
use App\Models\Withdrawal;
use Illuminate\Http\Request;

/** Original admin/withdrawals — pay / reject (with refund). */
class WithdrawalAdminController extends Controller
{
    public function index(Request $request)
    {
        if ($request->isMethod('POST')) {
            $action = $request->input('action', '');
            $wid = (int) $request->input('wid', 0);
            if ($action === 'pay' && $wid) {
                $note = trim($request->input('note', ''));
                $w = Withdrawal::query()->where('id', $wid)->where('status', 'pending')->first();
                if ($w) {
                    Withdrawal::query()->where('id', $wid)->update([
                        'status' => 'paid', 'admin_note' => $note, 'paid_at' => date('Y-m-d H:i:s'),
                    ]);
                    User::query()->where('id', $w->user_id)->update([
                        'total_withdrawn' => \Illuminate\Support\Facades\DB::raw('total_withdrawn + ' . (float) $w->amount),
                    ]);
                    createNotification((int) $w->user_id, 'withdraw', 'Withdrawal Paid! 💰', 'Your withdrawal of ' . formatAmount((float) $w->amount) . ' has been paid. ' . $note);
                    checkAchievements((int) $w->user_id);
                }
                session(['flash' => 'Withdrawal marked as paid.']);
                return redirect('/Icxpanel/withdrawals');
            } elseif ($action === 'reject' && $wid) {
                $reason = trim($request->input('reason', '')) ?: 'Rejected';
                $w = Withdrawal::query()->where('id', $wid)->where('status', 'pending')->first();
                if ($w) {
                    Withdrawal::query()->where('id', $wid)->update(['status' => 'rejected', 'admin_note' => $reason]);
                    User::query()->where('id', $w->user_id)->update([
                        'balance' => \Illuminate\Support\Facades\DB::raw('balance + ' . (float) $w->amount),
                    ]);
                    addTransaction((int) $w->user_id, 'admin_credit', (float) $w->amount, 'Withdrawal refunded: ' . $reason);
                    createNotification((int) $w->user_id, 'withdraw', 'Withdrawal Rejected', 'Your withdrawal was rejected. Reason: ' . $reason . '. Amount refunded to your balance.');
                }
                session(['flash' => 'Withdrawal rejected and amount refunded.']);
                return redirect('/Icxpanel/withdrawals');
            }
        }

        $flash = session()->pull('flash') ?? '';
        $status = in_array($request->query('status', ''), ['pending', 'paid', 'rejected', 'all']) ? $request->query('status') : 'pending';
        $method = (int) $request->query('method', 0);
        $page = max(1, (int) $request->query('page', 1));
        $limit = 20;
        $offset = ($page - 1) * $limit;

        $query = Withdrawal::query()
            ->select('withdrawals.*', 'users.name as user_name', 'users.email as user_email', 'withdraw_methods.name as method_name', 'withdraw_methods.icon as method_icon')
            ->join('users', 'users.id', '=', 'withdrawals.user_id')
            ->join('withdraw_methods', 'withdraw_methods.id', '=', 'withdrawals.method_id');
        if ($status !== 'all') {
            $query->where('withdrawals.status', $status);
        }
        if ($method) {
            $query->where('withdrawals.method_id', $method);
        }

        $total = (int) (clone $query)->count();
        $withdrawals = (clone $query)->orderByDesc('withdrawals.created_at')->limit($limit)->offset($offset)->get();

        $methods = WithdrawMethod::query()->orderBy('id')->get();
        $pendingSum = (float) Withdrawal::query()->where('status', 'pending')->sum('amount');

        return view('admin.withdrawals', [
            'pageTitle' => 'Withdrawal Management',
            'adminPage' => 'withdrawals',
            'flash' => $flash,
            'status' => $status,
            'method' => $method,
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'withdrawals' => $withdrawals,
            'methods' => $methods,
            'pendingSum' => $pendingSum,
        ]);
    }
}
