<?php

namespace App\Http\Controllers;

use Symfony\Component\HttpFoundation\BinaryFileResponse;

/**
 * Serves /assets/* through Laravel as a safety net.
 *
 * Normally Apache/LiteSpeed serves these files directly. On some cPanel setups
 * (wrong extract folder, permissions, .htaccess overrides, wrong MIME type) the
 * static request fails and the site renders without CSS/JS. This route makes
 * the assets work in every one of those cases.
 */
class AssetController extends Controller
{
    /** @var array<string, string> allowed extension => MIME type */
    private const TYPES = [
        'css'   => 'text/css; charset=UTF-8',
        'js'    => 'application/javascript; charset=UTF-8',
        'json'  => 'application/json',
        'svg'   => 'image/svg+xml',
        'png'   => 'image/png',
        'jpg'   => 'image/jpeg',
        'jpeg'  => 'image/jpeg',
        'gif'   => 'image/gif',
        'webp'  => 'image/webp',
        'ico'   => 'image/x-icon',
        'woff'  => 'font/woff',
        'woff2' => 'font/woff2',
        'ttf'   => 'font/ttf',
        'mp4'   => 'video/mp4',
        'webm'  => 'video/webm',
    ];

    public function show(string $path)
    {
        // Block traversal / hidden files / null bytes
        if (str_contains($path, '..') || str_contains($path, "\0") || str_starts_with(basename($path), '.')) {
            abort(404);
        }

        $base = realpath(public_path('assets'));
        $full = $base ? realpath($base . DIRECTORY_SEPARATOR . $path) : false;

        if (!$full || !is_file($full) || !str_starts_with($full, $base . DIRECTORY_SEPARATOR)) {
            abort(404);
        }

        $ext = strtolower(pathinfo($full, PATHINFO_EXTENSION));
        if (!isset(self::TYPES[$ext])) {
            abort(404); // never serve .php or unknown types
        }

        /** @var BinaryFileResponse $response */
        $response = response()->file($full, [
            'Content-Type'  => self::TYPES[$ext],
            'Cache-Control' => 'public, max-age=86400',
        ]);

        return $response;
    }
}
