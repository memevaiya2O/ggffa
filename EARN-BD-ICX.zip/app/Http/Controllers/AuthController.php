<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

/** Original login.php, register.php, logout.php. */
class AuthController extends Controller
{
    public function showLogin(Request $request)
    {
        if (!empty(session('user_id'))) {
            return redirect('/dashboard');
        }

        return view('login', [
            'error' => '',
            'banned' => $request->query('banned'),
            'registered' => $request->query('registered'),
            'remEmail' => $request->cookie('user_email') ?? '',
        ]);
    }

    public function login(Request $request)
    {
        if (!empty(session('user_id'))) {
            return redirect('/dashboard');
        }

        $error = '';
        $email = trim($request->input('email', ''));
        $password = $request->input('password', '');
        if (!$email || !$password) {
            $error = 'Please fill in all fields.';
        } else {
            $result = loginUser($email, $password);
            if ($result['success']) {
                $response = redirect('/dashboard');
                if (!empty($request->input('remember'))) {
                    $response->withCookie(cookie('user_email', $email, 60 * 24 * 30, '/', null, false, true));
                }
                return $response;
            }
            $error = $result['message'];
        }

        return view('login', [
            'error' => $error,
            'banned' => null,
            'registered' => null,
            'remEmail' => $request->cookie('user_email') ?? '',
        ]);
    }

    public function showRegister(Request $request)
    {
        if (!empty(session('user_id'))) {
            return redirect('/dashboard');
        }
        if (getSetting('registration_open', '1') === '0') {
            return response('<h2 style="text-align:center;margin-top:80px;">Registration is currently closed.</h2>');
        }

        if (session('captcha_a') === null) {
            $captchaA = rand(1, 9);
            $captchaB = rand(1, 9);
            session(['captcha_a' => $captchaA, 'captcha_b' => $captchaB]);
        } else {
            $captchaA = (int) session('captcha_a');
            $captchaB = (int) session('captcha_b');
        }

        return view('register', [
            'error' => '',
            'captchaA' => $captchaA,
            'captchaB' => $captchaB,
            'refCode' => trim($request->query('ref', '')),
            'old' => ['name' => '', 'email' => '', 'phone' => '', 'referral_code' => trim($request->input('referral_code', ''))],
        ]);
    }

    public function register(Request $request)
    {
        if (!empty(session('user_id'))) {
            return redirect('/dashboard');
        }
        if (getSetting('registration_open', '1') === '0') {
            return response('<h2 style="text-align:center;margin-top:80px;">Registration is currently closed.</h2>');
        }

        $captchaA = session('captcha_a') !== null ? (int) session('captcha_a') : rand(1, 9);
        $captchaB = session('captcha_b') !== null ? (int) session('captcha_b') : rand(1, 9);
        if (session('captcha_a') === null) {
            session(['captcha_a' => $captchaA, 'captcha_b' => $captchaB]);
        }

        $error = '';
        $name = trim($request->input('name', ''));
        $email = trim($request->input('email', ''));
        $phoneRaw = trim((string) $request->input('phone', ''));
        $phone = normalizeBdPhone($phoneRaw);
        $pass = $request->input('password', '');
        $confirm = $request->input('password_confirmation', $request->input('confirm_password', ''));
        $ref = trim($request->input('referral_code', ''));
        $captcha = (int) $request->input('captcha', 0);

        if (!$name || !$email || !$pass || !$confirm) {
            $error = 'Please fill in all required fields.';
        } elseif (strlen($name) < 2) {
            $error = 'Name must be at least 2 characters.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Invalid email address.';
        } elseif ($phoneRaw === '') {
            $error = 'Mobile number is required.';
        } elseif ($phone === '') {
            $error = 'Enter a valid mobile number (e.g. 01XXXXXXXXX).';
        } elseif (strlen($pass) < 6) {
            $error = 'Password must be at least 6 characters.';
        } elseif ($pass !== $confirm) {
            $error = 'Passwords do not match.';
        } elseif ($captcha !== ((int) session('captcha_a') + (int) session('captcha_b'))) {
            $error = 'Incorrect CAPTCHA answer.';
            session()->forget(['captcha_a', 'captcha_b']);
        } else {
            $result = registerUser($name, $email, $pass, $ref ?: null, $phone);
            if ($result['success']) {
                session()->forget(['captcha_a', 'captcha_b']);
                session(['user_id' => $result['user_id']]);
                return redirect('/dashboard?welcome=1');
            }
            $error = $result['message'];
        }

        if ($error) {
            session()->forget(['captcha_a', 'captcha_b']);
            $captchaA = rand(1, 9);
            $captchaB = rand(1, 9);
            session(['captcha_a' => $captchaA, 'captcha_b' => $captchaB]);
        }

        return view('register', [
            'error' => $error,
            'captchaA' => $captchaA,
            'captchaB' => $captchaB,
            'refCode' => trim($request->query('ref', '')),
            'old' => ['name' => $name, 'email' => $email, 'phone' => $phoneRaw, 'referral_code' => $ref],
        ]);
    }

    public function logout()
    {
        session()->flush();
        return redirect('/login');
    }
}
