<?php

namespace App\Http\Controllers;

use App\Models\CustomPage;
use Illuminate\Http\Request;

/** Original page.php — serves custom_pages by slug (?slug=... and /page/{slug}). */
class CmsPageController extends Controller
{
    public function show(Request $request)
    {
        $slug = trim($request->query('slug', ''));
        if (!$slug) {
            return redirect('/');
        }
        return $this->render($slug);
    }

    public function showPretty(string $slug)
    {
        return $this->render(trim($slug));
    }

    protected function render(string $slug)
    {
        $page = CustomPage::query()->where('slug', $slug)->where('status', 'active')->first();
        if (!$page) {
            return response('<h2 style="text-align:center;margin-top:80px;">Page not found</h2>', 404);
        }

        return view('page', ['page' => $page]);
    }
}
