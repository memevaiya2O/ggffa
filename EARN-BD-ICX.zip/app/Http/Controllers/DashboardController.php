<?php

namespace App\Http\Controllers;

use App\Models\Achievement;
use App\Models\DailyBonus;
use App\Models\Level;
use App\Models\Transaction;
use App\Models\UserAchievement;
use Illuminate\Http\Request;

/** Original dashboard.php — balance card, daily bonus claim, stats, achievements. */
class DashboardController extends Controller
{
    public function index(Request $request)
    {
        $user = requireLoginUser();
        if ($user instanceof \Illuminate\Http\RedirectResponse) {
            return $user;
        }

        $notifCount = getUnreadNotificationCount((int) $user->id);

        // Daily bonus
        $today = date('Y-m-d');
        $bonusClaimed = (bool) DailyBonus::query()
            ->where('user_id', $user->id)
            ->where('claimed_date', $today)
            ->first();

        // Handle daily bonus claim
        if (!empty($request->input('claim_bonus')) && !$bonusClaimed) {
            $amount = (float) getSetting('daily_bonus_amount', '5');
            DailyBonus::query()->insertOrIgnore([
                'user_id' => $user->id,
                'claimed_date' => $today,
                'amount' => $amount,
            ]);
            creditUser((int) $user->id, $amount, 'daily_bonus', 'Daily bonus claim');
            addPoints((int) $user->id, 10);
            createNotification((int) $user->id, 'bonus_credited', 'Daily Bonus!', 'You claimed your daily bonus of ' . formatAmount($amount));
            $bonusClaimed = true;
            return redirect('/dashboard?bonus=1');
        }

        // Recent transactions
        $transactions = Transaction::query()->where('user_id', $user->id)
            ->orderByDesc('created_at')->limit(5)->get();

        // Stats
        $tasksCompleted = (int) \App\Models\Submission::query()
            ->where('user_id', $user->id)->where('status', 'approved')->count();
        $referralsCount = (int) \App\Models\Referral::query()
            ->where('referrer_id', $user->id)->where('level', 1)->count();

        // Achievements
        $allAch = Achievement::query()
            ->selectRaw('achievements.*, (SELECT id FROM user_achievements WHERE user_id = ? AND achievement_id = achievements.id) as unlocked_id', [$user->id])
            ->limit(8)->get();

        // Next level
        $nextLevel = Level::query()->where('required_points', '>', $user->points)
            ->orderBy('required_points')->first();
        $curPoints = (int) $user->points;
        $curLvlReq = (int) (Level::query()->where('id', $user->level_id)->value('required_points') ?: 0);
        $xpPct = $nextLevel
            ? min(100, round(($curPoints - $curLvlReq) / max(1, ($nextLevel->required_points - $curLvlReq)) * 100))
            : 100;

        // Next claim time
        $nextMidnight = new \DateTime('tomorrow midnight');
        $nextBonus = $nextMidnight->format('c');

        return view('dashboard', [
            'user' => $user,
            'notifCount' => $notifCount,
            'bonusClaimed' => $bonusClaimed,
            'transactions' => $transactions,
            'tasksCompleted' => $tasksCompleted,
            'referralsCount' => $referralsCount,
            'allAch' => $allAch,
            'nextLevel' => $nextLevel,
            'curPoints' => $curPoints,
            'xpPct' => $xpPct,
            'nextBonus' => $nextBonus,
            'welcome' => $request->query('welcome'),
            'bonus' => $request->query('bonus'),
        ]);
    }
}
