<?php

namespace App\Http\Controllers;

use App\Models\Announcement;
use App\Models\Popup;
use App\Models\Task;
use App\Models\User;
use App\Models\WithdrawProof;
use App\Models\Withdrawal;
use Illuminate\Http\Request;

/** Original index.php (public homepage). */
class HomeController extends Controller
{
    public function index(Request $request)
    {
        if (!empty(session('user_id'))) {
            return redirect('/dashboard');
        }

        // Stats
        $totalUsers = (int) User::query()->count();
        $totalTasks = (int) Task::query()->where('status', 'active')->count();
        $totalPayout = (float) Withdrawal::query()->where('status', 'paid')->sum('amount');
        $totalWithdraws = (int) Withdrawal::query()->where('status', 'paid')->count();

        // Featured tasks
        $featTasks = Task::query()
            ->select('tasks.*', 'task_categories.name as cat_name', 'task_categories.icon as cat_icon', 'task_categories.color as cat_color')
            ->leftJoin('task_categories', 'task_categories.id', '=', 'tasks.category_id')
            ->where('tasks.status', 'active')
            ->where('tasks.is_featured', true)
            ->orderBy('tasks.sort_order')
            ->limit(4)->get();
        if ($featTasks->isEmpty()) {
            $featTasks = Task::query()
                ->select('tasks.*', 'task_categories.name as cat_name', 'task_categories.icon as cat_icon', 'task_categories.color as cat_color')
                ->leftJoin('task_categories', 'task_categories.id', '=', 'tasks.category_id')
                ->where('tasks.status', 'active')
                ->orderByDesc('tasks.created_at')
                ->limit(4)->get();
        }

        // Top earners
        $topEarners = User::query()
            ->select('users.name', 'users.avatar', 'users.total_earned', 'levels.name as level_name', 'levels.icon as level_icon', 'levels.color as level_color')
            ->leftJoin('levels', 'levels.id', '=', 'users.level_id')
            ->where('users.status', 'active')
            ->orderByDesc('users.total_earned')
            ->limit(5)->get();

        // Withdraw proof
        $proofs = WithdrawProof::query()->orderByDesc('created_at')->limit(8)->get();

        // Announcements
        $ann = Announcement::query()->where('status', 'active')->first();

        // Popup
        $popup = null;
        if (!session('popup_seen')) {
            $popup = Popup::query()->where('status', 'active')->whereIn('show_on', ['homepage', 'all'])->first();
            if ($popup && $popup->frequency === 'once') {
                session(['popup_seen' => true]);
            }
        }

        return view('index', [
            'totalUsers' => $totalUsers,
            'totalTasks' => $totalTasks,
            'totalPayout' => $totalPayout,
            'totalWithdraws' => $totalWithdraws,
            'featTasks' => $featTasks,
            'topEarners' => $topEarners,
            'proofs' => $proofs,
            'ann' => $ann,
            'popup' => $popup,
            'siteName' => getSetting('site_name', 'EarnBD'),
        ]);
    }
}
