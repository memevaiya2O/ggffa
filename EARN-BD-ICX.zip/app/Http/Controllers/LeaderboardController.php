<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/** Original leaderboard.php — weekly / monthly / all-time top earners. */
class LeaderboardController extends Controller
{
    public function index(Request $request)
    {
        $user = requireLoginUser();
        if ($user instanceof \Illuminate\Http\RedirectResponse) {
            return $user;
        }

        $notifCount = getUnreadNotificationCount((int) $user->id);
        $period = in_array($request->query('period', ''), ['weekly', 'monthly', 'alltime']) ? $request->query('period') : 'alltime';

        $dateFilter = '';
        if ($period === 'weekly') {
            $dateFilter = 'AND t.created_at >= NOW() - INTERVAL 7 DAY';
        } elseif ($period === 'monthly') {
            $dateFilter = 'AND t.created_at >= NOW() - INTERVAL 30 DAY';
        }

        $top = User::query()
            ->selectRaw('users.id, users.name, users.avatar, levels.name as level_name, levels.icon as level_icon, levels.color as level_color,
                COALESCE(SUM(CASE WHEN t.amount > 0 ' . $dateFilter . ' THEN t.amount ELSE 0 END),0) as earned')
            ->leftJoin('levels', 'levels.id', '=', 'users.level_id')
            ->leftJoin('transactions as t', function ($join) {
                $join->on('t.user_id', '=', 'users.id')->where('t.type', '!=', 'withdrawal');
            })
            ->where('users.status', 'active')
            ->groupBy('users.id', 'users.name', 'users.avatar', 'levels.name', 'levels.icon', 'levels.color')
            ->orderByDesc('earned')
            ->limit(10)
            ->get();

        // My rank (works even outside top-10)
        $myRank = null;
        foreach ($top as $i => $t) {
            if ($t->id == $user->id) {
                $myRank = $i + 1;
                break;
            }
        }
        if ($myRank === null) {
            $myEarned = (float) DB::table('transactions')
                ->where('user_id', (int) $user->id)
                ->where('type', '!=', 'withdrawal')
                ->where('amount', '>', 0)
                ->when($period === 'weekly', fn ($q) => $q->where('created_at', '>=', DB::raw('NOW() - INTERVAL 7 DAY')))
                ->when($period === 'monthly', fn ($q) => $q->where('created_at', '>=', DB::raw('NOW() - INTERVAL 30 DAY')))
                ->sum('amount');
            $higher = User::query()
                ->selectRaw('users.id, COALESCE(SUM(CASE WHEN t.amount > 0 ' . $dateFilter . ' THEN t.amount ELSE 0 END),0) as earned')
                ->leftJoin('transactions as t', function ($join) {
                    $join->on('t.user_id', '=', 'users.id')->where('t.type', '!=', 'withdrawal');
                })
                ->where('users.status', 'active')
                ->groupBy('users.id')
                ->get()
                ->filter(fn ($row) => (float) $row->earned > $myEarned)
                ->count();
            $myRank = $higher + 1;
        }

        return view('leaderboard', [
            'user' => $user,
            'notifCount' => $notifCount,
            'period' => $period,
            'top' => $top,
            'myRank' => $myRank,
        ]);
    }
}
