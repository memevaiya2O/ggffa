<?php

namespace App\Http\Controllers;

use App\Models\Notification;
use Illuminate\Http\Request;

/** Original notifications.php — user notification list + mark all read. */
class NotificationController extends Controller
{
    public function index(Request $request)
    {
        $user = requireLoginUser();
        if ($user instanceof \Illuminate\Http\RedirectResponse) {
            return $user;
        }

        $page = max(1, (int) $request->query('page', 1));
        $limit = 20;
        $offset = ($page - 1) * $limit;

        $total = (int) Notification::query()->where('user_id', $user->id)->count();
        $notifications = Notification::query()->where('user_id', $user->id)
            ->orderByDesc('created_at')->limit($limit)->offset($offset)->get();

        $notifCount = getUnreadNotificationCount((int) $user->id);

        $typeIcons = [
            'task_approved' => ['fa-check-circle', '#00C896'],
            'task_rejected' => ['fa-times-circle', '#FF4757'],
            'withdraw' => ['fa-money-bill-transfer', '#FFA502'],
            'level_up' => ['fa-arrow-trend-up', '#9C27B0'],
            'badge_unlocked' => ['fa-trophy', '#FFD700'],
            'bonus_credited' => ['fa-gift', '#00C896'],
            'welcome' => ['fa-star', '#00C896'],
            'submission' => ['fa-paper-plane', '#00B4D8'],
            'broadcast' => ['fa-bullhorn', '#FF4757'],
        ];

        return view('notifications', [
            'user' => $user,
            'notifications' => $notifications,
            'notifCount' => $notifCount,
            'total' => $total,
            'page' => $page,
            'limit' => $limit,
            'typeIcons' => $typeIcons,
        ]);
    }

    public function markRead(Request $request)
    {
        $user = requireLoginUser();
        if ($user instanceof \Illuminate\Http\RedirectResponse) {
            return $user;
        }

        if (!empty($request->input('mark_read'))) {
            Notification::query()->where('user_id', $user->id)->update(['is_read' => true]);
            return redirect('/notifications');
        }

        return redirect('/notifications');
    }
}
