<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

/** Original profile.php — edit profile, avatar upload, change password. */
class ProfileController extends Controller
{
    public function index(Request $request)
    {
        $user = requireLoginUser();
        if ($user instanceof \Illuminate\Http\RedirectResponse) {
            return $user;
        }

        return $this->render($user, '', '');
    }

    public function update(Request $request)
    {
        $user = requireLoginUser();
        if ($user instanceof \Illuminate\Http\RedirectResponse) {
            return $user;
        }

        $error = $success = '';
        $action = $request->input('action', '');

        if ($action === 'update_profile') {
            $name = trim($request->input('name', ''));
            if (strlen($name) < 2) {
                $error = 'Name too short.';
            } else {
                $avatar = $user->avatar;
                if (!empty($_FILES['avatar']['name'])) {
                    $up = handleUpload('avatar', 'uploads/avatars');
                    if ($up['success']) {
                        $avatar = $up['path'];
                    } else {
                        $error = $up['message'];
                    }
                }
                if (!$error) {
                    User::query()->where('id', $user->id)->update(['name' => $name, 'avatar' => $avatar]);
                    $success = 'Profile updated!';
                    $user = getCurrentUser();
                }
            }
        } elseif ($action === 'change_password') {
            $current = $request->input('current_password', '');
            $new = $request->input('new_password', '');
            $confirm = $request->input('confirm_password', '');
            if (!Hash::check($current, $user->password)) {
                $error = 'Current password is incorrect.';
            } elseif (strlen($new) < 6) {
                $error = 'New password must be at least 6 characters.';
            } elseif ($new !== $confirm) {
                $error = 'Passwords do not match.';
            } else {
                User::query()->where('id', $user->id)->update(['password' => Hash::make($new)]);
                $success = 'Password changed successfully!';
            }
        }

        return $this->render($user, $error, $success);
    }

    protected function render($user, string $error, string $success)
    {
        $notifCount = getUnreadNotificationCount((int) $user->id);
        $tasksCompleted = (int) \App\Models\Submission::query()->where('user_id', $user->id)->where('status', 'approved')->count();
        $withdrawCount = (int) \App\Models\Withdrawal::query()->where('user_id', $user->id)->where('status', 'paid')->count();
        $refCount = (int) \App\Models\Referral::query()->where('referrer_id', $user->id)->where('level', 1)->count();

        return view('profile', [
            'user' => $user,
            'notifCount' => $notifCount,
            'tasksCompleted' => $tasksCompleted,
            'withdrawCount' => $withdrawCount,
            'refCount' => $refCount,
            'error' => $error,
            'success' => $success,
        ]);
    }
}
