<?php

namespace App\Http\Controllers;

use App\Models\Referral;
use Illuminate\Http\Request;

/** Original referral.php — 2-level referral program page. */
class ReferralController extends Controller
{
    public function index(Request $request)
    {
        $user = requireLoginUser();
        if ($user instanceof \Illuminate\Http\RedirectResponse) {
            return $user;
        }

        $notifCount = getUnreadNotificationCount((int) $user->id);
        $refLink = $request->getSchemeAndHttpHost() . '/register?ref=' . $user->referral_code;

        $referrals = Referral::query()
            ->selectRaw('users.name, users.avatar, users.created_at,
                (SELECT COUNT(*) FROM submissions WHERE user_id = users.id AND status = \'approved\') as tasks_done,
                referrals.bonus, referrals.level')
            ->join('users', 'users.id', '=', 'referrals.referred_id')
            ->where('referrals.referrer_id', $user->id)
            ->orderByDesc('referrals.created_at')
            ->get();

        $totalBonus = (float) Referral::query()->where('referrer_id', $user->id)->sum('bonus');
        $l1Count = array_sum(array_map(fn ($r) => $r->level == 1 ? 1 : 0, $referrals->all()));
        $l2Count = count($referrals) - $l1Count;

        return view('referral', [
            'user' => $user,
            'notifCount' => $notifCount,
            'refLink' => $refLink,
            'referrals' => $referrals,
            'totalBonus' => $totalBonus,
            'l1Count' => $l1Count,
            'l2Count' => $l2Count,
        ]);
    }
}
