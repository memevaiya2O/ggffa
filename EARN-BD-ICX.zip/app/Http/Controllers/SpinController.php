<?php

namespace App\Http\Controllers;

use App\Models\SpinHistory;
use App\Models\SpinPrize;
use Illuminate\Http\Request;

/** Original spin.php — daily spin wheel (AJAX spin + history). */
class SpinController extends Controller
{
    public function index(Request $request)
    {
        $user = requireLoginUser();
        if ($user instanceof \Illuminate\Http\RedirectResponse) {
            return $user;
        }

        $notifCount = getUnreadNotificationCount((int) $user->id);
        $today = date('Y-m-d');
        $spunToday = (bool) SpinHistory::query()
            ->where('user_id', $user->id)->where('spin_date', $today)->first();

        $prizes = SpinPrize::query()->where('status', 'active')->orderBy('id')->get();

        // AJAX spin
        if ($request->ajax() && $request->isMethod('POST')) {
            return $this->doSpin($user, $spunToday, $prizes, $today);
        }

        // History
        $history = SpinHistory::query()->where('user_id', $user->id)
            ->orderByDesc('spin_date')->limit(10)->get();

        return view('spin', [
            'user' => $user,
            'notifCount' => $notifCount,
            'spunToday' => $spunToday,
            'prizes' => $prizes,
            'history' => $history,
        ]);
    }

    public function spin(Request $request)
    {
        $user = requireLoginUser();
        if ($user instanceof \Illuminate\Http\RedirectResponse) {
            return $user;
        }

        $today = date('Y-m-d');
        $spunToday = (bool) SpinHistory::query()
            ->where('user_id', $user->id)->where('spin_date', $today)->first();
        $prizes = SpinPrize::query()->where('status', 'active')->orderBy('id')->get();

        return $this->doSpin($user, $spunToday, $prizes, $today);
    }

    protected function doSpin($user, bool $spunToday, $prizes, string $today)
    {
        if ($spunToday) {
            return response()->json(['success' => false, 'message' => 'Already spun today.']);
        }

        // Select prize by probability
        $rand = mt_rand(1, 10000) / 100;
        $cumulative = 0;
        $winner = null;
        foreach ($prizes as $p) {
            $cumulative += (float) $p->probability;
            if ($rand <= $cumulative) {
                $winner = $p;
                break;
            }
        }
        if (!$winner) {
            $winner = $prizes->first();
        }

        SpinHistory::query()->create([
            'user_id' => $user->id,
            'prize_label' => $winner->label,
            'amount' => $winner->amount,
            'spin_date' => $today,
        ]);

        if ((float) $winner->amount > 0) {
            creditUser((int) $user->id, (float) $winner->amount, 'spin_reward', 'Spin reward: ' . $winner->label);
            createNotification((int) $user->id, 'bonus_credited', 'Spin Win!', 'You won ' . formatAmount((float) $winner->amount) . ' from the spin wheel!');
        }

        return response()->json([
            'success' => true,
            'prize_label' => $winner->label,
            'amount' => $winner->amount,
            'amount_formatted' => formatAmount((float) $winner->amount),
        ]);
    }
}
