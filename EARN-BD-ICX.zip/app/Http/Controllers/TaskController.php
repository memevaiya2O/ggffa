<?php

namespace App\Http\Controllers;

use App\Models\Submission;
use App\Models\Task;
use App\Models\TaskCategory;
use Illuminate\Http\Request;

/** Original tasks.php (listing/filter/search) and task-detail.php (submission form). */
class TaskController extends Controller
{
    public function index(Request $request)
    {
        $user = requireLoginUser();
        if ($user instanceof \Illuminate\Http\RedirectResponse) {
            return $user;
        }

        $notifCount = getUnreadNotificationCount((int) $user->id);
        $catId = (int) $request->query('cat', 0);
        $search = trim($request->query('search', ''));
        $page = max(1, (int) $request->query('page', 1));
        $limit = 10;
        $offset = ($page - 1) * $limit;

        $categories = TaskCategory::query()->where('status', 'active')->orderBy('sort_order')->get();

        $query = Task::query()
            ->select('tasks.*', 'task_categories.name as cat_name', 'task_categories.icon as cat_icon', 'task_categories.color as cat_color')
            ->selectRaw('(SELECT COUNT(*) FROM submissions WHERE task_id = tasks.id AND status IN (\'approved\',\'pending\')) as completion_count')
            ->selectRaw('(SELECT id FROM submissions WHERE task_id = tasks.id AND user_id = ?) as user_sub_id', [$user->id])
            ->selectRaw('(SELECT status FROM submissions WHERE task_id = tasks.id AND user_id = ?) as user_sub_status', [$user->id])
            ->leftJoin('task_categories', 'task_categories.id', '=', 'tasks.category_id')
            ->where('tasks.status', 'active');

        if ($catId) {
            $query->where('tasks.category_id', $catId);
        }
        if ($search) {
            $query->where('tasks.title', 'like', "%$search%");
        }
        if (!$user->can_access_vip) {
            $query->where('tasks.is_vip', false);
        }

        $total = (int) (clone $query)->count();
        $tasks = $query->orderBy('tasks.sort_order')->orderByDesc('tasks.created_at')
            ->limit($limit)->offset($offset)->get();

        return view('tasks', [
            'user' => $user,
            'notifCount' => $notifCount,
            'catId' => $catId,
            'search' => $search,
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'categories' => $categories,
            'tasks' => $tasks,
        ]);
    }

    public function show(Request $request)
    {
        $user = requireLoginUser();
        if ($user instanceof \Illuminate\Http\RedirectResponse) {
            return $user;
        }

        $taskId = (int) $request->query('id', 0);
        if (!$taskId) {
            return redirect('/tasks');
        }

        $task = Task::query()
            ->select('tasks.*', 'task_categories.name as cat_name', 'task_categories.icon as cat_icon', 'task_categories.color as cat_color')
            ->selectRaw('(SELECT COUNT(*) FROM submissions WHERE task_id = tasks.id AND status = \'approved\') as approved_count')
            ->leftJoin('task_categories', 'task_categories.id', '=', 'tasks.category_id')
            ->where('tasks.id', $taskId)
            ->where('tasks.status', 'active')
            ->first();
        if (!$task) {
            return redirect('/tasks');
        }
        if ($task->is_vip && !$user->can_access_vip) {
            return redirect('/tasks');
        }

        $existingSub = Submission::query()
            ->where('task_id', $taskId)->where('user_id', $user->id)
            ->orderByDesc('created_at')->first();

        return view('task-detail', [
            'user' => $user,
            'task' => $task,
            'taskId' => $taskId,
            'existingSub' => $existingSub,
            'error' => '',
            'submitted' => $request->query('submitted'),
            'notifCount' => getUnreadNotificationCount((int) $user->id),
            'oldNotes' => '',
        ]);
    }

    public function submit(Request $request)
    {
        $user = requireLoginUser();
        if ($user instanceof \Illuminate\Http\RedirectResponse) {
            return $user;
        }

        $taskId = (int) $request->query('id', 0);
        if (!$taskId) {
            return redirect('/tasks');
        }

        $task = Task::query()
            ->select('tasks.*', 'task_categories.name as cat_name', 'task_categories.icon as cat_icon', 'task_categories.color as cat_color')
            ->selectRaw('(SELECT COUNT(*) FROM submissions WHERE task_id = tasks.id AND status = \'approved\') as approved_count')
            ->leftJoin('task_categories', 'task_categories.id', '=', 'tasks.category_id')
            ->where('tasks.id', $taskId)
            ->where('tasks.status', 'active')
            ->first();
        if (!$task) {
            return redirect('/tasks');
        }
        if ($task->is_vip && !$user->can_access_vip) {
            return redirect('/tasks');
        }

        $existingSub = Submission::query()
            ->where('task_id', $taskId)->where('user_id', $user->id)
            ->orderByDesc('created_at')->first();

        $error = '';
        $notes = trim($request->input('notes', ''));

        if (!$existingSub) {
            $screenshot = null;

            if ($task->screenshot_required) {
                if (empty($_FILES['screenshot']['name'])) {
                    $error = 'Screenshot is required for this task.';
                } else {
                    $upload = handleUpload('screenshot');
                    if (!$upload['success']) {
                        $error = $upload['message'];
                    } else {
                        $screenshot = $upload['path'];
                    }
                }
            } else {
                if (!empty($_FILES['screenshot']['name'])) {
                    $upload = handleUpload('screenshot');
                    if ($upload['success']) {
                        $screenshot = $upload['path'];
                    }
                }
            }

            if (!$error) {
                $submission = Submission::query()->create([
                    'user_id' => $user->id,
                    'task_id' => $taskId,
                    'screenshot' => $screenshot,
                    'notes' => $notes,
                    'status' => 'pending',
                ]);
                // Telegram bot → admin (user details + task + proof screenshot)
                notifyTelegramTask($user, $task, $submission);
                createNotification((int) $user->id, 'submission', 'Task Submitted', 'Your submission for "' . $task->title . '" is under review.');
                return redirect('/task-detail?id=' . $taskId . '&submitted=1');
            }
        }

        return view('task-detail', [
            'user' => $user,
            'task' => $task,
            'taskId' => $taskId,
            'existingSub' => $existingSub,
            'error' => $error,
            'submitted' => null,
            'notifCount' => getUnreadNotificationCount((int) $user->id),
            'oldNotes' => $notes,
        ]);
    }
}
