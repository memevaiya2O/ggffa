<?php

namespace App\Http\Controllers;

use App\Models\Transaction;
use App\Models\Withdrawal;
use Illuminate\Http\Request;

/** Original wallet.php — transaction history, filters, income chart. */
class WalletController extends Controller
{
    public function index(Request $request)
    {
        $user = requireLoginUser();
        if ($user instanceof \Illuminate\Http\RedirectResponse) {
            return $user;
        }

        $notifCount = getUnreadNotificationCount((int) $user->id);
        $type = $request->query('type', 'all');
        $page = max(1, (int) $request->query('page', 1));
        $limit = 15;
        $offset = ($page - 1) * $limit;

        $validTypes = ['task_reward', 'referral_bonus', 'daily_bonus', 'spin_reward', 'withdrawal', 'level_up_bonus', 'admin_credit', 'deposit'];
        if ($type !== 'all' && !in_array($type, $validTypes)) {
            $type = 'all';
        }

        $query = Transaction::query()->where('user_id', $user->id);
        if ($type !== 'all') {
            $query->where('type', $type);
        }

        $total = (int) (clone $query)->count();
        $transactions = (clone $query)->orderByDesc('created_at')->limit($limit)->offset($offset)->get();

        // Breakdown by type for chart
        $chartData = Transaction::query()
            ->where('user_id', $user->id)
            ->where('amount', '>', 0)
            ->where('type', '!=', 'deposit')
            ->selectRaw('type, SUM(amount) as total')
            ->groupBy('type')
            ->get();

        // Pending
        $pendingAmt = (float) Withdrawal::query()->where('user_id', $user->id)->where('status', 'pending')->sum('amount');

        return view('wallet', [
            'user' => $user,
            'notifCount' => $notifCount,
            'type' => $type,
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'transactions' => $transactions,
            'chartData' => $chartData,
            'pendingAmt' => $pendingAmt,
        ]);
    }
}
