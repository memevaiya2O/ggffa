<?php

namespace App\Http\Controllers;

use App\Models\Transaction;
use App\Models\WithdrawMethod;
use App\Models\Withdrawal;
use Illuminate\Http\Request;

/** Original withdraw.php — request withdrawals + history. */
class WithdrawController extends Controller
{
    public function index(Request $request)
    {
        $user = requireLoginUser();
        if ($user instanceof \Illuminate\Http\RedirectResponse) {
            return $user;
        }

        return $this->render($user, '', '');
    }

    public function store(Request $request)
    {
        $user = requireLoginUser();
        if ($user instanceof \Illuminate\Http\RedirectResponse) {
            return $user;
        }

        $error = $success = '';
        $methodId = (int) $request->input('method_id', 0);
        $address = trim($request->input('address', ''));
        $amount = (float) $request->input('amount', 0);

        $method = WithdrawMethod::query()->where('id', $methodId)->where('status', 'active')->first();

        $minGlobal = (float) getSetting('min_withdraw', '50');
        $minMethod = $method ? (float) $method->min_amount : $minGlobal;
        $minAmt = max($minGlobal, $minMethod);

        if (!isWalletActive($user)) {
            $error = 'Your wallet is not active. Please add money first to enable withdrawals.';
        } elseif (!$method) {
            $error = 'Invalid payment method.';
        } elseif (!$address) {
            $error = 'Please enter your account/wallet address.';
        } elseif ($amount < $minAmt) {
            $error = 'Minimum withdrawal is ' . formatAmount($minAmt) . '.';
        } elseif ($amount > (float) $user->balance) {
            $error = 'Insufficient balance.';
        } elseif ($amount > (float) $user->daily_withdraw_limit) {
            $error = 'Exceeds your daily limit of ' . formatAmount((float) $user->daily_withdraw_limit) . '.';
        } else {
            $dupCheck = Withdrawal::query()->where('user_id', $user->id)->where('status', 'pending')->first();
            if ($dupCheck) {
                $error = 'You already have a pending withdrawal request.';
            } else {
                Withdrawal::query()->create([
                    'user_id' => $user->id,
                    'method_id' => $methodId,
                    'address' => $address,
                    'amount' => $amount,
                ]);
                \App\Models\User::query()->where('id', $user->id)->update([
                    'balance' => \Illuminate\Support\Facades\DB::raw('balance - ' . (float) $amount),
                ]);
                addTransaction((int) $user->id, 'withdrawal', -$amount, 'Withdrawal via ' . $method->name . ' to ' . $address);
                createNotification((int) $user->id, 'withdraw', 'Withdrawal Requested', 'Your withdrawal of ' . formatAmount($amount) . ' via ' . $method->name . ' is pending.');
                $success = 'Withdrawal request submitted successfully!';
                $user = getCurrentUser();
            }
        }

        return $this->render($user, $error, $success);
    }

    protected function render($user, string $error, string $success)
    {
        $notifCount = getUnreadNotificationCount((int) $user->id);
        $methods = WithdrawMethod::query()->where('status', 'active')->orderBy('id')->get();

        // History
        $history = Withdrawal::query()
            ->select('withdrawals.*', 'withdraw_methods.name as method_name', 'withdraw_methods.icon as method_icon')
            ->leftJoin('withdraw_methods', 'withdraw_methods.id', '=', 'withdrawals.method_id')
            ->where('withdrawals.user_id', $user->id)
            ->orderByDesc('withdrawals.created_at')
            ->limit(20)->get();

        return view('withdraw', [
            'user' => $user,
            'notifCount' => $notifCount,
            'methods' => $methods,
            'history' => $history,
            'walletLocked' => !isWalletActive($user),
            'activationMin' => walletActivationMin(),
            'error' => $error,
            'success' => $success,
        ]);
    }
}
