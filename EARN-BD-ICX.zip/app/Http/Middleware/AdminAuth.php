<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/** Original requireAdmin() as middleware. */
class AdminAuth
{
    public function handle(Request $request, Closure $closure): Response
    {
        $result = requireAdminUser();
        if ($result instanceof Response) {
            return $result;
        }

        return $closure($request);
    }
}
