<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Schema;
use Symfony\Component\HttpFoundation\Response;

/**
 * Replaces includes/settings-loader.php:
 *  - boots the schema on first run (the original created/seeded tables lazily in getDB())
 *  - loads all settings into the $_SETTINGS global used by getSetting()/views
 *  - enforces maintenance mode (admins and login/register stay reachable)
 */
class LoadSettings
{
    protected static bool $booted = false;

    public function handle(Request $request, Closure $closure): Response
    {
        if (!self::$booted) {
            self::$booted = true;
            try {
                if (!Schema::hasTable('settings')) {
                    Artisan::call('migrate', ['--force' => true]);
                    Artisan::call('db:seed', ['--force' => true]);
                } elseif (\App\Models\Setting::query()->count() === 0) {
                    Artisan::call('db:seed', ['--force' => true]);
                }
            } catch (\Throwable $e) {
                report($e);
            }
        }

        // Existing installs: run any pending migrations automatically (once per release).
        try {
            if (!Cache::get('schema_v3') && Schema::hasTable('settings')) {
                Artisan::call('migrate', ['--force' => true]);
                Cache::forever('schema_v3', 1);
            }
        } catch (\Throwable $e) {
            report($e);
        }

        $GLOBALS['_SETTINGS'] = loadSettings();

        // Check maintenance mode (allow admin through) — same rules as the original.
        if ((getSetting('maintenance_mode') ?? '0') === '1' && empty(session('admin_id'))) {
            $currentFile = basename($request->getPathInfo());
            $allowedFiles = ['login', 'register'];
            if (!in_array($currentFile, $allowedFiles) && !($request->getPathInfo() === '/Icxpanel' || str_starts_with($request->getPathInfo(), '/Icxpanel/'))) {
                $msg = h(getSetting('maintenance_message') ?? 'Site under maintenance');
                return response("<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Maintenance</title>
        <style>body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;background:#f4f4f4}
        .box{background:#fff;padding:3rem;border-radius:12px;text-align:center;max-width:400px}
        h1{color:#00C896}p{color:#666}</style></head><body>
        <div class='box'><h1>🔧 Under Maintenance</h1><p>$msg</p></div></body></html>");
            }
        }

        return $closure($request);
    }
}
