<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/** Original requireLogin() as middleware. */
class UserAuth
{
    public function handle(Request $request, Closure $closure): Response
    {
        $result = requireLoginUser();
        if ($result instanceof Response) {
            return $result;
        }

        return $closure($request);
    }
}
