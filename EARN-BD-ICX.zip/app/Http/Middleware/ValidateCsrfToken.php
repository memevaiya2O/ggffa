<?php

namespace App\Http\Middleware;

use Illuminate\Foundation\Http\Middleware\ValidateCsrfToken as Middleware;

/**
 * Same protection as Laravel's CSRF middleware, but the token lookup understands
 * the original project's conventions so existing forms/JS keep working unchanged:
 *  - hidden input name="csrf_token" (csrfField())
 *  - JSON body key "csrf_token" (admin.js initSortable / bulkAction)
 *  - JSON body key "csrf" (main.js spin wheel)
 */
class ValidateCsrfToken extends Middleware
{
    protected function getTokenFromRequest($request)
    {
        $token = $request->input('_token') ?: $request->input('csrf_token');

        if (!$token && $request->isJson()) {
            $token = $request->json('csrf_token') ?: $request->json('csrf');
        }

        return $token ?: parent::getTokenFromRequest($request);
    }
}
