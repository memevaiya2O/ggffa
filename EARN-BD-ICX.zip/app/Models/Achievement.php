<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Achievement extends Model
{
    public $timestamps = false;

    protected $table = 'achievements';

    protected $fillable = ['name', 'description', 'icon', 'condition_type', 'condition_value'];

    public function users()
    {
        return $this->belongsToMany(User::class, 'user_achievements', 'achievement_id', 'user_id')
            ->withPivot('unlocked_at');
    }
}
