<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AdminUser extends Model
{
    public $timestamps = false;

    protected $table = 'admin_users';

    protected $fillable = ['username', 'password'];
}
