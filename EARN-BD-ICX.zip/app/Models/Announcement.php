<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Announcement extends Model
{
    public $timestamps = false;

    protected $table = 'announcements';

    protected $fillable = ['text', 'color', 'link', 'status'];
}
