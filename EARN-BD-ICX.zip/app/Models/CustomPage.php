<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CustomPage extends Model
{
    public $timestamps = false;

    protected $table = 'custom_pages';

    protected $fillable = ['slug', 'title', 'content', 'meta_title', 'meta_desc', 'status', 'updated_at'];
}
