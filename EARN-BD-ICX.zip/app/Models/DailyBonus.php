<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DailyBonus extends Model
{
    public $timestamps = false;

    protected $table = 'daily_bonus';

    protected $fillable = ['user_id', 'claimed_date', 'amount'];

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}
