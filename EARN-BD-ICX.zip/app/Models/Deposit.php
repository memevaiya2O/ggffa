<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Deposit extends Model
{
    public $timestamps = false;

    protected $table = 'deposits';

    protected $fillable = [
        'user_id', 'method_id', 'amount', 'sender_number', 'transaction_id', 'screenshot',
        'status', 'admin_note', 'processed_at',
    ];

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function method()
    {
        return $this->belongsTo(DepositMethod::class, 'method_id');
    }
}
