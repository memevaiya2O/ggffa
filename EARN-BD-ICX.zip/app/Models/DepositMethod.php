<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DepositMethod extends Model
{
    public $timestamps = false;

    protected $table = 'deposit_methods';

    protected $fillable = ['name', 'icon', 'account_number', 'account_type', 'instructions', 'min_amount', 'status'];
}
