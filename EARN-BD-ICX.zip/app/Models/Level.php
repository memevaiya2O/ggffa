<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Level extends Model
{
    public $timestamps = false;

    protected $table = 'levels';

    protected $fillable = [
        'name', 'icon', 'color', 'required_points', 'levelup_bonus',
        'daily_withdraw_limit', 'can_access_vip', 'sort_order',
    ];

    protected $casts = [
        'required_points' => 'integer',
        'levelup_bonus' => 'float',
        'daily_withdraw_limit' => 'float',
        'can_access_vip' => 'boolean',
        'sort_order' => 'integer',
    ];

    public function users()
    {
        return $this->hasMany(User::class, 'level_id');
    }
}
