<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RejectTemplate extends Model
{
    public $timestamps = false;

    protected $table = 'reject_templates';

    protected $fillable = ['reason'];
}
