<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SessionEntry extends Model
{
    public $timestamps = false;

    public $incrementing = false;

    protected $table = 'sessions';

    protected $fillable = ['id', 'user_id', 'last_activity'];
}
