<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SpinHistory extends Model
{
    public $timestamps = false;

    protected $table = 'spin_history';

    protected $fillable = ['user_id', 'prize_label', 'amount', 'spin_date'];

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}
