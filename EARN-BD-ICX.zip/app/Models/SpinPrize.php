<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SpinPrize extends Model
{
    public $timestamps = false;

    protected $table = 'spin_prizes';

    protected $fillable = ['label', 'amount', 'probability', 'color', 'status'];
}
