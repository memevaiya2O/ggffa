<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SpinSegment extends Model
{
    public $timestamps = false;

    protected $table = 'spin_segments';

    protected $fillable = ['label', 'prize_type', 'prize_value', 'weight', 'color'];
}
