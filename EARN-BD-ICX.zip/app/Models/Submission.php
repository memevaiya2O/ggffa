<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Submission extends Model
{
    public $timestamps = false;

    protected $table = 'submissions';

    protected $fillable = ['user_id', 'task_id', 'screenshot', 'notes', 'status', 'reject_reason', 'reviewed_at'];

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function task()
    {
        return $this->belongsTo(Task::class, 'task_id');
    }
}
