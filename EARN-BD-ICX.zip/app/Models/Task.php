<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Task extends Model
{
    public $timestamps = false;

    protected $table = 'tasks';

    protected $fillable = [
        'category_id', 'title', 'type', 'reward', 'thumbnail', 'instructions', 'rules',
        'screenshot_required', 'max_per_user', 'max_total', 'is_vip', 'is_featured',
        'is_hot', 'is_new', 'sort_order', 'status',
    ];

    public function category()
    {
        return $this->belongsTo(TaskCategory::class, 'category_id');
    }

    public function submissions()
    {
        return $this->hasMany(Submission::class, 'task_id');
    }
}
