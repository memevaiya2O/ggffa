<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TaskCategory extends Model
{
    public $timestamps = false;

    protected $table = 'task_categories';

    protected $fillable = ['name', 'icon', 'color', 'sort_order', 'status'];

    public function tasks()
    {
        return $this->hasMany(Task::class, 'category_id');
    }
}
