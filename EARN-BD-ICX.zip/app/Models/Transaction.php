<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Transaction extends Model
{
    public $timestamps = false;

    protected $table = 'transactions';

    protected $fillable = ['user_id', 'type', 'amount', 'description', 'reference_id'];

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}
