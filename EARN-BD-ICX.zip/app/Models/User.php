<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class User extends Model
{
    public $timestamps = false;

    protected $table = 'users';

    protected $fillable = [
        'name', 'email', 'password', 'avatar', 'referral_code', 'referred_by',
        'level_id', 'points', 'balance', 'total_earned', 'total_withdrawn',
        'streak_days', 'last_login', 'status', 'phone', 'wallet_active', 'wallet_activated_at',
    ];

    protected $hidden = ['password'];

    public function level()
    {
        return $this->belongsTo(Level::class, 'level_id');
    }

    public function referrer()
    {
        return $this->belongsTo(User::class, 'referred_by');
    }

    public function referralsMade()
    {
        return $this->hasMany(Referral::class, 'referrer_id');
    }

    public function submissions()
    {
        return $this->hasMany(Submission::class, 'user_id');
    }

    public function transactions()
    {
        return $this->hasMany(Transaction::class, 'user_id');
    }

    public function withdrawals()
    {
        return $this->hasMany(Withdrawal::class, 'user_id');
    }

    public function notifications()
    {
        return $this->hasMany(Notification::class, 'user_id');
    }

    public function spinHistory()
    {
        return $this->hasMany(SpinHistory::class, 'user_id');
    }

    public function achievements()
    {
        return $this->belongsToMany(Achievement::class, 'user_achievements', 'user_id', 'achievement_id')
            ->withPivot('unlocked_at');
    }
}
