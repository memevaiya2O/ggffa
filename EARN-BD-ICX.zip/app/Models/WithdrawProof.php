<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WithdrawProof extends Model
{
    public $timestamps = false;

    protected $table = 'withdraw_proof';

    protected $fillable = ['image', 'caption'];
}
