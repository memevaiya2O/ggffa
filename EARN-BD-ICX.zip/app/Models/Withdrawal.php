<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Withdrawal extends Model
{
    public $timestamps = false;

    protected $table = 'withdrawals';

    protected $fillable = [
        'user_id', 'method_id', 'address', 'amount', 'status', 'admin_note',
        'paid_at', 'method', 'details', 'tx_reference', 'processed_at',
    ];

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function methodRow()
    {
        return $this->belongsTo(WithdrawMethod::class, 'method_id');
    }
}
