<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WithdrawalMethod extends Model
{
    public $timestamps = false;

    protected $table = 'withdrawal_methods';

    protected $fillable = ['name', 'min_amount', 'max_amount', 'charge_pct', 'instructions', 'required_fields', 'status'];
}
