<?php

/**
 * Global helper functions migrated 1:1 from the original PHP project
 * (includes/functions.php, includes/auth.php, includes/upload.php, includes/settings-loader.php).
 */

use App\Models\Achievement;
use App\Models\AdminUser;
use App\Models\DailyBonus;
use App\Models\Level;
use App\Models\Notification;
use App\Models\Referral;
use App\Models\Setting;
use App\Models\Submission;
use App\Models\Transaction;
use App\Models\User;
use App\Models\UserAchievement;
use App\Models\Withdrawal;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

if (!function_exists('h')) {
    function h(mixed $s): string
    {
        return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('loadSettings')) {
    /** @return array<string, string|null> */
    function loadSettings(): array
    {
        $rows = Setting::query()->get(['key', 'value']);
        $s = [];
        foreach ($rows as $r) {
            $s[$r->key] = $r->value;
        }
        // Keep the untouched values (admin forms edit these) …
        $GLOBALS['_SETTINGS_RAW'] = $s;
        // … and resolve {site_name} / {year} so changing the site name in ONE place updates every text.
        $name = (string) ($s['site_name'] ?? 'EarnBD');
        foreach ($s as $k => $v) {
            if (is_string($v) && $k !== 'site_name' && str_contains($v, '{')) {
                $s[$k] = str_replace(['{site_name}', '{year}'], [$name, date('Y')], $v);
            }
        }
        return $s;
    }
}

if (!function_exists('getSetting')) {
    function getSetting(string $key, string $default = ''): string
    {
        global $_SETTINGS;
        return $_SETTINGS[$key] ?? $default;
    }
}

if (!function_exists('getRawSetting')) {
    /** Setting value exactly as stored (with {site_name} tokens) — for admin edit forms. */
    function getRawSetting(string $key, string $default = ''): string
    {
        return $GLOBALS['_SETTINGS_RAW'][$key] ?? $default;
    }
}

if (!function_exists('faviconUrl')) {
    /** Site icon set in Admin → Settings, falling back to the bundled favicon. */
    function faviconUrl(): string
    {
        $f = getSetting('favicon');
        return $f !== '' ? $f : '/favicon.svg';
    }
}

if (!function_exists('renderFavicon')) {
    function renderFavicon(): string
    {
        $url = h(faviconUrl());
        $ext = strtolower(pathinfo(parse_url($url, PHP_URL_PATH) ?: '', PATHINFO_EXTENSION));
        $type = match ($ext) {
            'svg' => 'image/svg+xml', 'ico' => 'image/x-icon', 'png' => 'image/png',
            'gif' => 'image/gif', 'webp' => 'image/webp', 'jpg', 'jpeg' => 'image/jpeg', default => 'image/png',
        };
        return "<link rel=\"icon\" href=\"{$url}\" type=\"{$type}\"><link rel=\"apple-touch-icon\" href=\"{$url}\">";
    }
}

if (!function_exists('generateReferralCode')) {
    function generateReferralCode(): string
    {
        return strtoupper(substr(uniqid(), -8));
    }
}

if (!function_exists('getUser')) {
    function getUser(int $id): ?User
    {
        return User::query()
            ->select('users.*', 'levels.name as level_name', 'levels.icon as level_icon', 'levels.color as level_color',
                'levels.required_points', 'levels.daily_withdraw_limit', 'levels.can_access_vip')
            ->leftJoin('levels', 'levels.id', '=', 'users.level_id')
            ->where('users.id', $id)
            ->first();
    }
}

if (!function_exists('getCurrentUser')) {
    function getCurrentUser(): ?User
    {
        $userId = session('user_id');
        if (!$userId) {
            return null;
        }
        return getUser((int) $userId);
    }
}

if (!function_exists('requireLoginUser')) {
    /**
     * Original requireLogin(): redirects when not logged in / banned, otherwise returns the user row.
     * @return User|RedirectResponse
     */
    function requireLoginUser(): User|RedirectResponse
    {
        if (!session('user_id')) {
            return redirect('/login');
        }
        $user = getCurrentUser();
        if (!$user || $user->status === 'banned') {
            session()->flush();
            return redirect('/login?banned=1');
        }
        return $user;
    }
}

if (!function_exists('requireAdminUser')) {
    /** Original requireAdmin(): redirects to the admin login when the admin session is missing. */
    function requireAdminUser(): ?RedirectResponse
    {
        if (empty(session('admin_id'))) {
            return redirect('/Icxpanel/login');
        }
        return null;
    }
}

if (!function_exists('createNotification')) {
    function createNotification(int $userId, string $type, string $title, string $message): void
    {
        Notification::query()->create([
            'user_id' => $userId,
            'type' => $type,
            'title' => $title,
            'message' => $message,
        ]);
    }
}

if (!function_exists('addTransaction')) {
    function addTransaction(int $userId, string $type, float $amount, string $description, ?int $refId = null): void
    {
        Transaction::query()->create([
            'user_id' => $userId,
            'type' => $type,
            'amount' => $amount,
            'description' => $description,
            'reference_id' => $refId,
        ]);
    }
}

if (!function_exists('creditUser')) {
    function creditUser(int $userId, float $amount, string $type, string $description, ?int $refId = null): void
    {
        User::query()->where('id', $userId)->update([
            'balance' => DB::raw('balance + ' . (float) $amount),
            'total_earned' => DB::raw('total_earned + ' . (float) $amount),
        ]);
        addTransaction($userId, $type, $amount, $description, $refId);
        checkLevelUp($userId);
        checkAchievements($userId);
    }
}

if (!function_exists('checkLevelUp')) {
    function checkLevelUp(int $userId): void
    {
        $user = getUser($userId);
        if (!$user) {
            return;
        }

        $nl = Level::query()->where('required_points', '>', $user->points)
            ->orderBy('required_points')->first();

        $cl = Level::query()->where('required_points', '<=', $user->points)
            ->orderByDesc('required_points')->first();

        if ($cl && $cl->id != $user->level_id) {
            User::query()->where('id', $userId)->update(['level_id' => $cl->id]);
            if ((float) $cl->levelup_bonus > 0) {
                creditUser($userId, (float) $cl->levelup_bonus, 'level_up_bonus', 'Level up bonus: ' . $cl->name);
            }
            createNotification($userId, 'level_up', 'Level Up!', 'Congratulations! You reached ' . $cl->name . ' level!');
        }
    }
}

if (!function_exists('addPoints')) {
    function addPoints(int $userId, int $points): void
    {
        User::query()->where('id', $userId)->update([
            'points' => DB::raw('points + ' . (int) $points),
        ]);
        checkLevelUp($userId);
    }
}

if (!function_exists('checkAchievements')) {
    function checkAchievements(int $userId): void
    {
        $user = getUser($userId);
        if (!$user) {
            return;
        }

        $achievements = Achievement::query()->get();
        foreach ($achievements as $a) {
            $existing = UserAchievement::query()
                ->where('user_id', $userId)
                ->where('achievement_id', $a->id)
                ->first();
            if ($existing) {
                continue;
            }

            $met = false;
            switch ($a->condition_type) {
                case 'tasks_completed':
                    $count = Submission::query()->where('user_id', $userId)->where('status', 'approved')->count();
                    $met = $count >= $a->condition_value;
                    break;
                case 'referrals':
                    $count = Referral::query()->where('referrer_id', $userId)->where('level', 1)->count();
                    $met = $count >= $a->condition_value;
                    break;
                case 'streak_days':
                    $met = $user->streak_days >= $a->condition_value;
                    break;
                case 'withdrawals':
                    $count = Withdrawal::query()->where('user_id', $userId)->where('status', 'paid')->count();
                    $met = $count >= $a->condition_value;
                    break;
                case 'level_reached':
                    $met = $user->level_id >= $a->condition_value;
                    break;
            }

            if ($met) {
                UserAchievement::query()->insertOrIgnore([
                    'user_id' => $userId,
                    'achievement_id' => $a->id,
                ]);
                createNotification($userId, 'badge_unlocked', 'Badge Unlocked!', 'You unlocked the "' . $a->name . '" badge!');
            }
        }
    }
}

if (!function_exists('getUnreadNotificationCount')) {
    function getUnreadNotificationCount(int $userId): int
    {
        return Notification::query()->where('user_id', $userId)->where('is_read', false)->count();
    }
}

if (!function_exists('formatAmount')) {
    function formatAmount(float $amount): string
    {
        global $_SETTINGS;
        $sym = $_SETTINGS['currency_symbol'] ?? '৳';
        return $sym . number_format($amount, 2);
    }
}

if (!function_exists('timeAgo')) {
    function timeAgo(string $datetime): string
    {
        $now = new DateTime();
        $then = new DateTime($datetime);
        $diff = $now->diff($then);
        if ($diff->y > 0) return $diff->y . 'y ago';
        if ($diff->m > 0) return $diff->m . 'mo ago';
        if ($diff->d > 0) return $diff->d . 'd ago';
        if ($diff->h > 0) return $diff->h . 'h ago';
        if ($diff->i > 0) return $diff->i . 'm ago';
        return 'just now';
    }
}

if (!function_exists('getTransactionIcon')) {
    function getTransactionIcon(string $type): string
    {
        return match ($type) {
            'task_reward' => 'fa-list-check',
            'referral_bonus' => 'fa-user-plus',
            'daily_bonus' => 'fa-gift',
            'spin_reward' => 'fa-circle-notch',
            'withdrawal' => 'fa-money-bill-transfer',
            'level_up_bonus' => 'fa-arrow-trend-up',
            'admin_credit' => 'fa-plus-circle',
            'deposit' => 'fa-circle-plus',
            default => 'fa-circle-dollar-to-slot',
        };
    }
}

if (!function_exists('walletActivationRequired')) {
    /** Admin switch: must a user add money before the first withdrawal? */
    function walletActivationRequired(): bool
    {
        return getSetting('wallet_activation_required', '1') === '1';
    }
}

if (!function_exists('walletActivationMin')) {
    /** Minimum total deposit (set by admin) needed to activate the wallet. */
    function walletActivationMin(): float
    {
        return max(0, (float) getSetting('wallet_activation_min', '100'));
    }
}

if (!function_exists('isWalletActive')) {
    function isWalletActive($user): bool
    {
        return !walletActivationRequired() || !empty($user->wallet_active);
    }
}

if (!function_exists('csrfField')) {
    /**
     * Kept name-compatible with the original forms/JS which reference [name=csrf_token].
     * Laravel's CSRF middleware accepts this token via the overridden token lookup.
     */
    function csrfField(): string
    {
        return '<input type="hidden" name="csrf_token" value="' . h(csrf_token()) . '">';
    }
}

if (!function_exists('paginationLinks')) {
    function paginationLinks(int $total, int $page, int $limit, string $baseUrl): string
    {
        $pages = (int) ceil($total / $limit);
        if ($pages <= 1) return '';
        $html = '<div class="pagination">';
        for ($i = 1; $i <= $pages; $i++) {
            $active = $i === $page ? ' active' : '';
            $sep = str_contains($baseUrl, '?') ? '&' : '?';
            $html .= "<a href=\"{$baseUrl}{$sep}page={$i}\" class=\"page-btn{$active}\">{$i}</a>";
        }
        $html .= '</div>';
        return $html;
    }
}

if (!function_exists('handleUpload')) {
    /** Original includes/upload.php — files land in public/assets/{subDir}/ with the same public URL. */
    function handleUpload(string $fieldName, string $subDir = 'uploads', bool $allowIcons = false): array
    {
        if (empty($_FILES[$fieldName]['name'])) {
            return ['success' => false, 'message' => 'No file uploaded.'];
        }

        $file = $_FILES[$fieldName];
        $allowed = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
        if ($allowIcons) {
            $allowed = array_merge($allowed, ['image/x-icon', 'image/vnd.microsoft.icon', 'image/svg+xml']);
        }
        $maxSize = 2 * 1024 * 1024; // 2MB

        if ($file['error'] !== UPLOAD_ERR_OK) {
            return ['success' => false, 'message' => 'Upload error: ' . $file['error']];
        }
        if ($file['size'] > $maxSize) {
            return ['success' => false, 'message' => 'File too large. Max 2MB.'];
        }

        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);

        if (!in_array($mimeType, $allowed)) {
            return ['success' => false, 'message' => 'Invalid file type. Only JPG, PNG, GIF, WebP' . ($allowIcons ? ', ICO, SVG' : '') . ' allowed.'];
        }

        // Extension comes from the detected type, never from the client-supplied name.
        $ext = [
            'image/jpeg' => 'jpg', 'image/jpg' => 'jpg', 'image/png' => 'png', 'image/gif' => 'gif',
            'image/webp' => 'webp', 'image/x-icon' => 'ico', 'image/vnd.microsoft.icon' => 'ico', 'image/svg+xml' => 'svg',
        ][$mimeType];
        $filename = bin2hex(random_bytes(16)) . '.' . $ext;
        $dir = public_path('assets/' . $subDir . '/');

        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }

        $dest = $dir . $filename;
        if (!move_uploaded_file($file['tmp_name'], $dest)) {
            return ['success' => false, 'message' => 'Failed to save file.'];
        }

        return ['success' => true, 'path' => '/assets/' . $subDir . '/' . $filename, 'filename' => $filename];
    }
}

if (!function_exists('renderCssVars')) {
    function renderCssVars(): string
    {
        global $_SETTINGS;
        $vars = [
            '--primary' => $_SETTINGS['color_primary'] ?? '#00C896',
            '--secondary' => $_SETTINGS['color_secondary'] ?? '#009688',
            '--bg' => $_SETTINGS['color_bg'] ?? '#FFFFFF',
            '--card-bg' => $_SETTINGS['color_card'] ?? '#F4FBF9',
            '--text' => $_SETTINGS['color_text'] ?? '#1A1A2E',
            '--accent' => $_SETTINGS['color_accent'] ?? '#00E5B0',
            '--danger' => $_SETTINGS['color_danger'] ?? '#FF4757',
            '--warning' => $_SETTINGS['color_warning'] ?? '#FFA502',
            '--radius' => ($_SETTINGS['border_radius'] ?? '12') . 'px',
            '--font' => "'" . ($_SETTINGS['font_family'] ?? 'Nunito') . "', sans-serif",
        ];
        $css = ':root{';
        foreach ($vars as $k => $v) $css .= "$k:$v;";
        $css .= '}';
        return "<style>$css</style>";
    }
}

if (!function_exists('renderGoogleFont')) {
    function renderGoogleFont(): string
    {
        global $_SETTINGS;
        $font = urlencode($_SETTINGS['font_family'] ?? 'Nunito');
        return "<link href=\"https://fonts.googleapis.com/css2?family={$font}:wght@400;500;600;700;800;900&display=swap\" rel=\"stylesheet\">";
    }
}

if (!function_exists('renderSeoMeta')) {
    function renderSeoMeta(string $page = 'home'): string
    {
        global $_SETTINGS;
        $pick = function (array $names, string $default = '') use ($_SETTINGS) {
            foreach ($names as $n) {
                if (!empty($_SETTINGS[$n])) {
                    return $_SETTINGS[$n];
                }
            }
            return $default;
        };
        $title = h($pick(['seo_title', 'meta_title'], $_SETTINGS['site_name'] ?? ''));
        $desc = h($pick(['seo_description', 'meta_description']));
        $keys = h($pick(['seo_keywords', 'meta_keywords']));
        $og = h($pick(['seo_og_image', 'og_image']));
        $ga = h($pick(['google_analytics_id', 'google_analytics']));
        $head = $_SETTINGS['custom_header_script'] ?? '';
        $html = "<meta charset='UTF-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
    <title>$title</title>
    <meta name='description' content='$desc'>
    <meta name='keywords' content='$keys'>" . renderFavicon();
        if ($og) $html .= "<meta property='og:image' content='$og'>";
        if ($ga) $html .= "<script async src='https://www.googletagmanager.com/gtag/js?id=$ga'></script><script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','$ga');</script>";
        $html .= $head;
        return $html;
    }
}

if (!function_exists('registerUser')) {
    /** Original includes/auth.php registerUser() — welcome bonus + 2-level referral bonuses. */
    function registerUser(string $name, string $email, string $password, ?string $referralCode = null, ?string $phone = null): array
    {
        $existing = User::query()->where('email', $email)->first();
        if ($existing) {
            return ['success' => false, 'message' => 'Email already registered.'];
        }

        $hash = Hash::make($password);
        $refCode = generateReferralCode();
        while (true) {
            $check = User::query()->where('referral_code', $refCode)->first();
            if (!$check) break;
            $refCode = generateReferralCode();
        }

        $referredById = null;
        if ($referralCode) {
            $referrer = User::query()->where('referral_code', $referralCode)->first();
            if ($referrer) $referredById = (int) $referrer->id;
        }

        $user = User::query()->create([
            'name' => $name,
            'email' => $email,
            'password' => $hash,
            'referral_code' => $refCode,
            'referred_by' => $referredById,
            'level_id' => 1,
            'phone' => $phone,
        ]);

        $newUserId = (int) $user->id;

        // Welcome bonus
        global $_SETTINGS;
        $welcome = (float) ($_SETTINGS['welcome_bonus'] ?? 10);
        if ($welcome > 0) {
            creditUser($newUserId, $welcome, 'admin_credit', 'Welcome bonus');
            createNotification($newUserId, 'bonus_credited', 'Welcome Bonus!', 'You received a welcome bonus of ' . formatAmount($welcome));
        }

        // Referral bonuses
        if ($referredById) {
            $l1 = (float) ($_SETTINGS['referral_l1_bonus'] ?? 20);
            if ($l1 > 0) {
                creditUser($referredById, $l1, 'referral_bonus', 'Level 1 referral bonus for ' . $name);
                createNotification($referredById, 'bonus_credited', 'Referral Bonus!', 'You earned ' . formatAmount($l1) . ' for referring ' . $name);
                Referral::query()->create([
                    'referrer_id' => $referredById,
                    'referred_id' => $newUserId,
                    'level' => 1,
                    'bonus' => $l1,
                ]);
            }

            // Level 2
            $referrerRow = User::query()->find($referredById);
            if ($referrerRow && $referrerRow->referred_by) {
                $l2 = (float) ($_SETTINGS['referral_l2_bonus'] ?? 5);
                if ($l2 > 0) {
                    creditUser((int) $referrerRow->referred_by, $l2, 'referral_bonus', 'Level 2 referral bonus for ' . $name);
                    Referral::query()->create([
                        'referrer_id' => (int) $referrerRow->referred_by,
                        'referred_id' => $newUserId,
                        'level' => 2,
                        'bonus' => $l2,
                    ]);
                }
            }
        }

        createNotification($newUserId, 'welcome', 'Welcome to ' . getSetting('site_name', 'EarnBD') . '!', 'Your account has been created. Start completing tasks to earn money!');

        return ['success' => true, 'user_id' => $newUserId];
    }
}

if (!function_exists('loginUser')) {
    /** Original includes/auth.php loginUser(). */
    function loginUser(string $email, string $password): array
    {
        $user = User::query()->where('email', $email)->first();

        if (!$user || !Hash::check($password, $user->password)) {
            return ['success' => false, 'message' => 'Invalid email or password.'];
        }
        if ($user->status === 'banned') {
            return ['success' => false, 'message' => 'Your account has been suspended.'];
        }

        User::query()->where('id', $user->id)->update(['last_login' => date('Y-m-d H:i:s')]);

        // Update streak
        updateStreak((int) $user->id);

        session(['user_id' => $user->id]);
        return ['success' => true, 'user' => $user];
    }
}

if (!function_exists('updateStreak')) {
    function updateStreak(int $userId): void
    {
        $u = User::query()->find($userId);
        if (!$u) return;

        $today = new DateTime();
        $lastLogin = $u->last_login ? new DateTime($u->last_login) : null;

        if (!$lastLogin) {
            User::query()->where('id', $userId)->update(['streak_days' => 1]);
            return;
        }

        $diff = $today->diff($lastLogin)->days;
        if ($diff === 1) {
            User::query()->where('id', $userId)->update(['streak_days' => DB::raw('streak_days + 1')]);
        } elseif ($diff > 1) {
            User::query()->where('id', $userId)->update(['streak_days' => 1]);
        }
    }
}

if (!function_exists('loginAdmin')) {
    /** Original includes/auth.php loginAdmin(). */
    function loginAdmin(string $username, string $password): bool
    {
        $admin = AdminUser::query()->where('username', $username)->first();
        if (!$admin || !Hash::check($password, $admin->password)) {
            return false;
        }
        session(['admin_id' => $admin->id, 'admin_username' => $admin->username]);
        return true;
    }
}

if (!function_exists('normalizeBdPhone')) {
    /**
     * Bangladeshi mobile number → 01XXXXXXXXX. Accepts 01…, 8801…, +8801… (spaces/dashes ignored).
     * Returns '' when the number is not valid.
     */
    function normalizeBdPhone(string $raw): string
    {
        $p = preg_replace('/[\s\-()]/', '', trim($raw));
        if (preg_match('/^(?:\+?88)?(01[3-9]\d{8})$/', (string) $p, $m)) {
            return $m[1];
        }
        return '';
    }
}

if (!function_exists('telegramCreds')) {
    /**
     * Bot token + chat IDs. Admin → Deposits → Telegram settings win; .env is the fallback.
     * @return array{0:string,1:array<int,string>} [token, chatIds]
     */
    function telegramCreds(): array
    {
        $token = trim(getSetting('telegram_bot_token')) ?: trim((string) config('services.telegram.token'));
        $chat = trim(getSetting('telegram_chat_id')) ?: trim((string) config('services.telegram.chat_id'));
        $ids = array_values(array_filter(array_map('trim', explode(',', $chat))));
        return [$token, $ids];
    }
}

if (!function_exists('telegramCall')) {
    /** One Telegram Bot API call. $fields may contain CURLFile objects. Returns true when Telegram answers ok. */
    function telegramCall(string $token, string $method, array $fields): bool
    {
        if (!function_exists('curl_init')) {
            return false;
        }
        $ch = curl_init('https://api.telegram.org/bot' . $token . '/' . $method);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $fields,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 6,
            CURLOPT_TIMEOUT => 20,
        ]);
        $res = curl_exec($ch);
        $curlErr = curl_error($ch);
        curl_close($ch);
        $json = is_string($res) ? json_decode($res, true) : null;
        if (empty($json['ok'])) {
            $GLOBALS['_TG_ERR'] = is_array($json) && !empty($json['description']) ? (string) $json['description'] : ($curlErr ?: 'No response from Telegram');
            \Illuminate\Support\Facades\Log::warning('Telegram ' . $method . ' failed: ' . (is_string($res) ? substr($res, 0, 300) : 'no response'));
            return false;
        }
        return true;
    }
}

if (!function_exists('telegramEsc')) {
    /** Escape + shorten a value for a Telegram HTML message. */
    function telegramEsc($v, int $max = 60): string
    {
        return htmlspecialchars(mb_strimwidth((string) $v, 0, $max, '…'), ENT_NOQUOTES, 'UTF-8');
    }
}

if (!function_exists('telegramDispatch')) {
    /**
     * Sends a message (with an optional screenshot) to every configured chat.
     * Runs after the response is sent, never throws, and does nothing until the bot token
     * and chat ID are set (Admin → Deposits → Telegram Bot, or .env).
     */
    function telegramDispatch(string $caption, string $shot = ''): void
    {
        [$token, $chatIds] = telegramCreds();
        if ($token === '' || !$chatIds) {
            return;
        }

        app()->terminating(function () use ($token, $chatIds, $caption, $shot) {
            try {
                foreach ($chatIds as $chatId) {
                    $sent = false;
                    if ($shot !== '' && is_file($shot)) {
                        $mime = function_exists('mime_content_type') ? (mime_content_type($shot) ?: 'image/jpeg') : 'image/jpeg';
                        $sent = telegramCall($token, 'sendPhoto', [
                            'chat_id' => $chatId, 'photo' => new \CURLFile($shot, $mime, basename($shot)),
                            'caption' => $caption, 'parse_mode' => 'HTML',
                        ]);
                        if (!$sent) { // odd image dimensions etc. → send it as a file instead
                            $sent = telegramCall($token, 'sendDocument', [
                                'chat_id' => $chatId, 'document' => new \CURLFile($shot, $mime, basename($shot)),
                                'caption' => $caption, 'parse_mode' => 'HTML',
                            ]);
                        }
                    }
                    if (!$sent) {
                        telegramCall($token, 'sendMessage', ['chat_id' => $chatId, 'text' => $caption, 'parse_mode' => 'HTML']);
                    }
                }
            } catch (\Throwable $ex) {
                report($ex);
            }
        });
    }
}

if (!function_exists('notifyTelegramDeposit')) {
    /** New deposit (wallet activation payment) → user details, amount, TrxID + payment screenshot. */
    function notifyTelegramDeposit($user, $deposit, string $methodName = '', string $methodAccount = ''): void
    {
        if (getSetting('telegram_enabled', '1') !== '1') {
            return;
        }
        $e = 'telegramEsc';
        $walletActive = !empty($user->wallet_active);
        $caption = "🔔 <b>New Deposit Request</b>\n"
            . ($walletActive ? "" : "⚡ <b>Wallet activation payment</b>\n")
            . "\n👤 <b>Name:</b> " . $e($user->name)
            . "\n🆔 <b>User ID:</b> #" . (int) $user->id
            . "\n📧 <b>Email:</b> " . $e($user->email)
            . "\n📱 <b>Mobile:</b> " . $e(($user->phone ?? '') !== '' ? $user->phone : '—')
            . "\n\n💰 <b>Amount:</b> " . $e(formatAmount((float) $deposit->amount))
            . "\n🏦 <b>Method:</b> " . $e($methodName !== '' ? $methodName : '—')
            . ($methodAccount !== '' ? " (" . $e($methodAccount) . ")" : "")
            . "\n📞 <b>Sent from:</b> " . $e($deposit->sender_number)
            . "\n🧾 <b>Transaction ID:</b> <code>" . $e($deposit->transaction_id, 128) . "</code>"
            . "\n🔐 <b>Wallet:</b> " . ($walletActive ? 'Active' : 'Not active')
            . "\n🕒 " . now('Asia/Dhaka')->format('d M Y, h:i A') . " (BST)"
            . "\n\n🔗 " . rtrim((string) config('app.url'), '/') . "/Icxpanel/deposits";

        $shot = !empty($deposit->screenshot) ? public_path(ltrim((string) $deposit->screenshot, '/')) : '';
        telegramDispatch($caption, $shot);
    }
}

if (!function_exists('notifyTelegramTask')) {
    /** Task submitted → user details, task, reward, notes + proof screenshot. */
    function notifyTelegramTask($user, $task, $submission): void
    {
        if (getSetting('telegram_notify_tasks', '1') !== '1') {
            return;
        }
        $e = 'telegramEsc';
        $notes = trim((string) ($submission->notes ?? ''));
        $caption = "📝 <b>New Task Submission</b>\n"
            . "\n👤 <b>Name:</b> " . $e($user->name)
            . "\n🆔 <b>User ID:</b> #" . (int) $user->id
            . "\n📧 <b>Email:</b> " . $e($user->email)
            . "\n📱 <b>Mobile:</b> " . $e(($user->phone ?? '') !== '' ? $user->phone : '—')
            . "\n\n📌 <b>Task:</b> " . $e($task->title, 100) . " (#" . (int) $task->id . ")"
            . (!empty($task->cat_name) ? "\n🏷 <b>Category:</b> " . $e($task->cat_name) : "")
            . "\n💰 <b>Reward:</b> " . $e(formatAmount((float) $task->reward))
            . ($notes !== '' ? "\n💬 <b>Notes:</b> " . $e($notes, 200) : "")
            . "\n🔐 <b>Wallet:</b> " . (!empty($user->wallet_active) ? 'Active' : 'Not active')
            . "\n🕒 " . now('Asia/Dhaka')->format('d M Y, h:i A') . " (BST)"
            . "\n\n🔗 " . rtrim((string) config('app.url'), '/') . "/Icxpanel/submissions";

        $shot = !empty($submission->screenshot) ? public_path(ltrim((string) $submission->screenshot, '/')) : '';
        telegramDispatch($caption, $shot);
    }
}
