<?php

use App\Http\Middleware\AdminAuth;
use App\Http\Middleware\LoadSettings;
use App\Http\Middleware\UserAuth;
use App\Http\Middleware\ValidateCsrfToken;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

$app = Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        // Runs on every web request after the session starts:
        // schema bootstrap (first run), settings load, maintenance-mode gate.
        $middleware->web(append: [
            LoadSettings::class,
        ]);

        // Accept the original project's CSRF token conventions (csrf_token / csrf JSON keys).
        $middleware->replaceInGroup('web', \Illuminate\Foundation\Http\Middleware\ValidateCsrfToken::class, ValidateCsrfToken::class);

        $middleware->alias([
            'user.auth' => UserAuth::class,
            'admin.auth' => AdminAuth::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        //
    })->create();

// Dual layout support:
// - Standard layout (dev / old deploys): web root is the /public subfolder.
// - cPanel root layout (this package): all files sit in the web root and the
//   public folder does not exist, so the base path itself is the public path.
$app->usePublicPath(is_dir(__DIR__.'/../public') ? dirname(__DIR__).'/public' : dirname(__DIR__));

return $app;
