<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('levels', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('icon')->default('fa-medal');
            $table->string('color', 32)->default('#CD7F32');
            $table->integer('required_points')->default(0);
            $table->decimal('levelup_bonus', 12, 2)->default(0);
            $table->decimal('daily_withdraw_limit', 12, 2)->default(100);
            $table->boolean('can_access_vip')->default(false);
            $table->integer('sort_order')->default(0);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('levels');
    }
};
