<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('email')->unique();
            $table->string('password');
            $table->text('avatar')->nullable();
            $table->string('referral_code', 64)->unique();
            $table->unsignedBigInteger('referred_by')->nullable();
            $table->unsignedBigInteger('level_id')->default(1);
            $table->integer('points')->default(0);
            $table->decimal('balance', 12, 2)->default(0);
            $table->decimal('total_earned', 12, 2)->default(0);
            $table->decimal('total_withdrawn', 12, 2)->default(0);
            $table->integer('streak_days')->default(0);
            $table->timestamp('last_login')->nullable();
            $table->string('status', 32)->default('active');
            $table->text('phone')->nullable();
            $table->timestamp('created_at')->useCurrent();
            $table->foreign('referred_by')->references('id')->on('users');
            $table->foreign('level_id')->references('id')->on('levels');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('users');
    }
};
