<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('task_categories', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('icon')->default('fa-tag');
            $table->string('color', 32)->default('#00C896');
            $table->integer('sort_order')->default(0);
            $table->string('status', 32)->default('active');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('task_categories');
    }
};
