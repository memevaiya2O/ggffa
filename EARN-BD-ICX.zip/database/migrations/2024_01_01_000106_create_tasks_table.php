<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('tasks', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('category_id')->nullable();
            $table->string('title');
            $table->string('type', 32)->default('standard');
            $table->decimal('reward', 10, 2)->default(0);
            $table->text('thumbnail')->nullable();
            $table->text('instructions')->nullable();
            $table->text('rules')->nullable();
            $table->boolean('screenshot_required')->default(true);
            $table->integer('max_per_user')->default(1);
            $table->integer('max_total')->default(1000);
            $table->boolean('is_vip')->default(false);
            $table->boolean('is_featured')->default(false);
            $table->boolean('is_hot')->default(false);
            $table->boolean('is_new')->default(true);
            $table->integer('sort_order')->default(0);
            $table->string('status', 32)->default('active');
            $table->timestamp('created_at')->useCurrent();
            $table->foreign('category_id')->references('id')->on('task_categories');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tasks');
    }
};
