<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('withdraw_methods', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('icon')->default('fa-wallet');
            $table->decimal('min_amount', 10, 2)->default(50);
            $table->string('processing_time')->default('24 hours');
            $table->text('instructions');
            $table->string('status', 32)->default('active');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('withdraw_methods');
    }
};
