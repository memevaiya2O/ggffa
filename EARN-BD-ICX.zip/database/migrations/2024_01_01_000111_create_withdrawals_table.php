<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('withdrawals', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id');
            $table->unsignedBigInteger('method_id');
            $table->text('address');
            $table->decimal('amount', 12, 2);
            $table->string('status', 32)->default('pending');
            $table->text('admin_note')->nullable();
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('paid_at')->nullable();
            $table->text('method')->nullable();
            $table->text('details')->nullable();
            $table->text('tx_reference')->nullable();
            $table->timestamp('processed_at')->nullable();
            $table->foreign('user_id')->references('id')->on('users');
            $table->foreign('method_id')->references('id')->on('withdraw_methods');
        });

        // Legacy data backfill (mirrors original runMigrations):
        // UPDATE withdrawals w SET method = wm.name FROM withdraw_methods wm WHERE wm.id = w.method_id AND w.method IS NULL
        DB::statement('UPDATE withdrawals w JOIN withdraw_methods wm ON wm.id = w.method_id SET w.method = wm.name WHERE w.method IS NULL');
    }

    public function down(): void
    {
        Schema::dropIfExists('withdrawals');
    }
};
