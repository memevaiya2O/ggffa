<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('spin_prizes', function (Blueprint $table) {
            $table->id();
            $table->string('label');
            $table->decimal('amount', 10, 2)->default(0);
            $table->decimal('probability', 5, 2)->default(10);
            $table->string('color', 32)->default('#00C896');
            $table->string('status', 32)->default('active');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('spin_prizes');
    }
};
