<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('spin_segments', function (Blueprint $table) {
            $table->id();
            $table->string('label');
            $table->string('prize_type', 32)->default('coins');
            $table->decimal('prize_value', 10, 2)->default(0);
            $table->integer('weight')->default(1);
            $table->string('color', 32)->default('#4CAF50');
            $table->timestamp('created_at')->useCurrent();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('spin_segments');
    }
};
