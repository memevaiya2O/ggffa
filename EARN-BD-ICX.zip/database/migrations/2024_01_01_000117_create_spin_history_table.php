<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('spin_history', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id');
            $table->string('prize_label');
            $table->decimal('amount', 10, 2);
            // Original: spin_date DATE NOT NULL DEFAULT CURRENT_DATE.
            // Always inserted explicitly by the application (MySQL DATE has no CURRENT_TIMESTAMP default).
            $table->date('spin_date');
            $table->foreign('user_id')->references('id')->on('users');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('spin_history');
    }
};
