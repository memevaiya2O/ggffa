<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('referrals', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('referrer_id');
            $table->unsignedBigInteger('referred_id');
            $table->integer('level')->default(1);
            $table->decimal('bonus', 10, 2)->default(0);
            $table->timestamp('created_at')->useCurrent();
            $table->foreign('referrer_id')->references('id')->on('users');
            $table->foreign('referred_id')->references('id')->on('users');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('referrals');
    }
};
