<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('achievements', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->text('description');
            $table->string('icon')->default('fa-trophy');
            $table->string('condition_type', 64);
            $table->integer('condition_value')->default(1);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('achievements');
    }
};
