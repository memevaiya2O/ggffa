<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('announcements', function (Blueprint $table) {
            $table->id();
            $table->string('text');
            $table->string('color', 32)->default('#00C896');
            $table->text('link')->nullable();
            $table->string('status', 32)->default('active');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('announcements');
    }
};
