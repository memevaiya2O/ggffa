<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Wallet activation ("Add Money" before the first withdrawal).
 * Idempotent: safe to run on a database that already has some of these objects.
 */
return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasColumn('users', 'wallet_active')) {
            Schema::table('users', function (Blueprint $table) {
                $table->boolean('wallet_active')->default(false);
                $table->timestamp('wallet_activated_at')->nullable();
            });

            // Users who already withdrew before this feature existed stay active.
            DB::table('users')->whereIn('id', function ($q) {
                $q->select('user_id')->from('withdrawals')->where('status', '!=', 'rejected');
            })->update(['wallet_active' => 1, 'wallet_activated_at' => now()]);
        }

        if (!Schema::hasTable('deposit_methods')) {
            Schema::create('deposit_methods', function (Blueprint $table) {
                $table->id();
                $table->string('name');
                $table->string('icon')->default('fa-wallet');
                $table->string('account_number')->default('');
                $table->string('account_type', 64)->default('Personal');
                $table->text('instructions')->nullable();
                $table->decimal('min_amount', 10, 2)->default(0);
                $table->string('status', 32)->default('active');
            });
        }

        if (!Schema::hasTable('deposits')) {
            Schema::create('deposits', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('user_id');
                $table->unsignedBigInteger('method_id')->nullable();
                $table->decimal('amount', 12, 2);
                $table->string('sender_number', 64)->default('');
                $table->string('transaction_id', 128)->default('');
                $table->string('status', 32)->default('pending');
                $table->text('admin_note')->nullable();
                $table->timestamp('created_at')->useCurrent();
                $table->timestamp('processed_at')->nullable();
                $table->index('user_id');
                $table->index('status');
            });
        }

        $defaults = [
            'wallet_activation_required' => '1',
            'wallet_activation_min' => '100',
            'deposit_credit_balance' => '1',
        ];
        foreach ($defaults as $k => $v) {
            if (!DB::table('settings')->where('key', $k)->exists()) {
                DB::table('settings')->insert(['key' => $k, 'value' => $v, 'group_name' => 'wallet', 'updated_at' => now()]);
            }
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('deposits');
        Schema::dropIfExists('deposit_methods');
        if (Schema::hasColumn('users', 'wallet_active')) {
            Schema::table('users', function (Blueprint $table) {
                $table->dropColumn(['wallet_active', 'wallet_activated_at']);
            });
        }
    }
};
