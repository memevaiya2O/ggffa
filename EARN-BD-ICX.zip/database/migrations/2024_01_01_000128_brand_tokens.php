<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

/**
 * Turn the hard-coded "EarnBD" in text settings into a {site_name} token,
 * so renaming the site in Admin → Settings renames it everywhere.
 */
return new class extends Migration
{
    public function up(): void
    {
        $rows = DB::table('settings')->where('key', '!=', 'site_name')->where('value', 'like', '%EarnBD%')->get(['id', 'key', 'value']);
        foreach ($rows as $r) {
            $v = str_replace('EarnBD', '{site_name}', (string) $r->value);
            if ($r->key === 'footer_copyright') {
                $v = preg_replace('/©\s*\d{4}/u', '© {year}', $v);
            }
            DB::table('settings')->where('id', $r->id)->update(['value' => $v]);
        }
        // "earnbd" keyword left over in meta keywords
        $kw = DB::table('settings')->where('key', 'meta_keywords')->first();
        if ($kw && stripos((string) $kw->value, 'earnbd') !== false) {
            $clean = preg_replace('/\s*earnbd\s*,?/i', '', (string) $kw->value);
            DB::table('settings')->where('id', $kw->id)->update(['value' => trim($clean, " ,")]);
        }
    }

    public function down(): void
    {
        //
    }
};
