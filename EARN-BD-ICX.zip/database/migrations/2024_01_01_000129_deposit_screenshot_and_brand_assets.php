<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * - deposits.screenshot : payment screenshot uploaded with the Add Money form
 *   (it is also what the Telegram bot forwards to the admin).
 * - default site logo + site icon (only filled in when nothing is set yet,
 *   so a logo uploaded from Admin → Settings is never overwritten).
 * Idempotent: safe to run more than once.
 */
return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('deposits') && !Schema::hasColumn('deposits', 'screenshot')) {
            Schema::table('deposits', function (Blueprint $table) {
                $table->string('screenshot', 255)->nullable()->after('transaction_id');
            });
        }

        if (Schema::hasTable('settings')) {
            foreach (['site_logo' => '/assets/img/logo.svg', 'favicon' => '/assets/img/icon.png'] as $key => $path) {
                $row = DB::table('settings')->where('key', $key)->first();
                if (!$row) {
                    DB::table('settings')->insert(['key' => $key, 'value' => $path, 'group_name' => 'general', 'updated_at' => now()]);
                } elseif (trim((string) $row->value) === '') {
                    DB::table('settings')->where('key', $key)->update(['value' => $path, 'updated_at' => now()]);
                }
            }
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('deposits', 'screenshot')) {
            Schema::table('deposits', function (Blueprint $table) {
                $table->dropColumn('screenshot');
            });
        }
    }
};
