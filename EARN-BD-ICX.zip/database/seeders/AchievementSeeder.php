<?php

namespace Database\Seeders;

use App\Models\Achievement;
use Illuminate\Database\Seeder;

class AchievementSeeder extends Seeder
{
    public function run(): void
    {
        foreach ([
            ['First Task', 'Complete your first task', 'fa-star', 'tasks_completed', 1],
            ['Task Pro', 'Complete 10 tasks', 'fa-star-half-stroke', 'tasks_completed', 10],
            ['Task Master', 'Complete 50 tasks', 'fa-certificate', 'tasks_completed', 50],
            ['Task Legend', 'Complete 100 tasks', 'fa-crown', 'tasks_completed', 100],
            ['First Withdraw', 'Make your first withdrawal', 'fa-hand-holding-dollar', 'withdrawals', 1],
            ['Referral King', 'Refer 10 friends', 'fa-user-group', 'referrals', 10],
            ['Daily Streak 7', 'Login 7 days in a row', 'fa-fire', 'streak_days', 7],
            ['Diamond Member', 'Reach Diamond level', 'fa-gem', 'level_reached', 5],
        ] as $a) {
            if (!Achievement::query()->where('name', $a[0])->exists()) {
                Achievement::query()->create([
                    'name' => $a[0], 'description' => $a[1], 'icon' => $a[2],
                    'condition_type' => $a[3], 'condition_value' => $a[4],
                ]);
            }
        }
    }
}
