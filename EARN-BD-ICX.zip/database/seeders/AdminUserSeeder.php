<?php

namespace Database\Seeders;

use App\Models\AdminUser;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class AdminUserSeeder extends Seeder
{
    public function run(): void
    {
        if (!AdminUser::query()->where('username', 'admin')->exists()) {
            AdminUser::query()->create([
                'username' => 'admin',
                'password' => Hash::make('admin123'),
            ]);
        }
    }
}
