<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            LevelSeeder::class,
            TaskCategorySeeder::class,
            TaskSeeder::class,
            WithdrawMethodSeeder::class,
            WithdrawalMethodSeeder::class,
            SpinPrizeSeeder::class,
            SpinSegmentSeeder::class,
            AchievementSeeder::class,
            RejectTemplateSeeder::class,
            SettingSeeder::class,
            AdminUserSeeder::class,
        ]);
    }
}
