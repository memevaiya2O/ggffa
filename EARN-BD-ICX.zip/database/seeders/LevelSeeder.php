<?php

namespace Database\Seeders;

use App\Models\Level;
use Illuminate\Database\Seeder;

class LevelSeeder extends Seeder
{
    public function run(): void
    {
        foreach ([
            ['Bronze', 'fa-medal', '#CD7F32', 0, 0, 500, 0, 1],
            ['Silver', 'fa-medal', '#C0C0C0', 500, 10, 1000, 0, 2],
            ['Gold', 'fa-medal', '#FFD700', 2000, 25, 2000, 0, 3],
            ['Platinum', 'fa-gem', '#00B4D8', 5000, 50, 5000, 1, 4],
            ['Diamond', 'fa-gem', '#B9F2FF', 10000, 100, 10000, 1, 5],
        ] as $l) {
            if (!Level::query()->where('name', $l[0])->exists()) {
                Level::query()->create([
                    'name' => $l[0], 'icon' => $l[1], 'color' => $l[2], 'required_points' => $l[3],
                    'levelup_bonus' => $l[4], 'daily_withdraw_limit' => $l[5], 'can_access_vip' => $l[6],
                    'sort_order' => $l[7],
                ]);
            }
        }
    }
}
