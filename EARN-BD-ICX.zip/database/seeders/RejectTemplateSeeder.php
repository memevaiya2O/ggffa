<?php

namespace Database\Seeders;

use App\Models\RejectTemplate;
use Illuminate\Database\Seeder;

class RejectTemplateSeeder extends Seeder
{
    public function run(): void
    {
        foreach ([
            'Screenshot is blurry or unclear',
            'Task not completed as per instructions',
            'Fake account detected',
            'Duplicate submission',
            'Screenshot does not match requirements',
        ] as $reason) {
            if (!RejectTemplate::query()->where('reason', $reason)->exists()) {
                RejectTemplate::query()->create(['reason' => $reason]);
            }
        }
    }
}
