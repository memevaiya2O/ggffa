<?php

namespace Database\Seeders;

use App\Models\Setting;
use Illuminate\Database\Seeder;

class SettingSeeder extends Seeder
{
    public function run(): void
    {
        $settings = [
            'site_name' => 'EarnBD',
            'site_tagline' => 'Earn Real Money Online',
            'site_logo' => '/assets/img/logo.svg',
            'favicon' => '/assets/img/icon.png',
            'admin_email' => 'admin@earnbd.com',
            'contact_email' => 'support@earnbd.com',
            'currency_symbol' => '৳',
            'currency_name' => 'BDT',
            'daily_bonus_amount' => '5',
            'welcome_bonus' => '10',
            'referral_l1_bonus' => '20',
            'referral_l2_bonus' => '5',
            'min_withdraw' => '50',
            'wallet_activation_required' => '1',
            'wallet_activation_min' => '100',
            'deposit_credit_balance' => '1',
            'registration_open' => '1',
            'maintenance_mode' => '0',
            'maintenance_message' => 'Site is under maintenance. Please check back soon.',
            'color_primary' => '#00C896',
            'color_secondary' => '#009688',
            'color_bg' => '#FFFFFF',
            'color_card' => '#F4FBF9',
            'color_text' => '#1A1A2E',
            'color_accent' => '#00E5B0',
            'color_danger' => '#FF4757',
            'color_warning' => '#FFA502',
            'font_family' => 'Nunito',
            'border_radius' => '12',
            'button_style' => 'filled',
            'hero_headline' => 'Earn Real Money Completing Simple Tasks',
            'hero_subtext' => 'Join thousands of users earning daily rewards',
            'hero_cta' => 'Start Earning Now',
            'spin_mode' => 'wheel',
            'google_analytics' => '',
            'meta_title' => '{site_name} - Earn Real Money Online',
            'meta_description' => 'Complete tasks and earn real money in Bangladesh',
            'meta_keywords' => 'earn money online, tasks, rewards',
            'footer_description' => 'The #1 earning platform in Bangladesh. Earn real money by completing simple tasks.',
            'footer_copyright' => '© {year} {site_name}. All rights reserved.',
            'social_facebook' => '#',
            'social_youtube' => '#',
            'social_telegram' => '#',
            'social_twitter' => '#',
            'social_instagram' => '#',
            'howit_1_icon' => 'fa-user-plus',
            'howit_1_title' => 'Register Free',
            'howit_1_desc' => 'Create your free account in seconds',
            'howit_2_icon' => 'fa-list-check',
            'howit_2_title' => 'Complete Tasks',
            'howit_2_desc' => 'Browse and complete available tasks',
            'howit_3_icon' => 'fa-money-bill-transfer',
            'howit_3_title' => 'Get Paid',
            'howit_3_desc' => 'Withdraw earnings to bKash, Nagad & more',
            'custom_header_script' => '',
            'custom_footer_script' => '',
            'og_image' => '',
            'section_stats' => '1',
            'section_howit' => '1',
            'section_tasks' => '1',
            'section_earners' => '1',
            'section_proof' => '1',
            'section_testimonials' => '0',
            'section_faq' => '0',
        ];

        foreach ($settings as $k => $v) {
            Setting::query()->insertOrIgnore(['key' => $k, 'value' => $v, 'group_name' => 'general']);
        }

        // Defaults added by the original runMigrations()
        $grouped = [
            'spin' => ['spin_enabled' => '1', 'spin_daily_limit' => '1', 'spin_cooldown_hours' => '24'],
            'referral' => [
                'referral_enabled' => '1', 'referral_bonus_referrer' => '10', 'referral_bonus_referee' => '5',
                'referral_max_per_user' => '0', 'referral_bonus_on' => 'register', 'referral_min_withdraw' => '0',
            ],
            'leaderboard' => [
                'leaderboard_enabled' => '1', 'leaderboard_period' => 'alltime', 'leaderboard_top_n' => '10',
                'leaderboard_prize_1' => '500', 'leaderboard_prize_2' => '250', 'leaderboard_prize_3' => '100',
            ],
            'maintenance' => [
                'maintenance_mode' => '0', 'maintenance_title' => "We'll Be Back Soon!", 'maintenance_message' => 'Under maintenance.',
                'maintenance_end_time' => '', 'maintenance_allow_admin' => '1',
            ],
        ];
        foreach ($grouped as $group => $pairs) {
            foreach ($pairs as $k => $v) {
                Setting::query()->insertOrIgnore(['key' => $k, 'value' => $v, 'group_name' => $group]);
            }
        }
    }
}
