<?php

namespace Database\Seeders;

use App\Models\SpinPrize;
use Illuminate\Database\Seeder;

class SpinPrizeSeeder extends Seeder
{
    public function run(): void
    {
        foreach ([
            ['BDT 5', 5, 30, '#00C896'],
            ['BDT 10', 10, 25, '#009688'],
            ['BDT 20', 20, 20, '#FFA502'],
            ['BDT 50', 50, 15, '#FF4757'],
            ['BDT 100', 100, 7, '#9C27B0'],
            ['BDT 200', 200, 2.5, '#FFD700'],
            ['BDT 500', 500, 0.5, '#00E5B0'],
        ] as $p) {
            if (!SpinPrize::query()->where('label', $p[0])->exists()) {
                SpinPrize::query()->create([
                    'label' => $p[0], 'amount' => $p[1], 'probability' => $p[2], 'color' => $p[3],
                ]);
            }
        }
    }
}
