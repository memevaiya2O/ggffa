<?php

namespace Database\Seeders;

use App\Models\SpinSegment;
use Illuminate\Database\Seeder;

class SpinSegmentSeeder extends Seeder
{
    public function run(): void
    {
        if (SpinSegment::query()->count() > 0) {
            return;
        }
        foreach ([
            ['Try Again', 'nothing', 0, 30, '#e2e8f0'],
            ['৳5', 'coins', 5, 25, '#4CAF50'],
            ['৳10', 'coins', 10, 20, '#2196F3'],
            ['৳20', 'coins', 20, 13, '#FF9800'],
            ['৳50', 'coins', 50, 7, '#E91E63'],
            ['৳100', 'coins', 100, 3, '#9C27B0'],
            ['৳200', 'bonus', 200, 2, '#FFD700'],
        ] as $s) {
            SpinSegment::query()->create([
                'label' => $s[0], 'prize_type' => $s[1], 'prize_value' => $s[2],
                'weight' => $s[3], 'color' => $s[4],
            ]);
        }
    }
}
