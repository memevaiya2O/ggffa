<?php

namespace Database\Seeders;

use App\Models\TaskCategory;
use Illuminate\Database\Seeder;

class TaskCategorySeeder extends Seeder
{
    public function run(): void
    {
        foreach ([
            ['Social Media', 'fa-share-nodes', '#4267B2', 1],
            ['App Install', 'fa-mobile-screen', '#00C896', 2],
            ['Survey', 'fa-clipboard-list', '#FFA502', 3],
            ['Video Watch', 'fa-play-circle', '#FF4757', 4],
            ['Referral', 'fa-user-plus', '#9C27B0', 5],
        ] as $c) {
            if (!TaskCategory::query()->where('name', $c[0])->exists()) {
                TaskCategory::query()->create([
                    'name' => $c[0], 'icon' => $c[1], 'color' => $c[2], 'sort_order' => $c[3],
                ]);
            }
        }
    }
}
