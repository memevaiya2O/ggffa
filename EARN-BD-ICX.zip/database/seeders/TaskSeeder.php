<?php

namespace Database\Seeders;

use App\Models\Task;
use Illuminate\Database\Seeder;

class TaskSeeder extends Seeder
{
    public function run(): void
    {
        foreach ([
            [1, 'Follow us on Facebook', 'social', 5.00, '1. Go to our Facebook page' . "\n" . '2. Click Follow' . "\n" . '3. Take a screenshot showing you followed', 'Must use real account' . "\n" . 'No fake accounts', 1, 1, 500, 0, 1, 1],
            [2, 'Install & Rate TaskApp', 'app', 15.00, '1. Download TaskApp from Play Store' . "\n" . '2. Install and open it' . "\n" . '3. Give 5-star rating' . "\n" . '4. Screenshot the rating screen', 'Must keep app installed for 7 days' . "\n" . 'Real account only', 1, 1, 200, 1, 0, 1],
            [3, 'Complete Survey #1', 'survey', 20.00, '1. Click the survey link' . "\n" . '2. Complete all questions honestly' . "\n" . '3. Screenshot completion page', 'Must complete in one session', 1, 1, 100, 0, 1, 1],
            [4, 'Watch Promo Video', 'video', 8.00, '1. Watch the full 3-minute video' . "\n" . '2. Do not skip' . "\n" . '3. Screenshot end screen', 'Must watch completely', 1, 3, 1000, 0, 0, 1],
        ] as $t) {
            if (!Task::query()->where('title', $t[1])->exists()) {
                Task::query()->create([
                    'category_id' => $t[0], 'title' => $t[1], 'type' => $t[2], 'reward' => $t[3],
                    'instructions' => $t[4], 'rules' => $t[5], 'screenshot_required' => $t[6],
                    'max_per_user' => $t[7], 'max_total' => $t[8], 'is_featured' => $t[9],
                    'is_hot' => $t[10], 'is_new' => $t[11],
                ]);
            }
        }
    }
}
