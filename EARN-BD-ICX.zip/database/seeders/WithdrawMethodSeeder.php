<?php

namespace Database\Seeders;

use App\Models\WithdrawMethod;
use Illuminate\Database\Seeder;

class WithdrawMethodSeeder extends Seeder
{
    public function run(): void
    {
        foreach ([
            ['bKash', 'fa-mobile-screen-button', 50, '1-24 hours', 'Enter your bKash number'],
            ['Nagad', 'fa-wallet', 50, '1-24 hours', 'Enter your Nagad number'],
            ['Rocket', 'fa-rocket', 50, '1-24 hours', 'Enter your Rocket number'],
            ['USDT (TRC20)', 'fa-coins', 100, '1-48 hours', 'Enter your TRC20 wallet address'],
            ['Bitcoin', 'fa-bitcoin-sign', 500, '24-72 hours', 'Enter your BTC wallet address'],
        ] as $m) {
            if (!WithdrawMethod::query()->where('name', $m[0])->exists()) {
                WithdrawMethod::query()->create([
                    'name' => $m[0], 'icon' => $m[1], 'min_amount' => $m[2],
                    'processing_time' => $m[3], 'instructions' => $m[4],
                ]);
            }
        }
    }
}
