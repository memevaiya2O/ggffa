<?php

namespace Database\Seeders;

use App\Models\WithdrawalMethod;
use Illuminate\Database\Seeder;

class WithdrawalMethodSeeder extends Seeder
{
    public function run(): void
    {
        if (WithdrawalMethod::query()->count() > 0) {
            return;
        }
        foreach ([
            ['bKash', 200, 10000, 0, 'Send to our bKash agent number', 'Account Number,Account Name'],
            ['Nagad', 200, 10000, 0, 'Send to our Nagad number', 'Account Number,Account Name'],
            ['Rocket', 200, 5000, 0, 'Send to our Rocket number', 'Account Number'],
            ['USDT TRC20', 1000, 50000, 1, 'Send to our USDT TRC20 wallet address', 'Wallet Address'],
            ['Bank Transfer', 5000, 100000, 0, 'Bank NPSB transfer', 'Bank Name,Account Number,Account Name,Branch'],
        ] as $m) {
            WithdrawalMethod::query()->create([
                'name' => $m[0], 'min_amount' => $m[1], 'max_amount' => $m[2],
                'charge_pct' => $m[3], 'instructions' => $m[4], 'required_fields' => $m[5],
            ]);
        }
    }
}
