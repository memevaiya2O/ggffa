<!DOCTYPE html>
<html lang="en">
<head>
{!! renderSeoMeta() !!}
{!! renderGoogleFont() !!}
{!! renderCssVars() !!}
<link rel="stylesheet" href="/assets/css/style.css?v=3">
<link rel="stylesheet" href="/assets/css/dashboard.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="app-layout">
  <header class="app-header">
    <div class="app-header-left"><div class="user-name">Achievements</div></div>
    <div class="app-header-right">
      <a href="/notifications" class="notif-btn"><i class="fa-solid fa-bell"></i>@if ($notifCount)<span class="notif-badge">{{ $notifCount }}</span>@endif</a>
    </div>
  </header>
  <main class="main-content">
    <div class="card" style="text-align:center;margin-bottom:20px;">
      <div style="font-size:36px;font-weight:900;color:var(--primary)">{{ $unlockedCount }} / {{ count($achievements) }}</div>
      <div style="color:#888;font-size:14px;margin-top:4px;">Badges Unlocked</div>
      <div class="xp-bar" style="margin-top:12px;"><div class="xp-fill" style="width:{{ count($achievements) ? round($unlockedCount/count($achievements)*100) : 0 }}%"></div></div>
    </div>
    <div class="achievements-grid">
      @foreach ($achievements as $a)
        @php $unlocked = !empty($a['unlocked_at']); @endphp
        <div class="achievement-card {{ $unlocked ? 'unlocked' : 'locked' }}">
          <div class="ach-icon" style="{{ $unlocked ? "color:var(--primary)" : '' }}">
            <i class="fa-solid {{ $a['icon'] }}" style="font-size:36px;"></i>
          </div>
          <h4>{{ $a['name'] }}</h4>
          <p>{{ $a['description'] }}</p>
          @if ($unlocked)
            <div class="ach-check"><i class="fa-solid fa-circle-check"></i> {{ date('M j', strtotime($a['unlocked_at'])) }}</div>
          @else
            <div style="margin-top:8px;font-size:11px;color:#aaa;"><i class="fa-solid fa-lock"></i> Locked</div>
          @endif
        </div>
      @endforeach
    </div>
  </main>
  <nav class="bottom-nav">
    <a href="/dashboard" class="nav-item"><i class="fa-solid fa-house"></i>Home</a>
    <a href="/tasks" class="nav-item"><i class="fa-solid fa-list-check"></i>Tasks</a>
    <a href="/wallet" class="nav-item"><i class="fa-solid fa-wallet"></i>Wallet</a>
    <a href="/leaderboard" class="nav-item"><i class="fa-solid fa-trophy"></i>Board</a>
    <a href="/profile" class="nav-item active"><i class="fa-solid fa-user"></i>Profile</a>
  </nav>
</div>
<script src="/assets/js/main.js"></script>
</body>
</html>
