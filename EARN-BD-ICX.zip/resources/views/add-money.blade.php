<!DOCTYPE html>
<html lang="en">
<head>
{!! renderSeoMeta() !!}
{!! renderGoogleFont() !!}
{!! renderCssVars() !!}
<link rel="stylesheet" href="/assets/css/style.css?v=3">
<link rel="stylesheet" href="/assets/css/dashboard.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
  .dep-card{background:var(--card-bg);border-radius:var(--radius);padding:18px 12px;text-align:center;cursor:pointer;border:2px solid transparent;transition:all .2s}
  .dep-card i{font-size:30px;color:var(--primary);margin-bottom:8px}
  .dep-card h4{font-size:14px;font-weight:700}
  .dep-card.selected{border-color:var(--primary);background:rgba(0,200,150,.06)}
  .send-box{display:none;background:rgba(0,200,150,.07);border:1px dashed var(--primary);border-radius:var(--radius);padding:14px 16px;margin-bottom:16px;font-size:14px;line-height:1.7}
  .send-box .acc{font-size:20px;font-weight:900;letter-spacing:.5px;word-break:break-all}
  .copy-btn{margin-left:8px;border:0;background:var(--primary);color:#fff;border-radius:6px;padding:3px 10px;font-size:12px;font-weight:700;cursor:pointer}
  .wa-banner{border-radius:var(--radius);padding:16px;margin-bottom:20px;font-size:14px;line-height:1.6;font-weight:600}
  .wa-need{background:rgba(255,165,2,.12);color:#b26a00;border:1px solid rgba(255,165,2,.35)}
  .wa-ok{background:rgba(0,200,150,.1);color:var(--primary);border:1px solid rgba(0,200,150,.3)}
  .dep-badge{display:inline-block;padding:3px 10px;border-radius:99px;font-size:11px;font-weight:800}
  .dep-pending{background:rgba(255,165,2,.15);color:#b26a00}
  .dep-approved{background:rgba(0,200,150,.15);color:var(--primary)}
  .dep-rejected{background:rgba(255,71,87,.12);color:var(--danger)}
  .dep-methods{display:grid;grid-template-columns:repeat(2,1fr);gap:12px;margin-bottom:18px}
</style>
</head>
<body>
<div class="app-layout">
  <header class="app-header">
    <div class="app-header-left"><div class="user-name">Add Money</div></div>
    <div class="app-header-right">
      <a href="/notifications" class="notif-btn"><i class="fa-solid fa-bell"></i>@if ($notifCount)<span class="notif-badge">{{ $notifCount }}</span>@endif</a>
    </div>
  </header>
  <main class="main-content">
    @if ($error)<div class="alert alert-error">{{ $error }}</div>@endif
    @if ($success)<div class="alert alert-success">{{ $success }}</div>@endif

    @if ($required && !$walletActive)
      <div class="wa-banner wa-need">
        <i class="fa-solid fa-lock"></i> Your wallet is not active yet.
        Add at least <strong>{{ formatAmount($activationMin) }}</strong> to activate it — you need this once, before your first withdrawal.
      </div>
    @elseif ($required)
      <div class="wa-banner wa-ok"><i class="fa-solid fa-circle-check"></i> Your wallet is active. You can withdraw anytime.</div>
    @endif

    @if ($hasPending)
      <div class="alert alert-error" style="background:rgba(255,165,2,.1);color:#b26a00;border-color:rgba(255,165,2,.3);">
        <i class="fa-solid fa-clock"></i> You have a deposit waiting for approval. You can add another one after it is reviewed.
      </div>
    @elseif (!$methods->count())
      <div style="text-align:center;padding:30px;color:#888;">No payment method is available right now. Please check back later.</div>
    @else
      <h3 style="margin-bottom:14px;font-size:16px;font-weight:800;">1. Choose payment method</h3>
      <div class="dep-methods">
        @foreach ($methods as $m)
          <div class="dep-card" data-id="{{ $m->id }}" data-account="{{ $m->account_number }}" data-type="{{ $m->account_type }}" data-min="{{ $m->min_amount }}" data-note="{{ $m->instructions }}">
            <i class="fa-solid {{ $m->icon ?: 'fa-wallet' }}"></i>
            <h4>{{ $m->name }}</h4>
          </div>
        @endforeach
      </div>

      <form method="post" action="/add-money" id="dep-form" style="display:none;" enctype="multipart/form-data">
        {!! csrfField() !!}
        <input type="hidden" name="method_id" id="dep-method">
        <h3 style="margin-bottom:10px;font-size:16px;font-weight:800;">2. Send money</h3>
        <div class="send-box" id="send-box" style="display:block;">
          Send to this <span id="send-type">Personal</span> number:<br>
          <span class="acc" id="send-acc">—</span>
          <button type="button" class="copy-btn" id="copy-acc">Copy</button>
          <div id="send-note" style="font-size:13px;color:#666;margin-top:6px;"></div>
        </div>

        <h3 style="margin:8px 0 10px;font-size:16px;font-weight:800;">3. Submit details</h3>
        <div class="form-group">
          <label class="form-label">Amount</label>
          <div class="input-group">
            <i class="input-icon fa-solid fa-coins"></i>
            <input type="number" name="amount" class="form-control" placeholder="Amount you sent" step="0.01" min="1" value="{{ $required && !$walletActive ? $minNow : '' }}" required>
          </div>
          <p style="font-size:12px;color:#888;margin-top:6px;">Minimum: <strong id="dep-min">{{ formatAmount($minNow) }}</strong></p>
        </div>
        <div class="form-group">
          <label class="form-label">Your number (sent from)</label>
          <div class="input-group">
            <i class="input-icon fa-solid fa-phone"></i>
            <input type="text" name="sender_number" class="form-control" placeholder="01XXXXXXXXX" maxlength="64" required>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Transaction ID (TrxID)</label>
          <div class="input-group">
            <i class="input-icon fa-solid fa-hashtag"></i>
            <input type="text" name="transaction_id" class="form-control" placeholder="e.g. 9A7B6C5D4E" maxlength="128" required>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Payment Screenshot</label>
          <div class="input-group">
            <i class="input-icon fa-solid fa-image"></i>
            <input type="file" name="screenshot" class="form-control" accept="image/png,image/jpeg,image/webp" required>
          </div>
          <p style="font-size:12px;color:#888;margin-top:6px;">Upload a screenshot of your Send Money confirmation (JPG/PNG, max 2MB).</p>
        </div>
        <button type="submit" class="btn btn-primary btn-block btn-lg"><i class="fa-solid fa-paper-plane"></i> Submit Deposit</button>
      </form>
    @endif

    @if ($history->count())
    <h3 style="margin:24px 0 14px;font-size:16px;font-weight:800;">Deposit History</h3>
    @foreach ($history as $d)
      <div class="withdraw-item">
        <div class="withdraw-icon"><i class="fa-solid {{ $d->method_icon ?: 'fa-wallet' }}"></i></div>
        <div class="withdraw-info">
          <div class="withdraw-method">{{ $d->method_name ?? 'Unknown' }}</div>
          <div class="withdraw-addr">TrxID: {{ $d->transaction_id }}</div>
          @if ($d->status === 'rejected' && $d->admin_note)<div class="withdraw-addr" style="color:var(--danger)">{{ $d->admin_note }}</div>@endif
        </div>
        <div class="withdraw-right">
          <div class="withdraw-amount">{{ formatAmount((float)$d->amount) }}</div>
          <span class="dep-badge dep-{{ $d->status }}">{{ ucfirst($d->status) }}</span>
          <div class="withdraw-date">{{ date('M j, Y', strtotime($d->created_at)) }}</div>
        </div>
      </div>
    @endforeach
    @endif
  </main>
  <nav class="bottom-nav">
    <a href="/dashboard" class="nav-item"><i class="fa-solid fa-house"></i>Home</a>
    <a href="/tasks" class="nav-item"><i class="fa-solid fa-list-check"></i>Tasks</a>
    <a href="/wallet" class="nav-item active"><i class="fa-solid fa-wallet"></i>Wallet</a>
    <a href="/leaderboard" class="nav-item"><i class="fa-solid fa-trophy"></i>Board</a>
    <a href="/profile" class="nav-item"><i class="fa-solid fa-user"></i>Profile</a>
  </nav>
</div>
<div id="toast-container"></div>
<script src="/assets/js/main.js"></script>
<script>
(function () {
  var cards = document.querySelectorAll('.dep-card');
  var form = document.getElementById('dep-form');
  if (!cards.length || !form) return;
  cards.forEach(function (c) {
    c.addEventListener('click', function () {
      cards.forEach(function (x) { x.classList.remove('selected'); });
      c.classList.add('selected');
      document.getElementById('dep-method').value = c.dataset.id;
      document.getElementById('send-acc').textContent = c.dataset.account || '—';
      document.getElementById('send-type').textContent = c.dataset.type || 'Personal';
      document.getElementById('send-note').textContent = c.dataset.note || '';
      form.style.display = 'block';
      form.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  });
  var copy = document.getElementById('copy-acc');
  if (copy) copy.addEventListener('click', function () {
    var t = document.getElementById('send-acc').textContent;
    if (navigator.clipboard) navigator.clipboard.writeText(t);
    copy.textContent = 'Copied';
    setTimeout(function () { copy.textContent = 'Copy'; }, 1500);
  });
})();
</script>
</body>
</html>
