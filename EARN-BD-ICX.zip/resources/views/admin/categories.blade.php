@include('admin.partials-header')
@if ($flash)<div class="alert alert-success" style="margin-bottom:20px;">{{ $flash }}</div>@endif
@if ($flashErr)<div class="alert alert-error" style="margin-bottom:20px;">{{ $flashErr }}</div>@endif
<div style="display:grid;grid-template-columns:1fr 340px;gap:24px;">
  <div class="admin-card">
    <div class="admin-card-header"><div class="admin-card-title">Categories</div></div>
    <div class="admin-table-wrap">
      <table class="admin-table">
        <thead><tr><th>☰</th><th>Category</th><th>Tasks</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody id="sortable-cats">
          @foreach ($cats as $c)
            <tr data-id="{{ $c['id'] }}">
              <td><span class="drag-handle"><i class="fa-solid fa-grip-lines"></i></span></td>
              <td>
                <div style="display:flex;align-items:center;gap:10px;">
                  <div style="width:40px;height:40px;border-radius:10px;background:{{ $c['color'] }}22;display:flex;align-items:center;justify-content:center;color:{{ $c['color'] }};font-size:18px;">
                    <i class="fa-solid {{ $c['icon'] }}"></i>
                  </div>
                  <div style="font-weight:700">{{ $c['name'] }}</div>
                </div>
              </td>
              <td>{{ $c['task_count'] }}</td>
              <td><span class="status-badge status-{{ $c['status'] }}">{{ ucfirst($c['status']) }}</span></td>
              <td>
                <div class="action-btns">
                  <button class="action-btn-sm action-btn-edit" onclick="editCat({!! h(json_encode($c)) !!})"><i class="fa-solid fa-pen"></i></button>
                  <form method="post" style="display:inline">{!! csrfField() !!}<input type="hidden" name="action" value="delete"><input type="hidden" name="cat_id" value="{{ $c['id'] }}"><button type="submit" class="action-btn-sm action-btn-delete" data-confirm="Delete this category?"><i class="fa-solid fa-trash"></i></button></form>
                </div>
              </td>
            </tr>
          @endforeach
        </tbody>
      </table>
    </div>
  </div>
  <div class="admin-card" id="cat-form-card">
    <div class="admin-card-title" style="margin-bottom:20px;" id="cat-form-title">Add Category</div>
    <form method="post" id="cat-form">
      {!! csrfField() !!}
      <input type="hidden" name="action" id="cat-action" value="add">
      <input type="hidden" name="cat_id" id="cat-id" value="0">
      <div class="admin-form-group"><label class="admin-label">Name *</label><input type="text" name="name" id="cat-name" class="admin-input" required></div>
      <div class="admin-form-group"><label class="admin-label">Font Awesome Icon Class</label><input type="text" name="icon" id="cat-icon" class="admin-input" placeholder="fa-tag" value="fa-tag"><div style="margin-top:8px;font-size:24px;"><i class="fa-solid fa-tag" id="icon-preview"></i></div></div>
      <div class="admin-form-group">
        <label class="admin-label">Color</label>
        <div class="color-picker-wrap"><input type="color" name="color" id="cat-color" value="#00C896"><input type="text" id="cat-color-text" value="#00C896" style="width:100px;padding:8px;border:2px solid #e8e8e8;border-radius:6px;font-family:monospace;font-size:13px;"></div>
      </div>
      <div class="admin-form-group"><label class="admin-label">Status</label><select name="status" id="cat-status" class="admin-input"><option value="active">Active</option><option value="inactive">Inactive</option></select></div>
      <button type="submit" class="btn btn-primary btn-block">Save Category</button>
      <button type="button" class="btn btn-outline btn-block" style="margin-top:8px;" onclick="resetCatForm()">Reset</button>
    </form>
  </div>
</div>
@php
$extraJs = '<script>
function editCat(c) {
  document.getElementById("cat-action").value="edit";
  document.getElementById("cat-id").value=c.id;
  document.getElementById("cat-name").value=c.name;
  document.getElementById("cat-icon").value=c.icon;
  document.getElementById("cat-color").value=c.color;
  document.getElementById("cat-color-text").value=c.color;
  document.getElementById("cat-status").value=c.status;
  document.getElementById("cat-form-title").textContent="Edit: "+c.name;
  document.getElementById("icon-preview").className="fa-solid "+c.icon;
  document.getElementById("cat-form-card").scrollIntoView({behavior:"smooth"});
}
function resetCatForm() {
  document.getElementById("cat-action").value="add";
  document.getElementById("cat-id").value="0";
  document.getElementById("cat-form").reset();
  document.getElementById("cat-form-title").textContent="Add Category";
}
document.getElementById("cat-icon").addEventListener("input", function() {
  document.getElementById("icon-preview").className="fa-solid "+this.value;
});
initSortable("sortable-cats","/Icxpanel/categories");
</script>';
@endphp
@include('admin.partials-footer', ['extraJs' => $extraJs])
