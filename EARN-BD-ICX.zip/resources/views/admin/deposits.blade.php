@include('admin.partials-header')
@if ($flash)<div class="alert alert-success" style="margin-bottom:20px;">{{ $flash }}</div>@endif
<style>
  .dep-top{display:grid;grid-template-columns:1fr 1fr;gap:24px;align-items:start;margin-bottom:24px}
  .dep-top .admin-card{margin-bottom:0!important}
  .dep-table{min-width:1180px}
  .dep-proof{width:64px;height:64px;object-fit:cover;border-radius:8px;border:1px solid #e5e5e5;cursor:zoom-in;display:block}
  .dep-noproof{font-size:12px;color:#bbb}
  .dep-user-line{font-size:12px;color:#666;margin-top:2px}
  .dep-lightbox{position:fixed;inset:0;background:rgba(0,0,0,.85);z-index:9999;display:none;align-items:center;justify-content:center;padding:24px;cursor:zoom-out}
  .dep-lightbox img{max-width:92vw;max-height:92vh;border-radius:10px;background:#fff}
  @media (max-width:1100px){.dep-top{grid-template-columns:1fr}}
</style>

<div class="kpi-grid" style="margin-bottom:20px;">
  <div class="kpi-card"><div class="kpi-icon orange"><i class="fa-solid fa-clock"></i></div><div class="kpi-body"><div class="kpi-label">Pending Deposits</div><div class="kpi-value">{{ formatAmount($pendingSum) }}</div></div></div>
  <div class="kpi-card"><div class="kpi-icon green"><i class="fa-solid fa-circle-check"></i></div><div class="kpi-body"><div class="kpi-label">Approved Total</div><div class="kpi-value">{{ formatAmount($approvedSum) }}</div></div></div>
</div>

<div class="dep-top">
<div class="admin-card" style="margin-bottom:24px;">
  <div class="admin-card-header"><div class="admin-card-title">Wallet Activation Settings</div></div>
  <div class="admin-card-body">
    <form method="post" action="/Icxpanel/deposits">
      {!! csrfField() !!}
      <input type="hidden" name="action" value="save_settings">
      <div class="form-group" style="display:flex;align-items:center;gap:12px;">
        <label class="toggle-switch"><input type="checkbox" name="wallet_activation_required" value="1" {{ getSetting('wallet_activation_required','1')==='1'?'checked':'' }}><span class="toggle-slider"></span></label>
        <span><strong>Require wallet activation before first withdrawal</strong><br><small style="color:#888;">When off, every user can withdraw without adding money.</small></span>
      </div>
      <div class="form-group">
        <label>Minimum amount to activate wallet ({{ getSetting('currency_name','BDT') }})</label>
        <input type="number" name="wallet_activation_min" class="form-control" step="0.01" min="0" value="{{ getSetting('wallet_activation_min','100') }}" style="max-width:240px;">
        <small style="color:#888;">The user's approved deposits must add up to at least this amount.</small>
      </div>
      <div class="form-group" style="display:flex;align-items:center;gap:12px;">
        <label class="toggle-switch"><input type="checkbox" name="deposit_credit_balance" value="1" {{ getSetting('deposit_credit_balance','1')==='1'?'checked':'' }}><span class="toggle-slider"></span></label>
        <span><strong>Add the approved deposit to the user's balance</strong><br><small style="color:#888;">When off, the deposit only activates the wallet (works like an activation fee).</small></span>
      </div>
      <button class="btn btn-primary" type="submit">Save Settings</button>
    </form>
  </div>
</div>

@php $__tgToken = trim(getSetting('telegram_bot_token')) ?: trim((string) config('services.telegram.token')); @endphp
<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title"><i class="fa-brands fa-telegram" style="color:#229ED9"></i> Telegram Bot — Deposit &amp; Task Alerts</div></div>
  <div class="admin-card-body">
    <form method="post" action="/Icxpanel/deposits">
      {!! csrfField() !!}
      <input type="hidden" name="action" value="save_telegram">
      <div class="form-group" style="display:flex;align-items:center;gap:12px;">
        <label class="toggle-switch"><input type="checkbox" name="telegram_enabled" value="1" {{ getSetting('telegram_enabled','1')==='1'?'checked':'' }}><span class="toggle-slider"></span></label>
        <span><strong>Alert me on every new deposit</strong><br><small style="color:#888;">User details, amount, TrxID and the payment screenshot.</small></span>
      </div>
      <div class="form-group" style="display:flex;align-items:center;gap:12px;">
        <label class="toggle-switch"><input type="checkbox" name="telegram_notify_tasks" value="1" {{ getSetting('telegram_notify_tasks','1')==='1'?'checked':'' }}><span class="toggle-slider"></span></label>
        <span><strong>Alert me on every task submission</strong><br><small style="color:#888;">User details, task, reward and the proof screenshot.</small></span>
      </div>
      <div class="form-group">
        <label>Bot Token <small style="color:#888;">(from @BotFather)</small></label>
        <input type="password" name="telegram_bot_token" class="form-control" autocomplete="new-password" placeholder="{{ $__tgToken !== '' ? 'Saved ✔ — leave blank to keep it' : '123456789:AA…' }}">
        @if (trim(getSetting('telegram_bot_token')) !== '')<label style="font-size:12px;display:block;margin-top:6px;"><input type="checkbox" name="clear_telegram_token" value="1"> Remove saved token</label>@endif
      </div>
      <div class="form-group">
        <label>Chat ID <small style="color:#888;">(your chat or group; separate several with commas)</small></label>
        <input type="text" name="telegram_chat_id" class="form-control" value="{{ trim(getSetting('telegram_chat_id')) !== '' ? getSetting('telegram_chat_id') : config('services.telegram.chat_id') }}" placeholder="123456789">
      </div>
      <button class="btn btn-primary" type="submit">Save Telegram</button>
    </form>
    <form method="post" action="/Icxpanel/deposits" style="margin-top:10px;">
      {!! csrfField() !!}<input type="hidden" name="action" value="telegram_test">
      <button class="btn btn-outline" type="submit"><i class="fa-solid fa-paper-plane"></i> Send test message</button>
    </form>
  </div>
</div>
</div><!-- /dep-top -->

<div class="admin-card">
  <div class="admin-card-header">
    <div class="admin-card-title">Deposits ({{ $total }})</div>
    <a href="/Icxpanel/deposit-methods" class="btn btn-sm btn-outline"><i class="fa-solid fa-wallet"></i> Payment Accounts</a>
  </div>
  <div class="admin-filters">
    @foreach (['pending'=>'⏳ Pending','approved'=>'✅ Approved','rejected'=>'❌ Rejected','all'=>'All'] as $k => $v)
      <a href="/Icxpanel/deposits?status={{ $k }}" class="filter-btn {{ $status===$k?'filter-btn-primary':'filter-btn-outline' }}">{{ $v }}</a>
    @endforeach
  </div>
  <div class="admin-table-wrap">
    <table class="admin-table dep-table">
      <thead><tr><th>User</th><th>Method</th><th>Sent From</th><th>TrxID</th><th>Amount</th><th>Proof</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead>
      <tbody>
        @foreach ($deposits as $d)
        <tr>
          <td><div class="user-cell"><div class="table-avatar">{{ strtoupper(substr($d->user_name,0,1)) }}</div><div><div class="user-cell-name">{{ $d->user_name }}</div><div class="user-cell-email">{{ $d->user_email }}</div><div class="dep-user-line"><i class="fa-solid fa-phone"></i> {{ $d->user_phone ?: '—' }} · ID #{{ $d->user_id }}</div></div></div></td>
          <td><i class="fa-solid {{ $d->method_icon ?: 'fa-wallet' }}" style="color:var(--primary)"></i> {{ $d->method_name ?? '—' }}</td>
          <td style="font-family:monospace;font-size:13px;">{{ $d->sender_number }}</td>
          <td style="font-family:monospace;font-size:13px;">{{ $d->transaction_id }}</td>
          <td style="font-weight:900;font-size:16px;">{{ formatAmount((float)$d->amount) }}</td>
          <td>@if ($d->screenshot)<img src="{{ $d->screenshot }}" class="dep-proof" data-full="{{ $d->screenshot }}" alt="Payment proof" title="Click to enlarge">@else<span class="dep-noproof">No screenshot</span>@endif</td>
          <td>
            <span class="status-badge status-{{ $d->status }}">{{ ucfirst($d->status) }}</span>
            @if ($d->admin_note)<div style="font-size:11px;color:#888;margin-top:4px;">{{ mb_substr($d->admin_note,0,40) }}</div>@endif
            @if ($d->status==='approved' && $d->wallet_active)<div style="font-size:11px;color:var(--primary);margin-top:4px;">Wallet active</div>@endif
          </td>
          <td style="font-size:12px;color:#888">{{ date('M j, Y g:ia',strtotime($d->created_at)) }}</td>
          <td>
            @if ($d->status === 'pending')
              <form method="post" action="/Icxpanel/deposits?status={{ $status }}" style="display:inline" onsubmit="return confirm('Approve this deposit?')">
                {!! csrfField() !!}<input type="hidden" name="action" value="approve"><input type="hidden" name="id" value="{{ $d->id }}">
                <button class="btn btn-success btn-xs"><i class="fa-solid fa-check"></i> Approve</button>
              </form>
              <form method="post" action="/Icxpanel/deposits?status={{ $status }}" style="display:inline" onsubmit="var n=prompt('Reason for rejection (shown to user):','Payment could not be verified.'); if(n===null) return false; this.note.value=n; return true;">
                {!! csrfField() !!}<input type="hidden" name="action" value="reject"><input type="hidden" name="id" value="{{ $d->id }}"><input type="hidden" name="note" value="">
                <button class="btn btn-danger btn-xs"><i class="fa-solid fa-xmark"></i> Reject</button>
              </form>
            @else — @endif
          </td>
        </tr>
        @endforeach
        @if (!$deposits->count())<tr><td colspan="9" style="text-align:center;color:#888;">No deposits found.</td></tr>@endif
      </tbody>
    </table>
  </div>
  {!! paginationLinks($total,$page,$limit,'/Icxpanel/deposits?status='.$status) !!}
</div>
<div class="dep-lightbox" id="dep-lightbox"><img src="" alt="Payment proof"></div>
<script>
(function(){
  var box=document.getElementById('dep-lightbox'); if(!box) return; var img=box.querySelector('img');
  document.querySelectorAll('.dep-proof').forEach(function(t){t.addEventListener('click',function(){img.src=t.dataset.full;box.style.display='flex';});});
  box.addEventListener('click',function(){box.style.display='none';img.src='';});
  document.addEventListener('keydown',function(e){if(e.key==='Escape'){box.style.display='none';}});
})();
</script>
@include('admin.partials-footer')
