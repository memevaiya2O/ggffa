@include('admin.partials-header')
<!-- KPI Row 1 -->
<div class="kpi-grid">
  <div class="kpi-card"><div class="kpi-icon green"><i class="fa-solid fa-users"></i></div><div class="kpi-body"><div class="kpi-label">Total Users</div><div class="kpi-value">{{ number_format($totalUsers) }}</div><div class="kpi-sub">Today: +{{ $todayUsers }}</div></div></div>
  <div class="kpi-card"><div class="kpi-icon blue"><i class="fa-solid fa-user-clock"></i></div><div class="kpi-body"><div class="kpi-label">Active (7d)</div><div class="kpi-value">{{ number_format($activeUsers) }}</div></div></div>
  <div class="kpi-card"><div class="kpi-icon red"><i class="fa-solid fa-user-slash"></i></div><div class="kpi-body"><div class="kpi-label">Banned</div><div class="kpi-value">{{ number_format($bannedUsers) }}</div></div></div>
  <div class="kpi-card"><div class="kpi-icon orange"><i class="fa-solid fa-inbox"></i></div><div class="kpi-body"><div class="kpi-label">Pending Subs</div><div class="kpi-value">{{ number_format($pendingSubs) }}</div><div class="kpi-sub">Today: {{ $todayApproved }} approved</div></div></div>
  <div class="kpi-card"><div class="kpi-icon green"><i class="fa-solid fa-list-check"></i></div><div class="kpi-body"><div class="kpi-label">Total Tasks</div><div class="kpi-value">{{ number_format($totalTasks) }}</div><div class="kpi-sub">{{ $totalCats }} categories</div></div></div>
  <div class="kpi-card"><div class="kpi-icon orange"><i class="fa-solid fa-clock"></i></div><div class="kpi-body"><div class="kpi-label">Pending Withdrawals</div><div class="kpi-value">{{ number_format($pendingWith) }}</div><div class="kpi-sub">Today: {{ $todayPaid }} paid</div></div></div>
  <div class="kpi-card"><div class="kpi-icon green"><i class="fa-solid fa-sack-dollar"></i></div><div class="kpi-body"><div class="kpi-label">Total Payout</div><div class="kpi-value">{{ getSetting('currency_symbol','৳') }}{{ number_format($totalPayout,0) }}</div></div></div>
  <div class="kpi-card"><div class="kpi-icon purple"><i class="fa-solid fa-piggy-bank"></i></div><div class="kpi-body"><div class="kpi-label">Balance in System</div><div class="kpi-value">{{ getSetting('currency_symbol','৳') }}{{ number_format($totalBalance,0) }}</div></div></div>
</div>

<!-- Charts -->
<div class="charts-grid">
  <div class="chart-card"><h3>New Users (12 Months)</h3><div style="height:220px"><canvas id="usersChart"></canvas></div></div>
  <div class="chart-card"><h3>Total Payout (12 Months)</h3><div style="height:220px"><canvas id="payoutChart"></canvas></div></div>
</div>

<!-- Recent Records -->
<div style="display:grid;grid-template-columns:1fr 1fr;gap:24px;margin-bottom:24px;">
  <!-- Top Earners -->
  <div class="admin-card">
    <div class="admin-card-header"><div class="admin-card-title">Top Earners This Month</div></div>
    <div class="admin-table-wrap">
      <table class="admin-table">
        <thead><tr><th>#</th><th>User</th><th>Earned</th></tr></thead>
        <tbody>
          @foreach ($topMonth as $i => $u)
            <tr><td>{{ $i+1 }}</td><td>{{ $u['name'] }}</td><td style="color:var(--primary);font-weight:700">{{ getSetting('currency_symbol','৳') }}{{ number_format($u['earned'],2) }}</td></tr>
          @endforeach
        </tbody>
      </table>
    </div>
  </div>
  <!-- Recent Registrations -->
  <div class="admin-card">
    <div class="admin-card-header"><div class="admin-card-title">Recent Registrations</div><a href="/Icxpanel/users" class="btn btn-sm btn-outline">View All</a></div>
    <div class="admin-table-wrap">
      <table class="admin-table">
        <thead><tr><th>User</th><th>Level</th><th>Joined</th></tr></thead>
        <tbody>
          @foreach ($recentUsers as $u)
            <tr>
              <td><div class="user-cell"><div class="table-avatar">{{ strtoupper(substr($u['name'],0,1)) }}</div><div class="user-cell-info"><div class="user-cell-name">{{ $u['name'] }}</div><div class="user-cell-email">{{ $u['email'] }}</div></div></div></td>
              <td><span class="badge badge-info" style="background:{{ $u['level_color']??'#CD7F32' }}22;color:{{ $u['level_color']??'#CD7F32' }}">{{ $u['level_name']??'Bronze' }}</span></td>
              <td style="font-size:12px;color:#888">{{ date('M j',strtotime($u['created_at'])) }}</td>
            </tr>
          @endforeach
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Recent Submissions + Withdrawals -->
<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">Recent Submissions</div><a href="/Icxpanel/submissions" class="btn btn-sm btn-outline">View All</a></div>
  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>User</th><th>Task</th><th>Status</th><th>Time</th></tr></thead>
      <tbody>
        @foreach ($recentSubs as $s)
          <tr>
            <td>{{ $s['user_name'] }}</td>
            <td>{{ $s['task_title'] }}</td>
            <td><span class="status-badge status-{{ $s['status'] }}">{{ ucfirst($s['status']) }}</span></td>
            <td style="font-size:12px;color:#888">{{ timeAgo($s['created_at']) }}</td>
          </tr>
        @endforeach
      </tbody>
    </table>
  </div>
</div>

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">Recent Withdrawals</div><a href="/Icxpanel/withdrawals" class="btn btn-sm btn-outline">View All</a></div>
  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>User</th><th>Method</th><th>Amount</th><th>Status</th><th>Date</th></tr></thead>
      <tbody>
        @foreach ($recentWith as $w)
          <tr>
            <td>{{ $w['user_name'] }}</td>
            <td>{{ $w['method_name'] }}</td>
            <td style="font-weight:700">{{ getSetting('currency_symbol','৳') }}{{ number_format($w['amount'],2) }}</td>
            <td><span class="status-badge status-{{ $w['status'] }}">{{ ucfirst($w['status']) }}</span></td>
            <td style="font-size:12px;color:#888">{{ timeAgo($w['created_at']) }}</td>
          </tr>
        @endforeach
      </tbody>
    </table>
  </div>
</div>

@php
$extraJs = '<script>
createLineChart("usersChart",' . json_encode(array_column($monthlyUsers->all(),'month')) . ',' . json_encode(array_map(fn($r)=>(int)$r["cnt"],$monthlyUsers->all())) . ',"New Users");
createBarChart("payoutChart",' . json_encode(array_column($monthlyPayout->all(),'month')) . ',' . json_encode(array_map(fn($r)=>(float)$r["total"],$monthlyPayout->all())) . ',"Payout");
</script>';
@endphp
@include('admin.partials-footer', ['extraJs' => $extraJs])
