@include('admin.partials-header')
@php $g = fn($k,$d='') => $s[$k] ?? $d; @endphp
@if ($flash)<div class="alert alert-success" style="margin-bottom:20px;">{{ $flash }}</div>@endif

<div class="admin-grid-2" style="display:grid;grid-template-columns:320px 1fr;gap:24px;">

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">Leaderboard Settings</div></div>
  <div class="admin-card-body">
    <form method="post">
      {!! csrfField() !!}
      <div class="form-group">
        <label>Enabled</label>
        <select name="leaderboard_enabled" class="form-control">
          <option value="1" {{ $g('leaderboard_enabled','1')==='1'?'selected':'' }}>Yes</option>
          <option value="0" {{ $g('leaderboard_enabled','1')==='0'?'selected':'' }}>No</option>
        </select>
      </div>
      <div class="form-group">
        <label>Default Period</label>
        <select name="leaderboard_period" class="form-control">
          @foreach (['alltime'=>'All Time','month'=>'Monthly','week'=>'Weekly','today'=>'Daily'] as $v => $l)
          <option value="{{ $v }}" {{ $g('leaderboard_period','alltime')===$v?'selected':'' }}>{{ $l }}</option>
          @endforeach
        </select>
      </div>
      <div class="form-group">
        <label>Display Top N Users</label>
        <input type="number" name="leaderboard_top_n" class="form-control" value="{{ $g('leaderboard_top_n','10') }}" min="5" max="100">
      </div>
      <div class="form-group"><label>🥇 1st Prize (BDT)</label><input type="number" name="leaderboard_prize_1" class="form-control" value="{{ $g('leaderboard_prize_1','500') }}" step="0.01" min="0"></div>
      <div class="form-group"><label>🥈 2nd Prize (BDT)</label><input type="number" name="leaderboard_prize_2" class="form-control" value="{{ $g('leaderboard_prize_2','250') }}" step="0.01" min="0"></div>
      <div class="form-group"><label>🥉 3rd Prize (BDT)</label><input type="number" name="leaderboard_prize_3" class="form-control" value="{{ $g('leaderboard_prize_3','100') }}" step="0.01" min="0"></div>
      <button class="btn btn-primary">Save</button>
    </form>
  </div>
</div>

<div class="admin-card">
  <div class="admin-card-header">
    <div class="admin-card-title">Live Rankings</div>
    <div style="display:flex;gap:8px;">
      @foreach (['alltime'=>'All Time','month'=>'Month','week'=>'Week','today'=>'Today'] as $v => $l)
      <a href="?period={{ $v }}" class="btn btn-xs {{ $period===$v?'btn-primary':'btn-secondary' }}">{{ $l }}</a>
      @endforeach
    </div>
  </div>
  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>Rank</th><th>User</th><th>Level</th><th>Earned (BDT)</th></tr></thead>
      <tbody>
        @foreach ($leaders as $i => $u)
          @php $medal = $i===0?'🥇':($i===1?'🥈':($i===2?'🥉':'')); @endphp
        <tr>
          <td><strong>{{ $medal !== '' ? $medal : ($i+1) }}</strong></td>
          <td><a href="/Icxpanel/user-detail?id={{ $u['id'] }}">{{ $u['name'] }}</a></td>
          <td>@if ($u['level_name'])<span class="badge" style="background:{{ $u['level_color'] }}">{{ $u['level_name'] }}</span>@endif</td>
          <td>৳{{ number_format($u['earned'],2) }}</td>
        </tr>
        @endforeach
        @if (!$leaders->count())<tr><td colspan="4" style="text-align:center;color:#888;">No data.</td></tr>@endif
      </tbody>
    </table>
  </div>
</div>

</div>
@include('admin.partials-footer')
