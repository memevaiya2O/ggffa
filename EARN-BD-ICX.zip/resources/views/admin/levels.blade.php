@include('admin.partials-header')
@if ($flash)<div class="alert alert-success" style="margin-bottom:20px;">{{ $flash }}</div>@endif
<div class="admin-card">
  <div class="admin-card-header">
    <div class="admin-card-title">Levels</div>
    <form method="post" style="display:inline">{!! csrfField() !!}<input type="hidden" name="action" value="add"><button type="submit" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Add Level</button></form>
  </div>
  <form method="post">
    {!! csrfField() !!}
    <input type="hidden" name="action" value="save_all">
    <div class="admin-table-wrap">
      <table class="admin-table">
        <thead><tr><th>Name</th><th>Icon</th><th>Color</th><th>Required Points</th><th>Levelup Bonus</th><th>Daily Withdraw Limit</th><th>VIP Access</th><th></th></tr></thead>
        <tbody>
          @foreach ($levels as $i => $lv)
            <tr>
              <td><input type="hidden" name="level_id[]" value="{{ $lv['id'] }}"><input type="text" name="name[{{ $i }}]" class="admin-input" value="{{ $lv['name'] }}" style="width:130px;"></td>
              <td><input type="text" name="icon[{{ $i }}]" class="admin-input" value="{{ $lv['icon'] }}" style="width:110px;"></td>
              <td><div class="color-picker-wrap"><input type="color" name="color[{{ $i }}]" value="{{ $lv['color'] }}"></div></td>
              <td><input type="number" name="required_points[{{ $i }}]" class="admin-input" value="{{ $lv['required_points'] }}" style="width:110px;"></td>
              <td><input type="number" name="levelup_bonus[{{ $i }}]" class="admin-input" step="0.01" value="{{ $lv['levelup_bonus'] }}" style="width:100px;"></td>
              <td><input type="number" name="daily_withdraw_limit[{{ $i }}]" class="admin-input" step="0.01" value="{{ $lv['daily_withdraw_limit'] }}" style="width:110px;"></td>
              <td><label class="toggle-label"><span class="toggle-switch"><input type="checkbox" name="can_access_vip[{{ $i }}]" value="1" {{ $lv['can_access_vip']?'checked':'' }}><span class="toggle-slider"></span></span></label></td>
              <td>
                <button type="submit" form="del-{{ $lv['id'] }}" class="action-btn-sm action-btn-delete" data-confirm="Delete this level?"><i class="fa-solid fa-trash"></i></button>
              </td>
            </tr>
          @endforeach
        </tbody>
      </table>
    </div>
    <div style="padding:16px;">
      <button type="submit" class="btn btn-primary"><i class="fa-solid fa-save"></i> Save All</button>
    </div>
  </form>
  @foreach ($levels as $lv)
    <form method="post" id="del-{{ $lv['id'] }}" style="display:none">{!! csrfField() !!}<input type="hidden" name="action" value="delete"><input type="hidden" name="level_id_del" value="{{ $lv['id'] }}"></form>
  @endforeach
</div>
@include('admin.partials-footer')
