@include('admin.partials-header')
@php $g = fn($k,$d='') => $s[$k] ?? $d; @endphp
@if ($flash)<div class="alert alert-success" style="margin-bottom:20px;">{{ $flash }}</div>@endif
@if ($g('maintenance_mode')==='1')
<div class="alert alert-warning" style="margin-bottom:20px;">⚠️ <strong>Maintenance mode is currently ACTIVE.</strong> Users see the maintenance page.</div>
@endif

<div class="admin-grid-2" style="display:grid;grid-template-columns:1fr 1fr;gap:24px;">

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">🔧 Maintenance Settings</div></div>
  <div class="admin-card-body">
    <form method="post">
      {!! csrfField() !!}
      <input type="hidden" name="action" value="save">
      <div class="form-group">
        <label>Maintenance Mode</label>
        <select name="maintenance_mode" class="form-control">
          <option value="0" {{ $g('maintenance_mode','0')==='0'?'selected':'' }}>Off — Site is Live</option>
          <option value="1" {{ $g('maintenance_mode','0')==='1'?'selected':'' }}>ON — Under Maintenance</option>
        </select>
      </div>
      <div class="form-group">
        <label>Allow Admin Access During Maintenance</label>
        <select name="maintenance_allow_admin" class="form-control">
          <option value="1" {{ $g('maintenance_allow_admin','1')==='1'?'selected':'' }}>Yes (admins can log in)</option>
          <option value="0" {{ $g('maintenance_allow_admin','1')==='0'?'selected':'' }}>No (full lockdown)</option>
        </select>
      </div>
      <div class="form-group">
        <label>Maintenance Title</label>
        <input type="text" name="maintenance_title" class="form-control" value="{{ $g('maintenance_title',"We'll Be Back Soon!") }}">
      </div>
      <div class="form-group">
        <label>Maintenance Message</label>
        <textarea name="maintenance_message" class="form-control" rows="4">{{ $g('maintenance_message','We are currently performing scheduled maintenance. Please check back later.') }}</textarea>
      </div>
      <div class="form-group">
        <label>Expected End Time (optional)</label>
        <input type="datetime-local" name="maintenance_end_time" class="form-control" value="{{ $g('maintenance_end_time') }}">
      </div>
      <button class="btn btn-primary">Save Settings</button>
    </form>
  </div>
</div>

<div>
  <div class="admin-card" style="margin-bottom:20px;">
    <div class="admin-card-header"><div class="admin-card-title">📊 Database Stats</div></div>
    <div class="admin-card-body">
      <table style="width:100%;border-collapse:collapse;">
        @foreach ($dbStats as $table => $count)
        <tr style="border-bottom:1px solid #f0f0f0;">
          <td style="padding:8px 0;font-weight:500;">{{ ucfirst($table) }}</td>
          <td style="padding:8px 0;text-align:right;color:#667eea;font-weight:700;">{{ number_format($count) }} rows</td>
        </tr>
        @endforeach
      </table>
    </div>
  </div>

  <div class="admin-card">
    <div class="admin-card-header"><div class="admin-card-title">🛠 Tools</div></div>
    <div class="admin-card-body" style="display:flex;flex-direction:column;gap:12px;">
      <form method="post" onsubmit="return confirm('Clear sessions older than 24h?')">
        {!! csrfField() !!}<input type="hidden" name="action" value="clear_cache">
        <button class="btn btn-secondary" style="width:100%;text-align:left;">🗑 Clear Old Sessions</button>
      </form>
      <form method="post" onsubmit="return confirm('Delete spin history older than 7 days?')">
        {!! csrfField() !!}<input type="hidden" name="action" value="reset_spins">
        <button class="btn btn-secondary" style="width:100%;text-align:left;">🎡 Clear Old Spin History</button>
      </form>
      <form method="post" onsubmit="return confirm('Recalculate all user balances from transactions? This may take a moment.')">
        {!! csrfField() !!}<input type="hidden" name="action" value="fix_balances">
        <button class="btn btn-warning" style="width:100%;text-align:left;">💰 Recalculate All Balances</button>
      </form>
    </div>
  </div>
</div>

</div>
@include('admin.partials-footer')
