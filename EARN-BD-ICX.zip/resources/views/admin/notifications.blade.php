@include('admin.partials-header')
@if ($flash)<div class="alert alert-success" style="margin-bottom:20px;">{{ $flash }}</div>@endif

<div class="admin-grid-2" style="gap:24px;display:grid;grid-template-columns:1fr 1.8fr;">

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">Send Broadcast</div></div>
  <div class="admin-card-body">
    <form method="post">
      {!! csrfField() !!}
      <input type="hidden" name="action" value="broadcast">
      <div class="form-group">
        <label>Target</label>
        <select name="target" class="form-control">
          <option value="all">All Active Users</option>
          @foreach ($users as $u)
          <option value="{{ $u['id'] }}">{{ $u['name'] }}</option>
          @endforeach
        </select>
      </div>
      <div class="form-group">
        <label>Title</label>
        <input type="text" name="title" class="form-control" placeholder="Notification title" required>
      </div>
      <div class="form-group">
        <label>Message</label>
        <textarea name="message" class="form-control" rows="4" placeholder="Write your message..." required></textarea>
      </div>
      <button class="btn btn-primary">Send Broadcast</button>
    </form>
  </div>
</div>

<div class="admin-card">
  <div class="admin-card-header">
    <div class="admin-card-title">Recent Notifications ({{ $total }})</div>
    <div style="display:flex;gap:8px;">
      <form method="post" style="display:inline" onsubmit="return confirm('Mark all as read?')">
        {!! csrfField() !!}<input type="hidden" name="action" value="mark_read">
        <button class="btn btn-secondary btn-sm">Mark All Read</button>
      </form>
      <form method="post" style="display:inline" onsubmit="return confirm('Delete ALL notifications? This is irreversible.')">
        {!! csrfField() !!}<input type="hidden" name="action" value="delete_all">
        <button class="btn btn-danger btn-sm">Clear All</button>
      </form>
    </div>
  </div>
  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>User</th><th>Type</th><th>Title</th><th>Time</th><th>Read</th><th>Del</th></tr></thead>
      <tbody>
        @foreach ($notifs as $n)
        <tr>
          <td>{{ $n['user_name'] ?? 'N/A' }}</td>
          <td><span class="badge badge-info">{{ $n['type'] }}</span></td>
          <td title="{{ $n['message'] }}">{{ mb_strimwidth($n['title'],0,40,'…') }}</td>
          <td style="font-size:12px;">{{ date('d M H:i',strtotime($n['created_at'])) }}</td>
          <td>{!! $n['is_read']?'<span style="color:green">✓</span>':'<span style="color:#aaa">✗</span>' !!}</td>
          <td>
            <form method="post" style="display:inline" onsubmit="return confirm('Delete?')">
              {!! csrfField() !!}<input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="{{ $n['id'] }}">
              <button class="btn btn-danger btn-xs">×</button>
            </form>
          </td>
        </tr>
        @endforeach
        @if (!$notifs->count())<tr><td colspan="6" style="text-align:center;color:#888;">No notifications.</td></tr>@endif
      </tbody>
    </table>
  </div>
  @if ($total > $limit)
  <div style="padding:12px;text-align:center;">
    @for ($i = 1; $i <= ceil($total/$limit); $i++)
    <a href="?page={{ $i }}" class="btn btn-xs {{ $page==$i?'btn-primary':'btn-secondary' }}">{{ $i }}</a>
    @endfor
  </div>
  @endif
</div>

</div>
@include('admin.partials-footer')
