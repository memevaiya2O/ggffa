@include('admin.partials-header')
@if ($flash)<div class="alert alert-success" style="margin-bottom:20px;">{{ $flash }}</div>@endif

<div class="admin-grid-2" style="display:grid;grid-template-columns:1fr 1.5fr;gap:24px;">

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">{{ $editPage ? 'Edit Page' : 'New Page' }}</div></div>
  <div class="admin-card-body">
    <form method="post">
      {!! csrfField() !!}
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" value="{{ $editPage ? $editPage['id'] : 0 }}">
      <div class="form-group">
        <label>Title</label>
        <input type="text" name="title" id="pg-title" class="form-control" value="{{ $editPage['title'] ?? '' }}" required oninput="autoSlug(this.value)">
      </div>
      <div class="form-group">
        <label>Slug (URL)</label>
        <div style="display:flex;align-items:center;gap:8px;">
          <span style="color:#888;">/page/</span>
          <input type="text" name="slug" id="pg-slug" class="form-control" value="{{ $editPage['slug'] ?? '' }}" required>
        </div>
      </div>
      <div class="form-group">
        <label>Content (HTML allowed)</label>
        <textarea name="content" class="form-control" rows="12" style="font-family:monospace;">{{ $editPage['content'] ?? '' }}</textarea>
      </div>
      <div class="form-group">
        <label>Status</label>
        <select name="status" class="form-control">
          <option value="published" {{ ($editPage['status']??'published')==='published'?'selected':'' }}>Published</option>
          <option value="draft" {{ ($editPage['status']??'')==='draft'?'selected':'' }}>Draft</option>
        </select>
      </div>
      <button class="btn btn-primary">Save Page</button>
      @if ($editPage)<a href="/Icxpanel/pages" class="btn btn-secondary">Cancel</a>@endif
    </form>
  </div>
</div>

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">All Pages ({{ count($pages) }})</div></div>
  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>Title</th><th>Slug</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
        @foreach ($pages as $p)
        <tr>
          <td><strong>{{ $p['title'] }}</strong></td>
          <td><a href="/page/{{ $p['slug'] }}" target="_blank" style="color:#667eea;">/page/{{ $p['slug'] }}</a></td>
          <td>
            <form method="post" style="display:inline">
              {!! csrfField() !!}<input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="{{ $p['id'] }}">
              <button class="btn btn-xs {{ $p['status']==='published'?'btn-success':'btn-secondary' }}">{{ $p['status'] }}</button>
            </form>
          </td>
          <td>
            <a href="?edit={{ $p['id'] }}" class="btn btn-warning btn-xs">Edit</a>
            <form method="post" style="display:inline" onsubmit="return confirm('Delete this page?')">
              {!! csrfField() !!}<input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="{{ $p['id'] }}">
              <button class="btn btn-danger btn-xs">Del</button>
            </form>
          </td>
        </tr>
        @endforeach
        @if (!$pages->count())<tr><td colspan="4" style="text-align:center;color:#888;">No pages yet.</td></tr>@endif
      </tbody>
    </table>
  </div>
</div>

</div>
@php
$extraJs = '<script>
function autoSlug(val) {
  if (!document.getElementById("pg-slug").dataset.manual) {
    document.getElementById("pg-slug").value = val.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"");
  }
}
document.getElementById("pg-slug").addEventListener("input", function(){ this.dataset.manual = "1"; });
</script>';
@endphp
@include('admin.partials-footer', ['extraJs' => $extraJs])
