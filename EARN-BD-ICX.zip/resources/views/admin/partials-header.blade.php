@php
$adminPage = $adminPage ?? 'dashboard';
$pendSubs  = (int) \App\Models\Submission::query()->where('status', 'pending')->count();
$pendWith  = (int) \App\Models\Withdrawal::query()->where('status', 'pending')->count();
$pendDeps  = \Illuminate\Support\Facades\Schema::hasTable('deposits') ? (int) \App\Models\Deposit::query()->where('status', 'pending')->count() : 0;
$defaultPw = false;
if (($adminPage ?? '') === 'dashboard' && session('admin_id')) {
    $__a = \App\Models\AdminUser::query()->where('id', session('admin_id'))->first();
    $defaultPw = $__a && \Illuminate\Support\Facades\Hash::check('admin123', $__a->password);
}
@endphp
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{{ $pageTitle ?? 'Admin' }} — {{ getSetting('site_name','EarnBD') }} Admin</title>
{!! renderFavicon() !!}
{!! renderGoogleFont() !!}
{!! renderCssVars() !!}
<link rel="stylesheet" href="/assets/css/style.css?v=3">
<link rel="stylesheet" href="/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4/dist/chart.umd.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js"></script>
</head>
<body>
<div class="admin-layout">
  <aside class="admin-sidebar" id="admin-sidebar">
    <div class="sidebar-header">
      <div class="sidebar-logo">{{ getSetting('site_name','EarnBD') }}</div>
      <div class="sidebar-subtitle">Admin Panel</div>
    </div>
    <nav class="sidebar-nav">
      <div class="sidebar-section">Main</div>
      <a href="/Icxpanel/" class="sidebar-link {{ $adminPage==='dashboard'?'active':'' }}"><i class="fa-solid fa-chart-pie"></i> Dashboard</a>
      <a href="/Icxpanel/users" class="sidebar-link {{ $adminPage==='users'?'active':'' }}"><i class="fa-solid fa-users"></i> Users</a>

      <div class="sidebar-section">Tasks</div>
      <a href="/Icxpanel/tasks" class="sidebar-link {{ $adminPage==='tasks'?'active':'' }}"><i class="fa-solid fa-list-check"></i> All Tasks</a>
      <a href="/Icxpanel/task-add" class="sidebar-link {{ $adminPage==='task-add'?'active':'' }}"><i class="fa-solid fa-plus"></i> Add Task</a>
      <a href="/Icxpanel/categories" class="sidebar-link {{ $adminPage==='categories'?'active':'' }}"><i class="fa-solid fa-tags"></i> Categories</a>
      <a href="/Icxpanel/submissions" class="sidebar-link {{ $adminPage==='submissions'?'active':'' }}">
        <i class="fa-solid fa-inbox"></i> Submissions @if ($pendSubs)<span class="sidebar-badge">{{ $pendSubs }}</span>@endif
      </a>

      <div class="sidebar-section">Finance</div>
      <a href="/Icxpanel/withdrawals" class="sidebar-link {{ $adminPage==='withdrawals'?'active':'' }}">
        <i class="fa-solid fa-money-bill-transfer"></i> Withdrawals @if ($pendWith)<span class="sidebar-badge">{{ $pendWith }}</span>@endif
      </a>
      <a href="/Icxpanel/deposits" class="sidebar-link {{ $adminPage==='deposits'?'active':'' }}">
        <i class="fa-solid fa-circle-plus"></i> Deposits @if ($pendDeps)<span class="sidebar-badge">{{ $pendDeps }}</span>@endif
      </a>
      <a href="/Icxpanel/deposit-methods" class="sidebar-link {{ $adminPage==='deposit-methods'?'active':'' }}"><i class="fa-solid fa-building-columns"></i> Deposit Accounts</a>
      <a href="/Icxpanel/withdraw-methods" class="sidebar-link {{ $adminPage==='withdraw-methods'?'active':'' }}"><i class="fa-solid fa-wallet"></i> Methods</a>
      <a href="/Icxpanel/withdraw-proof" class="sidebar-link {{ $adminPage==='withdraw-proof'?'active':'' }}"><i class="fa-solid fa-images"></i> Pay Proof</a>
      <a href="/Icxpanel/reports" class="sidebar-link {{ $adminPage==='reports'?'active':'' }}"><i class="fa-solid fa-chart-bar"></i> Reports</a>

      <div class="sidebar-section">Gamification</div>
      <a href="/Icxpanel/levels" class="sidebar-link {{ $adminPage==='levels'?'active':'' }}"><i class="fa-solid fa-medal"></i> Levels</a>
      <a href="/Icxpanel/spin-config" class="sidebar-link {{ $adminPage==='spin-config'?'active':'' }}"><i class="fa-solid fa-circle-notch"></i> Spin Config</a>
      <a href="/Icxpanel/referral-config" class="sidebar-link {{ $adminPage==='referral-config'?'active':'' }}"><i class="fa-solid fa-user-plus"></i> Referrals</a>
      <a href="/Icxpanel/leaderboard" class="sidebar-link {{ $adminPage==='leaderboard'?'active':'' }}"><i class="fa-solid fa-trophy"></i> Leaderboard</a>

      <div class="sidebar-section">Content</div>
      <a href="/Icxpanel/notifications" class="sidebar-link {{ $adminPage==='notifications'?'active':'' }}"><i class="fa-solid fa-bell"></i> Notifications</a>
      <a href="/Icxpanel/homepage-editor" class="sidebar-link {{ $adminPage==='homepage-editor'?'active':'' }}"><i class="fa-solid fa-home"></i> Homepage</a>
      <a href="/Icxpanel/pages" class="sidebar-link {{ $adminPage==='pages'?'active':'' }}"><i class="fa-solid fa-file-lines"></i> Pages</a>
      <a href="/Icxpanel/popup-manager" class="sidebar-link {{ $adminPage==='popup-manager'?'active':'' }}"><i class="fa-solid fa-comment-dots"></i> Popups</a>

      <div class="sidebar-section">System</div>
      <a href="/Icxpanel/theme" class="sidebar-link {{ $adminPage==='theme'?'active':'' }}"><i class="fa-solid fa-palette"></i> Theme</a>
      <a href="/Icxpanel/seo" class="sidebar-link {{ $adminPage==='seo'?'active':'' }}"><i class="fa-solid fa-magnifying-glass-chart"></i> SEO</a>
      <a href="/Icxpanel/settings" class="sidebar-link {{ $adminPage==='settings'?'active':'' }}"><i class="fa-solid fa-gear"></i> Settings</a>
      <a href="/Icxpanel/maintenance" class="sidebar-link {{ $adminPage==='maintenance'?'active':'' }}"><i class="fa-solid fa-screwdriver-wrench"></i> Maintenance</a>
      <a href="/Icxpanel/account" class="sidebar-link {{ $adminPage==='account'?'active':'' }}"><i class="fa-solid fa-user-shield"></i> My Account</a>
      <a href="/Icxpanel/logout" class="sidebar-link" style="color:var(--danger);margin-top:12px;"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
    </nav>
  </aside>
  <div class="admin-main">
    <header class="admin-topbar">
      <div class="admin-topbar-left">
        <span class="sidebar-toggle" onclick="document.getElementById('admin-sidebar').classList.toggle('open')"><i class="fa-solid fa-bars"></i></span>
        <div class="page-title">{{ $pageTitle ?? 'Dashboard' }}</div>
      </div>
      <div class="admin-topbar-right">
        <a href="/" target="_blank" style="font-size:13px;color:#888;font-weight:600;"><i class="fa-solid fa-external-link"></i> View Site</a>
        <a href="/Icxpanel/account" class="admin-user" style="text-decoration:none;color:inherit;">
          <div class="admin-user-avatar">{{ strtoupper(substr(session('admin_username') ?? 'A', 0, 1)) }}</div>
          {{ session('admin_username') ?? 'Admin' }}
        </a>
      </div>
    </header>
    <div class="admin-content">
    @if ($defaultPw)
      <div class="alert alert-error" style="margin-bottom:20px;">
        <i class="fa-solid fa-triangle-exclamation"></i> You are still using the default password. <a href="/Icxpanel/account" style="text-decoration:underline;">Change it now</a>.
      </div>
    @endif
