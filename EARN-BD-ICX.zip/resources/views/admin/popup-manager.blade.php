@include('admin.partials-header')
@php $d = $editPop['_data'] ?? []; @endphp
@if ($flash)<div class="alert alert-success" style="margin-bottom:20px;">{{ $flash }}</div>@endif

<div class="admin-grid-2" style="display:grid;grid-template-columns:1fr 1.5fr;gap:24px;">

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">{{ $editPop ? 'Edit Popup' : 'New Popup' }}</div></div>
  <div class="admin-card-body">
    <form method="post">
      {!! csrfField() !!}
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" value="{{ $editPop ? $editPop['id'] : 0 }}">
      <div class="form-group"><label>Title</label><input type="text" name="title" class="form-control" value="{{ $editPop['title'] ?? $d['title'] ?? '' }}" required></div>
      <div class="form-group"><label>Content (HTML)</label><textarea name="content" class="form-control" rows="5">{{ $d['content'] ?? '' }}</textarea></div>
      <div class="form-group"><label>Type</label>
        <select name="type" class="form-control">
          @foreach (['info'=>'Info','success'=>'Success','warning'=>'Warning','promo'=>'Promo','announcement'=>'Announcement'] as $v => $l)
          <option value="{{ $v }}" {{ ($d['type']??'info')===$v?'selected':'' }}>{{ $l }}</option>
          @endforeach
        </select>
      </div>
      <div class="form-group"><label>Trigger</label>
        <select name="trigger" class="form-control">
          <option value="pageload" {{ ($d['trigger']??'pageload')==='pageload'?'selected':'' }}>Page Load</option>
          <option value="exit_intent" {{ ($d['trigger']??'')==='exit_intent'?'selected':'' }}>Exit Intent</option>
          <option value="scroll" {{ ($d['trigger']??'')==='scroll'?'selected':'' }}>On Scroll</option>
        </select>
      </div>
      <div class="form-group"><label>Delay (seconds)</label><input type="number" name="delay" class="form-control" value="{{ $d['delay'] ?? 0 }}" min="0"></div>
      <div class="form-group"><label>Show on Pages (comma-separated paths, empty = all)</label><input type="text" name="show_pages" class="form-control" value="{{ $d['pages'] ?? '' }}" placeholder="/,/tasks,/register"></div>
      <div class="form-group"><label>Button Text</label><input type="text" name="btn_text" class="form-control" value="{{ $d['btn_text'] ?? '' }}" placeholder="Get Started"></div>
      <div class="form-group"><label>Button Link</label><input type="text" name="btn_link" class="form-control" value="{{ $d['btn_link'] ?? '' }}" placeholder="/register"></div>
      <div class="form-group"><label>Start Date (optional)</label><input type="datetime-local" name="start_date" class="form-control" value="{{ $d['start_date'] ?? '' }}"></div>
      <div class="form-group"><label>End Date (optional)</label><input type="datetime-local" name="end_date" class="form-control" value="{{ $d['end_date'] ?? '' }}"></div>
      <div class="form-group"><label>Status</label>
        <select name="status" class="form-control">
          <option value="active" {{ ($editPop['status']??'active')==='active'?'selected':'' }}>Active</option>
          <option value="inactive" {{ ($editPop['status']??'')==='inactive'?'selected':'' }}>Inactive</option>
        </select>
      </div>
      <button class="btn btn-primary">Save Popup</button>
      @if ($editPop)<a href="/Icxpanel/popup-manager" class="btn btn-secondary">Cancel</a>@endif
    </form>
  </div>
</div>

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">All Popups ({{ count($popups) }})</div></div>
  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>Title</th><th>Type</th><th>Trigger</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
        @foreach ($popups as $p)
          @php $pd = json_decode($p['data'], true) ?? []; @endphp
        <tr>
          <td><strong>{{ $p['title'] }}</strong></td>
          <td><span class="badge badge-info">{{ $pd['type'] ?? '-' }}</span></td>
          <td>{{ $pd['trigger'] ?? '-' }}</td>
          <td>
            <form method="post" style="display:inline">
              {!! csrfField() !!}<input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="{{ $p['id'] }}">
              <button class="btn btn-xs {{ $p['status']==='active'?'btn-success':'btn-secondary' }}">{{ $p['status'] }}</button>
            </form>
          </td>
          <td>
            <a href="?edit={{ $p['id'] }}" class="btn btn-warning btn-xs">Edit</a>
            <form method="post" style="display:inline" onsubmit="return confirm('Delete?')">
              {!! csrfField() !!}<input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="{{ $p['id'] }}">
              <button class="btn btn-danger btn-xs">Del</button>
            </form>
          </td>
        </tr>
        @endforeach
        @if (!$popups->count())<tr><td colspan="5" style="text-align:center;color:#888;">No popups yet.</td></tr>@endif
      </tbody>
    </table>
  </div>
</div>

</div>
@include('admin.partials-footer')
