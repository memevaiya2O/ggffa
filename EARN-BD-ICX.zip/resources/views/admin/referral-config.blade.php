@include('admin.partials-header')
@php $g = fn($k,$d='') => $s[$k] ?? $d; @endphp
@if ($flash)<div class="alert alert-success" style="margin-bottom:20px;">{{ $flash }}</div>@endif

<div class="admin-grid-2" style="display:grid;grid-template-columns:1fr 1.5fr;gap:24px;">

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">Referral Settings</div></div>
  <div class="admin-card-body">
    <form method="post">
      {!! csrfField() !!}
      <div class="form-group">
        <label>Referral System Enabled</label>
        <select name="referral_enabled" class="form-control">
          <option value="1" {{ $g('referral_enabled','1')==='1'?'selected':'' }}>Yes</option>
          <option value="0" {{ $g('referral_enabled','1')==='0'?'selected':'' }}>No</option>
        </select>
      </div>
      <div class="form-group">
        <label>Bonus for Referrer (BDT)</label>
        <input type="number" name="referral_bonus_referrer" class="form-control" value="{{ $g('referral_bonus_referrer','10') }}" step="0.01" min="0">
      </div>
      <div class="form-group">
        <label>Bonus for Referee (BDT)</label>
        <input type="number" name="referral_bonus_referee" class="form-control" value="{{ $g('referral_bonus_referee','5') }}" step="0.01" min="0">
      </div>
      <div class="form-group">
        <label>Max Referrals per User (0 = unlimited)</label>
        <input type="number" name="referral_max_per_user" class="form-control" value="{{ $g('referral_max_per_user','0') }}" min="0">
      </div>
      <div class="form-group">
        <label>Bonus Triggered On</label>
        <select name="referral_bonus_on" class="form-control">
          <option value="register" {{ $g('referral_bonus_on','register')==='register'?'selected':'' }}>Registration</option>
          <option value="first_task" {{ $g('referral_bonus_on','register')==='first_task'?'selected':'' }}>First Task Approved</option>
        </select>
      </div>
      <div class="form-group">
        <label>Min Withdraw to Unlock Referral Bonus (0 = no min)</label>
        <input type="number" name="referral_min_withdraw" class="form-control" value="{{ $g('referral_min_withdraw','0') }}" step="0.01" min="0">
      </div>
      <button class="btn btn-primary">Save Settings</button>
    </form>
  </div>
</div>

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">Top Referrers — Total Referred: {{ $totalReferrals }}</div></div>
  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>#</th><th>User</th><th>Referrals</th></tr></thead>
      <tbody>
        @foreach ($topReferrers as $i => $r)
        <tr><td>{{ $i+1 }}</td><td>{{ $r['name'] }}</td><td>{{ $r['cnt'] }}</td></tr>
        @endforeach
        @if (!$topReferrers->count())<tr><td colspan="3" style="text-align:center;color:#888;">No referrals yet.</td></tr>@endif
      </tbody>
    </table>
  </div>
</div>

</div>
@include('admin.partials-footer')
