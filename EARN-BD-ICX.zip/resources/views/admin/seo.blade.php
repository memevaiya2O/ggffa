@include('admin.partials-header')
@php $g = fn($k,$d='') => $s[$k] ?? $d; @endphp
@if ($flash)<div class="alert alert-success" style="margin-bottom:20px;">{{ $flash }}</div>@endif

<form method="post">
  {!! csrfField() !!}

  <div class="admin-card" style="margin-bottom:20px;">
    <div class="admin-card-header"><div class="admin-card-title">🔍 Basic SEO</div></div>
    <div class="admin-card-body">
      <div class="form-group"><label>Meta Title (default)</label><input type="text" name="seo_title" class="form-control" value="{{ $g('seo_title') }}" placeholder="{site_name} - Earn Money Online in Bangladesh"><small style="color:#888;">Tip: <code>{site_name}</code> is replaced by your site name automatically.</small></div>
      <div class="form-group"><label>Meta Description</label><textarea name="seo_description" class="form-control" rows="3" placeholder="Complete tasks, earn money and withdraw via bKash/Nagad">{{ $g('seo_description') }}</textarea></div>
      <div class="form-group"><label>Keywords (comma-separated)</label><input type="text" name="seo_keywords" class="form-control" value="{{ $g('seo_keywords') }}" placeholder="earn money online, bangladesh, bkash payment"></div>
      <div class="form-group"><label>OG / Social Image URL</label><input type="text" name="seo_og_image" class="form-control" value="{{ $g('seo_og_image') }}" placeholder="https://..."></div>
      <div class="form-group"><label>Twitter Card Type</label>
        <select name="seo_twitter_card" class="form-control">
          @foreach (['summary','summary_large_image','app'] as $t)
          <option value="{{ $t }}" {{ $g('seo_twitter_card','summary')===$t?'selected':'' }}>{{ $t }}</option>
          @endforeach
        </select>
      </div>
      <div class="form-group"><label>Canonical URL</label><input type="text" name="seo_canonical_url" class="form-control" value="{{ $g('seo_canonical_url') }}" placeholder="https://yoursite.com"></div>
      <div class="form-group"><label>Google Site Verification</label><input type="text" name="google_site_verification" class="form-control" value="{{ $g('google_site_verification') }}" placeholder="verification code"></div>
    </div>
  </div>

  <div class="admin-card" style="margin-bottom:20px;">
    <div class="admin-card-header"><div class="admin-card-title">📈 Analytics & Tracking</div></div>
    <div class="admin-card-body">
      <div class="form-group"><label>Google Analytics 4 ID</label><input type="text" name="google_analytics_id" class="form-control" value="{{ $g('google_analytics_id') }}" placeholder="G-XXXXXXXXXX"></div>
      <div class="form-group"><label>Google Tag Manager ID</label><input type="text" name="google_tag_manager_id" class="form-control" value="{{ $g('google_tag_manager_id') }}" placeholder="GTM-XXXXXXX"></div>
      <div class="form-group"><label>Facebook Pixel ID</label><input type="text" name="facebook_pixel_id" class="form-control" value="{{ $g('facebook_pixel_id') }}" placeholder="XXXXXXXXXXXXXXXXX"></div>
    </div>
  </div>

  <div class="admin-card" style="margin-bottom:20px;">
    <div class="admin-card-header"><div class="admin-card-title">🤖 Robots.txt</div></div>
    <div class="admin-card-body">
      <div class="form-group">
        <label>robots.txt Content</label>
        <textarea name="robots_txt" class="form-control" rows="6" style="font-family:monospace;">{{ $g('robots_txt', "User-agent: *\nAllow: /") }}</textarea>
        <small style="color:#888;">This content is served at <a href="/robots.txt" target="_blank">/robots.txt</a></small>
      </div>
    </div>
  </div>

  <div class="admin-card" style="margin-bottom:20px;">
    <div class="admin-card-header"><div class="admin-card-title">💻 Custom Code Injection</div></div>
    <div class="admin-card-body">
      <div class="form-group"><label>Custom &lt;head&gt; Code</label><textarea name="custom_head_code" class="form-control" rows="5" style="font-family:monospace;" placeholder="<!-- e.g. custom CSS, meta tags -->">{{ $g('custom_head_code') }}</textarea></div>
      <div class="form-group"><label>Custom &lt;body&gt; Code (before &lt;/body&gt;)</label><textarea name="custom_body_code" class="form-control" rows="5" style="font-family:monospace;" placeholder="<!-- e.g. live chat scripts -->">{{ $g('custom_body_code') }}</textarea></div>
    </div>
  </div>

  <button class="btn btn-primary btn-lg">💾 Save SEO Settings</button>
</form>
@include('admin.partials-footer')
