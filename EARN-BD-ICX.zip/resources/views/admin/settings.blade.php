@include('admin.partials-header')
@if ($flash)<div class="alert alert-success" style="margin-bottom:20px;">{{ $flash }}</div>@endif
<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">General Settings</div></div>
  <div class="admin-card-body">
  <form method="post" enctype="multipart/form-data">
    {!! csrfField() !!}
    <div class="admin-form-grid">
      <div class="admin-form-group"><label class="admin-label">Site Name</label><input type="text" name="site_name" class="admin-input" value="{{ getSetting('site_name','EarnBD') }}" required><small style="color:#888;display:block;margin-top:4px;">Change it here once — it updates everywhere (titles, footer, notifications, share texts).</small></div>
      <div class="admin-form-group"><label class="admin-label">Site Tagline</label><input type="text" name="site_tagline" class="admin-input" value="{{ getSetting('site_tagline') }}"></div>
      <div class="admin-form-group"><label class="admin-label">Admin Email</label><input type="email" name="admin_email" class="admin-input" value="{{ getSetting('admin_email') }}"></div>
      <div class="admin-form-group"><label class="admin-label">Contact Email</label><input type="email" name="contact_email" class="admin-input" value="{{ getSetting('contact_email') }}"></div>
      <div class="admin-form-group"><label class="admin-label">Currency Symbol</label><input type="text" name="currency_symbol" class="admin-input" value="{{ getSetting('currency_symbol','৳') }}" maxlength="5"></div>
      <div class="admin-form-group"><label class="admin-label">Currency Name</label><input type="text" name="currency_name" class="admin-input" value="{{ getSetting('currency_name','BDT') }}"></div>
      <div class="admin-form-group"><label class="admin-label">Daily Bonus Amount</label><input type="number" name="daily_bonus_amount" class="admin-input" step="0.01" value="{{ getSetting('daily_bonus_amount','5') }}"></div>
      <div class="admin-form-group"><label class="admin-label">Welcome Bonus</label><input type="number" name="welcome_bonus" class="admin-input" step="0.01" value="{{ getSetting('welcome_bonus','10') }}"></div>
      <div class="admin-form-group"><label class="admin-label">Min Withdraw Amount (global)</label><input type="number" name="min_withdraw" class="admin-input" step="0.01" value="{{ getSetting('min_withdraw','50') }}"></div>
      <div class="admin-form-group"><label class="admin-label">Site Logo <small style="color:#888;">(shown in header, footer, login &amp; register — image only)</small></label>
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:8px;">
          @if ($l = getSetting('site_logo'))<img src="{{ $l }}" style="height:44px;max-width:180px;object-fit:contain;border-radius:6px;border:1px solid #eee;padding:4px;"><label style="font-size:13px;"><input type="checkbox" name="remove_logo" value="1"> Remove</label>@else<div style="width:64px;height:44px;border:2px dashed #ccc;border-radius:8px;display:flex;align-items:center;justify-content:center;color:#bbb;"><i class="fa-regular fa-image"></i></div><span style="font-size:13px;color:#888;">No logo set yet</span>@endif
        </div>
        <input type="file" name="logo" class="admin-input" accept="image/png,image/jpeg,image/webp,image/gif,image/svg+xml"></div>
      <div class="admin-form-group"><label class="admin-label">Site Icon (Favicon) <small style="color:#888;">(browser tab &amp; home-screen icon — square PNG/ICO/SVG)</small></label>
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:8px;">
          @if ($f = getSetting('favicon'))<img src="{{ $f }}" style="height:40px;width:40px;object-fit:contain;border:1px solid #eee;border-radius:6px;padding:4px;"><label style="font-size:13px;"><input type="checkbox" name="remove_favicon" value="1"> Remove</label>@else<img src="/favicon.svg" style="height:40px;width:40px;object-fit:contain;border:1px solid #eee;border-radius:6px;padding:4px;"><span style="font-size:13px;color:#888;">Using the default icon</span>@endif
        </div>
        <input type="file" name="favicon" class="admin-input" accept="image/png,image/x-icon,image/vnd.microsoft.icon,image/svg+xml,image/jpeg,image/webp"></div>
      <div class="admin-form-group"><label class="admin-label">Footer Description</label><textarea name="footer_description" class="admin-input admin-textarea" rows="2">{{ getRawSetting('footer_description') }}</textarea></div>
      <div class="admin-form-group"><label class="admin-label">Footer Copyright</label><input type="text" name="footer_copyright" class="admin-input" value="{{ getRawSetting('footer_copyright', '© {year} {site_name}. All rights reserved.') }}"><small style="color:#888;display:block;margin-top:4px;">Tip: <code>{site_name}</code> and <code>{year}</code> fill in automatically.</small></div>
    </div>
    <hr style="margin:20px 0;border-color:#f0f0f0;">
    <div class="admin-form-grid">
      <div class="admin-form-group">
        <label class="toggle-label"><span class="toggle-switch"><input type="checkbox" name="registration_open" value="1" {{ getSetting('registration_open','1')==='1'?'checked':'' }}><span class="toggle-slider"></span></span> Open Registration</label>
      </div>
      <div class="admin-form-group">
        <label class="toggle-label"><span class="toggle-switch"><input type="checkbox" name="maintenance_mode" value="1" {{ getSetting('maintenance_mode')==='1'?'checked':'' }}><span class="toggle-slider"></span></span> Maintenance Mode</label>
      </div>
    </div>
    <div class="admin-form-group"><label class="admin-label">Maintenance Message</label><textarea name="maintenance_message" class="admin-input admin-textarea" rows="3">{{ getSetting('maintenance_message') }}</textarea></div>
    <button type="submit" class="btn btn-primary"><i class="fa-solid fa-save"></i> Save Settings</button>
  </form>
  </div>
</div>
@include('admin.partials-footer')
