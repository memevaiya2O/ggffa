@include('admin.partials-header')
@if ($flash)<div class="alert alert-success" style="margin-bottom:20px;">{{ $flash }}</div>@endif

<div class="admin-grid-2" style="gap:24px;display:grid;grid-template-columns:1fr 1fr;">

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">Spin Settings</div></div>
  <div class="admin-card-body">
    <form method="post">
      {!! csrfField() !!}
      <input type="hidden" name="action" value="save_settings">
      <div class="form-group">
        <label>Spin Wheel Enabled</label>
        <select name="spin_enabled" class="form-control">
          <option value="1" {{ ($settings['spin_enabled']??'1')==='1'?'selected':'' }}>Yes</option>
          <option value="0" {{ ($settings['spin_enabled']??'1')==='0'?'selected':'' }}>No</option>
        </select>
      </div>
      <div class="form-group">
        <label>Daily Spin Limit</label>
        <input type="number" name="spin_daily_limit" class="form-control" value="{{ $settings['spin_daily_limit']??'1' }}" min="1">
      </div>
      <div class="form-group">
        <label>Cooldown Hours</label>
        <input type="number" name="spin_cooldown_hours" class="form-control" value="{{ $settings['spin_cooldown_hours']??'24' }}" min="0">
      </div>
      <button class="btn btn-primary">Save Settings</button>
    </form>
  </div>
</div>

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">Add / Edit Segment</div></div>
  <div class="admin-card-body">
    <form method="post" id="seg-form">
      {!! csrfField() !!}
      <input type="hidden" name="action" value="save_segment">
      <input type="hidden" name="id" id="seg-id" value="0">
      <div class="form-group">
        <label>Label</label>
        <input type="text" name="label" id="seg-label" class="form-control" placeholder="e.g. 50 Coins" required>
      </div>
      <div class="form-group">
        <label>Prize Type</label>
        <select name="prize_type" id="seg-type" class="form-control">
          <option value="coins">Coins</option>
          <option value="bonus">Bonus BDT</option>
          <option value="nothing">No Prize</option>
        </select>
      </div>
      <div class="form-group">
        <label>Prize Value</label>
        <input type="number" name="prize_value" id="seg-value" class="form-control" value="0" step="0.01" min="0">
      </div>
      <div class="form-group">
        <label>Weight (higher = more likely)</label>
        <input type="number" name="weight" id="seg-weight" class="form-control" value="1" min="1">
      </div>
      <div class="form-group">
        <label>Color</label>
        <input type="color" name="color" id="seg-color" value="#4CAF50" style="height:40px;width:100%;">
      </div>
      <button class="btn btn-primary" type="submit">Save Segment</button>
      <button class="btn btn-secondary" type="button" onclick="resetSegForm()">Clear</button>
    </form>
  </div>
</div>

</div>

<div class="admin-card" style="margin-top:24px;">
  <div class="admin-card-header"><div class="admin-card-title">Wheel Segments ({{ count($segments) }})</div></div>
  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>Label</th><th>Type</th><th>Value</th><th>Weight</th><th>Color</th><th>Actions</th></tr></thead>
      <tbody>
        @foreach ($segments as $seg)
        <tr>
          <td>{{ $seg['label'] }}</td>
          <td><span class="badge badge-info">{{ $seg['prize_type'] }}</span></td>
          <td>{{ $seg['prize_value'] }}</td>
          <td>{{ $seg['weight'] }}</td>
          <td><span style="display:inline-block;width:24px;height:24px;border-radius:4px;background:{{ $seg['color'] }};border:1px solid #ccc;"></span></td>
          <td>
            <button class="btn btn-warning btn-xs" onclick="editSeg({!! htmlspecialchars(json_encode($seg)) !!})">Edit</button>
            <form method="post" style="display:inline" onsubmit="return confirm('Delete?')">
              {!! csrfField() !!}<input type="hidden" name="action" value="delete_segment"><input type="hidden" name="id" value="{{ $seg['id'] }}">
              <button class="btn btn-danger btn-xs">Del</button>
            </form>
          </td>
        </tr>
        @endforeach
      </tbody>
    </table>
  </div>
</div>

@php
$extraJs = '<script>
function editSeg(s) {
  document.getElementById("seg-id").value = s.id;
  document.getElementById("seg-label").value = s.label;
  document.getElementById("seg-type").value = s.prize_type;
  document.getElementById("seg-value").value = s.prize_value;
  document.getElementById("seg-weight").value = s.weight;
  document.getElementById("seg-color").value = s.color;
  document.getElementById("seg-form").scrollIntoView({behavior:"smooth"});
}
function resetSegForm() {
  document.getElementById("seg-id").value = "0";
  document.getElementById("seg-form").reset();
}
</script>';
@endphp
@include('admin.partials-footer', ['extraJs' => $extraJs])
