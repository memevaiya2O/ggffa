@include('admin.partials-header')
@if ($flash)<div class="alert alert-success" style="margin-bottom:20px;">{{ $flash }}</div>@endif

<div class="admin-card">
  <div class="admin-card-header">
    <div class="admin-card-title">Submissions ({{ number_format($total) }})</div>
  </div>
  <div class="admin-filters">
    @foreach (['pending'=>'⏳ Pending','approved'=>'✅ Approved','rejected'=>'❌ Rejected','all'=>'All'] as $k => $v)
      <a href="?status={{ $k }}" class="filter-btn {{ $status===$k?'filter-btn-primary':'filter-btn-outline' }}">{{ $v }}</a>
    @endforeach
  </div>

  <!-- Bulk action bar -->
  <div id="bulk-action-bar" style="display:none;background:rgba(0,200,150,.1);padding:12px 16px;border-radius:8px;margin-bottom:16px;align-items:center;gap:12px;">
    <span class="bulk-count" style="font-weight:700;"></span>
    @if ($status === 'pending')
      <button id="bulk-approve-btn" class="action-btn-sm action-btn-approve"><i class="fa-solid fa-check"></i> Approve All</button>
      <button id="bulk-reject-btn" class="action-btn-sm action-btn-reject"><i class="fa-solid fa-times"></i> Reject All</button>
    @endif
  </div>
  {!! csrfField() !!}

  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr>
        @if ($status === 'pending')<th><input type="checkbox" id="select-all"></th>@endif
        <th>User</th><th>Task</th><th>Screenshot</th><th>Notes</th><th>Submitted</th><th>Status</th><th>Actions</th>
      </tr></thead>
      <tbody>
        @foreach ($submissions as $s)
          <tr>
            @if ($status === 'pending')<td><input type="checkbox" class="row-checkbox" value="{{ $s['id'] }}"></td>@endif
            <td>
              <div class="user-cell">
                <div class="table-avatar">{{ strtoupper(substr($s['user_name'],0,1)) }}</div>
                <div>{{ $s['user_name'] }}</div>
              </div>
            </td>
            <td style="font-size:13px;">{{ $s['task_title'] }}<br><span style="color:var(--primary);font-weight:700">{{ formatAmount((float)$s['reward']) }}</span></td>
            <td>
              @if ($s['screenshot'])
                <img src="{{ $s['screenshot'] }}" class="sub-screenshot" data-lightbox="{{ $s['screenshot'] }}" alt="" style="max-height:60px;border-radius:6px;cursor:pointer;">
              @else<span style="color:#aaa;font-size:12px;">None</span>@endif
            </td>
            <td style="font-size:13px;max-width:160px;overflow:hidden;text-overflow:ellipsis;">{!! $s['notes'] ? e(substr($s['notes'],0,60)) : '<span style="color:#aaa">—</span>' !!}</td>
            <td style="font-size:12px;color:#888">{{ timeAgo($s['created_at']) }}</td>
            <td><span class="status-badge status-{{ $s['status'] }}">{{ ucfirst($s['status']) }}</span>@if ($s['reject_reason'])<div style="font-size:11px;color:#888;margin-top:4px;">{{ substr($s['reject_reason'],0,40) }}</div>@endif</td>
            <td>
              @if ($s['status'] === 'pending')
                <div class="action-btns">
                  <form method="post" style="display:inline">{!! csrfField() !!}<input type="hidden" name="action" value="approve"><input type="hidden" name="sub_id" value="{{ $s['id'] }}"><button type="submit" class="action-btn-sm action-btn-approve" data-confirm="Approve this submission?"><i class="fa-solid fa-check"></i> Approve</button></form>
                  <button class="action-btn-sm action-btn-reject" onclick="openRejectModal({{ $s['id'] }})"><i class="fa-solid fa-times"></i> Reject</button>
                </div>
              @endif
            </td>
          </tr>
        @endforeach
      </tbody>
    </table>
  </div>
  {!! paginationLinks($total,$page,$limit,'/Icxpanel/submissions?status='.$status) !!}
</div>

<!-- Reject Modal -->
<div class="modal-overlay" id="reject-modal">
  <div class="modal-box">
    <div class="modal-header"><h3>Reject Submission</h3><span class="modal-close"><i class="fa-solid fa-xmark"></i></span></div>
    <form method="post" action="/Icxpanel/submissions">
      {!! csrfField() !!}
      <input type="hidden" name="action" value="reject">
      <input type="hidden" name="sub_id" id="reject-sid">
      <div class="form-group">
        <label class="form-label">Quick Templates</label>
        <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:10px;">
          @foreach ($templates as $t)
            <button type="button" class="filter-btn filter-btn-outline" style="font-size:12px;" onclick="document.getElementById('reject-reason').value='{{ addslashes($t['reason']) }}'">{{ $t['reason'] }}</button>
          @endforeach
        </div>
      </div>
      <div class="form-group"><label class="form-label">Reason <span style="color:var(--danger)">*</span></label><textarea name="reason" id="reject-reason" class="form-control" rows="3" required placeholder="Enter rejection reason..."></textarea></div>
      <button type="submit" class="btn btn-danger btn-block">Reject Submission</button>
    </form>
  </div>
</div>
@php $extraJs = '<script>function openRejectModal(sid){document.getElementById("reject-sid").value=sid;document.getElementById("reject-modal").classList.add("active");}</script>'; @endphp
@include('admin.partials-footer', ['extraJs' => $extraJs])
