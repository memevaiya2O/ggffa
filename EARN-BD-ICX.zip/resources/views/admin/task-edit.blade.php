@include('admin.partials-header')
@if ($error)<div class="alert alert-error" style="margin-bottom:20px;">{{ $error }}</div>@endif
<div class="admin-card">
  <form method="post" enctype="multipart/form-data">
    {!! csrfField() !!}
    <div class="admin-form-grid">
      <div class="admin-form-group"><label class="admin-label">Task Title *</label><input type="text" name="title" class="admin-input" value="{{ $task['title'] }}" required></div>
      <div class="admin-form-group"><label class="admin-label">Category</label><select name="category_id" class="admin-input"><option value="">No Category</option>@foreach ($cats as $c)<option value="{{ $c['id'] }}" {{ $task['category_id']==$c['id']?'selected':'' }}>{{ $c['name'] }}</option>@endforeach</select></div>
      <div class="admin-form-group"><label class="admin-label">Type</label><select name="type" class="admin-input">@foreach (['standard','social','app','survey','video'] as $t)<option value="{{ $t }}" {{ $task['type']===$t?'selected':'' }}>{{ ucfirst($t) }}</option>@endforeach</select></div>
      <div class="admin-form-group"><label class="admin-label">Reward Amount *</label><input type="number" name="reward" class="admin-input" step="0.01" min="0.01" value="{{ $task['reward'] }}" required></div>
      <div class="admin-form-group"><label class="admin-label">Max per User</label><input type="number" name="max_per_user" class="admin-input" min="1" value="{{ $task['max_per_user'] }}"></div>
      <div class="admin-form-group"><label class="admin-label">Max Total Completions</label><input type="number" name="max_total" class="admin-input" min="1" value="{{ $task['max_total'] }}"></div>
      <div class="admin-form-group"><label class="admin-label">Thumbnail @if ($task['thumbnail']) <a href="{{ $task['thumbnail'] }}" target="_blank" style="font-size:11px">(current)</a>@endif</label><input type="file" name="thumbnail" class="admin-input" accept="image/*"></div>
      <div class="admin-form-group"><label class="admin-label">Status</label><select name="status" class="admin-input"><option value="active" {{ $task['status']==='active'?'selected':'' }}>Active</option><option value="inactive" {{ $task['status']==='inactive'?'selected':'' }}>Inactive</option></select></div>
    </div>
    <div class="admin-form-group"><label class="admin-label">Instructions</label><textarea name="instructions" class="admin-input admin-textarea" rows="6">{{ $task['instructions'] }}</textarea></div>
    <div class="admin-form-group"><label class="admin-label">Rules</label><textarea name="rules" class="admin-input admin-textarea" rows="4">{{ $task['rules'] }}</textarea></div>
    <div style="display:flex;flex-wrap:wrap;gap:20px;margin-bottom:20px;">
      <label class="toggle-label"><span class="toggle-switch"><input type="checkbox" name="screenshot_required" value="1" {{ $task['screenshot_required']?'checked':'' }}><span class="toggle-slider"></span></span> Require Screenshot</label>
      <label class="toggle-label"><span class="toggle-switch"><input type="checkbox" name="is_featured" value="1" {{ $task['is_featured']?'checked':'' }}><span class="toggle-slider"></span></span> Featured</label>
      <label class="toggle-label"><span class="toggle-switch"><input type="checkbox" name="is_hot" value="1" {{ $task['is_hot']?'checked':'' }}><span class="toggle-slider"></span></span> 🔥 Hot</label>
      <label class="toggle-label"><span class="toggle-switch"><input type="checkbox" name="is_new" value="1" {{ $task['is_new']?'checked':'' }}><span class="toggle-slider"></span></span> ✨ New</label>
      <label class="toggle-label"><span class="toggle-switch"><input type="checkbox" name="is_vip" value="1" {{ $task['is_vip']?'checked':'' }}><span class="toggle-slider"></span></span> 👑 VIP Only</label>
    </div>
    <button type="submit" class="btn btn-primary"><i class="fa-solid fa-save"></i> Save Changes</button>
    <a href="/Icxpanel/tasks" class="btn btn-outline" style="margin-left:10px;">Cancel</a>
  </form>
</div>
@include('admin.partials-footer')
