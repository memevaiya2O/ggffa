@include('admin.partials-header')
@if ($flash)<div class="alert alert-success" style="margin-bottom:20px;">{{ $flash }}</div>@endif
<div class="admin-card">
  <div class="admin-card-header">
    <div class="admin-card-title">Tasks ({{ $total }})</div>
    <a href="/Icxpanel/task-add" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Add Task</a>
  </div>
  <form method="get" class="admin-filters">
    <select name="cat" class="filter-select" onchange="this.form.submit()"><option value="">All Categories</option>@foreach ($cats as $c)<option value="{{ $c['id'] }}" {{ $cat==$c['id']?'selected':'' }}>{{ $c['name'] }}</option>@endforeach</select>
    <select name="status" class="filter-select" onchange="this.form.submit()"><option value="all">All Status</option><option value="active" {{ $status==='active'?'selected':'' }}>Active</option><option value="inactive" {{ $status==='inactive'?'selected':'' }}>Inactive</option></select>
  </form>
  <div class="admin-table-wrap">
    <table class="admin-table" id="tasks-table">
      <thead><tr><th>☰</th><th>Task</th><th>Category</th><th>Reward</th><th>Stats</th><th>Flags</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody id="sortable-tasks">
        @foreach ($tasks as $t)
          <tr data-id="{{ $t['id'] }}">
            <td><span class="drag-handle"><i class="fa-solid fa-grip-lines"></i></span></td>
            <td>
              <div style="display:flex;align-items:center;gap:10px;">
                @if ($t['thumbnail'])<img src="{{ $t['thumbnail'] }}" style="width:40px;height:40px;border-radius:8px;object-fit:cover;">@endif
                <div><div style="font-weight:700;font-size:14px;">{{ $t['title'] }}</div><div style="font-size:11px;color:#888">{{ ucfirst($t['type']) }}</div></div>
              </div>
            </td>
            <td>{{ $t['cat_name']??'—' }}</td>
            <td style="font-weight:700;color:var(--primary)">{{ formatAmount((float)$t['reward']) }}</td>
            <td style="font-size:12px"><span style="color:var(--primary)">{{ $t['approved_count'] }} done</span> · <span style="color:var(--warning)">{{ $t['pending_count'] }} pending</span></td>
            <td>
              @php $flags = []; if ($t['is_featured']) $flags[]='<span class="badge badge-info">Featured</span>'; if ($t['is_hot']) $flags[]='<span class="badge badge-hot">🔥</span>'; if ($t['is_new']) $flags[]='<span class="badge badge-new">✨</span>'; if ($t['is_vip']) $flags[]='<span class="badge badge-vip">👑</span>'; @endphp
              {!! implode(' ',$flags) !!}
            </td>
            <td>
              <form method="post" style="display:inline">{!! csrfField() !!}<input type="hidden" name="action" value="toggle_status"><input type="hidden" name="task_id" value="{{ $t['id'] }}"><button type="submit" class="status-badge status-{{ $t['status'] === 'active'?'active':'rejected' }}" style="cursor:pointer;border:none;">{{ $t['status'] === 'active' ? 'Active' : 'Inactive' }}</button></form>
            </td>
            <td>
              <div class="action-btns">
                <a href="/Icxpanel/task-edit?id={{ $t['id'] }}" class="action-btn-sm action-btn-edit"><i class="fa-solid fa-pen"></i></a>
                <form method="post" style="display:inline">{!! csrfField() !!}<input type="hidden" name="action" value="delete"><input type="hidden" name="task_id" value="{{ $t['id'] }}"><button type="submit" class="action-btn-sm action-btn-delete" data-confirm="Delete this task and all submissions?"><i class="fa-solid fa-trash"></i></button></form>
              </div>
            </td>
          </tr>
        @endforeach
      </tbody>
    </table>
  </div>
  {!! paginationLinks($total,$page,$limit,'/Icxpanel/tasks?cat='.$cat.'&status='.$status) !!}
</div>
@php $extraJs='<script>initSortable("sortable-tasks","/Icxpanel/tasks");</script>'; @endphp
@include('admin.partials-footer', ['extraJs' => $extraJs])
