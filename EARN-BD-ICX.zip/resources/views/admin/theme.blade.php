@include('admin.partials-header')
@if ($flash)<div class="alert alert-success" style="margin-bottom:20px;">{{ $flash }}</div>@endif
<div class="admin-card">
  <form method="post">
    {!! csrfField() !!}
    <h3 style="margin-bottom:6px;">Color Themes</h3>
    <p style="color:#888;font-size:13px;margin-bottom:12px;">Pick a ready-made color combination, then fine-tune below if you like. Nothing changes on the site until you press <strong>Save Theme</strong>.</p>
    @php
    $presets = [
      'Emerald (default)' => ['#00C896','#009688','#FFFFFF','#F4FBF9','#1A1A2E','#00E5B0'],
      'Ocean Blue'        => ['#1E88E5','#1565C0','#FFFFFF','#F1F7FE','#12213A','#4FC3F7'],
      'Royal Purple'      => ['#7C4DFF','#5E35B1','#FFFFFF','#F6F3FF','#1E1633','#B388FF'],
      'Sunset Orange'     => ['#FF7043','#E64A19','#FFFFFF','#FFF5F1','#2B1810','#FFAB91'],
      'Rose Pink'         => ['#EC407A','#C2185B','#FFFFFF','#FFF1F6','#2A1220','#F48FB1'],
      'Golden'            => ['#F9A825','#F57F17','#FFFFFF','#FFFBEF','#2A2210','#FFD54F'],
      'Midnight Dark'     => ['#00C896','#009688','#0F172A','#1E293B','#E2E8F0','#00E5B0'],
      'Dark Purple'       => ['#A78BFA','#7C3AED','#12101F','#1F1B33','#EDE9FE','#C4B5FD'],
    ];
    @endphp
    <div style="display:flex;flex-wrap:wrap;gap:10px;margin-bottom:28px;">
      @foreach ($presets as $name => $c)
        <button type="button" class="theme-preset" data-colors="{{ json_encode(['color_primary'=>$c[0],'color_secondary'=>$c[1],'color_bg'=>$c[2],'color_card'=>$c[3],'color_text'=>$c[4],'color_accent'=>$c[5]]) }}"
          style="border:2px solid #e8e8e8;background:#fff;border-radius:10px;padding:8px 12px;cursor:pointer;display:flex;align-items:center;gap:8px;font-size:13px;font-weight:700;">
          <span style="display:inline-flex;">
            @foreach ([0,1,2,3] as $i)<span style="width:16px;height:16px;border-radius:50%;background:{{ $c[$i] }};border:1px solid rgba(0,0,0,.12);margin-left:{{ $i?'-5px':'0' }};"></span>@endforeach
          </span>{{ $name }}
        </button>
      @endforeach
    </div>
    <h3 style="margin-bottom:20px;">Colors</h3>
    <div class="color-row" style="margin-bottom:28px;">
      @php
        $colorFields = ['color_primary'=>'Primary','color_secondary'=>'Secondary','color_bg'=>'Background','color_card'=>'Card BG','color_text'=>'Text','color_accent'=>'Accent','color_danger'=>'Danger','color_warning'=>'Warning'];
      @endphp
      @foreach ($colorFields as $k => $label)
        @php $val = getSetting($k,'#00C896'); @endphp
        <div class="color-item">
          <label>{{ $label }}</label>
          <div class="color-picker-wrap">
            <input type="color" name="{{ $k }}" value="{{ $val }}" oninput="this.nextElementSibling.value=this.value.toUpperCase()">
            <input type="text" value="{{ $val }}" onchange="if(/^#[0-9A-Fa-f]{6}$/.test(this.value)){this.previousElementSibling.value=this.value}" style="width:90px;padding:8px;border:2px solid #e8e8e8;border-radius:6px;font-family:monospace;font-size:13px;">
          </div>
        </div>
      @endforeach
    </div>
    <h3 style="margin-bottom:20px;">Typography & Style</h3>
    <div class="admin-form-grid">
      <div class="admin-form-group">
        <label class="admin-label">Font Family</label>
        <select name="font_family" class="admin-input">
          @foreach ($fonts as $f)
            <option value="{{ $f }}" {{ getSetting('font_family','Nunito')===$f?'selected':'' }}>{{ $f }}</option>
          @endforeach
        </select>
      </div>
      <div class="admin-form-group">
        <label class="admin-label">Border Radius (px): <strong id="radius-val">{{ getSetting('border_radius','12') }}</strong>px</label>
        <input type="range" name="border_radius" min="0" max="32" step="2" value="{{ getSetting('border_radius','12') }}" oninput="document.getElementById('radius-val').textContent=this.value" style="width:100%;margin-top:8px;">
      </div>
      <div class="admin-form-group">
        <label class="admin-label">Button Style</label>
        <select name="button_style" class="admin-input">
          <option value="filled" {{ getSetting('button_style','filled')==='filled'?'selected':'' }}>Filled</option>
          <option value="outlined" {{ getSetting('button_style')==='outlined'?'selected':'' }}>Outlined</option>
          <option value="gradient" {{ getSetting('button_style')==='gradient'?'selected':'' }}>Gradient</option>
        </select>
      </div>
    </div>
    <div style="display:flex;gap:12px;">
      <button type="submit" class="btn btn-primary"><i class="fa-solid fa-save"></i> Save Theme</button>
      <button type="button" class="btn btn-outline" onclick="if(confirm('Reset all colors to default?')){resetDefaults()}">Reset to Default</button>
    </div>
  </form>
</div>
@php
$extraJs = '<script>
document.querySelectorAll(".theme-preset").forEach(function(b){b.addEventListener("click",function(){
  var c=JSON.parse(b.dataset.colors);
  Object.keys(c).forEach(function(k){var i=document.querySelector("[name="+k+"]");if(i){i.value=c[k];if(i.nextElementSibling){i.nextElementSibling.value=c[k];}}});
  document.querySelectorAll(".theme-preset").forEach(function(x){x.style.borderColor="#e8e8e8";});
  b.style.borderColor=c.color_primary;
});});
function resetDefaults() {
  const d = {color_primary:"#00C896",color_secondary:"#009688",color_bg:"#FFFFFF",color_card:"#F4FBF9",color_text:"#1A1A2E",color_accent:"#00E5B0",color_danger:"#FF4757",color_warning:"#FFA502"};
  Object.entries(d).forEach(([k,v])=>{const inp=document.querySelector("[name="+k+"]");if(inp){inp.value=v;inp.nextElementSibling&&(inp.nextElementSibling.value=v);}});
}
</script>';
@endphp
@include('admin.partials-footer', ['extraJs' => $extraJs])
