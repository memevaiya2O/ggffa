@include('admin.partials-header')
@if ($flash)<div class="alert alert-success" style="margin-bottom:20px;">{{ $flash }}</div>@endif

<div style="display:flex;align-items:center;gap:16px;margin-bottom:24px;flex-wrap:wrap;">
  <a href="/Icxpanel/users" class="btn btn-secondary btn-sm">← Back to Users</a>
  <h2 style="margin:0;">{{ $user['name'] }}</h2>
  <span class="badge {{ $user['status']==='active'?'badge-success':($user['status']==='banned'?'badge-danger':'badge-warning') }}">{{ ucfirst($user['status']) }}</span>
  @if ($user['level_name'])<span class="badge" style="background:{{ $user['level_color'] }}">{{ $user['level_name'] }}</span>@endif
</div>

<!-- Stats row -->
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:16px;margin-bottom:24px;">
  <div class="stat-card"><div class="stat-value">৳{{ number_format($user['balance'],2) }}</div><div class="stat-label">Current Balance</div></div>
  <div class="stat-card"><div class="stat-value">৳{{ number_format($totalEarned,2) }}</div><div class="stat-label">Total Earned</div></div>
  <div class="stat-card"><div class="stat-value">৳{{ number_format($totalWithdrawn,2) }}</div><div class="stat-label">Total Withdrawn</div></div>
  <div class="stat-card"><div class="stat-value">{{ $tasksDone }}</div><div class="stat-label">Tasks Completed</div></div>
  <div class="stat-card"><div class="stat-value">{{ count($referrals) }}</div><div class="stat-label">Referrals</div></div>
  <div class="stat-card"><div class="stat-value">{{ $user['points'] ?? 0 }}</div><div class="stat-label">Points</div></div>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:24px;margin-bottom:24px;">

<!-- Edit Profile -->
<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">Edit Profile</div></div>
  <div class="admin-card-body">
    <form method="post">
      {!! csrfField() !!}
      <input type="hidden" name="action" value="update_profile">
      <div class="form-group"><label>Name</label><input type="text" name="name" class="form-control" value="{{ $user['name'] }}" required></div>
      <div class="form-group"><label>Email</label><input type="email" name="email" class="form-control" value="{{ $user['email'] }}" required></div>
      <div class="form-group"><label>Phone</label><input type="text" name="phone" class="form-control" value="{{ $user['phone'] ?? '' }}"></div>
      <div class="form-group"><label>Level</label>
        <select name="level_id" class="form-control">
          @foreach ($levels as $lv)<option value="{{ $lv['id'] }}" {{ $user['level_id']==$lv['id']?'selected':'' }}>{{ $lv['name'] }}</option>@endforeach
        </select>
      </div>
      <div class="form-group"><label>Status</label>
        <select name="status" class="form-control">
          <option value="active" {{ $user['status']==='active'?'selected':'' }}>Active</option>
          <option value="banned" {{ $user['status']==='banned'?'selected':'' }}>Banned</option>
          <option value="inactive" {{ $user['status']==='inactive'?'selected':'' }}>Inactive</option>
        </select>
      </div>
      <button class="btn btn-primary">Update</button>
    </form>
  </div>
</div>

<div style="display:flex;flex-direction:column;gap:16px;">
  <!-- Quick Actions -->
  <div class="admin-card">
    <div class="admin-card-header"><div class="admin-card-title">Quick Actions</div></div>
    <div class="admin-card-body" style="display:flex;flex-direction:column;gap:10px;">
      <!-- Credit/Debit -->
      <form method="post" style="display:flex;gap:8px;flex-wrap:wrap;">
        {!! csrfField() !!}<input type="hidden" name="action" value="credit">
        <input type="number" name="amount" class="form-control" placeholder="Amount (neg to debit)" style="width:130px;" step="0.01">
        <input type="text" name="note" class="form-control" placeholder="Note" style="flex:1;min-width:100px;">
        <button class="btn btn-success btn-sm">Credit/Debit</button>
      </form>
      <!-- Wallet activation -->
      <form method="post" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
        {!! csrfField() !!}<input type="hidden" name="action" value="toggle_wallet">
        <span style="font-size:13px;font-weight:700;">Wallet: <span style="color:{{ $user['wallet_active'] ? 'var(--primary)' : 'var(--danger)' }}">{{ $user['wallet_active'] ? 'Active' : 'Inactive' }}</span></span>
        <input type="hidden" name="activate" value="{{ $user['wallet_active'] ? '0' : '1' }}">
        <button class="btn {{ $user['wallet_active'] ? 'btn-danger' : 'btn-success' }} btn-sm">{{ $user['wallet_active'] ? 'Deactivate' : 'Activate manually' }}</button>
      </form>
      <!-- Notify -->
      <form method="post">
        {!! csrfField() !!}<input type="hidden" name="action" value="notify">
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
          <input type="text" name="notif_title" class="form-control" placeholder="Title" style="flex:1;min-width:100px;">
          <input type="text" name="notif_msg" class="form-control" placeholder="Message" style="flex:2;min-width:140px;">
          <button class="btn btn-info btn-sm">Send</button>
        </div>
      </form>
      <!-- Password -->
      <form method="post" style="display:flex;gap:8px;">
        {!! csrfField() !!}<input type="hidden" name="action" value="change_password">
        <input type="password" name="new_password" class="form-control" placeholder="New password (min 6)" style="flex:1;">
        <button class="btn btn-warning btn-sm">Set PW</button>
      </form>
      <!-- Delete -->
      <form method="post" onsubmit="return confirm('Delete this user permanently? All data will be lost.')">
        {!! csrfField() !!}<input type="hidden" name="action" value="delete">
        <button class="btn btn-danger" style="width:100%;">🗑 Delete User</button>
      </form>
    </div>
  </div>

  <!-- User Info -->
  <div class="admin-card">
    <div class="admin-card-header"><div class="admin-card-title">User Info</div></div>
    <div class="admin-card-body">
      <table style="width:100%;border-collapse:collapse;font-size:13px;">
        <tr style="border-bottom:1px solid #f5f5f5;"><td style="padding:6px;color:#888;">Joined</td><td style="padding:6px;">{{ date('d M Y H:i',strtotime($user['created_at'])) }}</td></tr>
        <tr style="border-bottom:1px solid #f5f5f5;"><td style="padding:6px;color:#888;">Referral Code</td><td style="padding:6px;font-family:monospace;">{{ $user['referral_code'] ?? 'N/A' }}</td></tr>
        <tr style="border-bottom:1px solid #f5f5f5;"><td style="padding:6px;color:#888;">Referred By</td><td style="padding:6px;">@if ($user['referred_by']){{ \App\Models\User::query()->where('id', (int)$user['referred_by'])->value('name') ?: 'Unknown' }}@else—@endif</td></tr>
        <tr style="border-bottom:1px solid #f5f5f5;"><td style="padding:6px;color:#888;">Daily Streak</td><td style="padding:6px;">{{ $user['streak_days'] ?? 0 }} days</td></tr>
        <tr><td style="padding:6px;color:#888;">Last Login</td><td style="padding:6px;">{{ $user['last_login'] ? date('d M Y H:i',strtotime($user['last_login'])) : 'Never' }}</td></tr>
      </table>
    </div>
  </div>
</div>
</div>

<!-- Tabs for history -->
<div class="admin-card">
  <div style="display:flex;gap:4px;padding:12px 16px;border-bottom:1px solid #f0f0f0;flex-wrap:wrap;" id="ud-tabs">
    @foreach (['transactions'=>'Transactions','submissions'=>'Submissions','withdrawals'=>'Withdrawals','referrals'=>'Referrals','notifications'=>'Notifications'] as $tab=>$label)
    <button class="btn btn-sm ud-tab-btn" data-tab="{{ $tab }}" onclick="showTab('{{ $tab }}')">{{ $label }}</button>
    @endforeach
  </div>

  <div id="tab-transactions" class="ud-tab">
    <div class="admin-table-wrap">
      <table class="admin-table">
        <thead><tr><th>Type</th><th>Description</th><th>Amount</th><th>Date</th></tr></thead>
        <tbody>
          @foreach ($txs as $tx)
          <tr>
            <td><span class="badge badge-info">{{ $tx['type'] }}</span></td>
            <td>{{ $tx['description'] }}</td>
            <td style="color:{{ $tx['amount']>=0?'#22c55e':'#ef4444' }};font-weight:600;">{{ $tx['amount']>=0?'+':'' }}৳{{ number_format(abs($tx['amount']),2) }}</td>
            <td style="font-size:12px;">{{ date('d M Y H:i',strtotime($tx['created_at'])) }}</td>
          </tr>
          @endforeach
          @if (!$txs->count())<tr><td colspan="4" style="text-align:center;color:#888;padding:20px;">No transactions.</td></tr>@endif
        </tbody>
      </table>
    </div>
  </div>

  <div id="tab-submissions" class="ud-tab" style="display:none;">
    <div class="admin-table-wrap">
      <table class="admin-table">
        <thead><tr><th>Task</th><th>Status</th><th>Date</th></tr></thead>
        <tbody>
          @foreach ($subs as $sub)
          <tr>
            <td>{{ $sub['task_title'] }}</td>
            <td><span class="badge {{ $sub['status']==='approved'?'badge-success':($sub['status']==='rejected'?'badge-danger':'badge-warning') }}">{{ ucfirst($sub['status']) }}</span></td>
            <td style="font-size:12px;">{{ date('d M Y H:i',strtotime($sub['created_at'])) }}</td>
          </tr>
          @endforeach
          @if (!$subs->count())<tr><td colspan="3" style="text-align:center;color:#888;padding:20px;">No submissions.</td></tr>@endif
        </tbody>
      </table>
    </div>
  </div>

  <div id="tab-withdrawals" class="ud-tab" style="display:none;">
    <div class="admin-table-wrap">
      <table class="admin-table">
        <thead><tr><th>Method</th><th>Amount</th><th>Status</th><th>Date</th></tr></thead>
        <tbody>
          @foreach ($withs as $w)
          <tr>
            <td><span class="badge badge-info">{{ $w['method'] }}</span></td>
            <td>৳{{ number_format($w['amount'],2) }}</td>
            <td><span class="badge {{ $w['status']==='approved'?'badge-success':($w['status']==='rejected'?'badge-danger':'badge-warning') }}">{{ ucfirst($w['status']) }}</span></td>
            <td style="font-size:12px;">{{ date('d M Y H:i',strtotime($w['created_at'])) }}</td>
          </tr>
          @endforeach
          @if (!$withs->count())<tr><td colspan="4" style="text-align:center;color:#888;padding:20px;">No withdrawals.</td></tr>@endif
        </tbody>
      </table>
    </div>
  </div>

  <div id="tab-referrals" class="ud-tab" style="display:none;">
    <div class="admin-table-wrap">
      <table class="admin-table">
        <thead><tr><th>Name</th><th>Email</th><th>Joined</th></tr></thead>
        <tbody>
          @foreach ($referrals as $r)
          <tr><td>{{ $r['name'] }}</td><td>{{ $r['email'] }}</td><td style="font-size:12px;">{{ date('d M Y',strtotime($r['created_at'])) }}</td></tr>
          @endforeach
          @if (!$referrals->count())<tr><td colspan="3" style="text-align:center;color:#888;padding:20px;">No referrals.</td></tr>@endif
        </tbody>
      </table>
    </div>
  </div>

  <div id="tab-notifications" class="ud-tab" style="display:none;">
    <div class="admin-table-wrap">
      <table class="admin-table">
        <thead><tr><th>Type</th><th>Title</th><th>Read</th><th>Date</th></tr></thead>
        <tbody>
          @foreach ($notifs as $n)
          <tr>
            <td><span class="badge badge-info">{{ $n['type'] }}</span></td>
            <td title="{{ $n['message'] }}">{{ mb_strimwidth($n['title'],0,50,'…') }}</td>
            <td>{{ $n['is_read']?'<span style="color:green">✓</span>':'<span style="color:#aaa">✗</span>' }}</td>
            <td style="font-size:12px;">{{ date('d M H:i',strtotime($n['created_at'])) }}</td>
          </tr>
          @endforeach
          @if (!$notifs->count())<tr><td colspan="4" style="text-align:center;color:#888;padding:20px;">No notifications.</td></tr>@endif
        </tbody>
      </table>
    </div>
  </div>
</div>

<script>
function showTab(name) {
  document.querySelectorAll('.ud-tab').forEach(t => t.style.display='none');
  document.querySelectorAll('.ud-tab-btn').forEach(b => b.classList.remove('btn-primary'));
  document.querySelectorAll('.ud-tab-btn').forEach(b => b.classList.add('btn-secondary'));
  document.getElementById('tab-'+name).style.display='block';
  document.querySelector('[data-tab="'+name+'"]').classList.add('btn-primary');
  document.querySelector('[data-tab="'+name+'"]').classList.remove('btn-secondary');
}
showTab('transactions');
</script>
@include('admin.partials-footer')
