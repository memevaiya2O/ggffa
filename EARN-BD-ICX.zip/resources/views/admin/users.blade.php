@include('admin.partials-header')
@if ($flash)<div class="alert alert-success" style="margin-bottom:20px;">{{ $flash }}</div>@endif
{!! csrfField() !!}

<div class="admin-card">
  <div class="admin-card-header">
    <div class="admin-card-title">Users ({{ number_format($total) }})</div>
    <a href="?export=csv" class="btn btn-sm btn-outline"><i class="fa-solid fa-download"></i> Export CSV</a>
  </div>

  <form method="get" class="admin-filters">
    <input type="text" name="search" class="filter-input" placeholder="Search name or email..." value="{{ $search }}">
    <select name="level" class="filter-select">
      <option value="">All Levels</option>
      @foreach ($levels as $l)
        <option value="{{ $l['id'] }}" {{ $level==$l['id']?'selected':'' }}>{{ $l['name'] }}</option>
      @endforeach
    </select>
    <select name="status" class="filter-select">
      <option value="">All Status</option>
      <option value="active" {{ $status==='active'?'selected':'' }}>Active</option>
      <option value="banned" {{ $status==='banned'?'selected':'' }}>Banned</option>
    </select>
    <button type="submit" class="filter-btn filter-btn-primary"><i class="fa-solid fa-magnifying-glass"></i> Search</button>
    <a href="/Icxpanel/users" class="filter-btn filter-btn-outline">Reset</a>
  </form>

  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>User</th><th>Level</th><th>Balance</th><th>Points</th><th>Status</th><th>Joined</th><th>Actions</th></tr></thead>
      <tbody>
        @foreach ($users as $u)
          <tr>
            <td>
              <div class="user-cell">
                <div class="table-avatar">@if ($u['avatar'])<img src="{{ $u['avatar'] }}" alt="">@else{{ strtoupper(substr($u['name'],0,1)) }}@endif</div>
                <div class="user-cell-info"><div class="user-cell-name">{{ $u['name'] }}</div><div class="user-cell-email">{{ $u['email'] }}</div></div>
              </div>
            </td>
            <td><span class="badge" style="background:{{ $u['level_color']??'#CD7F32' }}22;color:{{ $u['level_color']??'#CD7F32' }}">{{ $u['level_name']??'Bronze' }}</span></td>
            <td style="font-weight:700;color:var(--primary)">{{ formatAmount((float)$u['balance']) }}</td>
            <td>{{ number_format($u['points']) }}</td>
            <td><span class="status-badge status-{{ $u['status'] }}">{{ ucfirst($u['status']) }}</span></td>
            <td style="font-size:12px;color:#888">{{ date('M j, Y',strtotime($u['created_at'])) }}</td>
            <td>
              <div class="action-btns">
                <a href="/Icxpanel/user-detail?id={{ $u['id'] }}" class="action-btn-sm action-btn-view"><i class="fa-solid fa-eye"></i></a>
                <button class="action-btn-sm action-btn-edit" onclick="openCreditModal({{ $u['id'] }}, '{{ addslashes($u['name']) }}', {{ $u['balance'] }})"><i class="fa-solid fa-coins"></i></button>
                @if ($u['status'] === 'active')
                  <form method="post" style="display:inline">{!! csrfField() !!}<input type="hidden" name="action" value="ban"><input type="hidden" name="user_id" value="{{ $u['id'] }}"><button type="submit" class="action-btn-sm action-btn-reject" data-confirm="Ban this user?"><i class="fa-solid fa-ban"></i></button></form>
                @else
                  <form method="post" style="display:inline">{!! csrfField() !!}<input type="hidden" name="action" value="unban"><input type="hidden" name="user_id" value="{{ $u['id'] }}"><button type="submit" class="action-btn-sm action-btn-approve"><i class="fa-solid fa-check"></i></button></form>
                @endif
              </div>
            </td>
          </tr>
        @endforeach
      </tbody>
    </table>
  </div>
  {!! paginationLinks($total, $page, $limit, '/Icxpanel/users?' . http_build_query(['search'=>$search,'level'=>$level,'status'=>$status])) !!}
</div>

<!-- Credit Modal -->
<div class="modal-overlay" id="credit-modal">
  <div class="modal-box">
    <div class="modal-header"><h3 id="credit-modal-title">Balance</h3><span class="modal-close"><i class="fa-solid fa-xmark"></i></span></div>
    <form method="post" action="/Icxpanel/users">
      {!! csrfField() !!}
      <input type="hidden" name="action" value="credit">
      <input type="hidden" name="user_id" id="credit-uid">
      <div class="form-group"><label class="form-label">Amount (positive = credit, negative = deduct)</label><input type="number" name="amount" class="form-control" step="0.01" required placeholder="e.g. 100 or -50"></div>
      <button type="submit" class="btn btn-primary btn-block">Apply</button>
    </form>
  </div>
</div>
<script>function openCreditModal(uid,name,bal){document.getElementById('credit-uid').value=uid;document.getElementById('credit-modal-title').textContent='Balance: '+name+' (Current: '+bal+')';document.getElementById('credit-modal').classList.add('active');}</script>
@include('admin.partials-footer')
