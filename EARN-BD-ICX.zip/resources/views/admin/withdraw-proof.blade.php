@include('admin.partials-header')
@if ($flash)<div class="alert alert-success" style="margin-bottom:20px;">{{ $flash }}</div>@endif

<div class="admin-card">
  <div class="admin-card-header">
    <div class="admin-card-title">Withdrawal Proofs ({{ $total }})</div>
    <div style="display:flex;gap:8px;">
      @foreach (['pending'=>'Pending','approved'=>'Approved','rejected'=>'Rejected','all'=>'All'] as $v => $l)
      <a href="?status={{ $v }}" class="btn btn-sm {{ $filter===$v?'btn-primary':'btn-secondary' }}">{{ $l }}</a>
      @endforeach
    </div>
  </div>

  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>User</th><th>Method</th><th>Account</th><th>Amount</th><th>Requested</th><th>Status</th><th>Proof / Action</th></tr></thead>
      <tbody>
        @foreach ($withdrawals as $w)
          @php $details = json_decode($w['details'] ?? '{}', true) ?? []; @endphp
          <tr>
            <td>
              <a href="/Icxpanel/user-detail?id={{ $w['user_id'] }}"><strong>{{ $w['user_name'] }}</strong></a><br>
              <small style="color:#888;">{{ $w['user_email'] }}</small>
            </td>
            <td><span class="badge badge-info">{{ $w['method'] }}</span></td>
            <td style="font-size:13px;">
              @foreach ($details as $k => $v)
              <div><strong>{{ $k }}:</strong> {{ $v }}</div>
              @endforeach
            </td>
            <td><strong style="color:#22c55e;">৳{{ number_format($w['amount'],2) }}</strong></td>
            <td style="font-size:12px;">{{ date('d M Y H:i',strtotime($w['created_at'])) }}</td>
            <td>
              <span class="badge {{ $w['status']==='approved'?'badge-success':($w['status']==='rejected'?'badge-danger':'badge-warning') }}">
                {{ ucfirst($w['status']) }}
              </span>
              @if ($w['admin_note'])
              <div style="font-size:11px;color:#888;margin-top:4px;">{{ $w['admin_note'] }}</div>
              @endif
              @if ($w['tx_reference'])
              <div style="font-size:11px;color:#667eea;">Ref: {{ $w['tx_reference'] }}</div>
              @endif
            </td>
            <td>
              @if ($w['status']==='pending')
              <button class="btn btn-success btn-xs" onclick="approveW({{ $w['id'] }})">✓ Approve</button>
              <button class="btn btn-danger btn-xs" onclick="rejectW({{ $w['id'] }})">✗ Reject</button>
              @else
              <span style="color:#aaa;font-size:12px;">Processed</span>
              @endif
            </td>
          </tr>
        @endforeach
        @if (!$withdrawals->count())<tr><td colspan="7" style="text-align:center;color:#888;padding:30px;">No {{ $filter === 'all' ? '' : $filter }} withdrawals found.</td></tr>@endif
      </tbody>
    </table>
  </div>

  @if ($total > $limit)
  <div style="padding:12px;text-align:center;">
    @for ($i = 1; $i <= ceil($total/$limit); $i++)
    <a href="?status={{ $filter }}&page={{ $i }}" class="btn btn-xs {{ $page==$i?'btn-primary':'btn-secondary' }}">{{ $i }}</a>
    @endfor
  </div>
  @endif
</div>

<!-- Approve Modal -->
<div id="approve-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9999;align-items:center;justify-content:center;">
  <div style="background:#fff;border-radius:12px;padding:28px;min-width:360px;max-width:500px;width:90%;">
    <h3 style="margin:0 0 16px;">✓ Approve Withdrawal</h3>
    <form method="post">
      {!! csrfField() !!}
      <input type="hidden" name="action" value="approve">
      <input type="hidden" name="withdrawal_id" id="approve-wid">
      <div class="form-group"><label>Transaction Reference (optional)</label><input type="text" name="tx_ref" class="form-control" placeholder="bKash TrxID / Nagad Ref"></div>
      <div class="form-group"><label>Note (optional)</label><input type="text" name="note" class="form-control" placeholder="Payment sent via bKash"></div>
      <div style="display:flex;gap:8px;margin-top:16px;">
        <button class="btn btn-success">Confirm Approve</button>
        <button type="button" class="btn btn-secondary" onclick="closeModals()">Cancel</button>
      </div>
    </form>
  </div>
</div>

<!-- Reject Modal -->
<div id="reject-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9999;align-items:center;justify-content:center;">
  <div style="background:#fff;border-radius:12px;padding:28px;min-width:360px;max-width:500px;width:90%;">
    <h3 style="margin:0 0 16px;">✗ Reject Withdrawal</h3>
    <form method="post">
      {!! csrfField() !!}
      <input type="hidden" name="action" value="reject">
      <input type="hidden" name="withdrawal_id" id="reject-wid">
      <div class="form-group"><label>Rejection Reason</label><input type="text" name="reject_reason" class="form-control" value="Invalid account details" required></div>
      <small style="color:#e74c3c;">Amount will be automatically refunded to user's wallet.</small>
      <div style="display:flex;gap:8px;margin-top:16px;">
        <button class="btn btn-danger">Confirm Reject</button>
        <button type="button" class="btn btn-secondary" onclick="closeModals()">Cancel</button>
      </div>
    </form>
  </div>
</div>

@php
$extraJs = '<script>
function approveW(id) {
  document.getElementById("approve-wid").value = id;
  document.getElementById("approve-modal").style.display = "flex";
}
function rejectW(id) {
  document.getElementById("reject-wid").value = id;
  document.getElementById("reject-modal").style.display = "flex";
}
function closeModals() {
  document.getElementById("approve-modal").style.display = "none";
  document.getElementById("reject-modal").style.display = "none";
}
document.querySelectorAll("#approve-modal,#reject-modal").forEach(m => m.addEventListener("click", e => { if(e.target===m) closeModals(); }));
</script>';
@endphp
@include('admin.partials-footer', ['extraJs' => $extraJs])
