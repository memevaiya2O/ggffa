@include('admin.partials-header')
@if ($flash)<div class="alert alert-success" style="margin-bottom:20px;">{{ $flash }}</div>@endif

<div class="kpi-grid" style="margin-bottom:20px;">
  <div class="kpi-card"><div class="kpi-icon orange"><i class="fa-solid fa-clock"></i></div><div class="kpi-body"><div class="kpi-label">Pending Payout</div><div class="kpi-value">{{ getSetting('currency_symbol','৳') }}{{ number_format($pendingSum,2) }}</div></div></div>
</div>

<div class="admin-card">
  <div class="admin-card-header">
    <div class="admin-card-title">Withdrawals ({{ $total }})</div>
    <a href="?export=csv&status={{ $status }}" class="btn btn-sm btn-outline"><i class="fa-solid fa-download"></i> Export CSV</a>
  </div>
  <div class="admin-filters">
    @foreach (['pending'=>'⏳ Pending','paid'=>'✅ Paid','rejected'=>'❌ Rejected','all'=>'All'] as $k => $v)
      <a href="?status={{ $k }}" class="filter-btn {{ $status===$k?'filter-btn-primary':'filter-btn-outline' }}">{{ $v }}</a>
    @endforeach
    <form method="get" style="display:flex;gap:8px;">
      <input type="hidden" name="status" value="{{ $status }}">
      <select name="method" class="filter-select" onchange="this.form.submit()">
        <option value="">All Methods</option>
        @foreach ($methods as $m)<option value="{{ $m['id'] }}" {{ $method==$m['id']?'selected':'' }}>{{ $m['name'] }}</option>@endforeach
      </select>
    </form>
  </div>
  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>User</th><th>Method</th><th>Address</th><th>Amount</th><th>Status</th><th>Requested</th><th>Actions</th></tr></thead>
      <tbody>
        @foreach ($withdrawals as $w)
          <tr>
            <td><div class="user-cell"><div class="table-avatar">{{ strtoupper(substr($w['user_name'],0,1)) }}</div><div><div class="user-cell-name">{{ $w['user_name'] }}</div><div class="user-cell-email">{{ $w['user_email'] }}</div></div></div></td>
            <td><div style="display:flex;align-items:center;gap:6px;"><i class="fa-solid {{ $w['method_icon']??'fa-wallet' }}" style="color:var(--primary)"></i>{{ $w['method_name'] }}</div></td>
            <td style="font-size:13px;font-family:monospace;">{{ $w['address'] }}</td>
            <td style="font-weight:900;font-size:18px;">{{ formatAmount((float)$w['amount']) }}</td>
            <td><span class="status-badge status-{{ $w['status'] }}">{{ ucfirst($w['status']) }}</span>@if ($w['admin_note'])<div style="font-size:11px;color:#888;margin-top:4px;">{{ substr($w['admin_note'],0,40) }}</div>@endif</td>
            <td style="font-size:12px;color:#888">{{ date('M j, Y',strtotime($w['created_at'])) }}</td>
            <td>
              @if ($w['status'] === 'pending')
                <div class="action-btns">
                  <button class="action-btn-sm action-btn-pay" onclick="openPayModal({{ $w['id'] }},{{ $w['amount'] }})"><i class="fa-solid fa-check"></i> Pay</button>
                  <button class="action-btn-sm action-btn-reject" onclick="openRejectWModal({{ $w['id'] }})"><i class="fa-solid fa-times"></i> Reject</button>
                </div>
              @endif
            </td>
          </tr>
        @endforeach
      </tbody>
    </table>
  </div>
  {!! paginationLinks($total,$page,$limit,'/Icxpanel/withdrawals?status='.$status) !!}
</div>

<!-- Pay Modal -->
<div class="modal-overlay" id="pay-modal">
  <div class="modal-box">
    <div class="modal-header"><h3 id="pay-modal-title">Mark as Paid</h3><span class="modal-close"><i class="fa-solid fa-xmark"></i></span></div>
    <form method="post"><{!! csrfField() !!}<input type="hidden" name="action" value="pay"><input type="hidden" name="wid" id="pay-wid">
    <div class="form-group"><label class="form-label">Admin Note (optional)</label><input type="text" name="note" class="form-control" placeholder="Transaction ID or note..."></div>
    <button type="submit" class="btn btn-primary btn-block"><i class="fa-solid fa-check"></i> Mark as Paid</button>
    </form>
  </div>
</div>
<!-- Reject Modal -->
<div class="modal-overlay" id="reject-w-modal">
  <div class="modal-box">
    <div class="modal-header"><h3>Reject Withdrawal</h3><span class="modal-close"><i class="fa-solid fa-xmark"></i></span></div>
    <form method="post">{!! csrfField() !!}<input type="hidden" name="action" value="reject"><input type="hidden" name="wid" id="reject-wid">
    <div class="form-group"><label class="form-label">Reason <span style="color:var(--danger)">*</span></label><textarea name="reason" class="form-control" rows="3" required placeholder="Rejection reason..."></textarea></div>
    <button type="submit" class="btn btn-danger btn-block">Reject & Refund</button>
    </form>
  </div>
</div>
@php
$extraJs = '<script>
function openPayModal(id,amt){document.getElementById("pay-wid").value=id;document.getElementById("pay-modal-title").textContent="Mark as Paid — "+"' . e(getSetting('currency_symbol','৳')) . '"+amt;document.getElementById("pay-modal").classList.add("active");}
function openRejectWModal(id){document.getElementById("reject-wid").value=id;document.getElementById("reject-w-modal").classList.add("active");}
</script>';
@endphp
@include('admin.partials-footer', ['extraJs' => $extraJs])
