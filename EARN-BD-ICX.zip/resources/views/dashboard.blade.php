<!DOCTYPE html>
<html lang="en">
<head>
{!! renderSeoMeta() !!}
{!! renderGoogleFont() !!}
{!! renderCssVars() !!}
<link rel="stylesheet" href="/assets/css/style.css?v=3">
<link rel="stylesheet" href="/assets/css/dashboard.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
{!! getSetting('custom_header_script') !!}
</head>
<body>
<div class="app-layout">
  <header class="app-header">
    <div class="app-header-left">
      <div>
        <div class="greeting">Good {{ date('H') < 12 ? 'Morning' : (date('H') < 18 ? 'Afternoon' : 'Evening') }} 👋</div>
        <div class="user-name">{{ $user['name'] }}</div>
      </div>
    </div>
    <div class="app-header-right">
      <a href="/notifications" class="notif-btn">
        <i class="fa-solid fa-bell"></i>
        @if ($notifCount > 0)
          <span class="notif-badge">{{ $notifCount > 99 ? '99+' : $notifCount }}</span>
        @endif
      </a>
      <a href="/profile" class="user-avatar-sm">
        @if ($user['avatar'])<img src="{{ $user['avatar'] }}" alt="">@else{{ strtoupper(substr($user['name'],0,1)) }}@endif
      </a>
    </div>
  </header>

  <main class="main-content">
    @if (!empty($welcome))
      <div class="alert alert-success" style="margin-bottom:16px;">🎉 Welcome to {{ getSetting('site_name') }}! Your account is ready.</div>
    @endif
    @if (!empty($bonus))
      <div class="alert alert-success" style="margin-bottom:16px;">🎁 Daily bonus claimed successfully!</div>
    @endif

    <!-- Balance Card -->
    <div class="balance-card">
      <div class="balance-deco"><i class="fa-solid fa-coins"></i></div>
      <div class="balance-label">Available Balance</div>
      <div class="balance-amount">{{ getSetting('currency_symbol','৳') }}{{ number_format((float)$user['balance'],2) }}</div>
      <div class="balance-stats">
        <div class="balance-stat">
          <div class="label">Total Earned</div>
          <div class="value">{{ getSetting('currency_symbol','৳') }}{{ number_format((float)$user['total_earned'],2) }}</div>
        </div>
        <div class="balance-stat">
          <div class="label">Withdrawn</div>
          <div class="value">{{ getSetting('currency_symbol','৳') }}{{ number_format((float)$user['total_withdrawn'],2) }}</div>
        </div>
      </div>
    </div>

    <!-- Level Card -->
    <div class="level-card">
      <div class="level-header">
        <div class="level-badge" style="background:{{ $user['level_color'] ?? '#CD7F32' }}22;color:{{ $user['level_color'] ?? '#CD7F32' }}">
          <i class="fa-solid {{ $user['level_icon'] ?? 'fa-medal' }}"></i>
        </div>
        <div class="level-info">
          <h4>{{ $user['level_name'] ?? 'Bronze' }} Level</h4>
          <p>{{ $curPoints }} XP{{ $nextLevel ? ' / ' . $nextLevel['required_points'] . ' to ' . $nextLevel['name'] : ' — Max Level!' }}</p>
        </div>
      </div>
      <div class="xp-bar"><div class="xp-fill" style="width:{{ $xpPct }}%"></div></div>
      <div class="xp-labels"><span>{{ $curPoints }} XP</span><span>{{ $xpPct }}%</span></div>
    </div>

    <!-- Daily Bonus -->
    <div class="daily-card">
      <div class="daily-info">
        <h4>🎁 Daily Bonus</h4>
        <p>{{ formatAmount((float)getSetting('daily_bonus_amount','5')) }} reward</p>
        @if ($bonusClaimed)
          <div class="daily-timer">Next in: <span id="bonus-countdown" data-next="{{ $nextBonus }}">--:--:--</span></div>
        @endif
      </div>
      @if (!$bonusClaimed)
        <form method="post" action="/dashboard" style="flex-shrink:0">
          {!! csrfField() !!}
          <button type="submit" name="claim_bonus" value="1" class="btn-daily">CLAIM</button>
        </form>
      @else
        <button class="btn-daily" disabled>CLAIMED ✓</button>
      @endif
    </div>

    <!-- Quick Actions -->
    <div class="quick-actions">
      <a href="/tasks" class="action-btn"><i class="fa-solid fa-list-check"></i>Tasks</a>
      <a href="/withdraw" class="action-btn"><i class="fa-solid fa-money-bill-transfer"></i>Withdraw</a>
      <a href="/leaderboard" class="action-btn"><i class="fa-solid fa-trophy"></i>Board</a>
      <a href="/spin" class="action-btn"><i class="fa-solid fa-circle-notch"></i>Spin</a>
    </div>

    <!-- My Stats -->
    <div class="stats-cards">
      <div class="stat-mini"><div class="num">{{ $tasksCompleted }}</div><div class="lbl">Tasks Done</div></div>
      <div class="stat-mini"><div class="num">{{ $referralsCount }}</div><div class="lbl">Referrals</div></div>
      <div class="stat-mini"><div class="num">{{ (int)$user['streak_days'] }}</div><div class="lbl">Day Streak</div></div>
    </div>

    <!-- Recent Activity -->
    <div class="sec-header"><h3>Recent Activity</h3><a href="/wallet">See All</a></div>
    <div class="activity-list">
      @if (!$transactions->count())
        <div style="text-align:center;padding:24px;color:#888;font-size:14px;"><i class="fa-solid fa-inbox" style="font-size:32px;display:block;margin-bottom:8px;"></i>No transactions yet</div>
      @else
        @foreach ($transactions as $tx)
          @php $pos = $tx['amount'] > 0; @endphp
          <div class="activity-item">
            <div class="activity-icon {{ $pos ? 'credit' : 'debit' }}">
              <i class="fa-solid {{ getTransactionIcon($tx['type']) }}"></i>
            </div>
            <div class="activity-info">
              <div class="activity-desc">{{ $tx['description'] }}</div>
              <div class="activity-time">{{ timeAgo($tx['created_at']) }}</div>
            </div>
            <div class="activity-amount {{ $pos ? 'pos' : 'neg' }}">{{ $pos ? '+' : '' }}{{ formatAmount(abs($tx['amount'])) }}</div>
          </div>
        @endforeach
      @endif
    </div>

    <!-- Achievements -->
    @if ($allAch->count())
    <div class="sec-header" style="margin-top:20px"><h3>Badges</h3><a href="/achievements">See All</a></div>
    <div class="badges-row">
      @foreach ($allAch as $a)
        <div class="badge-item">
          <div class="badge-icon {{ $a['unlocked_id'] ? 'unlocked' : 'locked' }}">
            <i class="fa-solid {{ $a['icon'] }}"></i>
          </div>
          <div class="badge-name">{{ strlen($a['name']) > 10 ? substr($a['name'],0,8).'...' : $a['name'] }}</div>
        </div>
      @endforeach
    </div>
    @endif
  </main>

  <!-- Bottom Nav -->
  <nav class="bottom-nav">
    <a href="/dashboard" class="nav-item active"><i class="fa-solid fa-house"></i>Home</a>
    <a href="/tasks" class="nav-item"><i class="fa-solid fa-list-check"></i>Tasks</a>
    <a href="/wallet" class="nav-item"><i class="fa-solid fa-wallet"></i>Wallet</a>
    <a href="/leaderboard" class="nav-item"><i class="fa-solid fa-trophy"></i>Board</a>
    <a href="/profile" class="nav-item"><i class="fa-solid fa-user"></i>Profile</a>
  </nav>
</div>
<div id="toast-container"></div>
<script src="/assets/js/main.js"></script>
{!! getSetting('custom_footer_script','') !!}
</body>
</html>
