<!DOCTYPE html>
<html lang="en">
<head>
{!! renderSeoMeta('home') !!}
{!! renderGoogleFont() !!}
{!! renderCssVars() !!}
<link rel="stylesheet" href="/assets/css/style.css?v=3">
<link rel="stylesheet" href="/assets/css/landing.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
{!! getSetting('custom_header_script') !!}
</head>
<body>

@php
    $cur = getSetting('currency_symbol', '৳');
    $logo = getSetting('site_logo');
    $heroHeadline = getSetting('hero_headline', 'Earn Real Money Completing Simple Tasks');
    $heroSub = getSetting('hero_subtext', 'Join thousands of users earning daily rewards');
    $heroCta = getSetting('hero_cta', 'Start Earning Now');
    $sections = [
        'howit'   => getSetting('section_howit', '1') === '1',
        'tasks'   => getSetting('section_tasks', '1') === '1' && $featTasks->count(),
        'earners' => getSetting('section_earners', '1') === '1' && $topEarners->count(),
        'proof'   => getSetting('section_proof', '1') === '1' && $proofs->count(),
    ];

    $features = [
        ['fa-bolt',          'Instant Rewards',       'Complete a task and get your reward as soon as it is approved.'],
        ['fa-wallet',        'Easy Withdrawals',      'Cash out through popular local payment methods quickly and safely.'],
        ['fa-gift',          'Daily Bonus & Spin',    'Come back every day for free bonuses and lucky spin prizes.'],
        ['fa-users',         'Refer & Earn',          'Invite friends with your referral code and earn from every join.'],
        ['fa-ranking-star',  'Levels & Leaderboard',  'Level up, unlock VIP tasks and climb the top earners list.'],
        ['fa-shield-halved', 'Safe & Transparent',    'Every task, payment and proof is tracked right in your dashboard.'],
    ];

    $stepDefaults = [
        1 => ['fa-user-plus', 'Create Account',  'Sign up for free in less than a minute.'],
        2 => ['fa-list-check', 'Complete Tasks', 'Pick simple tasks and submit your proof.'],
        3 => ['fa-wallet',     'Get Paid',       'Withdraw your earnings to your wallet.'],
    ];

    $faqs = [
        ['Is ' . $siteName . ' free to join?', 'Yes. Creating an account is completely free. You only spend your time on tasks.'],
        ['How do I earn money?', 'Choose a task, complete it, submit your proof and get the reward after approval. You can also earn from the daily bonus, spin wheel and referrals.'],
        ['How can I withdraw my earnings?', 'Open your wallet, pick an available payment method, enter your details and request a withdrawal. Approved payments show up in the payment proof section.'],
        ['How does the referral program work?', 'Share your personal referral code. When your friends join and start earning, you get a bonus for each successful referral.'],
    ];

    $delays = ['', 'd1', 'd2'];

    // Highlight the last word of the headline with the gradient (safe for any admin-set text)
    $headWords = preg_split('/\s+/u', trim($heroHeadline)) ?: [];
    $headLast  = '';
    if (count($headWords) > 1) {
        $headLast = array_pop($headWords);
    }
    $headFirst = implode(' ', $headWords);
@endphp

@if ($ann && $ann['status'] === 'active')
  <div class="announcement-bar" style="background:{{ $ann['color'] }};color:#fff;">
    @if ($ann['link'])<a href="{{ $ann['link'] }}">@endif
    {{ $ann['text'] }}
    @if ($ann['link'])</a>@endif
  </div>
@endif

<!-- ═════════ Header ═════════ -->
<header class="ld-header" id="ldHeader">
  <div class="ld-header-inner">
    <a href="/" class="site-logo">
      @include('partials.brand-logo', ['size' => 'md'])
    </a>

    <nav class="ld-links">
      <a href="#features">Features</a>
      @if($sections['howit'])<a href="#how-it-works">How It Works</a>@endif
      @if($sections['tasks'])<a href="#tasks">Tasks</a>@endif
      @if($sections['earners'])<a href="#earners">Top Earners</a>@endif
      <a href="#faq">FAQ</a>
    </nav>

    <div class="ld-actions">
      <a href="/login" class="btn btn-outline btn-sm">Login</a>
      <a href="/register" class="btn btn-primary btn-sm"><i class="fa-solid fa-rocket"></i> Join Free</a>
      <button class="ld-burger" id="ldBurger" aria-label="Menu"><i class="fa-solid fa-bars"></i></button>
    </div>
  </div>
  <div class="ld-mobile-menu" id="ldMobile">
    <a href="#features">Features</a>
    @if($sections['howit'])<a href="#how-it-works">How It Works</a>@endif
    @if($sections['tasks'])<a href="#tasks">Tasks</a>@endif
    @if($sections['earners'])<a href="#earners">Top Earners</a>@endif
    <a href="#faq">FAQ</a>
    <a href="/login">Login</a>
    <a href="/register" class="btn btn-primary btn-block"><i class="fa-solid fa-rocket"></i> Join Free</a>
  </div>
</header>

<!-- ═════════ Hero ═════════ -->
<section class="ld-hero">
  <span class="ld-orb a"></span><span class="ld-orb b"></span>
  <div class="ld-coins" aria-hidden="true">
    @for ($i = 0; $i < 10; $i++)
      <span class="ld-coin" style="left:{{ rand(4,96) }}%;animation-duration:{{ rand(10,20) }}s;animation-delay:-{{ rand(0,14) }}s;font-size:{{ rand(18,34) }}px;">{{ $i % 3 === 0 ? '🪙' : '💰' }}</span>
    @endfor
  </div>

  <div class="ld-hero-inner">
    <div>
      <span class="ld-badge"><span class="dot"></span> {{ number_format($totalUsers) }}+ members earning right now</span>
      <h1>
        @if ($headLast !== '')
          {{ $headFirst }} <span class="ld-grad">{{ $headLast }}</span>
        @else
          <span class="ld-grad">{{ $heroHeadline }}</span>
        @endif
      </h1>
      <p class="lead">{{ $heroSub }}</p>
      <div class="ld-cta">
        <a href="/register" class="btn btn-primary btn-lg"><i class="fa-solid fa-rocket"></i> {{ $heroCta }}</a>
        @if($sections['howit'])
          <a href="#how-it-works" class="btn btn-lg ld-btn-ghost"><i class="fa-solid fa-circle-play"></i> How It Works</a>
        @endif
      </div>
      <div class="ld-trust">
        <span><i class="fa-solid fa-circle-check"></i>Free to join</span>
        <span><i class="fa-solid fa-bolt"></i>Fast withdrawals</span>
        <span><i class="fa-solid fa-shield-halved"></i>Secure &amp; trusted</span>
      </div>
    </div>

    <div class="ld-visual">
      <div class="ld-phone">
        <span class="ld-chip c1"><i class="fa-solid fa-circle-check"></i> Task approved</span>
        <span class="ld-chip c2"><i class="fa-solid fa-gift"></i> Daily bonus ready</span>
        <div class="lbl">Your Balance</div>
        <div class="bal"><small>{{ $cur }}</small>{{ number_format(1250) }}</div>
        <div class="ld-bars"><i></i><i></i><i></i><i></i><i></i><i></i></div>
        <div class="ld-mini">
          <div class="ic"><i class="fa-solid fa-list-check"></i></div>
          <div class="tx">Task completed<small>Just now</small></div>
          <div class="am">+{{ $cur }}25</div>
        </div>
        <div class="ld-mini">
          <div class="ic"><i class="fa-solid fa-user-plus"></i></div>
          <div class="tx">Referral bonus<small>Today</small></div>
          <div class="am">+{{ $cur }}50</div>
        </div>
        <div class="ld-mini">
          <div class="ic"><i class="fa-solid fa-money-bill-transfer"></i></div>
          <div class="tx">Withdrawal paid<small>Today</small></div>
          <div class="am">{{ $cur }}500</div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═════════ Stats ═════════ -->
@if (getSetting('section_stats', '1') === '1')
<section class="ld-stats">
  <div class="ld-stats-grid">
    <div class="ld-stat reveal"><div class="ic"><i class="fa-solid fa-users"></i></div><div class="num count-up" data-target="{{ $totalUsers }}">{{ $totalUsers }}</div><div class="lab">Total Users</div></div>
    <div class="ld-stat reveal d1"><div class="ic"><i class="fa-solid fa-coins"></i></div><div class="num count-up" data-target="{{ round($totalPayout,2) }}" data-decimals="0">{{ number_format($totalPayout,0) }}</div><div class="lab">Total Payout {{ $cur }}</div></div>
    <div class="ld-stat reveal d2"><div class="ic"><i class="fa-solid fa-list-check"></i></div><div class="num count-up" data-target="{{ $totalTasks }}">{{ $totalTasks }}</div><div class="lab">Active Tasks</div></div>
    <div class="ld-stat reveal d3"><div class="ic"><i class="fa-solid fa-money-bill-transfer"></i></div><div class="num count-up" data-target="{{ $totalWithdraws }}">{{ $totalWithdraws }}</div><div class="lab">Withdrawals</div></div>
  </div>
</section>
@endif

<!-- ═════════ Features ═════════ -->
<section class="ld-section" id="features">
  <div class="ld-container">
    <div class="ld-head reveal">
      <span class="ld-eyebrow">Why {{ $siteName }}</span>
      <h2>Everything you need to earn online</h2>
      <p>A simple, safe and rewarding platform built for you.</p>
    </div>
    <div class="ld-feat-grid">
      @foreach ($features as $k => $f)
        <div class="ld-feat reveal {{ $delays[$k % 3] }}">
          <div class="ic"><i class="fa-solid {{ $f[0] }}"></i></div>
          <h3>{{ $f[1] }}</h3>
          <p>{{ $f[2] }}</p>
        </div>
      @endforeach
    </div>
  </div>
</section>

<!-- ═════════ How it works ═════════ -->
@if ($sections['howit'])
<section class="ld-section alt" id="how-it-works">
  <div class="ld-container">
    <div class="ld-head reveal">
      <span class="ld-eyebrow">Getting Started</span>
      <h2>How It Works</h2>
      <p>Start earning in 3 simple steps</p>
    </div>
    <div class="ld-steps">
      @for ($s = 1; $s <= 3; $s++)
        <div class="ld-step reveal {{ $delays[$s - 1] }}">
          <div class="no">{{ $s }}</div>
          <i class="fa-solid {{ getSetting('howit_' . $s . '_icon', $stepDefaults[$s][0]) }}"></i>
          <h3>{{ getSetting('howit_' . $s . '_title', $stepDefaults[$s][1]) }}</h3>
          <p>{{ getSetting('howit_' . $s . '_desc', $stepDefaults[$s][2]) }}</p>
        </div>
      @endfor
    </div>
  </div>
</section>
@endif

<!-- ═════════ Featured tasks ═════════ -->
@if ($sections['tasks'])
<section class="ld-section" id="tasks">
  <div class="ld-container">
    <div class="ld-head reveal">
      <span class="ld-eyebrow">Popular Now</span>
      <h2>Featured Tasks</h2>
      <p>Start earning with these popular tasks</p>
    </div>
    <div class="ld-tasks">
      @foreach ($featTasks as $t)
        @php $cc = $t['cat_color'] ?? '#00C896'; @endphp
        <div class="ld-task reveal">
          @if ($t['is_hot'])<span class="ribbon">🔥 HOT</span>@elseif ($t['is_new'])<span class="ribbon new">✨ NEW</span>@elseif ($t['is_vip'])<span class="ribbon vip">👑 VIP</span>@endif
          <div class="top">
            <div class="cat-ic" style="background:{{ $cc }}22;color:{{ $cc }};"><i class="fa-solid {{ $t['cat_icon'] ?? 'fa-star' }}"></i></div>
            <div>
              <div class="ttl">{{ $t['title'] }}</div>
              <span class="cat">{{ $t['cat_name'] ?? 'General' }}</span>
            </div>
          </div>
          <div class="reward"><small>Reward</small>{{ formatAmount((float)$t['reward']) }}</div>
          <a href="/register" class="btn btn-primary btn-sm btn-block">Start Task <i class="fa-solid fa-arrow-right"></i></a>
        </div>
      @endforeach
    </div>
    <div style="text-align:center;margin-top:32px;">
      <a href="/register" class="btn btn-outline btn-lg">View All Tasks <i class="fa-solid fa-arrow-right"></i></a>
    </div>
  </div>
</section>
@endif

<!-- ═════════ Top earners ═════════ -->
@if ($sections['earners'])
<section class="ld-section alt" id="earners">
  <div class="ld-container">
    <div class="ld-head reveal">
      <span class="ld-eyebrow">Leaderboard</span>
      <h2>Top Earners</h2>
      <p>Join our community of top earners</p>
    </div>
    <div class="ld-earners">
      @foreach ($topEarners as $i => $e)
        <div class="ld-earner reveal">
          <div class="rk">{{ $i===0 ? '🥇' : ($i===1 ? '🥈' : ($i===2 ? '🥉' : '#'.($i+1))) }}</div>
          <div class="av">@if ($e['avatar'])<img src="{{ $e['avatar'] }}" alt="">@else{{ strtoupper(substr($e['name'],0,1)) }}@endif</div>
          <div class="grow">
            <div class="nm">{{ $e['name'] }}</div>
            <div class="lv"><i class="fa-solid {{ $e['level_icon'] ?? 'fa-medal' }}" style="color:{{ $e['level_color'] ?? '#CD7F32' }}"></i> {{ $e['level_name'] ?? 'Bronze' }}</div>
          </div>
          <div class="amt">{{ formatAmount((float)$e['total_earned']) }}</div>
        </div>
      @endforeach
    </div>
  </div>
</section>
@endif

<!-- ═════════ Payment proof ═════════ -->
@if ($sections['proof'])
<section class="ld-section" id="proof">
  <div class="ld-container">
    <div class="ld-head reveal">
      <span class="ld-eyebrow">Real Payments</span>
      <h2>Payment Proof</h2>
      <p>Real payments to real users</p>
    </div>
    <div class="ld-proof">
      @foreach ($proofs as $p)
        <div class="item reveal" data-lightbox="/{{ ltrim($p['image'],'/') }}">
          <img src="/{{ ltrim($p['image'],'/') }}" alt="{{ $p['caption'] ?? 'Payment Proof' }}" loading="lazy">
        </div>
      @endforeach
    </div>
  </div>
</section>
@endif

<!-- ═════════ FAQ ═════════ -->
<section class="ld-section alt" id="faq">
  <div class="ld-container">
    <div class="ld-head reveal">
      <span class="ld-eyebrow">Got Questions?</span>
      <h2>Frequently Asked Questions</h2>
      <p>Quick answers to the most common questions.</p>
    </div>
    <div class="ld-faq">
      @foreach ($faqs as $faq)
        <details class="reveal">
          <summary>{{ $faq[0] }} <i class="fa-solid fa-chevron-down"></i></summary>
          <div class="ans">{{ $faq[1] }}</div>
        </details>
      @endforeach
    </div>
  </div>
</section>

<!-- ═════════ Final CTA ═════════ -->
<section class="ld-section ld-final" style="padding-top:84px;">
  <div class="ld-final-box reveal">
    <h2>Ready to Start Earning?</h2>
    <p>Join {{ number_format($totalUsers) }}+ users already earning on {{ $siteName }}</p>
    <a href="/register" class="btn btn-primary btn-lg"><i class="fa-solid fa-user-plus"></i> Create Free Account</a>
  </div>
</section>

<!-- ═════════ Footer ═════════ -->
@include('partials.public-footer')

<!-- Popup -->
@if ($popup)
<div class="modal-overlay active" id="popup-modal">
  <div class="modal-box">
    <div class="modal-header">
      <h3>{{ $popup['title'] }}</h3>
      <span class="modal-close" onclick="document.getElementById('popup-modal').classList.remove('active')"><i class="fa-solid fa-xmark"></i></span>
    </div>
    @if ($popup['image'])<img src="{{ $popup['image'] }}" alt="" style="width:100%;border-radius:10px;margin-bottom:14px;">@endif
    <p>{!! nl2br(e($popup['content'] ?? '')) !!}</p>
    <button class="btn btn-primary btn-block" style="margin-top:16px;" onclick="document.getElementById('popup-modal').classList.remove('active')">Close</button>
  </div>
</div>
@endif

<div id="toast-container"></div>
<script src="/assets/js/main.js"></script>
<script>
(function () {
  // Sticky header shadow
  var hd = document.getElementById('ldHeader');
  var onScroll = function () { hd.classList.toggle('scrolled', window.scrollY > 8); };
  window.addEventListener('scroll', onScroll, { passive: true }); onScroll();

  // Mobile menu
  var b = document.getElementById('ldBurger'), m = document.getElementById('ldMobile');
  if (b && m) {
    b.addEventListener('click', function () { m.classList.toggle('open'); });
    m.querySelectorAll('a').forEach(function (a) { a.addEventListener('click', function () { m.classList.remove('open'); }); });
  }

  // Reveal on scroll
  var els = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (en) {
      en.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
    }, { threshold: 0.12 });
    els.forEach(function (el) { io.observe(el); });
  } else { els.forEach(function (el) { el.classList.add('in'); }); }
})();
</script>
</body>
</html>
