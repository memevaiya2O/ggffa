<!DOCTYPE html>
<html lang="en">
<head>
{!! renderSeoMeta() !!}
{!! renderGoogleFont() !!}
{!! renderCssVars() !!}
<link rel="stylesheet" href="/assets/css/style.css?v=3">
<link rel="stylesheet" href="/assets/css/dashboard.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="app-layout">
  <header class="app-header">
    <div class="app-header-left"><div class="user-name">Leaderboard</div></div>
    <div class="app-header-right">
      <a href="/notifications" class="notif-btn"><i class="fa-solid fa-bell"></i>@if ($notifCount)<span class="notif-badge">{{ $notifCount }}</span>@endif</a>
    </div>
  </header>
  <main class="main-content">
    <div class="leaderboard-tabs">
      <div class="lb-tab {{ $period==='weekly'?'active':'' }}" data-period="weekly">Weekly</div>
      <div class="lb-tab {{ $period==='monthly'?'active':'' }}" data-period="monthly">Monthly</div>
      <div class="lb-tab {{ $period==='alltime'?'active':'' }}" data-period="alltime">All Time</div>
    </div>
    @foreach ($top as $i => $u)
      @php
        $rank = $i + 1;
        $rankClass = $rank === 1 ? 'top-1' : ($rank === 2 ? 'top-2' : ($rank === 3 ? 'top-3' : ''));
        $rankIcon  = $rank === 1 ? '🥇' : ($rank === 2 ? '🥈' : ($rank === 3 ? '🥉' : "#$rank"));
        $isMe = $u['id'] == $user['id'];
      @endphp
      <div class="rank-card {{ $isMe ? 'my-rank' : '' }}">
        <div class="rank-num {{ $rankClass }}">{{ $rankIcon }}</div>
        <div class="earner-avatar">
          @if ($u['avatar'])<img src="{{ $u['avatar'] }}" alt="">@else{{ strtoupper(substr($u['name'],0,1)) }}@endif
        </div>
        <div style="flex:1;min-width:0;">
          <div style="font-weight:700;font-size:15px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">{{ $u['name'] }}{!! $isMe ? ' <span style="color:var(--primary);font-size:12px;">(You)</span>' : '' !!}</div>
          <div style="font-size:12px;color:#888;display:flex;align-items:center;gap:4px;margin-top:2px;">
            <i class="fa-solid {{ $u['level_icon']??'fa-medal' }}" style="color:{{ $u['level_color']??'#CD7F32' }}"></i> {{ $u['level_name']??'Bronze' }}
          </div>
        </div>
        <div style="font-size:20px;font-weight:900;color:var(--primary)">{{ formatAmount((float)$u['earned']) }}</div>
      </div>
    @endforeach
    @if ($myRank === null)
      <div class="rank-card my-rank" style="margin-top:8px;">
        <div class="rank-num" style="color:#888;">—</div>
        <div class="earner-avatar">{{ strtoupper(substr($user['name'],0,1)) }}</div>
        <div style="flex:1;">
          <div style="font-weight:700;font-size:15px;">{{ $user['name'] }} <span style="color:var(--primary);font-size:12px;">(You)</span></div>
          <div style="font-size:12px;color:#888;">Not ranked yet</div>
        </div>
        <div style="font-size:20px;font-weight:900;color:var(--primary)">{{ formatAmount((float)$user['total_earned']) }}</div>
      </div>
    @endif
  </main>
  <nav class="bottom-nav">
    <a href="/dashboard" class="nav-item"><i class="fa-solid fa-house"></i>Home</a>
    <a href="/tasks" class="nav-item"><i class="fa-solid fa-list-check"></i>Tasks</a>
    <a href="/wallet" class="nav-item"><i class="fa-solid fa-wallet"></i>Wallet</a>
    <a href="/leaderboard" class="nav-item active"><i class="fa-solid fa-trophy"></i>Board</a>
    <a href="/profile" class="nav-item"><i class="fa-solid fa-user"></i>Profile</a>
  </nav>
</div>
<div id="toast-container"></div>
<script src="/assets/js/main.js"></script>
</body>
</html>
