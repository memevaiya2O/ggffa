<!DOCTYPE html>
<html lang="en">
<head>
{!! renderSeoMeta('login') !!}
{!! renderGoogleFont() !!}
{!! renderCssVars() !!}
<link rel="stylesheet" href="/assets/css/style.css?v=3">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
{!! getSetting('custom_header_script') !!}
</head>
<body>
<div class="auth-page">
  <div class="auth-card">
    <div class="auth-logo">
      <div class="brand-logo-wrap">@include('partials.brand-logo', ['size' => 'lg'])</div>
      <div style="font-size:13px;color:#888;margin-top:4px;">{{ getSetting('site_tagline','Earn Real Money Online') }}</div>
    </div>
    <h2 class="auth-title">Welcome Back</h2>
    <p class="auth-subtitle">Sign in to your account</p>

    @if ($error)<div class="alert alert-error"><i class="fa-solid fa-circle-exclamation"></i> {{ $error }}</div>@endif
    @if (!empty($banned))<div class="alert alert-error">Your account has been suspended.</div>@endif
    @if (!empty($registered))<div class="alert alert-success"><i class="fa-solid fa-circle-check"></i> Account created! Please login.</div>@endif

    <form method="post" action="/login">
      {!! csrfField() !!}
      <div class="form-group">
        <label class="form-label">Email Address</label>
        <div class="input-group">
          <i class="input-icon fa-solid fa-envelope"></i>
          <input type="email" name="email" class="form-control" placeholder="you@email.com" value="{{ $remEmail }}" required autofocus>
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Password</label>
        <div class="input-group">
          <i class="input-icon fa-solid fa-lock"></i>
          <input type="password" name="password" class="form-control" placeholder="Enter password" required>
        </div>
      </div>
      <div class="form-group" style="display:flex;align-items:center;justify-content:space-between;">
        <label style="display:flex;align-items:center;gap:8px;font-size:14px;cursor:pointer;">
          <input type="checkbox" name="remember" {{ $remEmail ? 'checked' : '' }}> Remember me
        </label>
      </div>
      <button type="submit" class="btn btn-primary btn-block">
        <i class="fa-solid fa-right-to-bracket"></i> Login
      </button>
    </form>
    <div class="auth-footer">
      Don't have an account? <a href="/register">Register Free</a>
    </div>
  </div>
</div>
<div id="toast-container"></div>
<script src="/assets/js/main.js"></script>
{!! getSetting('custom_footer_script','') !!}
</body>
</html>
