<!DOCTYPE html>
<html lang="en">
<head>
{!! renderSeoMeta() !!}
{!! renderGoogleFont() !!}
{!! renderCssVars() !!}
<link rel="stylesheet" href="/assets/css/style.css?v=3">
<link rel="stylesheet" href="/assets/css/dashboard.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="app-layout">
  <header class="app-header">
    <div class="app-header-left"><div class="user-name">Notifications @if ($notifCount)<span class="notif-badge" style="position:static;margin-left:6px;">{{ $notifCount }}</span>@endif</div></div>
    <div class="app-header-right">
      @if ($notifCount)
        <form method="post" style="display:inline">{!! csrfField() !!}<button type="submit" name="mark_read" value="1" style="font-size:12px;color:var(--primary);font-weight:700;background:none;border:none;cursor:pointer;">Mark All Read</button></form>
      @endif
    </div>
  </header>
  <main class="main-content">
    @if (!$notifications->count())
      <div style="text-align:center;padding:60px 20px;color:#888;">
        <i class="fa-solid fa-bell-slash" style="font-size:48px;display:block;margin-bottom:16px;opacity:.3"></i>
        <p>No notifications yet</p>
      </div>
    @else
      @foreach ($notifications as $n)
        @php
          $icon = $typeIcons[$n['type']] ?? ['fa-bell','#00C896'];
          $isRead = $n['is_read'];
        @endphp
        <div class="notif-item {{ !$isRead ? 'unread' : '' }}">
          <div class="notif-icon" style="background:{{ $icon[1] }}22;color:{{ $icon[1] }}">
            <i class="fa-solid {{ $icon[0] }}"></i>
          </div>
          <div class="notif-body">
            <div class="notif-title">{{ $n['title'] }}</div>
            <div class="notif-msg">{{ $n['message'] }}</div>
            <div class="notif-time">{{ timeAgo($n['created_at']) }}</div>
          </div>
          @if (!$isRead)<div class="unread-dot"></div>@endif
        </div>
      @endforeach
      {!! paginationLinks($total, $page, $limit, '/notifications') !!}
    @endif
  </main>
  <nav class="bottom-nav">
    <a href="/dashboard" class="nav-item"><i class="fa-solid fa-house"></i>Home</a>
    <a href="/tasks" class="nav-item"><i class="fa-solid fa-list-check"></i>Tasks</a>
    <a href="/wallet" class="nav-item"><i class="fa-solid fa-wallet"></i>Wallet</a>
    <a href="/leaderboard" class="nav-item"><i class="fa-solid fa-trophy"></i>Board</a>
    <a href="/profile" class="nav-item"><i class="fa-solid fa-user"></i>Profile</a>
  </nav>
</div>
<script src="/assets/js/main.js"></script>
</body>
</html>
