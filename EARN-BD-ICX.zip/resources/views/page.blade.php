<!DOCTYPE html>
<html lang="en">
<head>
{!! renderSeoMeta() !!}
<meta name="description" content="{{ $page['meta_desc'] ?? '' }}">
<title>{{ $page['meta_title'] ?: $page['title'] }} — {{ getSetting('site_name') }}</title>
{!! renderGoogleFont() !!}
{!! renderCssVars() !!}
<link rel="stylesheet" href="/assets/css/style.css?v=3">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<header class="public-header">
  <div class="site-logo">
    <a href="/" style="display:flex;">@include('partials.brand-logo', ['size' => 'md'])</a>
  </div>
  <div class="header-nav">
    <a href="/">Home</a>
    @if (!empty(session('user_id')))
      <a href="/dashboard" class="btn btn-primary btn-sm">Dashboard</a>
    @else
      <a href="/login" class="btn btn-outline btn-sm">Login</a>
      <a href="/register" class="btn btn-primary btn-sm">Register</a>
    @endif
  </div>
</header>
<div class="section container" style="max-width:800px;min-height:60vh;">
  <h1 style="margin-bottom:24px;">{{ $page['title'] }}</h1>
  <div style="line-height:1.9;color:#444;font-size:16px;">{!! nl2br(e($page['content'] ?? '')) !!}</div>
</div>
@include('partials.public-footer')
</body>
</html>
