@php
$__logo = getSetting('site_logo');
$__name = getSetting('site_name', 'EarnBD');
$size = $size ?? 'md';
@endphp
@if ($__logo)
<img src="{{ $__logo }}" alt="{{ $__name }}" class="brand-logo brand-logo-{{ $size }}">
@else
<div class="brand-logo-placeholder brand-logo-{{ $size }}" title="Logo placeholder — upload your logo in Admin → Settings"><i class="fa-regular fa-image"></i></div>
@endif
<b class="sr-only">{{ $__name }}</b>
