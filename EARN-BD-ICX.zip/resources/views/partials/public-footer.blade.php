@php
$pages = \App\Models\CustomPage::query()->where('status', 'active')->orderBy('id')->get();
$socials = [
  'facebook'  => ['fa-facebook', getSetting('social_facebook')],
  'youtube'   => ['fa-youtube', getSetting('social_youtube')],
  'telegram'  => ['fa-telegram', getSetting('social_telegram')],
  'twitter'   => ['fa-x-twitter', getSetting('social_twitter')],
  'instagram' => ['fa-instagram', getSetting('social_instagram')],
];
@endphp
<footer class="public-footer">
  <div class="footer-grid">
    <div class="footer-brand">
      <div class="site-logo" style="margin-bottom:14px;">
        @include('partials.brand-logo', ['size' => 'md'])
      </div>
      <p>{{ getSetting('footer_description','The #1 earning platform.') }}</p>
      <div class="social-links">
        @foreach ($socials as $key => [$icon, $url])
          @if ($url && $url !== '#')
            <a href="{{ $url }}" target="_blank" rel="noopener"><i class="fa-brands {{ $icon }}"></i></a>
          @endif
        @endforeach
      </div>
    </div>
    <div class="footer-col">
      <h4>Quick Links</h4>
      <ul>
        <li><a href="/register">Register Free</a></li>
        <li><a href="/login">Login</a></li>
        <li><a href="/#how-it-works">How It Works</a></li>
        <li><a href="/#tasks">Featured Tasks</a></li>
        <li><a href="/#faq">FAQ</a></li>
      </ul>
    </div>
    @if ($pages->count())
    <div class="footer-col">
      <h4>Information</h4>
      <ul>
        @foreach ($pages as $p)
          <li><a href="/page/{{ $p['slug'] }}">{{ $p['title'] }}</a></li>
        @endforeach
      </ul>
    </div>
    @endif
  </div>
  <div class="footer-bottom">{{ getSetting('footer_copyright','© ' . date('Y') . ' ' . getSetting('site_name','EarnBD') . '. All rights reserved.') }}</div>
  <div class="footer-dev">
    <a class="footer-dev-link" href="https://t.me/infinity_codex" target="_blank" rel="noopener noreferrer">
      <i class="fa-brands fa-telegram"></i>
      <span>Developed by <b>SHADOW RIAD</b>🔰</span>
    </a>
  </div>
</footer>
{!! getSetting('custom_footer_script','') !!}
