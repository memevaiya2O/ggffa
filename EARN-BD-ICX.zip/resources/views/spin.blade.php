<!DOCTYPE html>
<html lang="en">
<head>
{!! renderSeoMeta() !!}
{!! renderGoogleFont() !!}
{!! renderCssVars() !!}
<link rel="stylesheet" href="/assets/css/style.css?v=3">
<link rel="stylesheet" href="/assets/css/dashboard.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="app-layout">
  <header class="app-header">
    <div class="app-header-left"><div class="user-name">Daily Spin</div></div>
    <div class="app-header-right">
      <a href="/notifications" class="notif-btn"><i class="fa-solid fa-bell"></i>@if ($notifCount)<span class="notif-badge">{{ $notifCount }}</span>@endif</a>
    </div>
  </header>
  <main class="main-content">
    <div class="spin-container">
      @if ($spunToday)
        <div style="text-align:center;padding:40px 20px;">
          <div style="font-size:64px;margin-bottom:16px;">⏰</div>
          <h3>Already spun today!</h3>
          <p style="color:#888;margin-top:8px;">Come back tomorrow for another spin.</p>
          @php
            $nextMidnight = new \DateTime('tomorrow midnight');
          @endphp
          <div style="margin-top:20px;font-size:28px;font-weight:900;color:var(--primary)" id="spin-wait-countdown" data-next="{{ $nextMidnight->format('c') }}">--:--:--</div>
        </div>
      @else
        <div class="wheel-wrapper">
          <div class="wheel-pointer"></div>
          <canvas id="spin-wheel" width="300" height="300" data-prizes='{{ json_encode(array_map(fn($p) => ['label' => $p['label'], 'color' => $p['color']], $prizes->all())) }}'></canvas>
          <div class="wheel-center">🍀</div>
        </div>
        {!! csrfField() !!}
        <button class="btn-spin" id="btn-spin">SPIN!</button>
        <p style="font-size:13px;color:#888;margin-top:12px;text-align:center;">Once per day • Prizes credited instantly</p>
      @endif
    </div>

    <!-- Spin Result Overlay -->
    <div class="spin-result-overlay">
      <div class="spin-result-box">
        <div class="spin-result-icon">🎉</div>
        <div style="font-size:20px;font-weight:700;margin-bottom:8px;">You Won!</div>
        <div class="spin-result-amount" id="spin-prize-amount"></div>
        <div class="spin-result-label" id="spin-prize-label"></div>
        <button class="btn btn-primary spin-result-close" style="margin-top:20px;width:100%;">Awesome! 🎊</button>
      </div>
    </div>

    <!-- Prize List -->
    <div class="sec-header" style="margin-top:24px;"><h3>Prize Pool</h3></div>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:10px;margin-bottom:20px;">
      @foreach ($prizes as $p)
        <div style="background:{{ $p['color'] }}22;border:2px solid {{ $p['color'] }}44;border-radius:var(--radius);padding:14px;text-align:center;">
          <div style="font-size:20px;font-weight:900;color:{{ $p['color'] }}">{{ $p['label'] }}</div>
          <div style="font-size:12px;color:#888;margin-top:4px;">{{ $p['probability'] }}% chance</div>
        </div>
      @endforeach
    </div>

    <!-- Spin History -->
    @if ($history->count())
    <div class="sec-header"><h3>My Spin History</h3></div>
    @foreach ($history as $h)
      <div class="activity-item">
        <div class="activity-icon credit"><i class="fa-solid fa-circle-notch"></i></div>
        <div class="activity-info">
          <div class="activity-desc">{{ $h['prize_label'] }}</div>
          <div class="activity-time">{{ date('M j, Y', strtotime($h['spin_date'])) }}</div>
        </div>
        <div class="activity-amount pos">+{{ formatAmount((float)$h['amount']) }}</div>
      </div>
    @endforeach
    @endif
  </main>
  <nav class="bottom-nav">
    <a href="/dashboard" class="nav-item"><i class="fa-solid fa-house"></i>Home</a>
    <a href="/tasks" class="nav-item"><i class="fa-solid fa-list-check"></i>Tasks</a>
    <a href="/wallet" class="nav-item"><i class="fa-solid fa-wallet"></i>Wallet</a>
    <a href="/leaderboard" class="nav-item"><i class="fa-solid fa-trophy"></i>Board</a>
    <a href="/profile" class="nav-item"><i class="fa-solid fa-user"></i>Profile</a>
  </nav>
</div>
<div id="toast-container"></div>
<script src="/assets/js/main.js"></script>
<script>
const wc = document.getElementById('spin-wait-countdown');
if (wc) {
  const next = new Date(wc.dataset.next);
  setInterval(() => {
    const diff = next - new Date();
    if (diff <= 0) { wc.textContent = 'Ready!'; return; }
    const h = Math.floor(diff/3600000), m = Math.floor((diff%3600000)/60000), s = Math.floor((diff%60000)/1000);
    wc.textContent = String(h).padStart(2,'0')+':'+String(m).padStart(2,'0')+':'+String(s).padStart(2,'0');
  }, 1000);
}
document.querySelector('.spin-result-close')?.addEventListener('click', () => {
  document.querySelector('.spin-result-overlay')?.classList.remove('show');
  window.location.reload();
});
</script>
</body>
</html>
