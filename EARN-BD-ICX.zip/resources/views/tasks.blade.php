<!DOCTYPE html>
<html lang="en">
<head>
{!! renderSeoMeta() !!}
{!! renderGoogleFont() !!}
{!! renderCssVars() !!}
<link rel="stylesheet" href="/assets/css/style.css?v=3">
<link rel="stylesheet" href="/assets/css/dashboard.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="app-layout">
  <header class="app-header">
    <div class="app-header-left">
      <div class="user-name">Tasks</div>
    </div>
    <div class="app-header-right">
      <a href="/notifications" class="notif-btn"><i class="fa-solid fa-bell"></i>@if ($notifCount)<span class="notif-badge">{{ $notifCount }}</span>@endif</a>
    </div>
  </header>
  <main class="main-content">
    <!-- Category Tabs -->
    <div class="category-tabs">
      <a href="/tasks" class="cat-tab {{ !$catId ? 'active' : '' }}"><i class="fa-solid fa-border-all"></i> All</a>
      @foreach ($categories as $c)
        <a href="/tasks?cat={{ $c['id'] }}" class="cat-tab {{ $catId == $c['id'] ? 'active' : '' }}">
          <i class="fa-solid {{ $c['icon'] }}" style="color:{{ $c['color'] }}"></i> {{ $c['name'] }}
        </a>
      @endforeach
    </div>

    <!-- Search -->
    <div class="search-box">
      <i class="fa-solid fa-magnifying-glass"></i>
      <input type="text" class="form-control" placeholder="Search tasks..." id="task-search" value="{{ $search }}">
    </div>

    <!-- Task List -->
    @if (!$tasks->count())
      <div style="text-align:center;padding:48px 20px;color:#888;"><i class="fa-solid fa-inbox" style="font-size:48px;display:block;margin-bottom:16px;opacity:.3"></i><p>No tasks available right now</p></div>
    @else
      @foreach ($tasks as $t)
        @php
          $isDone = $t['user_sub_status'] === 'approved';
          $isPending = $t['user_sub_status'] === 'pending';
          $isLocked = $t['is_vip'] && !$user['can_access_vip'];
        @endphp
        <a href="/task-detail?id={{ $t['id'] }}" class="task-card {{ $isDone ? 'completed' : '' }} {{ $isLocked ? 'locked' : '' }}" style="text-decoration:none;display:flex;">
          <div class="task-thumb" style="{{ $t['cat_color'] ? "background:linear-gradient(135deg,{$t['cat_color']}cc,{$t['cat_color']}88)" : '' }}">
            @if ($t['thumbnail'])
              <img src="{{ $t['thumbnail'] }}" alt="">
            @else
              <i class="fa-solid {{ $t['cat_icon'] ?? 'fa-star' }}"></i>
            @endif
          </div>
          <div class="task-info">
            <div class="task-title">{{ $t['title'] }}</div>
            <div class="task-meta">
              <span class="task-reward-tag">{{ formatAmount((float)$t['reward']) }}</span>
              <span class="task-cat-badge"><i class="fa-solid {{ $t['cat_icon'] ?? 'fa-tag' }}"></i> {{ $t['cat_name'] ?? 'General' }}</span>
            </div>
            <div class="task-ribbons">
              @if ($t['is_hot'])<span class="badge badge-hot">🔥 HOT</span>@endif
              @if ($t['is_new'])<span class="badge badge-new">✨ NEW</span>@endif
              @if ($t['is_vip'])<span class="badge badge-vip">👑 VIP</span>@endif
              @if ($isDone)<span class="badge badge-success">✅ Done</span>@endif
              @if ($isPending)<span class="badge badge-warning">⏳ Pending</span>@endif
              @if ($isLocked)<span class="badge" style="background:rgba(0,0,0,.08);color:#888;"><i class="fa-solid fa-lock"></i> VIP Required</span>@endif
            </div>
            <div class="task-progress" style="margin-top:6px;">{{ $t['completion_count'] }}/{{ $t['max_total'] }} completed</div>
          </div>
        </a>
      @endforeach
      {!! paginationLinks($total, $page, $limit, '/tasks?' . http_build_query(['cat' => $catId, 'search' => $search])) !!}
    @endif
  </main>
  <nav class="bottom-nav">
    <a href="/dashboard" class="nav-item"><i class="fa-solid fa-house"></i>Home</a>
    <a href="/tasks" class="nav-item active"><i class="fa-solid fa-list-check"></i>Tasks</a>
    <a href="/wallet" class="nav-item"><i class="fa-solid fa-wallet"></i>Wallet</a>
    <a href="/leaderboard" class="nav-item"><i class="fa-solid fa-trophy"></i>Board</a>
    <a href="/profile" class="nav-item"><i class="fa-solid fa-user"></i>Profile</a>
  </nav>
</div>
<div id="toast-container"></div>
<script src="/assets/js/main.js"></script>
<script>
document.getElementById('task-search').addEventListener('keydown', e => {
  if (e.key === 'Enter') {
    const url = new URL(window.location.href);
    url.searchParams.set('search', e.target.value);
    url.searchParams.delete('page');
    window.location.href = url.toString();
  }
});
</script>
</body>
</html>
