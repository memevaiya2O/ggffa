<!DOCTYPE html>
<html lang="en">
<head>
{!! renderSeoMeta() !!}
{!! renderGoogleFont() !!}
{!! renderCssVars() !!}
<link rel="stylesheet" href="/assets/css/style.css?v=3">
<link rel="stylesheet" href="/assets/css/dashboard.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="app-layout">
  <header class="app-header">
    <div class="app-header-left"><div class="user-name">Withdraw</div></div>
    <div class="app-header-right">
      <a href="/notifications" class="notif-btn"><i class="fa-solid fa-bell"></i>@if ($notifCount)<span class="notif-badge">{{ $notifCount }}</span>@endif</a>
    </div>
  </header>
  <main class="main-content">
    @if ($error)<div class="alert alert-error">{{ $error }}</div>@endif
    @if ($success)<div class="alert alert-success">{{ $success }}</div>@endif

    <!-- Balance -->
    <div class="balance-card" style="margin-bottom:20px;">
      <div class="balance-deco"><i class="fa-solid fa-money-bill"></i></div>
      <div class="balance-label">Available Balance</div>
      <div class="balance-amount">{{ formatAmount((float)$user['balance']) }}</div>
      <div style="position:relative;z-index:1;font-size:13px;color:rgba(255,255,255,.7);margin-top:8px;">Daily Limit: {{ formatAmount((float)$user['daily_withdraw_limit']) }}</div>
    </div>

    @if ($walletLocked)
    <div style="background:var(--card-bg);border-radius:var(--radius);padding:24px 20px;text-align:center;margin-bottom:20px;border:1px solid rgba(255,165,2,.35);">
      <i class="fa-solid fa-lock" style="font-size:34px;color:#FFA502;margin-bottom:10px;"></i>
      <h3 style="font-size:17px;font-weight:800;margin-bottom:8px;">Activate your wallet first</h3>
      <p style="font-size:14px;color:#777;line-height:1.6;margin-bottom:16px;">
        To make your first withdrawal, add at least <strong>{{ formatAmount($activationMin) }}</strong> to your wallet.
        You only need to do this once.
      </p>
      <a href="/add-money" class="btn btn-primary btn-lg"><i class="fa-solid fa-circle-plus"></i> Add Money</a>
    </div>
    @else
    <h3 style="margin-bottom:14px;font-size:16px;font-weight:800;">Select Payment Method</h3>
    <div class="method-list">
      @foreach ($methods as $m)
        <div class="method-card" data-id="{{ $m['id'] }}" data-min="{{ $m['min_amount'] }}">
          <i class="fa-solid {{ $m['icon'] }}"></i>
          <h4>{{ $m['name'] }}</h4>
          <p>Min: {{ formatAmount((float)$m['min_amount']) }}</p>
          <p style="font-size:11px;color:#aaa;">{{ $m['processing_time'] }}</p>
        </div>
      @endforeach
    </div>

    <form method="post" action="/withdraw" id="withdraw-form">
      {!! csrfField() !!}
      <input type="hidden" name="method_id" id="method_id">
      <div class="form-group">
        <label class="form-label">Amount</label>
        <div class="input-group">
          <i class="input-icon fa-solid fa-coins"></i>
          <input type="number" name="amount" class="form-control" placeholder="Enter amount" step="0.01" min="1" max="{{ $user['balance'] }}">
        </div>
        <p style="font-size:12px;color:#888;margin-top:6px;">Minimum: <strong id="min-amount-label">—</strong></p>
      </div>
      <div class="form-group">
        <label class="form-label">Account / Wallet Address</label>
        <div class="input-group">
          <i class="input-icon fa-solid fa-address-card"></i>
          <input type="text" name="address" class="form-control" placeholder="Enter your number or wallet address">
        </div>
      </div>
      <button type="submit" class="btn btn-primary btn-block btn-lg">
        <i class="fa-solid fa-paper-plane"></i> Submit Withdrawal
      </button>
    </form>
    @endif

    @if ($history->count())
    <h3 style="margin:24px 0 14px;font-size:16px;font-weight:800;">Withdrawal History</h3>
    @foreach ($history as $w)
      <div class="withdraw-item">
        <div class="withdraw-icon"><i class="fa-solid {{ $w['method_icon'] ?? 'fa-wallet' }}"></i></div>
        <div class="withdraw-info">
          <div class="withdraw-method">{{ $w['method_name'] ?? 'Unknown' }}</div>
          <div class="withdraw-addr">{{ substr($w['address'],0,20) }}...</div>
        </div>
        <div class="withdraw-right">
          <div class="withdraw-amount">{{ formatAmount((float)$w['amount']) }}</div>
          <span class="status-badge status-{{ $w['status'] }}">{{ ucfirst($w['status']) }}</span>
          <div class="withdraw-date">{{ date('M j, Y', strtotime($w['created_at'])) }}</div>
        </div>
      </div>
    @endforeach
    @endif
  </main>
  <nav class="bottom-nav">
    <a href="/dashboard" class="nav-item"><i class="fa-solid fa-house"></i>Home</a>
    <a href="/tasks" class="nav-item"><i class="fa-solid fa-list-check"></i>Tasks</a>
    <a href="/wallet" class="nav-item active"><i class="fa-solid fa-wallet"></i>Wallet</a>
    <a href="/leaderboard" class="nav-item"><i class="fa-solid fa-trophy"></i>Board</a>
    <a href="/profile" class="nav-item"><i class="fa-solid fa-user"></i>Profile</a>
  </nav>
</div>
<div id="toast-container"></div>
<script src="/assets/js/main.js"></script>
</body>
</html>
