<?php

/*
|--------------------------------------------------------------------------
| Routes — clean Laravel-style URLs (/login, /register, /Icxpanel/users ...).
| Old ".php" URLs are redirected to the clean URL at the bottom of this file.
|--------------------------------------------------------------------------
*/

use App\Http\Controllers\AddMoneyController;
use App\Http\Controllers\Admin\AccountAdminController;
use App\Http\Controllers\Admin\AdminAuthController;
use App\Http\Controllers\Admin\DepositAdminController;
use App\Http\Controllers\Admin\DepositMethodAdminController;
use App\Http\Controllers\Admin\CategoryAdminController;
use App\Http\Controllers\Admin\DashboardAdminController;
use App\Http\Controllers\Admin\HomepageEditorController;
use App\Http\Controllers\Admin\LeaderboardAdminController;
use App\Http\Controllers\Admin\LevelAdminController;
use App\Http\Controllers\Admin\MaintenanceAdminController;
use App\Http\Controllers\Admin\NotificationAdminController;
use App\Http\Controllers\Admin\PageAdminController;
use App\Http\Controllers\Admin\PopupAdminController;
use App\Http\Controllers\Admin\ReferralConfigController;
use App\Http\Controllers\Admin\ReportAdminController;
use App\Http\Controllers\Admin\SeoAdminController;
use App\Http\Controllers\Admin\SettingAdminController;
use App\Http\Controllers\Admin\SpinConfigAdminController;
use App\Http\Controllers\Admin\SubmissionAdminController;
use App\Http\Controllers\Admin\TaskAdminController;
use App\Http\Controllers\Admin\TaskFormAdminController;
use App\Http\Controllers\Admin\ThemeAdminController;
use App\Http\Controllers\Admin\UserAdminController;
use App\Http\Controllers\Admin\UserDetailAdminController;
use App\Http\Controllers\Admin\WithdrawalAdminController;
use App\Http\Controllers\Admin\WithdrawMethodAdminController;
use App\Http\Controllers\Admin\WithdrawProofAdminController;
use App\Http\Controllers\AchievementController;
use App\Http\Controllers\AssetController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CmsPageController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\LeaderboardController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ReferralController;
use App\Http\Controllers\SpinController;
use App\Http\Controllers\TaskController;
use App\Http\Controllers\WalletController;
use App\Http\Controllers\WithdrawController;
use Illuminate\Support\Facades\Route;

// ── Public / Auth ──
Route::get('/', [HomeController::class, 'index'])->name('home');

// Static-asset safety net: if the web server fails to serve /assets/* directly
// (wrong folder, permissions, MIME), Laravel serves it with the right headers.
Route::get('/assets/{path}', [AssetController::class, 'show'])
    ->where('path', '.*')
    ->withoutMiddleware([
        \Illuminate\Cookie\Middleware\EncryptCookies::class,
        \Illuminate\Session\Middleware\StartSession::class,
        \Illuminate\View\Middleware\ShareErrorsFromSession::class,
        \Illuminate\Foundation\Http\Middleware\ValidateCsrfToken::class,
        \App\Http\Middleware\ValidateCsrfToken::class,
        \App\Http\Middleware\LoadSettings::class,
    ]);

Route::get('/login', [AuthController::class, 'showLogin']);
Route::post('/login', [AuthController::class, 'login']);
Route::get('/register', [AuthController::class, 'showRegister']);
Route::post('/register', [AuthController::class, 'register']);
Route::get('/logout', [AuthController::class, 'logout']);

Route::get('/page', [CmsPageController::class, 'show']); // legacy ?slug= support
Route::get('/page/{slug}', [CmsPageController::class, 'showPretty'])->where('slug', '.*');

// ── User panel (protected exactly like the original requireLogin pages) ──
Route::middleware('user.auth')->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index']);
    Route::post('/dashboard', [DashboardController::class, 'index']);

    Route::get('/tasks', [TaskController::class, 'index']);
    Route::get('/task-detail', [TaskController::class, 'show']);
    Route::post('/task-detail', [TaskController::class, 'submit']);

    Route::get('/wallet', [WalletController::class, 'index']);
    Route::get('/add-money', [AddMoneyController::class, 'index']);
    Route::post('/add-money', [AddMoneyController::class, 'store']);
    Route::get('/withdraw', [WithdrawController::class, 'index']);
    Route::post('/withdraw', [WithdrawController::class, 'store']);
    Route::get('/referral', [ReferralController::class, 'index']);
    Route::get('/profile', [ProfileController::class, 'index']);
    Route::post('/profile', [ProfileController::class, 'update']);
    Route::get('/notifications', [NotificationController::class, 'index']);
    Route::post('/notifications', [NotificationController::class, 'markRead']);
    Route::get('/leaderboard', [LeaderboardController::class, 'index']);
    Route::get('/spin', [SpinController::class, 'index']);
    Route::post('/spin', [SpinController::class, 'spin']);
    Route::get('/achievements', [AchievementController::class, 'index']);
});

// ── Admin panel — lives at /Icxpanel (the old /admin URL no longer exists) ──
Route::get('/Icxpanel/login', [AdminAuthController::class, 'showLogin']);
Route::post('/Icxpanel/login', [AdminAuthController::class, 'login']);
Route::get('/Icxpanel/logout', [AdminAuthController::class, 'logout']);

Route::prefix('Icxpanel')->middleware('admin.auth')->group(function () {
    Route::get('/', [DashboardAdminController::class, 'index']);
    Route::match(['get', 'post'], '/account', [AccountAdminController::class, 'index']);
    Route::match(['get', 'post'], '/users', [UserAdminController::class, 'index']);
    Route::match(['get', 'post'], '/user-detail', [UserDetailAdminController::class, 'index']);
    Route::match(['get', 'post'], '/tasks', [TaskAdminController::class, 'index']);
    Route::match(['get', 'post'], '/task-add', [TaskFormAdminController::class, 'create']);
    Route::match(['get', 'post'], '/task-edit', [TaskFormAdminController::class, 'edit']);
    Route::match(['get', 'post'], '/categories', [CategoryAdminController::class, 'index']);
    Route::match(['get', 'post'], '/submissions', [SubmissionAdminController::class, 'index']);
    Route::match(['get', 'post'], '/withdrawals', [WithdrawalAdminController::class, 'index']);
    Route::match(['get', 'post'], '/deposits', [DepositAdminController::class, 'index']);
    Route::match(['get', 'post'], '/deposit-methods', [DepositMethodAdminController::class, 'index']);
    Route::match(['get', 'post'], '/withdraw-methods', [WithdrawMethodAdminController::class, 'index']);
    Route::match(['get', 'post'], '/withdraw-proof', [WithdrawProofAdminController::class, 'index']);
    Route::get('/reports', [ReportAdminController::class, 'index']);
    Route::match(['get', 'post'], '/levels', [LevelAdminController::class, 'index']);
    Route::match(['get', 'post'], '/spin-config', [SpinConfigAdminController::class, 'index']);
    Route::match(['get', 'post'], '/referral-config', [ReferralConfigController::class, 'index']);
    Route::match(['get', 'post'], '/leaderboard', [LeaderboardAdminController::class, 'index']);
    Route::match(['get', 'post'], '/notifications', [NotificationAdminController::class, 'index']);
    Route::match(['get', 'post'], '/homepage-editor', [HomepageEditorController::class, 'index']);
    Route::match(['get', 'post'], '/pages', [PageAdminController::class, 'index']);
    Route::match(['get', 'post'], '/popup-manager', [PopupAdminController::class, 'index']);
    Route::match(['get', 'post'], '/theme', [ThemeAdminController::class, 'index']);
    Route::match(['get', 'post'], '/seo', [SeoAdminController::class, 'index']);
    Route::match(['get', 'post'], '/settings', [SettingAdminController::class, 'index']);
    Route::match(['get', 'post'], '/maintenance', [MaintenanceAdminController::class, 'index']);
});

// ── Legacy ".php" URLs → clean URLs (keeps old bookmarks / shared links working) ──
Route::any('/{path}.php', function (\Illuminate\Http\Request $request, string $path) {
    if ($path === 'admin' || str_starts_with($path, 'admin/')) {
        abort(404); // the panel moved to /Icxpanel — old admin URLs are gone
    }
    if ($path === 'index') {
        $target = '/';
    } elseif ($path === 'page' && $request->query('slug')) {
        $target = '/page/' . rawurlencode((string) $request->query('slug'));
        return redirect($target, 301);
    } else {
        $target = '/' . $path;
    }
    $qs = $request->getQueryString();
    if ($qs) {
        $target .= '?' . $qs;
    }
    return redirect($target, in_array($request->method(), ['GET', 'HEAD'], true) ? 301 : 307);
})->where('path', '[A-Za-z0-9_\-/]+');

// Lower-case typo helper: /icxpanel/... → /Icxpanel/...
Route::get('/icxpanel/{rest?}', function (\Illuminate\Http\Request $request, ?string $rest = null) {
    $qs = $request->getQueryString();
    return redirect('/Icxpanel' . ($rest ? '/' . $rest : '') . ($qs ? '?' . $qs : ''), 301);
})->where('rest', '.*');
