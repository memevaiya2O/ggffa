<?php echo $__env->make('admin.partials-header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php if($flash): ?><div class="alert alert-success" style="margin-bottom:20px;"><?php echo e($flash); ?></div><?php endif; ?>

<div class="kpi-grid" style="margin-bottom:20px;">
  <div class="kpi-card"><div class="kpi-icon orange"><i class="fa-solid fa-clock"></i></div><div class="kpi-body"><div class="kpi-label">Pending Payout</div><div class="kpi-value"><?php echo e(getSetting('currency_symbol','৳')); ?><?php echo e(number_format($pendingSum,2)); ?></div></div></div>
</div>

<div class="admin-card">
  <div class="admin-card-header">
    <div class="admin-card-title">Withdrawals (<?php echo e($total); ?>)</div>
    <a href="?export=csv&status=<?php echo e($status); ?>" class="btn btn-sm btn-outline"><i class="fa-solid fa-download"></i> Export CSV</a>
  </div>
  <div class="admin-filters">
    <?php $__currentLoopData = ['pending'=>'⏳ Pending','paid'=>'✅ Paid','rejected'=>'❌ Rejected','all'=>'All']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <a href="?status=<?php echo e($k); ?>" class="filter-btn <?php echo e($status===$k?'filter-btn-primary':'filter-btn-outline'); ?>"><?php echo e($v); ?></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <form method="get" style="display:flex;gap:8px;">
      <input type="hidden" name="status" value="<?php echo e($status); ?>">
      <select name="method" class="filter-select" onchange="this.form.submit()">
        <option value="">All Methods</option>
        <?php $__currentLoopData = $methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($m['id']); ?>" <?php echo e($method==$m['id']?'selected':''); ?>><?php echo e($m['name']); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </form>
  </div>
  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>User</th><th>Method</th><th>Address</th><th>Amount</th><th>Status</th><th>Requested</th><th>Actions</th></tr></thead>
      <tbody>
        <?php $__currentLoopData = $withdrawals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><div class="user-cell"><div class="table-avatar"><?php echo e(strtoupper(substr($w['user_name'],0,1))); ?></div><div><div class="user-cell-name"><?php echo e($w['user_name']); ?></div><div class="user-cell-email"><?php echo e($w['user_email']); ?></div></div></div></td>
            <td><div style="display:flex;align-items:center;gap:6px;"><i class="fa-solid <?php echo e($w['method_icon']??'fa-wallet'); ?>" style="color:var(--primary)"></i><?php echo e($w['method_name']); ?></div></td>
            <td style="font-size:13px;font-family:monospace;"><?php echo e($w['address']); ?></td>
            <td style="font-weight:900;font-size:18px;"><?php echo e(formatAmount((float)$w['amount'])); ?></td>
            <td><span class="status-badge status-<?php echo e($w['status']); ?>"><?php echo e(ucfirst($w['status'])); ?></span><?php if($w['admin_note']): ?><div style="font-size:11px;color:#888;margin-top:4px;"><?php echo e(substr($w['admin_note'],0,40)); ?></div><?php endif; ?></td>
            <td style="font-size:12px;color:#888"><?php echo e(date('M j, Y',strtotime($w['created_at']))); ?></td>
            <td>
              <?php if($w['status'] === 'pending'): ?>
                <div class="action-btns">
                  <button class="action-btn-sm action-btn-pay" onclick="openPayModal(<?php echo e($w['id']); ?>,<?php echo e($w['amount']); ?>)"><i class="fa-solid fa-check"></i> Pay</button>
                  <button class="action-btn-sm action-btn-reject" onclick="openRejectWModal(<?php echo e($w['id']); ?>)"><i class="fa-solid fa-times"></i> Reject</button>
                </div>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
  <?php echo paginationLinks($total,$page,$limit,'/Icxpanel/withdrawals?status='.$status); ?>

</div>

<!-- Pay Modal -->
<div class="modal-overlay" id="pay-modal">
  <div class="modal-box">
    <div class="modal-header"><h3 id="pay-modal-title">Mark as Paid</h3><span class="modal-close"><i class="fa-solid fa-xmark"></i></span></div>
    <form method="post"><<?php echo csrfField(); ?><input type="hidden" name="action" value="pay"><input type="hidden" name="wid" id="pay-wid">
    <div class="form-group"><label class="form-label">Admin Note (optional)</label><input type="text" name="note" class="form-control" placeholder="Transaction ID or note..."></div>
    <button type="submit" class="btn btn-primary btn-block"><i class="fa-solid fa-check"></i> Mark as Paid</button>
    </form>
  </div>
</div>
<!-- Reject Modal -->
<div class="modal-overlay" id="reject-w-modal">
  <div class="modal-box">
    <div class="modal-header"><h3>Reject Withdrawal</h3><span class="modal-close"><i class="fa-solid fa-xmark"></i></span></div>
    <form method="post"><?php echo csrfField(); ?><input type="hidden" name="action" value="reject"><input type="hidden" name="wid" id="reject-wid">
    <div class="form-group"><label class="form-label">Reason <span style="color:var(--danger)">*</span></label><textarea name="reason" class="form-control" rows="3" required placeholder="Rejection reason..."></textarea></div>
    <button type="submit" class="btn btn-danger btn-block">Reject & Refund</button>
    </form>
  </div>
</div>
<?php
$extraJs = '<script>
function openPayModal(id,amt){document.getElementById("pay-wid").value=id;document.getElementById("pay-modal-title").textContent="Mark as Paid — "+"' . e(getSetting('currency_symbol','৳')) . '"+amt;document.getElementById("pay-modal").classList.add("active");}
function openRejectWModal(id){document.getElementById("reject-wid").value=id;document.getElementById("reject-w-modal").classList.add("active");}
</script>';
?>
<?php echo $__env->make('admin.partials-footer', ['extraJs' => $extraJs], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH /home/icxbdfsb/public_html/resources/views/admin/withdrawals.blade.php ENDPATH**/ ?>