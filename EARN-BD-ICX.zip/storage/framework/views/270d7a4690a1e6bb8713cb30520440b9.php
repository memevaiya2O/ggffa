<!DOCTYPE html>
<html lang="en">
<head>
<?php echo renderSeoMeta(); ?>

<?php echo renderGoogleFont(); ?>

<?php echo renderCssVars(); ?>

<link rel="stylesheet" href="/assets/css/style.css?v=3">
<link rel="stylesheet" href="/assets/css/dashboard.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<?php echo getSetting('custom_header_script'); ?>

</head>
<body>
<div class="app-layout">
  <header class="app-header">
    <div class="app-header-left">
      <div>
        <div class="greeting">Good <?php echo e(date('H') < 12 ? 'Morning' : (date('H') < 18 ? 'Afternoon' : 'Evening')); ?> 👋</div>
        <div class="user-name"><?php echo e($user['name']); ?></div>
      </div>
    </div>
    <div class="app-header-right">
      <a href="/notifications" class="notif-btn">
        <i class="fa-solid fa-bell"></i>
        <?php if($notifCount > 0): ?>
          <span class="notif-badge"><?php echo e($notifCount > 99 ? '99+' : $notifCount); ?></span>
        <?php endif; ?>
      </a>
      <a href="/profile" class="user-avatar-sm">
        <?php if($user['avatar']): ?><img src="<?php echo e($user['avatar']); ?>" alt=""><?php else: ?><?php echo e(strtoupper(substr($user['name'],0,1))); ?><?php endif; ?>
      </a>
    </div>
  </header>

  <main class="main-content">
    <?php if(!empty($welcome)): ?>
      <div class="alert alert-success" style="margin-bottom:16px;">🎉 Welcome to <?php echo e(getSetting('site_name')); ?>! Your account is ready.</div>
    <?php endif; ?>
    <?php if(!empty($bonus)): ?>
      <div class="alert alert-success" style="margin-bottom:16px;">🎁 Daily bonus claimed successfully!</div>
    <?php endif; ?>

    <!-- Balance Card -->
    <div class="balance-card">
      <div class="balance-deco"><i class="fa-solid fa-coins"></i></div>
      <div class="balance-label">Available Balance</div>
      <div class="balance-amount"><?php echo e(getSetting('currency_symbol','৳')); ?><?php echo e(number_format((float)$user['balance'],2)); ?></div>
      <div class="balance-stats">
        <div class="balance-stat">
          <div class="label">Total Earned</div>
          <div class="value"><?php echo e(getSetting('currency_symbol','৳')); ?><?php echo e(number_format((float)$user['total_earned'],2)); ?></div>
        </div>
        <div class="balance-stat">
          <div class="label">Withdrawn</div>
          <div class="value"><?php echo e(getSetting('currency_symbol','৳')); ?><?php echo e(number_format((float)$user['total_withdrawn'],2)); ?></div>
        </div>
      </div>
    </div>

    <!-- Level Card -->
    <div class="level-card">
      <div class="level-header">
        <div class="level-badge" style="background:<?php echo e($user['level_color'] ?? '#CD7F32'); ?>22;color:<?php echo e($user['level_color'] ?? '#CD7F32'); ?>">
          <i class="fa-solid <?php echo e($user['level_icon'] ?? 'fa-medal'); ?>"></i>
        </div>
        <div class="level-info">
          <h4><?php echo e($user['level_name'] ?? 'Bronze'); ?> Level</h4>
          <p><?php echo e($curPoints); ?> XP<?php echo e($nextLevel ? ' / ' . $nextLevel['required_points'] . ' to ' . $nextLevel['name'] : ' — Max Level!'); ?></p>
        </div>
      </div>
      <div class="xp-bar"><div class="xp-fill" style="width:<?php echo e($xpPct); ?>%"></div></div>
      <div class="xp-labels"><span><?php echo e($curPoints); ?> XP</span><span><?php echo e($xpPct); ?>%</span></div>
    </div>

    <!-- Daily Bonus -->
    <div class="daily-card">
      <div class="daily-info">
        <h4>🎁 Daily Bonus</h4>
        <p><?php echo e(formatAmount((float)getSetting('daily_bonus_amount','5'))); ?> reward</p>
        <?php if($bonusClaimed): ?>
          <div class="daily-timer">Next in: <span id="bonus-countdown" data-next="<?php echo e($nextBonus); ?>">--:--:--</span></div>
        <?php endif; ?>
      </div>
      <?php if(!$bonusClaimed): ?>
        <form method="post" action="/dashboard" style="flex-shrink:0">
          <?php echo csrfField(); ?>

          <button type="submit" name="claim_bonus" value="1" class="btn-daily">CLAIM</button>
        </form>
      <?php else: ?>
        <button class="btn-daily" disabled>CLAIMED ✓</button>
      <?php endif; ?>
    </div>

    <!-- Quick Actions -->
    <div class="quick-actions">
      <a href="/tasks" class="action-btn"><i class="fa-solid fa-list-check"></i>Tasks</a>
      <a href="/withdraw" class="action-btn"><i class="fa-solid fa-money-bill-transfer"></i>Withdraw</a>
      <a href="/leaderboard" class="action-btn"><i class="fa-solid fa-trophy"></i>Board</a>
      <a href="/spin" class="action-btn"><i class="fa-solid fa-circle-notch"></i>Spin</a>
    </div>

    <!-- My Stats -->
    <div class="stats-cards">
      <div class="stat-mini"><div class="num"><?php echo e($tasksCompleted); ?></div><div class="lbl">Tasks Done</div></div>
      <div class="stat-mini"><div class="num"><?php echo e($referralsCount); ?></div><div class="lbl">Referrals</div></div>
      <div class="stat-mini"><div class="num"><?php echo e((int)$user['streak_days']); ?></div><div class="lbl">Day Streak</div></div>
    </div>

    <!-- Recent Activity -->
    <div class="sec-header"><h3>Recent Activity</h3><a href="/wallet">See All</a></div>
    <div class="activity-list">
      <?php if(!$transactions->count()): ?>
        <div style="text-align:center;padding:24px;color:#888;font-size:14px;"><i class="fa-solid fa-inbox" style="font-size:32px;display:block;margin-bottom:8px;"></i>No transactions yet</div>
      <?php else: ?>
        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php $pos = $tx['amount'] > 0; ?>
          <div class="activity-item">
            <div class="activity-icon <?php echo e($pos ? 'credit' : 'debit'); ?>">
              <i class="fa-solid <?php echo e(getTransactionIcon($tx['type'])); ?>"></i>
            </div>
            <div class="activity-info">
              <div class="activity-desc"><?php echo e($tx['description']); ?></div>
              <div class="activity-time"><?php echo e(timeAgo($tx['created_at'])); ?></div>
            </div>
            <div class="activity-amount <?php echo e($pos ? 'pos' : 'neg'); ?>"><?php echo e($pos ? '+' : ''); ?><?php echo e(formatAmount(abs($tx['amount']))); ?></div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
    </div>

    <!-- Achievements -->
    <?php if($allAch->count()): ?>
    <div class="sec-header" style="margin-top:20px"><h3>Badges</h3><a href="/achievements">See All</a></div>
    <div class="badges-row">
      <?php $__currentLoopData = $allAch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="badge-item">
          <div class="badge-icon <?php echo e($a['unlocked_id'] ? 'unlocked' : 'locked'); ?>">
            <i class="fa-solid <?php echo e($a['icon']); ?>"></i>
          </div>
          <div class="badge-name"><?php echo e(strlen($a['name']) > 10 ? substr($a['name'],0,8).'...' : $a['name']); ?></div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>
  </main>

  <!-- Bottom Nav -->
  <nav class="bottom-nav">
    <a href="/dashboard" class="nav-item active"><i class="fa-solid fa-house"></i>Home</a>
    <a href="/tasks" class="nav-item"><i class="fa-solid fa-list-check"></i>Tasks</a>
    <a href="/wallet" class="nav-item"><i class="fa-solid fa-wallet"></i>Wallet</a>
    <a href="/leaderboard" class="nav-item"><i class="fa-solid fa-trophy"></i>Board</a>
    <a href="/profile" class="nav-item"><i class="fa-solid fa-user"></i>Profile</a>
  </nav>
</div>
<div id="toast-container"></div>
<script src="/assets/js/main.js"></script>
<?php echo getSetting('custom_footer_script',''); ?>

</body>
</html>
<?php /**PATH /home/icxbdfsb/public_html/resources/views/dashboard.blade.php ENDPATH**/ ?>