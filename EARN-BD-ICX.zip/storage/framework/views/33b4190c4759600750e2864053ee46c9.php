<?php
$pages = \App\Models\CustomPage::query()->where('status', 'active')->orderBy('id')->get();
$socials = [
  'facebook'  => ['fa-facebook', getSetting('social_facebook')],
  'youtube'   => ['fa-youtube', getSetting('social_youtube')],
  'telegram'  => ['fa-telegram', getSetting('social_telegram')],
  'twitter'   => ['fa-x-twitter', getSetting('social_twitter')],
  'instagram' => ['fa-instagram', getSetting('social_instagram')],
];
?>
<footer class="public-footer">
  <div class="footer-grid">
    <div class="footer-brand">
      <div class="site-logo" style="margin-bottom:14px;">
        <?php echo $__env->make('partials.brand-logo', ['size' => 'md'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      </div>
      <p><?php echo e(getSetting('footer_description','The #1 earning platform.')); ?></p>
      <div class="social-links">
        <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => [$icon, $url]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($url && $url !== '#'): ?>
            <a href="<?php echo e($url); ?>" target="_blank" rel="noopener"><i class="fa-brands <?php echo e($icon); ?>"></i></a>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
    <div class="footer-col">
      <h4>Quick Links</h4>
      <ul>
        <li><a href="/register">Register Free</a></li>
        <li><a href="/login">Login</a></li>
        <li><a href="/#how-it-works">How It Works</a></li>
        <li><a href="/#tasks">Featured Tasks</a></li>
        <li><a href="/#faq">FAQ</a></li>
      </ul>
    </div>
    <?php if($pages->count()): ?>
    <div class="footer-col">
      <h4>Information</h4>
      <ul>
        <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><a href="/page/<?php echo e($p['slug']); ?>"><?php echo e($p['title']); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
    <?php endif; ?>
  </div>
  <div class="footer-bottom"><?php echo e(getSetting('footer_copyright','© ' . date('Y') . ' ' . getSetting('site_name','EarnBD') . '. All rights reserved.')); ?></div>
  <div class="footer-dev">
    <a class="footer-dev-link" href="https://t.me/infinity_codex" target="_blank" rel="noopener noreferrer">
      <i class="fa-brands fa-telegram"></i>
      <span>Developed by <b>SHADOW RIAD</b>🔰</span>
    </a>
  </div>
</footer>
<?php echo getSetting('custom_footer_script',''); ?>

<?php /**PATH /home/icxbdfsb/public_html/resources/views/partials/public-footer.blade.php ENDPATH**/ ?>