<?php echo $__env->make('admin.partials-header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php if($flash): ?><div class="alert alert-success" style="margin-bottom:20px;"><?php echo e($flash); ?></div><?php endif; ?>
<?php if($error): ?><div class="alert alert-error" style="margin-bottom:20px;"><?php echo e($error); ?></div><?php endif; ?>

<div class="admin-card" style="max-width:560px;">
  <div class="admin-card-header"><div class="admin-card-title">My Account — Username &amp; Password</div></div>
  <div class="admin-card-body">
    <form method="post" action="/Icxpanel/account" autocomplete="off">
      <?php echo csrfField(); ?>

      <div class="form-group">
        <label>Username</label>
        <input type="text" name="username" class="form-control" value="<?php echo e($admin->username); ?>" required minlength="3" maxlength="60">
      </div>
      <div class="form-group">
        <label>New Password <small style="color:#888;">(leave empty to keep the current one)</small></label>
        <input type="password" name="new_password" class="form-control" minlength="8" autocomplete="new-password" placeholder="At least 8 characters">
      </div>
      <div class="form-group">
        <label>Confirm New Password</label>
        <input type="password" name="confirm_password" class="form-control" autocomplete="new-password">
      </div>
      <hr style="margin:18px 0;border-color:#f0f0f0;">
      <div class="form-group">
        <label>Current Password <small style="color:#888;">(required to save any change)</small></label>
        <input type="password" name="current_password" class="form-control" required autocomplete="current-password">
      </div>
      <button class="btn btn-primary" type="submit"><i class="fa-solid fa-key"></i> Save Changes</button>
    </form>
  </div>
</div>
<?php echo $__env->make('admin.partials-footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH /home/icxbdfsb/public_html/resources/views/admin/account.blade.php ENDPATH**/ ?>