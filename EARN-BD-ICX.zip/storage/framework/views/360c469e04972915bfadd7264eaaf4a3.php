<?php echo $__env->make('admin.partials-header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php if($flash): ?><div class="alert alert-success" style="margin-bottom:20px;"><?php echo e($flash); ?></div><?php endif; ?>
<?php echo csrfField(); ?>


<div class="admin-card">
  <div class="admin-card-header">
    <div class="admin-card-title">Users (<?php echo e(number_format($total)); ?>)</div>
    <a href="?export=csv" class="btn btn-sm btn-outline"><i class="fa-solid fa-download"></i> Export CSV</a>
  </div>

  <form method="get" class="admin-filters">
    <input type="text" name="search" class="filter-input" placeholder="Search name or email..." value="<?php echo e($search); ?>">
    <select name="level" class="filter-select">
      <option value="">All Levels</option>
      <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($l['id']); ?>" <?php echo e($level==$l['id']?'selected':''); ?>><?php echo e($l['name']); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <select name="status" class="filter-select">
      <option value="">All Status</option>
      <option value="active" <?php echo e($status==='active'?'selected':''); ?>>Active</option>
      <option value="banned" <?php echo e($status==='banned'?'selected':''); ?>>Banned</option>
    </select>
    <button type="submit" class="filter-btn filter-btn-primary"><i class="fa-solid fa-magnifying-glass"></i> Search</button>
    <a href="/Icxpanel/users" class="filter-btn filter-btn-outline">Reset</a>
  </form>

  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>User</th><th>Level</th><th>Balance</th><th>Points</th><th>Status</th><th>Joined</th><th>Actions</th></tr></thead>
      <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td>
              <div class="user-cell">
                <div class="table-avatar"><?php if($u['avatar']): ?><img src="<?php echo e($u['avatar']); ?>" alt=""><?php else: ?><?php echo e(strtoupper(substr($u['name'],0,1))); ?><?php endif; ?></div>
                <div class="user-cell-info"><div class="user-cell-name"><?php echo e($u['name']); ?></div><div class="user-cell-email"><?php echo e($u['email']); ?></div></div>
              </div>
            </td>
            <td><span class="badge" style="background:<?php echo e($u['level_color']??'#CD7F32'); ?>22;color:<?php echo e($u['level_color']??'#CD7F32'); ?>"><?php echo e($u['level_name']??'Bronze'); ?></span></td>
            <td style="font-weight:700;color:var(--primary)"><?php echo e(formatAmount((float)$u['balance'])); ?></td>
            <td><?php echo e(number_format($u['points'])); ?></td>
            <td><span class="status-badge status-<?php echo e($u['status']); ?>"><?php echo e(ucfirst($u['status'])); ?></span></td>
            <td style="font-size:12px;color:#888"><?php echo e(date('M j, Y',strtotime($u['created_at']))); ?></td>
            <td>
              <div class="action-btns">
                <a href="/Icxpanel/user-detail?id=<?php echo e($u['id']); ?>" class="action-btn-sm action-btn-view"><i class="fa-solid fa-eye"></i></a>
                <button class="action-btn-sm action-btn-edit" onclick="openCreditModal(<?php echo e($u['id']); ?>, '<?php echo e(addslashes($u['name'])); ?>', <?php echo e($u['balance']); ?>)"><i class="fa-solid fa-coins"></i></button>
                <?php if($u['status'] === 'active'): ?>
                  <form method="post" style="display:inline"><?php echo csrfField(); ?><input type="hidden" name="action" value="ban"><input type="hidden" name="user_id" value="<?php echo e($u['id']); ?>"><button type="submit" class="action-btn-sm action-btn-reject" data-confirm="Ban this user?"><i class="fa-solid fa-ban"></i></button></form>
                <?php else: ?>
                  <form method="post" style="display:inline"><?php echo csrfField(); ?><input type="hidden" name="action" value="unban"><input type="hidden" name="user_id" value="<?php echo e($u['id']); ?>"><button type="submit" class="action-btn-sm action-btn-approve"><i class="fa-solid fa-check"></i></button></form>
                <?php endif; ?>
              </div>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
  <?php echo paginationLinks($total, $page, $limit, '/Icxpanel/users?' . http_build_query(['search'=>$search,'level'=>$level,'status'=>$status])); ?>

</div>

<!-- Credit Modal -->
<div class="modal-overlay" id="credit-modal">
  <div class="modal-box">
    <div class="modal-header"><h3 id="credit-modal-title">Balance</h3><span class="modal-close"><i class="fa-solid fa-xmark"></i></span></div>
    <form method="post" action="/Icxpanel/users">
      <?php echo csrfField(); ?>

      <input type="hidden" name="action" value="credit">
      <input type="hidden" name="user_id" id="credit-uid">
      <div class="form-group"><label class="form-label">Amount (positive = credit, negative = deduct)</label><input type="number" name="amount" class="form-control" step="0.01" required placeholder="e.g. 100 or -50"></div>
      <button type="submit" class="btn btn-primary btn-block">Apply</button>
    </form>
  </div>
</div>
<script>function openCreditModal(uid,name,bal){document.getElementById('credit-uid').value=uid;document.getElementById('credit-modal-title').textContent='Balance: '+name+' (Current: '+bal+')';document.getElementById('credit-modal').classList.add('active');}</script>
<?php echo $__env->make('admin.partials-footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH /home/icxbdfsb/public_html/resources/views/admin/users.blade.php ENDPATH**/ ?>