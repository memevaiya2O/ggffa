<!DOCTYPE html>
<html lang="en">
<head>
<?php echo renderSeoMeta(); ?>

<?php echo renderGoogleFont(); ?>

<?php echo renderCssVars(); ?>

<link rel="stylesheet" href="/assets/css/style.css?v=3">
<link rel="stylesheet" href="/assets/css/dashboard.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="app-layout">
  <header class="app-header">
    <div class="app-header-left"><div class="user-name">Leaderboard</div></div>
    <div class="app-header-right">
      <a href="/notifications" class="notif-btn"><i class="fa-solid fa-bell"></i><?php if($notifCount): ?><span class="notif-badge"><?php echo e($notifCount); ?></span><?php endif; ?></a>
    </div>
  </header>
  <main class="main-content">
    <div class="leaderboard-tabs">
      <div class="lb-tab <?php echo e($period==='weekly'?'active':''); ?>" data-period="weekly">Weekly</div>
      <div class="lb-tab <?php echo e($period==='monthly'?'active':''); ?>" data-period="monthly">Monthly</div>
      <div class="lb-tab <?php echo e($period==='alltime'?'active':''); ?>" data-period="alltime">All Time</div>
    </div>
    <?php $__currentLoopData = $top; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php
        $rank = $i + 1;
        $rankClass = $rank === 1 ? 'top-1' : ($rank === 2 ? 'top-2' : ($rank === 3 ? 'top-3' : ''));
        $rankIcon  = $rank === 1 ? '🥇' : ($rank === 2 ? '🥈' : ($rank === 3 ? '🥉' : "#$rank"));
        $isMe = $u['id'] == $user['id'];
      ?>
      <div class="rank-card <?php echo e($isMe ? 'my-rank' : ''); ?>">
        <div class="rank-num <?php echo e($rankClass); ?>"><?php echo e($rankIcon); ?></div>
        <div class="earner-avatar">
          <?php if($u['avatar']): ?><img src="<?php echo e($u['avatar']); ?>" alt=""><?php else: ?><?php echo e(strtoupper(substr($u['name'],0,1))); ?><?php endif; ?>
        </div>
        <div style="flex:1;min-width:0;">
          <div style="font-weight:700;font-size:15px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?php echo e($u['name']); ?><?php echo $isMe ? ' <span style="color:var(--primary);font-size:12px;">(You)</span>' : ''; ?></div>
          <div style="font-size:12px;color:#888;display:flex;align-items:center;gap:4px;margin-top:2px;">
            <i class="fa-solid <?php echo e($u['level_icon']??'fa-medal'); ?>" style="color:<?php echo e($u['level_color']??'#CD7F32'); ?>"></i> <?php echo e($u['level_name']??'Bronze'); ?>

          </div>
        </div>
        <div style="font-size:20px;font-weight:900;color:var(--primary)"><?php echo e(formatAmount((float)$u['earned'])); ?></div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if($myRank === null): ?>
      <div class="rank-card my-rank" style="margin-top:8px;">
        <div class="rank-num" style="color:#888;">—</div>
        <div class="earner-avatar"><?php echo e(strtoupper(substr($user['name'],0,1))); ?></div>
        <div style="flex:1;">
          <div style="font-weight:700;font-size:15px;"><?php echo e($user['name']); ?> <span style="color:var(--primary);font-size:12px;">(You)</span></div>
          <div style="font-size:12px;color:#888;">Not ranked yet</div>
        </div>
        <div style="font-size:20px;font-weight:900;color:var(--primary)"><?php echo e(formatAmount((float)$user['total_earned'])); ?></div>
      </div>
    <?php endif; ?>
  </main>
  <nav class="bottom-nav">
    <a href="/dashboard" class="nav-item"><i class="fa-solid fa-house"></i>Home</a>
    <a href="/tasks" class="nav-item"><i class="fa-solid fa-list-check"></i>Tasks</a>
    <a href="/wallet" class="nav-item"><i class="fa-solid fa-wallet"></i>Wallet</a>
    <a href="/leaderboard" class="nav-item active"><i class="fa-solid fa-trophy"></i>Board</a>
    <a href="/profile" class="nav-item"><i class="fa-solid fa-user"></i>Profile</a>
  </nav>
</div>
<div id="toast-container"></div>
<script src="/assets/js/main.js"></script>
</body>
</html>
<?php /**PATH /home/icxbdfsb/public_html/resources/views/leaderboard.blade.php ENDPATH**/ ?>