<?php echo $__env->make('admin.partials-header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php if($flash): ?><div class="alert alert-success" style="margin-bottom:20px;"><?php echo e($flash); ?></div><?php endif; ?>

<div class="admin-grid-2" style="gap:24px;display:grid;grid-template-columns:1fr 1.8fr;">

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">Send Broadcast</div></div>
  <div class="admin-card-body">
    <form method="post">
      <?php echo csrfField(); ?>

      <input type="hidden" name="action" value="broadcast">
      <div class="form-group">
        <label>Target</label>
        <select name="target" class="form-control">
          <option value="all">All Active Users</option>
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($u['id']); ?>"><?php echo e($u['name']); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="form-group">
        <label>Title</label>
        <input type="text" name="title" class="form-control" placeholder="Notification title" required>
      </div>
      <div class="form-group">
        <label>Message</label>
        <textarea name="message" class="form-control" rows="4" placeholder="Write your message..." required></textarea>
      </div>
      <button class="btn btn-primary">Send Broadcast</button>
    </form>
  </div>
</div>

<div class="admin-card">
  <div class="admin-card-header">
    <div class="admin-card-title">Recent Notifications (<?php echo e($total); ?>)</div>
    <div style="display:flex;gap:8px;">
      <form method="post" style="display:inline" onsubmit="return confirm('Mark all as read?')">
        <?php echo csrfField(); ?><input type="hidden" name="action" value="mark_read">
        <button class="btn btn-secondary btn-sm">Mark All Read</button>
      </form>
      <form method="post" style="display:inline" onsubmit="return confirm('Delete ALL notifications? This is irreversible.')">
        <?php echo csrfField(); ?><input type="hidden" name="action" value="delete_all">
        <button class="btn btn-danger btn-sm">Clear All</button>
      </form>
    </div>
  </div>
  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>User</th><th>Type</th><th>Title</th><th>Time</th><th>Read</th><th>Del</th></tr></thead>
      <tbody>
        <?php $__currentLoopData = $notifs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($n['user_name'] ?? 'N/A'); ?></td>
          <td><span class="badge badge-info"><?php echo e($n['type']); ?></span></td>
          <td title="<?php echo e($n['message']); ?>"><?php echo e(mb_strimwidth($n['title'],0,40,'…')); ?></td>
          <td style="font-size:12px;"><?php echo e(date('d M H:i',strtotime($n['created_at']))); ?></td>
          <td><?php echo $n['is_read']?'<span style="color:green">✓</span>':'<span style="color:#aaa">✗</span>'; ?></td>
          <td>
            <form method="post" style="display:inline" onsubmit="return confirm('Delete?')">
              <?php echo csrfField(); ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?php echo e($n['id']); ?>">
              <button class="btn btn-danger btn-xs">×</button>
            </form>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if(!$notifs->count()): ?><tr><td colspan="6" style="text-align:center;color:#888;">No notifications.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php if($total > $limit): ?>
  <div style="padding:12px;text-align:center;">
    <?php for($i = 1; $i <= ceil($total/$limit); $i++): ?>
    <a href="?page=<?php echo e($i); ?>" class="btn btn-xs <?php echo e($page==$i?'btn-primary':'btn-secondary'); ?>"><?php echo e($i); ?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
</div>

</div>
<?php echo $__env->make('admin.partials-footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH /home/icxbdfsb/public_html/resources/views/admin/notifications.blade.php ENDPATH**/ ?>