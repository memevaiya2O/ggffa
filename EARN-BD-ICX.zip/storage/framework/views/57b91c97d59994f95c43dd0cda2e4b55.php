<!DOCTYPE html>
<html lang="en">
<head>
<?php echo renderSeoMeta(); ?>

<?php echo renderGoogleFont(); ?>

<?php echo renderCssVars(); ?>

<link rel="stylesheet" href="/assets/css/style.css?v=3">
<link rel="stylesheet" href="/assets/css/dashboard.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="app-layout">
  <header class="app-header">
    <div class="app-header-left">
      <a href="/tasks" style="color:var(--text);font-size:22px;"><i class="fa-solid fa-arrow-left"></i></a>
      <div class="user-name" style="margin-left:10px;">Task Detail</div>
    </div>
    <div class="app-header-right">
      <a href="/notifications" class="notif-btn"><i class="fa-solid fa-bell"></i><?php if($notifCount): ?><span class="notif-badge"><?php echo e($notifCount); ?></span><?php endif; ?></a>
    </div>
  </header>
  <main class="main-content">
    <?php if(!empty($submitted)): ?>
      <div class="alert alert-success" style="margin-bottom:16px;">✅ Submission received! Under review.</div>
    <?php endif; ?>

    <?php
      $instructionLines = array_filter(array_map('trim', explode("\n", $task['instructions'] ?? '')));
      $ruleLines = array_filter(array_map('trim', explode("\n", $task['rules'] ?? '')));
    ?>

    <!-- Task Hero -->
    <div class="task-detail-hero">
      <?php if($task['thumbnail']): ?><img src="<?php echo e($task['thumbnail']); ?>" alt="" style="width:100%;max-height:160px;object-fit:cover;border-radius:10px;margin-bottom:14px;"><?php endif; ?>
      <div class="task-cat-badge" style="margin-bottom:12px;justify-content:center;">
        <i class="fa-solid <?php echo e($task['cat_icon'] ?? 'fa-tag'); ?>"></i> <?php echo e($task['cat_name'] ?? 'General'); ?>

      </div>
      <h2><?php echo e($task['title']); ?></h2>
      <div class="reward"><?php echo e(formatAmount((float)$task['reward'])); ?></div>
      <div style="font-size:14px;opacity:.8;margin-top:8px;"><?php echo e($task['approved_count']); ?>/<?php echo e($task['max_total']); ?> completed</div>
      <div style="display:flex;gap:8px;justify-content:center;margin-top:12px;flex-wrap:wrap;">
        <?php if($task['is_hot']): ?><span class="badge" style="background:rgba(255,255,255,.2);color:#fff;">🔥 HOT</span><?php endif; ?>
        <?php if($task['is_new']): ?><span class="badge" style="background:rgba(255,255,255,.2);color:#fff;">✨ NEW</span><?php endif; ?>
        <?php if($task['is_vip']): ?><span class="badge" style="background:rgba(255,215,0,.3);color:#fff;">👑 VIP</span><?php endif; ?>
        <?php if($task['screenshot_required']): ?><span class="badge" style="background:rgba(255,255,255,.2);color:#fff;"><i class="fa-solid fa-camera"></i> Screenshot Required</span><?php endif; ?>
      </div>
    </div>

    <!-- Instructions -->
    <?php if($instructionLines): ?>
    <div class="card" style="margin-bottom:16px;">
      <h3 style="margin-bottom:16px;"><i class="fa-solid fa-clipboard-list" style="color:var(--primary);margin-right:8px;"></i>Instructions</h3>
      <ol class="instruction-steps" style="list-style:none;padding:0;">
        <?php $__currentLoopData = array_values($instructionLines); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li>
            <div class="step-num-dot"><?php echo e($i+1); ?></div>
            <div style="font-size:15px;color:#444;line-height:1.6;"><?php echo e($line); ?></div>
          </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ol>
    </div>
    <?php endif; ?>

    <!-- Rules -->
    <?php if($ruleLines): ?>
    <div class="card" style="margin-bottom:16px;">
      <h3 style="margin-bottom:16px;"><i class="fa-solid fa-triangle-exclamation" style="color:var(--warning);margin-right:8px;"></i>Rules</h3>
      <ul class="rules-list" style="list-style:none;padding:0;">
        <?php $__currentLoopData = $ruleLines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($rule); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
    <?php endif; ?>

    <!-- Submit / Status -->
    <?php if($existingSub): ?>
      <div class="card" style="text-align:center;padding:32px;">
        <?php if($existingSub['status'] === 'approved'): ?>
          <div style="font-size:48px;margin-bottom:12px;">✅</div>
          <h3 style="color:var(--primary)">Task Completed!</h3>
          <p style="color:#888;margin-top:8px;">Reward of <?php echo e(formatAmount((float)$task['reward'])); ?> has been credited.</p>
        <?php elseif($existingSub['status'] === 'rejected'): ?>
          <div style="font-size:48px;margin-bottom:12px;">❌</div>
          <h3 style="color:var(--danger)">Submission Rejected</h3>
          <p style="color:#888;margin-top:8px;"><?php echo e($existingSub['reject_reason'] ?? 'No reason provided'); ?></p>
        <?php else: ?>
          <div style="font-size:48px;margin-bottom:12px;">⏳</div>
          <h3 style="color:var(--warning)">Under Review</h3>
          <p style="color:#888;margin-top:8px;">Submitted <?php echo e(timeAgo($existingSub['created_at'])); ?> — we'll notify you soon.</p>
        <?php endif; ?>
      </div>
    <?php else: ?>
      <div class="card" style="margin-bottom:20px;">
        <h3 style="margin-bottom:16px;"><i class="fa-solid fa-paper-plane" style="color:var(--primary);margin-right:8px;"></i>Submit Proof</h3>
        <?php if($error): ?><div class="alert alert-error"><?php echo e($error); ?></div><?php endif; ?>
        <form method="post" action="/task-detail?id=<?php echo e($taskId); ?>" enctype="multipart/form-data">
          <?php echo csrfField(); ?>

          <?php if($task['screenshot_required']): ?>
          <div class="form-group">
            <label class="form-label">Screenshot <span style="color:var(--danger)">*</span></label>
            <div class="upload-area">
              <i class="fa-solid fa-cloud-arrow-up"></i>
              <p style="margin:8px 0 4px;font-weight:700;">Tap to upload or drag & drop</p>
              <p style="font-size:13px;color:#aaa;">JPG, PNG — max 2MB</p>
              <input type="file" name="screenshot" id="screenshot" accept="image/*" style="display:none">
            </div>
          </div>
          <?php endif; ?>
          <div class="form-group">
            <label class="form-label">Notes <span style="color:#aaa;font-weight:400">(optional)</span></label>
            <textarea name="notes" class="form-control" rows="3" placeholder="Any additional notes..."><?php echo e($oldNotes); ?></textarea>
          </div>
          <button type="submit" class="btn btn-primary btn-block btn-lg">
            <i class="fa-solid fa-paper-plane"></i> Submit for Review
          </button>
        </form>
      </div>
    <?php endif; ?>
  </main>
  <nav class="bottom-nav">
    <a href="/dashboard" class="nav-item"><i class="fa-solid fa-house"></i>Home</a>
    <a href="/tasks" class="nav-item active"><i class="fa-solid fa-list-check"></i>Tasks</a>
    <a href="/wallet" class="nav-item"><i class="fa-solid fa-wallet"></i>Wallet</a>
    <a href="/leaderboard" class="nav-item"><i class="fa-solid fa-trophy"></i>Board</a>
    <a href="/profile" class="nav-item"><i class="fa-solid fa-user"></i>Profile</a>
  </nav>
</div>
<div id="toast-container"></div>
<script src="/assets/js/main.js"></script>
</body>
</html>
<?php /**PATH /home/icxbdfsb/public_html/resources/views/task-detail.blade.php ENDPATH**/ ?>