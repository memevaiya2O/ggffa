<?php echo $__env->make('admin.partials-header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php if($error): ?><div class="alert alert-error" style="margin-bottom:20px;"><?php echo e($error); ?></div><?php endif; ?>
<div class="admin-card">
  <form method="post" enctype="multipart/form-data">
    <?php echo csrfField(); ?>

    <div class="admin-form-grid">
      <div class="admin-form-group"><label class="admin-label">Task Title *</label><input type="text" name="title" class="admin-input" value="<?php echo e(request()->input('title','')); ?>" required></div>
      <div class="admin-form-group"><label class="admin-label">Category</label><select name="category_id" class="admin-input"><option value="">No Category</option><?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($c['id']); ?>"><?php echo e($c['name']); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
      <div class="admin-form-group"><label class="admin-label">Type</label><select name="type" class="admin-input"><option value="standard">Standard</option><option value="social">Social Media</option><option value="app">App Install</option><option value="survey">Survey</option><option value="video">Video Watch</option></select></div>
      <div class="admin-form-group"><label class="admin-label">Reward Amount *</label><input type="number" name="reward" class="admin-input" step="0.01" min="0.01" value="<?php echo e(request()->input('reward','')); ?>" required></div>
      <div class="admin-form-group"><label class="admin-label">Max per User</label><input type="number" name="max_per_user" class="admin-input" min="1" value="<?php echo e(request()->input('max_per_user','1')); ?>"></div>
      <div class="admin-form-group"><label class="admin-label">Max Total Completions</label><input type="number" name="max_total" class="admin-input" min="1" value="<?php echo e(request()->input('max_total','1000')); ?>"></div>
      <div class="admin-form-group"><label class="admin-label">Thumbnail Image</label><input type="file" name="thumbnail" class="admin-input" accept="image/*"></div>
      <div class="admin-form-group"><label class="admin-label">Status</label><select name="status" class="admin-input"><option value="active">Active</option><option value="inactive">Inactive</option></select></div>
    </div>
    <div class="admin-form-group"><label class="admin-label">Instructions (one step per line)</label><textarea name="instructions" class="admin-input admin-textarea" rows="6" placeholder="Step 1: Do this&#10;Step 2: Do that"><?php echo e(request()->input('instructions','')); ?></textarea></div>
    <div class="admin-form-group"><label class="admin-label">Rules (one per line)</label><textarea name="rules" class="admin-input admin-textarea" rows="4" placeholder="Rule 1&#10;Rule 2"><?php echo e(request()->input('rules','')); ?></textarea></div>
    <div style="display:flex;flex-wrap:wrap;gap:20px;margin-bottom:20px;">
      <label class="toggle-label"><span class="toggle-switch"><input type="checkbox" name="screenshot_required" value="1" checked><span class="toggle-slider"></span></span> Require Screenshot</label>
      <label class="toggle-label"><span class="toggle-switch"><input type="checkbox" name="is_featured" value="1"><span class="toggle-slider"></span></span> Featured</label>
      <label class="toggle-label"><span class="toggle-switch"><input type="checkbox" name="is_hot" value="1"><span class="toggle-slider"></span></span> 🔥 Hot</label>
      <label class="toggle-label"><span class="toggle-switch"><input type="checkbox" name="is_new" value="1" checked><span class="toggle-slider"></span></span> ✨ New</label>
      <label class="toggle-label"><span class="toggle-switch"><input type="checkbox" name="is_vip" value="1"><span class="toggle-slider"></span></span> 👑 VIP Only</label>
    </div>
    <button type="submit" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Add Task</button>
    <a href="/Icxpanel/tasks" class="btn btn-outline" style="margin-left:10px;">Cancel</a>
  </form>
</div>
<?php echo $__env->make('admin.partials-footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH /home/icxbdfsb/public_html/resources/views/admin/task-add.blade.php ENDPATH**/ ?>