<?php
$__logo = getSetting('site_logo');
$__name = getSetting('site_name', 'EarnBD');
$size = $size ?? 'md';
?>
<?php if($__logo): ?>
<img src="<?php echo e($__logo); ?>" alt="<?php echo e($__name); ?>" class="brand-logo brand-logo-<?php echo e($size); ?>">
<?php else: ?>
<div class="brand-logo-placeholder brand-logo-<?php echo e($size); ?>" title="Logo placeholder — upload your logo in Admin → Settings"><i class="fa-regular fa-image"></i></div>
<?php endif; ?>
<b class="sr-only"><?php echo e($__name); ?></b>
<?php /**PATH /home/icxbdfsb/public_html/resources/views/partials/brand-logo.blade.php ENDPATH**/ ?>