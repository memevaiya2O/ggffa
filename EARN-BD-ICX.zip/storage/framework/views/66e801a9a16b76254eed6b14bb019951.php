<?php echo $__env->make('admin.partials-header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php if($error): ?><div class="alert alert-error" style="margin-bottom:20px;"><?php echo e($error); ?></div><?php endif; ?>
<div class="admin-card">
  <form method="post" enctype="multipart/form-data">
    <?php echo csrfField(); ?>

    <div class="admin-form-grid">
      <div class="admin-form-group"><label class="admin-label">Task Title *</label><input type="text" name="title" class="admin-input" value="<?php echo e($task['title']); ?>" required></div>
      <div class="admin-form-group"><label class="admin-label">Category</label><select name="category_id" class="admin-input"><option value="">No Category</option><?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($c['id']); ?>" <?php echo e($task['category_id']==$c['id']?'selected':''); ?>><?php echo e($c['name']); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
      <div class="admin-form-group"><label class="admin-label">Type</label><select name="type" class="admin-input"><?php $__currentLoopData = ['standard','social','app','survey','video']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($t); ?>" <?php echo e($task['type']===$t?'selected':''); ?>><?php echo e(ucfirst($t)); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
      <div class="admin-form-group"><label class="admin-label">Reward Amount *</label><input type="number" name="reward" class="admin-input" step="0.01" min="0.01" value="<?php echo e($task['reward']); ?>" required></div>
      <div class="admin-form-group"><label class="admin-label">Max per User</label><input type="number" name="max_per_user" class="admin-input" min="1" value="<?php echo e($task['max_per_user']); ?>"></div>
      <div class="admin-form-group"><label class="admin-label">Max Total Completions</label><input type="number" name="max_total" class="admin-input" min="1" value="<?php echo e($task['max_total']); ?>"></div>
      <div class="admin-form-group"><label class="admin-label">Thumbnail <?php if($task['thumbnail']): ?> <a href="<?php echo e($task['thumbnail']); ?>" target="_blank" style="font-size:11px">(current)</a><?php endif; ?></label><input type="file" name="thumbnail" class="admin-input" accept="image/*"></div>
      <div class="admin-form-group"><label class="admin-label">Status</label><select name="status" class="admin-input"><option value="active" <?php echo e($task['status']==='active'?'selected':''); ?>>Active</option><option value="inactive" <?php echo e($task['status']==='inactive'?'selected':''); ?>>Inactive</option></select></div>
    </div>
    <div class="admin-form-group"><label class="admin-label">Instructions</label><textarea name="instructions" class="admin-input admin-textarea" rows="6"><?php echo e($task['instructions']); ?></textarea></div>
    <div class="admin-form-group"><label class="admin-label">Rules</label><textarea name="rules" class="admin-input admin-textarea" rows="4"><?php echo e($task['rules']); ?></textarea></div>
    <div style="display:flex;flex-wrap:wrap;gap:20px;margin-bottom:20px;">
      <label class="toggle-label"><span class="toggle-switch"><input type="checkbox" name="screenshot_required" value="1" <?php echo e($task['screenshot_required']?'checked':''); ?>><span class="toggle-slider"></span></span> Require Screenshot</label>
      <label class="toggle-label"><span class="toggle-switch"><input type="checkbox" name="is_featured" value="1" <?php echo e($task['is_featured']?'checked':''); ?>><span class="toggle-slider"></span></span> Featured</label>
      <label class="toggle-label"><span class="toggle-switch"><input type="checkbox" name="is_hot" value="1" <?php echo e($task['is_hot']?'checked':''); ?>><span class="toggle-slider"></span></span> 🔥 Hot</label>
      <label class="toggle-label"><span class="toggle-switch"><input type="checkbox" name="is_new" value="1" <?php echo e($task['is_new']?'checked':''); ?>><span class="toggle-slider"></span></span> ✨ New</label>
      <label class="toggle-label"><span class="toggle-switch"><input type="checkbox" name="is_vip" value="1" <?php echo e($task['is_vip']?'checked':''); ?>><span class="toggle-slider"></span></span> 👑 VIP Only</label>
    </div>
    <button type="submit" class="btn btn-primary"><i class="fa-solid fa-save"></i> Save Changes</button>
    <a href="/Icxpanel/tasks" class="btn btn-outline" style="margin-left:10px;">Cancel</a>
  </form>
</div>
<?php echo $__env->make('admin.partials-footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH /home/icxbdfsb/public_html/resources/views/admin/task-edit.blade.php ENDPATH**/ ?>