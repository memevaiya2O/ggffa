<?php echo $__env->make('admin.partials-header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php if($flash): ?><div class="alert alert-success" style="margin-bottom:20px;"><?php echo e($flash); ?></div><?php endif; ?>

<form method="post">
  <?php echo csrfField(); ?>


  <div class="admin-card" style="margin-bottom:20px;">
    <div class="admin-card-header"><div class="admin-card-title">🏠 Hero Section</div></div>
    <div class="admin-card-body">
      <div class="admin-grid-2" style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
        <div class="form-group"><label>Hero Title</label><input type="text" name="hero_title" class="form-control" value="<?php echo e($s['hero_title'] ?? 'Earn Real Money Online'); ?>"></div>
        <div class="form-group"><label>Hero Subtitle</label><input type="text" name="hero_subtitle" class="form-control" value="<?php echo e($s['hero_subtitle'] ?? 'Complete tasks and get paid'); ?>"></div>
        <div class="form-group"><label>Button Text</label><input type="text" name="hero_btn_text" class="form-control" value="<?php echo e($s['hero_btn_text'] ?? 'Get Started'); ?>"></div>
        <div class="form-group"><label>Button Link</label><input type="text" name="hero_btn_link" class="form-control" value="<?php echo e($s['hero_btn_link'] ?? '/register'); ?>"></div>
        <div class="form-group"><label>Hero Background Color</label><input type="color" name="hero_bg_color" value="<?php echo e($s['hero_bg_color'] ?? '#667eea'); ?>" style="height:40px;width:100%;"></div>
        <div class="form-group"><label>Hero Text Color</label><input type="color" name="hero_text_color" value="<?php echo e($s['hero_text_color'] ?? '#ffffff'); ?>" style="height:40px;width:100%;"></div>
      </div>
    </div>
  </div>

  <div class="admin-card" style="margin-bottom:20px;">
    <div class="admin-card-header"><div class="admin-card-title">📊 Stats Bar</div></div>
    <div class="admin-card-body">
      <div class="form-group">
        <label>Show Stats Bar</label>
        <select name="stats_show" class="form-control" style="max-width:200px;">
          <option value="1" <?php echo e(($s['stats_show'] ?? '1')==='1'?'selected':''); ?>>Yes</option>
          <option value="0" <?php echo e(($s['stats_show'] ?? '1')==='0'?'selected':''); ?>>No</option>
        </select>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:16px;">
        <?php for($i = 1; $i <= 4; $i++): ?>
        <div>
          <div class="form-group"><label>Stat <?php echo e($i); ?> Number</label><input type="text" name="stat<?php echo e($i); ?>_number" class="form-control" value="<?php echo e($s["stat{$i}_number"] ?? '0+'); ?>"></div>
          <div class="form-group"><label>Stat <?php echo e($i); ?> Label</label><input type="text" name="stat<?php echo e($i); ?>_label" class="form-control" value="<?php echo e($s["stat{$i}_label"] ?? 'Label'); ?>"></div>
        </div>
        <?php endfor; ?>
      </div>
    </div>
  </div>

  <div class="admin-card" style="margin-bottom:20px;">
    <div class="admin-card-header"><div class="admin-card-title">✨ Features Section</div></div>
    <div class="admin-card-body">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px;">
        <div class="form-group"><label>Show Features</label><select name="features_show" class="form-control"><option value="1" <?php echo e(($s['features_show'] ?? '1')==='1'?'selected':''); ?>>Yes</option><option value="0" <?php echo e(($s['features_show'] ?? '1')==='0'?'selected':''); ?>>No</option></select></div>
        <div class="form-group"><label>Section Title</label><input type="text" name="features_title" class="form-control" value="<?php echo e($s['features_title'] ?? 'Why Choose Us'); ?>"></div>
      </div>
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px;">
        <?php for($i = 1; $i <= 6; $i++): ?>
        <div style="border:1px solid #eee;padding:12px;border-radius:8px;">
          <div class="form-group"><label>Icon <?php echo e($i); ?> (FA class)</label><input type="text" name="feat_icon_<?php echo e($i); ?>" class="form-control" value="<?php echo e($s["feat_icon_{$i}"] ?? 'fa-star'); ?>"></div>
          <div class="form-group"><label>Title <?php echo e($i); ?></label><input type="text" name="feat_title_<?php echo e($i); ?>" class="form-control" value="<?php echo e($s["feat_title_{$i}"] ?? "Feature {$i}"); ?>"></div>
          <div class="form-group"><label>Description <?php echo e($i); ?></label><input type="text" name="feat_desc_<?php echo e($i); ?>" class="form-control" value="<?php echo e($s["feat_desc_{$i}"] ?? ''); ?>"></div>
        </div>
        <?php endfor; ?>
      </div>
    </div>
  </div>

  <div class="admin-card" style="margin-bottom:20px;">
    <div class="admin-card-header"><div class="admin-card-title">📢 CTA Section</div></div>
    <div class="admin-card-body">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
        <div class="form-group"><label>Show CTA</label><select name="cta_show" class="form-control"><option value="1" <?php echo e(($s['cta_show'] ?? '1')==='1'?'selected':''); ?>>Yes</option><option value="0" <?php echo e(($s['cta_show'] ?? '1')==='0'?'selected':''); ?>>No</option></select></div>
        <div class="form-group"><label>CTA Title</label><input type="text" name="cta_title" class="form-control" value="<?php echo e($s['cta_title'] ?? 'Ready to Earn?'); ?>"></div>
        <div class="form-group"><label>CTA Subtitle</label><input type="text" name="cta_subtitle" class="form-control" value="<?php echo e($s['cta_subtitle'] ?? 'Join thousands of earners today!'); ?>"></div>
        <div class="form-group"><label>Button Text</label><input type="text" name="cta_btn_text" class="form-control" value="<?php echo e($s['cta_btn_text'] ?? 'Join Now'); ?>"></div>
        <div class="form-group"><label>Button Link</label><input type="text" name="cta_btn_link" class="form-control" value="<?php echo e($s['cta_btn_link'] ?? '/register'); ?>"></div>
      </div>
    </div>
  </div>

  <button class="btn btn-primary btn-lg">💾 Save Homepage</button>
</form>
<?php echo $__env->make('admin.partials-footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH /home/icxbdfsb/public_html/resources/views/admin/homepage-editor.blade.php ENDPATH**/ ?>