<?php echo $__env->make('admin.partials-header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $d = $editPop['_data'] ?? []; ?>
<?php if($flash): ?><div class="alert alert-success" style="margin-bottom:20px;"><?php echo e($flash); ?></div><?php endif; ?>

<div class="admin-grid-2" style="display:grid;grid-template-columns:1fr 1.5fr;gap:24px;">

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title"><?php echo e($editPop ? 'Edit Popup' : 'New Popup'); ?></div></div>
  <div class="admin-card-body">
    <form method="post">
      <?php echo csrfField(); ?>

      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" value="<?php echo e($editPop ? $editPop['id'] : 0); ?>">
      <div class="form-group"><label>Title</label><input type="text" name="title" class="form-control" value="<?php echo e($editPop['title'] ?? $d['title'] ?? ''); ?>" required></div>
      <div class="form-group"><label>Content (HTML)</label><textarea name="content" class="form-control" rows="5"><?php echo e($d['content'] ?? ''); ?></textarea></div>
      <div class="form-group"><label>Type</label>
        <select name="type" class="form-control">
          <?php $__currentLoopData = ['info'=>'Info','success'=>'Success','warning'=>'Warning','promo'=>'Promo','announcement'=>'Announcement']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v => $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($v); ?>" <?php echo e(($d['type']??'info')===$v?'selected':''); ?>><?php echo e($l); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="form-group"><label>Trigger</label>
        <select name="trigger" class="form-control">
          <option value="pageload" <?php echo e(($d['trigger']??'pageload')==='pageload'?'selected':''); ?>>Page Load</option>
          <option value="exit_intent" <?php echo e(($d['trigger']??'')==='exit_intent'?'selected':''); ?>>Exit Intent</option>
          <option value="scroll" <?php echo e(($d['trigger']??'')==='scroll'?'selected':''); ?>>On Scroll</option>
        </select>
      </div>
      <div class="form-group"><label>Delay (seconds)</label><input type="number" name="delay" class="form-control" value="<?php echo e($d['delay'] ?? 0); ?>" min="0"></div>
      <div class="form-group"><label>Show on Pages (comma-separated paths, empty = all)</label><input type="text" name="show_pages" class="form-control" value="<?php echo e($d['pages'] ?? ''); ?>" placeholder="/,/tasks,/register"></div>
      <div class="form-group"><label>Button Text</label><input type="text" name="btn_text" class="form-control" value="<?php echo e($d['btn_text'] ?? ''); ?>" placeholder="Get Started"></div>
      <div class="form-group"><label>Button Link</label><input type="text" name="btn_link" class="form-control" value="<?php echo e($d['btn_link'] ?? ''); ?>" placeholder="/register"></div>
      <div class="form-group"><label>Start Date (optional)</label><input type="datetime-local" name="start_date" class="form-control" value="<?php echo e($d['start_date'] ?? ''); ?>"></div>
      <div class="form-group"><label>End Date (optional)</label><input type="datetime-local" name="end_date" class="form-control" value="<?php echo e($d['end_date'] ?? ''); ?>"></div>
      <div class="form-group"><label>Status</label>
        <select name="status" class="form-control">
          <option value="active" <?php echo e(($editPop['status']??'active')==='active'?'selected':''); ?>>Active</option>
          <option value="inactive" <?php echo e(($editPop['status']??'')==='inactive'?'selected':''); ?>>Inactive</option>
        </select>
      </div>
      <button class="btn btn-primary">Save Popup</button>
      <?php if($editPop): ?><a href="/Icxpanel/popup-manager" class="btn btn-secondary">Cancel</a><?php endif; ?>
    </form>
  </div>
</div>

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">All Popups (<?php echo e(count($popups)); ?>)</div></div>
  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>Title</th><th>Type</th><th>Trigger</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
        <?php $__currentLoopData = $popups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php $pd = json_decode($p['data'], true) ?? []; ?>
        <tr>
          <td><strong><?php echo e($p['title']); ?></strong></td>
          <td><span class="badge badge-info"><?php echo e($pd['type'] ?? '-'); ?></span></td>
          <td><?php echo e($pd['trigger'] ?? '-'); ?></td>
          <td>
            <form method="post" style="display:inline">
              <?php echo csrfField(); ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?php echo e($p['id']); ?>">
              <button class="btn btn-xs <?php echo e($p['status']==='active'?'btn-success':'btn-secondary'); ?>"><?php echo e($p['status']); ?></button>
            </form>
          </td>
          <td>
            <a href="?edit=<?php echo e($p['id']); ?>" class="btn btn-warning btn-xs">Edit</a>
            <form method="post" style="display:inline" onsubmit="return confirm('Delete?')">
              <?php echo csrfField(); ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?php echo e($p['id']); ?>">
              <button class="btn btn-danger btn-xs">Del</button>
            </form>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if(!$popups->count()): ?><tr><td colspan="5" style="text-align:center;color:#888;">No popups yet.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

</div>
<?php echo $__env->make('admin.partials-footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH /home/icxbdfsb/public_html/resources/views/admin/popup-manager.blade.php ENDPATH**/ ?>