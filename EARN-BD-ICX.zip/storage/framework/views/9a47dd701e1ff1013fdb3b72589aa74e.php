<!DOCTYPE html>
<html lang="en">
<head>
<?php echo renderSeoMeta('login'); ?>

<?php echo renderGoogleFont(); ?>

<?php echo renderCssVars(); ?>

<link rel="stylesheet" href="/assets/css/style.css?v=3">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<?php echo getSetting('custom_header_script'); ?>

</head>
<body>
<div class="auth-page">
  <div class="auth-card">
    <div class="auth-logo">
      <div class="brand-logo-wrap"><?php echo $__env->make('partials.brand-logo', ['size' => 'lg'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
      <div style="font-size:13px;color:#888;margin-top:4px;"><?php echo e(getSetting('site_tagline','Earn Real Money Online')); ?></div>
    </div>
    <h2 class="auth-title">Welcome Back</h2>
    <p class="auth-subtitle">Sign in to your account</p>

    <?php if($error): ?><div class="alert alert-error"><i class="fa-solid fa-circle-exclamation"></i> <?php echo e($error); ?></div><?php endif; ?>
    <?php if(!empty($banned)): ?><div class="alert alert-error">Your account has been suspended.</div><?php endif; ?>
    <?php if(!empty($registered)): ?><div class="alert alert-success"><i class="fa-solid fa-circle-check"></i> Account created! Please login.</div><?php endif; ?>

    <form method="post" action="/login">
      <?php echo csrfField(); ?>

      <div class="form-group">
        <label class="form-label">Email Address</label>
        <div class="input-group">
          <i class="input-icon fa-solid fa-envelope"></i>
          <input type="email" name="email" class="form-control" placeholder="you@email.com" value="<?php echo e($remEmail); ?>" required autofocus>
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Password</label>
        <div class="input-group">
          <i class="input-icon fa-solid fa-lock"></i>
          <input type="password" name="password" class="form-control" placeholder="Enter password" required>
        </div>
      </div>
      <div class="form-group" style="display:flex;align-items:center;justify-content:space-between;">
        <label style="display:flex;align-items:center;gap:8px;font-size:14px;cursor:pointer;">
          <input type="checkbox" name="remember" <?php echo e($remEmail ? 'checked' : ''); ?>> Remember me
        </label>
      </div>
      <button type="submit" class="btn btn-primary btn-block">
        <i class="fa-solid fa-right-to-bracket"></i> Login
      </button>
    </form>
    <div class="auth-footer">
      Don't have an account? <a href="/register">Register Free</a>
    </div>
  </div>
</div>
<div id="toast-container"></div>
<script src="/assets/js/main.js"></script>
<?php echo getSetting('custom_footer_script',''); ?>

</body>
</html>
<?php /**PATH /home/icxbdfsb/public_html/resources/views/login.blade.php ENDPATH**/ ?>