<!DOCTYPE html>
<html lang="en">
<head>
<?php echo renderSeoMeta(); ?>

<?php echo renderGoogleFont(); ?>

<?php echo renderCssVars(); ?>

<link rel="stylesheet" href="/assets/css/style.css?v=3">
<link rel="stylesheet" href="/assets/css/dashboard.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="app-layout">
  <header class="app-header">
    <div class="app-header-left"><div class="user-name">Notifications <?php if($notifCount): ?><span class="notif-badge" style="position:static;margin-left:6px;"><?php echo e($notifCount); ?></span><?php endif; ?></div></div>
    <div class="app-header-right">
      <?php if($notifCount): ?>
        <form method="post" style="display:inline"><?php echo csrfField(); ?><button type="submit" name="mark_read" value="1" style="font-size:12px;color:var(--primary);font-weight:700;background:none;border:none;cursor:pointer;">Mark All Read</button></form>
      <?php endif; ?>
    </div>
  </header>
  <main class="main-content">
    <?php if(!$notifications->count()): ?>
      <div style="text-align:center;padding:60px 20px;color:#888;">
        <i class="fa-solid fa-bell-slash" style="font-size:48px;display:block;margin-bottom:16px;opacity:.3"></i>
        <p>No notifications yet</p>
      </div>
    <?php else: ?>
      <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
          $icon = $typeIcons[$n['type']] ?? ['fa-bell','#00C896'];
          $isRead = $n['is_read'];
        ?>
        <div class="notif-item <?php echo e(!$isRead ? 'unread' : ''); ?>">
          <div class="notif-icon" style="background:<?php echo e($icon[1]); ?>22;color:<?php echo e($icon[1]); ?>">
            <i class="fa-solid <?php echo e($icon[0]); ?>"></i>
          </div>
          <div class="notif-body">
            <div class="notif-title"><?php echo e($n['title']); ?></div>
            <div class="notif-msg"><?php echo e($n['message']); ?></div>
            <div class="notif-time"><?php echo e(timeAgo($n['created_at'])); ?></div>
          </div>
          <?php if(!$isRead): ?><div class="unread-dot"></div><?php endif; ?>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php echo paginationLinks($total, $page, $limit, '/notifications'); ?>

    <?php endif; ?>
  </main>
  <nav class="bottom-nav">
    <a href="/dashboard" class="nav-item"><i class="fa-solid fa-house"></i>Home</a>
    <a href="/tasks" class="nav-item"><i class="fa-solid fa-list-check"></i>Tasks</a>
    <a href="/wallet" class="nav-item"><i class="fa-solid fa-wallet"></i>Wallet</a>
    <a href="/leaderboard" class="nav-item"><i class="fa-solid fa-trophy"></i>Board</a>
    <a href="/profile" class="nav-item"><i class="fa-solid fa-user"></i>Profile</a>
  </nav>
</div>
<script src="/assets/js/main.js"></script>
</body>
</html>
<?php /**PATH /home/icxbdfsb/public_html/resources/views/notifications.blade.php ENDPATH**/ ?>