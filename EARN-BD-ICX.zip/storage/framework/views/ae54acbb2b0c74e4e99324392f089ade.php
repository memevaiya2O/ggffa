<?php echo $__env->make('admin.partials-header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php if($flash): ?><div class="alert alert-success" style="margin-bottom:20px;"><?php echo e($flash); ?></div><?php endif; ?>

<div class="admin-grid-2" style="display:grid;grid-template-columns:1fr 1.5fr;gap:24px;">

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title"><?php echo e($editPage ? 'Edit Page' : 'New Page'); ?></div></div>
  <div class="admin-card-body">
    <form method="post">
      <?php echo csrfField(); ?>

      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" value="<?php echo e($editPage ? $editPage['id'] : 0); ?>">
      <div class="form-group">
        <label>Title</label>
        <input type="text" name="title" id="pg-title" class="form-control" value="<?php echo e($editPage['title'] ?? ''); ?>" required oninput="autoSlug(this.value)">
      </div>
      <div class="form-group">
        <label>Slug (URL)</label>
        <div style="display:flex;align-items:center;gap:8px;">
          <span style="color:#888;">/page/</span>
          <input type="text" name="slug" id="pg-slug" class="form-control" value="<?php echo e($editPage['slug'] ?? ''); ?>" required>
        </div>
      </div>
      <div class="form-group">
        <label>Content (HTML allowed)</label>
        <textarea name="content" class="form-control" rows="12" style="font-family:monospace;"><?php echo e($editPage['content'] ?? ''); ?></textarea>
      </div>
      <div class="form-group">
        <label>Status</label>
        <select name="status" class="form-control">
          <option value="published" <?php echo e(($editPage['status']??'published')==='published'?'selected':''); ?>>Published</option>
          <option value="draft" <?php echo e(($editPage['status']??'')==='draft'?'selected':''); ?>>Draft</option>
        </select>
      </div>
      <button class="btn btn-primary">Save Page</button>
      <?php if($editPage): ?><a href="/Icxpanel/pages" class="btn btn-secondary">Cancel</a><?php endif; ?>
    </form>
  </div>
</div>

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">All Pages (<?php echo e(count($pages)); ?>)</div></div>
  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>Title</th><th>Slug</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
        <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><strong><?php echo e($p['title']); ?></strong></td>
          <td><a href="/page/<?php echo e($p['slug']); ?>" target="_blank" style="color:#667eea;">/page/<?php echo e($p['slug']); ?></a></td>
          <td>
            <form method="post" style="display:inline">
              <?php echo csrfField(); ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?php echo e($p['id']); ?>">
              <button class="btn btn-xs <?php echo e($p['status']==='published'?'btn-success':'btn-secondary'); ?>"><?php echo e($p['status']); ?></button>
            </form>
          </td>
          <td>
            <a href="?edit=<?php echo e($p['id']); ?>" class="btn btn-warning btn-xs">Edit</a>
            <form method="post" style="display:inline" onsubmit="return confirm('Delete this page?')">
              <?php echo csrfField(); ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?php echo e($p['id']); ?>">
              <button class="btn btn-danger btn-xs">Del</button>
            </form>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if(!$pages->count()): ?><tr><td colspan="4" style="text-align:center;color:#888;">No pages yet.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

</div>
<?php
$extraJs = '<script>
function autoSlug(val) {
  if (!document.getElementById("pg-slug").dataset.manual) {
    document.getElementById("pg-slug").value = val.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"");
  }
}
document.getElementById("pg-slug").addEventListener("input", function(){ this.dataset.manual = "1"; });
</script>';
?>
<?php echo $__env->make('admin.partials-footer', ['extraJs' => $extraJs], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH /home/icxbdfsb/public_html/resources/views/admin/pages.blade.php ENDPATH**/ ?>