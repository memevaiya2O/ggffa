<!DOCTYPE html>
<html lang="en">
<head>
<?php echo renderSeoMeta(); ?>

<?php echo renderGoogleFont(); ?>

<?php echo renderCssVars(); ?>

<link rel="stylesheet" href="/assets/css/style.css?v=3">
<link rel="stylesheet" href="/assets/css/dashboard.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="app-layout">
  <header class="app-header">
    <div class="app-header-left"><div class="user-name">My Profile</div></div>
    <div class="app-header-right">
      <a href="/notifications" class="notif-btn"><i class="fa-solid fa-bell"></i><?php if($notifCount): ?><span class="notif-badge"><?php echo e($notifCount); ?></span><?php endif; ?></a>
      <a href="/logout" style="color:var(--danger);font-size:22px;"><i class="fa-solid fa-right-from-bracket"></i></a>
    </div>
  </header>
  <main class="main-content">
    <?php if($error): ?><div class="alert alert-error"><?php echo e($error); ?></div><?php endif; ?>
    <?php if($success): ?><div class="alert alert-success"><?php echo e($success); ?></div><?php endif; ?>

    <div class="profile-header">
      <div class="profile-avatar-lg">
        <?php if($user['avatar']): ?><img src="<?php echo e($user['avatar']); ?>" alt=""><?php else: ?><?php echo e(strtoupper(substr($user['name'],0,1))); ?><?php endif; ?>
      </div>
      <div class="profile-name"><?php echo e($user['name']); ?></div>
      <div class="profile-level">
        <i class="fa-solid <?php echo e($user['level_icon']??'fa-medal'); ?>"></i> <?php echo e($user['level_name']??'Bronze'); ?> Level
      </div>
      <div style="font-size:12px;color:rgba(255,255,255,.6);margin-top:6px;">Joined <?php echo e(date('M Y', strtotime($user['created_at']))); ?></div>
    </div>

    <div class="profile-info-grid">
      <div class="profile-info-item"><div class="label">Balance</div><div class="value"><?php echo e(formatAmount((float)$user['balance'])); ?></div></div>
      <div class="profile-info-item"><div class="label">Total Earned</div><div class="value"><?php echo e(formatAmount((float)$user['total_earned'])); ?></div></div>
      <div class="profile-info-item"><div class="label">Tasks Done</div><div class="value"><?php echo e($tasksCompleted); ?></div></div>
      <div class="profile-info-item"><div class="label">Referrals</div><div class="value"><?php echo e($refCount); ?></div></div>
      <div class="profile-info-item"><div class="label">Withdrawals</div><div class="value"><?php echo e($withdrawCount); ?></div></div>
      <div class="profile-info-item"><div class="label">Streak</div><div class="value"><?php echo e($user['streak_days']); ?>🔥</div></div>
    </div>

    <!-- Quick Links -->
    <div style="display:flex;gap:10px;margin-bottom:20px;flex-wrap:wrap;">
      <a href="/referral" class="btn btn-outline btn-sm"><i class="fa-solid fa-user-plus"></i> Referral</a>
      <a href="/achievements" class="btn btn-outline btn-sm"><i class="fa-solid fa-trophy"></i> Badges</a>
      <a href="/spin" class="btn btn-outline btn-sm"><i class="fa-solid fa-circle-notch"></i> Spin</a>
    </div>

    <!-- Edit Profile -->
    <div class="card" style="margin-bottom:16px;">
      <h3 style="margin-bottom:16px;font-size:16px;"><i class="fa-solid fa-user-pen" style="color:var(--primary);margin-right:8px;"></i>Edit Profile</h3>
      <form method="post" enctype="multipart/form-data">
        <?php echo csrfField(); ?>

        <input type="hidden" name="action" value="update_profile">
        <div class="form-group">
          <label class="form-label">Full Name</label>
          <input type="text" name="name" class="form-control" value="<?php echo e($user['name']); ?>" required>
        </div>
        <div class="form-group">
          <label class="form-label">Email</label>
          <input type="email" class="form-control" value="<?php echo e($user['email']); ?>" readonly style="opacity:.6">
        </div>
        <div class="form-group">
          <label class="form-label">Profile Photo</label>
          <input type="file" name="avatar" class="form-control" accept="image/*">
        </div>
        <button type="submit" class="btn btn-primary btn-block">Save Changes</button>
      </form>
    </div>

    <!-- Change Password -->
    <div class="card" style="margin-bottom:20px;">
      <h3 style="margin-bottom:16px;font-size:16px;"><i class="fa-solid fa-lock" style="color:var(--warning);margin-right:8px;"></i>Change Password</h3>
      <form method="post">
        <?php echo csrfField(); ?>

        <input type="hidden" name="action" value="change_password">
        <div class="form-group">
          <label class="form-label">Current Password</label>
          <input type="password" name="current_password" class="form-control" placeholder="••••••••" required>
        </div>
        <div class="form-group">
          <label class="form-label">New Password</label>
          <input type="password" name="new_password" class="form-control" placeholder="Min 6 characters" required>
        </div>
        <div class="form-group">
          <label class="form-label">Confirm New Password</label>
          <input type="password" name="confirm_password" class="form-control" placeholder="Repeat new password" required>
        </div>
        <button type="submit" class="btn btn-outline btn-block">Update Password</button>
      </form>
    </div>

    <a href="/logout" class="btn btn-danger btn-block" style="margin-bottom:20px;">
      <i class="fa-solid fa-right-from-bracket"></i> Logout
    </a>
  </main>
  <nav class="bottom-nav">
    <a href="/dashboard" class="nav-item"><i class="fa-solid fa-house"></i>Home</a>
    <a href="/tasks" class="nav-item"><i class="fa-solid fa-list-check"></i>Tasks</a>
    <a href="/wallet" class="nav-item"><i class="fa-solid fa-wallet"></i>Wallet</a>
    <a href="/leaderboard" class="nav-item"><i class="fa-solid fa-trophy"></i>Board</a>
    <a href="/profile" class="nav-item active"><i class="fa-solid fa-user"></i>Profile</a>
  </nav>
</div>
<div id="toast-container"></div>
<script src="/assets/js/main.js"></script>
</body>
</html>
<?php /**PATH /home/icxbdfsb/public_html/resources/views/profile.blade.php ENDPATH**/ ?>