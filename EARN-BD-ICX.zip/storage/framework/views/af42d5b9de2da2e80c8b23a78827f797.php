<?php echo $__env->make('admin.partials-header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php if($flash): ?><div class="alert alert-success" style="margin-bottom:20px;"><?php echo e($flash); ?></div><?php endif; ?>

<div class="admin-grid-2" style="gap:24px;display:grid;grid-template-columns:1fr 1.5fr;">

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">Add / Edit Payment Account</div></div>
  <div class="admin-card-body">
    <form method="post" action="/Icxpanel/deposit-methods" id="dm-form">
      <?php echo csrfField(); ?>

      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" id="dm-id" value="0">
      <div class="form-group"><label>Method Name</label><input type="text" name="name" id="dm-name" class="form-control" placeholder="e.g. bKash" required></div>
      <div class="form-group"><label>Account / Number (users send money here)</label><input type="text" name="account_number" id="dm-account" class="form-control" placeholder="01XXXXXXXXX" required></div>
      <div class="form-group"><label>Account Type</label><input type="text" name="account_type" id="dm-type" class="form-control" value="Personal" placeholder="Personal / Agent / Merchant"></div>
      <div class="form-group"><label>Icon (Font Awesome class)</label><input type="text" name="icon" id="dm-icon" class="form-control" value="fa-wallet" placeholder="fa-wallet"></div>
      <div class="form-group"><label>Min Amount for this method (0 = use activation minimum)</label><input type="number" name="min_amount" id="dm-min" class="form-control" value="0" step="0.01" min="0"></div>
      <div class="form-group"><label>Instructions (shown to user)</label><textarea name="instructions" id="dm-note" class="form-control" rows="3" placeholder="e.g. Use Send Money, not Cash Out."></textarea></div>
      <div class="form-group"><label>Status</label>
        <select name="status" id="dm-status" class="form-control"><option value="active">Active</option><option value="inactive">Inactive</option></select>
      </div>
      <button class="btn btn-primary" type="submit">Save</button>
      <button class="btn btn-secondary" type="button" onclick="resetDm()">Clear</button>
    </form>
  </div>
</div>

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">Payment Accounts</div><a href="/Icxpanel/deposits" class="btn btn-sm btn-outline">Deposits</a></div>
  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>Name</th><th>Account</th><th>Type</th><th>Min</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
        <?php $__currentLoopData = $methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><strong><?php echo e($m->name); ?></strong></td>
          <td style="font-family:monospace"><?php echo e($m->account_number); ?></td>
          <td><?php echo e($m->account_type); ?></td>
          <td><?php echo e($m->min_amount); ?></td>
          <td>
            <form method="post" action="/Icxpanel/deposit-methods" style="display:inline">
              <?php echo csrfField(); ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?php echo e($m->id); ?>">
              <button class="btn btn-xs <?php echo e($m->status==='active'?'btn-success':'btn-secondary'); ?>"><?php echo e($m->status==='active'?'Active':'Inactive'); ?></button>
            </form>
          </td>
          <td>
            <button class="btn btn-warning btn-xs" onclick="editDm(<?php echo htmlspecialchars(json_encode($m)); ?>)">Edit</button>
            <form method="post" action="/Icxpanel/deposit-methods" style="display:inline" onsubmit="return confirm('Delete this account?')">
              <?php echo csrfField(); ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?php echo e($m->id); ?>">
              <button class="btn btn-danger btn-xs">Del</button>
            </form>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if(!$methods->count()): ?><tr><td colspan="6" style="text-align:center;color:#888;">No payment accounts yet. Add one so users can add money.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

</div>
<?php
$extraJs = '<script>
function editDm(m) {
  document.getElementById("dm-id").value = m.id;
  document.getElementById("dm-name").value = m.name;
  document.getElementById("dm-account").value = m.account_number || "";
  document.getElementById("dm-type").value = m.account_type || "Personal";
  document.getElementById("dm-icon").value = m.icon || "fa-wallet";
  document.getElementById("dm-min").value = m.min_amount;
  document.getElementById("dm-note").value = m.instructions || "";
  document.getElementById("dm-status").value = m.status;
  document.getElementById("dm-form").scrollIntoView({behavior:"smooth"});
}
function resetDm() {
  document.getElementById("dm-id").value = "0";
  document.getElementById("dm-form").reset();
}
</script>';
?>
<?php echo $__env->make('admin.partials-footer', ['extraJs' => $extraJs], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH /home/icxbdfsb/public_html/resources/views/admin/deposit-methods.blade.php ENDPATH**/ ?>