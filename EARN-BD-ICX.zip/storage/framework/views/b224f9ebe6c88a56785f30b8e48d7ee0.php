    </div><!-- /admin-content -->
  </div><!-- /admin-main -->
</div><!-- /admin-layout -->
<div id="toast-container"></div>
<script src="/assets/js/admin.js"></script>
<?php if(!empty($extraJs)): ?> <?php echo $extraJs; ?> <?php endif; ?>
</body>
</html>
<?php /**PATH /home/icxbdfsb/public_html/resources/views/admin/partials-footer.blade.php ENDPATH**/ ?>