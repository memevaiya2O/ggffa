<?php echo $__env->make('admin.partials-header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php if($flash): ?><div class="alert alert-success" style="margin-bottom:20px;"><?php echo e($flash); ?></div><?php endif; ?>
<div class="admin-card">
  <div class="admin-card-header">
    <div class="admin-card-title">Tasks (<?php echo e($total); ?>)</div>
    <a href="/Icxpanel/task-add" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Add Task</a>
  </div>
  <form method="get" class="admin-filters">
    <select name="cat" class="filter-select" onchange="this.form.submit()"><option value="">All Categories</option><?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($c['id']); ?>" <?php echo e($cat==$c['id']?'selected':''); ?>><?php echo e($c['name']); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
    <select name="status" class="filter-select" onchange="this.form.submit()"><option value="all">All Status</option><option value="active" <?php echo e($status==='active'?'selected':''); ?>>Active</option><option value="inactive" <?php echo e($status==='inactive'?'selected':''); ?>>Inactive</option></select>
  </form>
  <div class="admin-table-wrap">
    <table class="admin-table" id="tasks-table">
      <thead><tr><th>☰</th><th>Task</th><th>Category</th><th>Reward</th><th>Stats</th><th>Flags</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody id="sortable-tasks">
        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr data-id="<?php echo e($t['id']); ?>">
            <td><span class="drag-handle"><i class="fa-solid fa-grip-lines"></i></span></td>
            <td>
              <div style="display:flex;align-items:center;gap:10px;">
                <?php if($t['thumbnail']): ?><img src="<?php echo e($t['thumbnail']); ?>" style="width:40px;height:40px;border-radius:8px;object-fit:cover;"><?php endif; ?>
                <div><div style="font-weight:700;font-size:14px;"><?php echo e($t['title']); ?></div><div style="font-size:11px;color:#888"><?php echo e(ucfirst($t['type'])); ?></div></div>
              </div>
            </td>
            <td><?php echo e($t['cat_name']??'—'); ?></td>
            <td style="font-weight:700;color:var(--primary)"><?php echo e(formatAmount((float)$t['reward'])); ?></td>
            <td style="font-size:12px"><span style="color:var(--primary)"><?php echo e($t['approved_count']); ?> done</span> · <span style="color:var(--warning)"><?php echo e($t['pending_count']); ?> pending</span></td>
            <td>
              <?php $flags = []; if ($t['is_featured']) $flags[]='<span class="badge badge-info">Featured</span>'; if ($t['is_hot']) $flags[]='<span class="badge badge-hot">🔥</span>'; if ($t['is_new']) $flags[]='<span class="badge badge-new">✨</span>'; if ($t['is_vip']) $flags[]='<span class="badge badge-vip">👑</span>'; ?>
              <?php echo implode(' ',$flags); ?>

            </td>
            <td>
              <form method="post" style="display:inline"><?php echo csrfField(); ?><input type="hidden" name="action" value="toggle_status"><input type="hidden" name="task_id" value="<?php echo e($t['id']); ?>"><button type="submit" class="status-badge status-<?php echo e($t['status'] === 'active'?'active':'rejected'); ?>" style="cursor:pointer;border:none;"><?php echo e($t['status'] === 'active' ? 'Active' : 'Inactive'); ?></button></form>
            </td>
            <td>
              <div class="action-btns">
                <a href="/Icxpanel/task-edit?id=<?php echo e($t['id']); ?>" class="action-btn-sm action-btn-edit"><i class="fa-solid fa-pen"></i></a>
                <form method="post" style="display:inline"><?php echo csrfField(); ?><input type="hidden" name="action" value="delete"><input type="hidden" name="task_id" value="<?php echo e($t['id']); ?>"><button type="submit" class="action-btn-sm action-btn-delete" data-confirm="Delete this task and all submissions?"><i class="fa-solid fa-trash"></i></button></form>
              </div>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
  <?php echo paginationLinks($total,$page,$limit,'/Icxpanel/tasks?cat='.$cat.'&status='.$status); ?>

</div>
<?php $extraJs='<script>initSortable("sortable-tasks","/Icxpanel/tasks");</script>'; ?>
<?php echo $__env->make('admin.partials-footer', ['extraJs' => $extraJs], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH /home/icxbdfsb/public_html/resources/views/admin/tasks.blade.php ENDPATH**/ ?>