<?php echo $__env->make('admin.partials-header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php if($flash): ?><div class="alert alert-success" style="margin-bottom:20px;"><?php echo e($flash); ?></div><?php endif; ?>
<div class="admin-card">
  <div class="admin-card-header">
    <div class="admin-card-title">Levels</div>
    <form method="post" style="display:inline"><?php echo csrfField(); ?><input type="hidden" name="action" value="add"><button type="submit" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Add Level</button></form>
  </div>
  <form method="post">
    <?php echo csrfField(); ?>

    <input type="hidden" name="action" value="save_all">
    <div class="admin-table-wrap">
      <table class="admin-table">
        <thead><tr><th>Name</th><th>Icon</th><th>Color</th><th>Required Points</th><th>Levelup Bonus</th><th>Daily Withdraw Limit</th><th>VIP Access</th><th></th></tr></thead>
        <tbody>
          <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $lv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><input type="hidden" name="level_id[]" value="<?php echo e($lv['id']); ?>"><input type="text" name="name[<?php echo e($i); ?>]" class="admin-input" value="<?php echo e($lv['name']); ?>" style="width:130px;"></td>
              <td><input type="text" name="icon[<?php echo e($i); ?>]" class="admin-input" value="<?php echo e($lv['icon']); ?>" style="width:110px;"></td>
              <td><div class="color-picker-wrap"><input type="color" name="color[<?php echo e($i); ?>]" value="<?php echo e($lv['color']); ?>"></div></td>
              <td><input type="number" name="required_points[<?php echo e($i); ?>]" class="admin-input" value="<?php echo e($lv['required_points']); ?>" style="width:110px;"></td>
              <td><input type="number" name="levelup_bonus[<?php echo e($i); ?>]" class="admin-input" step="0.01" value="<?php echo e($lv['levelup_bonus']); ?>" style="width:100px;"></td>
              <td><input type="number" name="daily_withdraw_limit[<?php echo e($i); ?>]" class="admin-input" step="0.01" value="<?php echo e($lv['daily_withdraw_limit']); ?>" style="width:110px;"></td>
              <td><label class="toggle-label"><span class="toggle-switch"><input type="checkbox" name="can_access_vip[<?php echo e($i); ?>]" value="1" <?php echo e($lv['can_access_vip']?'checked':''); ?>><span class="toggle-slider"></span></span></label></td>
              <td>
                <button type="submit" form="del-<?php echo e($lv['id']); ?>" class="action-btn-sm action-btn-delete" data-confirm="Delete this level?"><i class="fa-solid fa-trash"></i></button>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <div style="padding:16px;">
      <button type="submit" class="btn btn-primary"><i class="fa-solid fa-save"></i> Save All</button>
    </div>
  </form>
  <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <form method="post" id="del-<?php echo e($lv['id']); ?>" style="display:none"><?php echo csrfField(); ?><input type="hidden" name="action" value="delete"><input type="hidden" name="level_id_del" value="<?php echo e($lv['id']); ?>"></form>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php echo $__env->make('admin.partials-footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH /home/icxbdfsb/public_html/resources/views/admin/levels.blade.php ENDPATH**/ ?>