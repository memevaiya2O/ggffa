<?php echo $__env->make('admin.partials-header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php if($flash): ?><div class="alert alert-success" style="margin-bottom:20px;"><?php echo e($flash); ?></div><?php endif; ?>

<div class="admin-grid-2" style="gap:24px;display:grid;grid-template-columns:1fr 1.5fr;">

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">Add / Edit Method</div></div>
  <div class="admin-card-body">
    <form method="post" id="mth-form">
      <?php echo csrfField(); ?>

      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" id="mth-id" value="0">
      <div class="form-group">
        <label>Method Name</label>
        <input type="text" name="name" id="mth-name" class="form-control" placeholder="e.g. bKash" required>
      </div>
      <div class="form-group">
        <label>Min Amount (BDT)</label>
        <input type="number" name="min_amount" id="mth-min" class="form-control" value="200" step="0.01" min="0">
      </div>
      <div class="form-group">
        <label>Max Amount (BDT)</label>
        <input type="number" name="max_amount" id="mth-max" class="form-control" value="10000" step="0.01" min="0">
      </div>
      <div class="form-group">
        <label>Charge % (0 = no charge)</label>
        <input type="number" name="charge_pct" id="mth-charge" class="form-control" value="0" step="0.01" min="0" max="100">
      </div>
      <div class="form-group">
        <label>Required Fields (comma-separated)</label>
        <input type="text" name="required_fields" id="mth-fields" class="form-control" placeholder="Account Number,Account Name">
      </div>
      <div class="form-group">
        <label>Instructions</label>
        <textarea name="instructions" id="mth-instruc" class="form-control" rows="3" placeholder="e.g. Send to our bKash number..."></textarea>
      </div>
      <div class="form-group">
        <label>Status</label>
        <select name="status" id="mth-status" class="form-control">
          <option value="active">Active</option>
          <option value="inactive">Inactive</option>
        </select>
      </div>
      <button class="btn btn-primary" type="submit">Save Method</button>
      <button class="btn btn-secondary" type="button" onclick="resetMth()">Clear</button>
    </form>
  </div>
</div>

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">All Methods</div></div>
  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>Name</th><th>Min</th><th>Max</th><th>Charge%</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
        <?php $__currentLoopData = $methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><strong><?php echo e($m['name']); ?></strong></td>
          <td><?php echo e($m['min_amount']); ?></td>
          <td><?php echo e($m['max_amount']); ?></td>
          <td><?php echo e($m['charge_pct']); ?>%</td>
          <td>
            <form method="post" style="display:inline">
              <?php echo csrfField(); ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?php echo e($m['id']); ?>">
              <button class="btn btn-xs <?php echo e($m['status']==='active'?'btn-success':'btn-secondary'); ?>"><?php echo e($m['status']==='active'?'Active':'Inactive'); ?></button>
            </form>
          </td>
          <td>
            <button class="btn btn-warning btn-xs" onclick="editMth(<?php echo htmlspecialchars(json_encode($m)); ?>)">Edit</button>
            <form method="post" style="display:inline" onsubmit="return confirm('Delete this method?')">
              <?php echo csrfField(); ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?php echo e($m['id']); ?>">
              <button class="btn btn-danger btn-xs">Del</button>
            </form>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if(!$methods->count()): ?><tr><td colspan="6" style="text-align:center;color:#888;">No methods yet.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

</div>
<?php
$extraJs = '<script>
function editMth(m) {
  document.getElementById("mth-id").value = m.id;
  document.getElementById("mth-name").value = m.name;
  document.getElementById("mth-min").value = m.min_amount;
  document.getElementById("mth-max").value = m.max_amount;
  document.getElementById("mth-charge").value = m.charge_pct;
  document.getElementById("mth-fields").value = m.required_fields || "";
  document.getElementById("mth-instruc").value = m.instructions || "";
  document.getElementById("mth-status").value = m.status;
  document.getElementById("mth-form").scrollIntoView({behavior:"smooth"});
}
function resetMth() {
  document.getElementById("mth-id").value = "0";
  document.getElementById("mth-form").reset();
}
</script>';
?>
<?php echo $__env->make('admin.partials-footer', ['extraJs' => $extraJs], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH /home/icxbdfsb/public_html/resources/views/admin/withdraw-methods.blade.php ENDPATH**/ ?>