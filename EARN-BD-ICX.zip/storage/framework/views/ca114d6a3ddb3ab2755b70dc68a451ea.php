<?php echo $__env->make('admin.partials-header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<!-- KPI Row 1 -->
<div class="kpi-grid">
  <div class="kpi-card"><div class="kpi-icon green"><i class="fa-solid fa-users"></i></div><div class="kpi-body"><div class="kpi-label">Total Users</div><div class="kpi-value"><?php echo e(number_format($totalUsers)); ?></div><div class="kpi-sub">Today: +<?php echo e($todayUsers); ?></div></div></div>
  <div class="kpi-card"><div class="kpi-icon blue"><i class="fa-solid fa-user-clock"></i></div><div class="kpi-body"><div class="kpi-label">Active (7d)</div><div class="kpi-value"><?php echo e(number_format($activeUsers)); ?></div></div></div>
  <div class="kpi-card"><div class="kpi-icon red"><i class="fa-solid fa-user-slash"></i></div><div class="kpi-body"><div class="kpi-label">Banned</div><div class="kpi-value"><?php echo e(number_format($bannedUsers)); ?></div></div></div>
  <div class="kpi-card"><div class="kpi-icon orange"><i class="fa-solid fa-inbox"></i></div><div class="kpi-body"><div class="kpi-label">Pending Subs</div><div class="kpi-value"><?php echo e(number_format($pendingSubs)); ?></div><div class="kpi-sub">Today: <?php echo e($todayApproved); ?> approved</div></div></div>
  <div class="kpi-card"><div class="kpi-icon green"><i class="fa-solid fa-list-check"></i></div><div class="kpi-body"><div class="kpi-label">Total Tasks</div><div class="kpi-value"><?php echo e(number_format($totalTasks)); ?></div><div class="kpi-sub"><?php echo e($totalCats); ?> categories</div></div></div>
  <div class="kpi-card"><div class="kpi-icon orange"><i class="fa-solid fa-clock"></i></div><div class="kpi-body"><div class="kpi-label">Pending Withdrawals</div><div class="kpi-value"><?php echo e(number_format($pendingWith)); ?></div><div class="kpi-sub">Today: <?php echo e($todayPaid); ?> paid</div></div></div>
  <div class="kpi-card"><div class="kpi-icon green"><i class="fa-solid fa-sack-dollar"></i></div><div class="kpi-body"><div class="kpi-label">Total Payout</div><div class="kpi-value"><?php echo e(getSetting('currency_symbol','৳')); ?><?php echo e(number_format($totalPayout,0)); ?></div></div></div>
  <div class="kpi-card"><div class="kpi-icon purple"><i class="fa-solid fa-piggy-bank"></i></div><div class="kpi-body"><div class="kpi-label">Balance in System</div><div class="kpi-value"><?php echo e(getSetting('currency_symbol','৳')); ?><?php echo e(number_format($totalBalance,0)); ?></div></div></div>
</div>

<!-- Charts -->
<div class="charts-grid">
  <div class="chart-card"><h3>New Users (12 Months)</h3><div style="height:220px"><canvas id="usersChart"></canvas></div></div>
  <div class="chart-card"><h3>Total Payout (12 Months)</h3><div style="height:220px"><canvas id="payoutChart"></canvas></div></div>
</div>

<!-- Recent Records -->
<div style="display:grid;grid-template-columns:1fr 1fr;gap:24px;margin-bottom:24px;">
  <!-- Top Earners -->
  <div class="admin-card">
    <div class="admin-card-header"><div class="admin-card-title">Top Earners This Month</div></div>
    <div class="admin-table-wrap">
      <table class="admin-table">
        <thead><tr><th>#</th><th>User</th><th>Earned</th></tr></thead>
        <tbody>
          <?php $__currentLoopData = $topMonth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr><td><?php echo e($i+1); ?></td><td><?php echo e($u['name']); ?></td><td style="color:var(--primary);font-weight:700"><?php echo e(getSetting('currency_symbol','৳')); ?><?php echo e(number_format($u['earned'],2)); ?></td></tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
  <!-- Recent Registrations -->
  <div class="admin-card">
    <div class="admin-card-header"><div class="admin-card-title">Recent Registrations</div><a href="/Icxpanel/users" class="btn btn-sm btn-outline">View All</a></div>
    <div class="admin-table-wrap">
      <table class="admin-table">
        <thead><tr><th>User</th><th>Level</th><th>Joined</th></tr></thead>
        <tbody>
          <?php $__currentLoopData = $recentUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><div class="user-cell"><div class="table-avatar"><?php echo e(strtoupper(substr($u['name'],0,1))); ?></div><div class="user-cell-info"><div class="user-cell-name"><?php echo e($u['name']); ?></div><div class="user-cell-email"><?php echo e($u['email']); ?></div></div></div></td>
              <td><span class="badge badge-info" style="background:<?php echo e($u['level_color']??'#CD7F32'); ?>22;color:<?php echo e($u['level_color']??'#CD7F32'); ?>"><?php echo e($u['level_name']??'Bronze'); ?></span></td>
              <td style="font-size:12px;color:#888"><?php echo e(date('M j',strtotime($u['created_at']))); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Recent Submissions + Withdrawals -->
<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">Recent Submissions</div><a href="/Icxpanel/submissions" class="btn btn-sm btn-outline">View All</a></div>
  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>User</th><th>Task</th><th>Status</th><th>Time</th></tr></thead>
      <tbody>
        <?php $__currentLoopData = $recentSubs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($s['user_name']); ?></td>
            <td><?php echo e($s['task_title']); ?></td>
            <td><span class="status-badge status-<?php echo e($s['status']); ?>"><?php echo e(ucfirst($s['status'])); ?></span></td>
            <td style="font-size:12px;color:#888"><?php echo e(timeAgo($s['created_at'])); ?></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">Recent Withdrawals</div><a href="/Icxpanel/withdrawals" class="btn btn-sm btn-outline">View All</a></div>
  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>User</th><th>Method</th><th>Amount</th><th>Status</th><th>Date</th></tr></thead>
      <tbody>
        <?php $__currentLoopData = $recentWith; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($w['user_name']); ?></td>
            <td><?php echo e($w['method_name']); ?></td>
            <td style="font-weight:700"><?php echo e(getSetting('currency_symbol','৳')); ?><?php echo e(number_format($w['amount'],2)); ?></td>
            <td><span class="status-badge status-<?php echo e($w['status']); ?>"><?php echo e(ucfirst($w['status'])); ?></span></td>
            <td style="font-size:12px;color:#888"><?php echo e(timeAgo($w['created_at'])); ?></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>

<?php
$extraJs = '<script>
createLineChart("usersChart",' . json_encode(array_column($monthlyUsers->all(),'month')) . ',' . json_encode(array_map(fn($r)=>(int)$r["cnt"],$monthlyUsers->all())) . ',"New Users");
createBarChart("payoutChart",' . json_encode(array_column($monthlyPayout->all(),'month')) . ',' . json_encode(array_map(fn($r)=>(float)$r["total"],$monthlyPayout->all())) . ',"Payout");
</script>';
?>
<?php echo $__env->make('admin.partials-footer', ['extraJs' => $extraJs], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH /home/icxbdfsb/public_html/resources/views/admin/index.blade.php ENDPATH**/ ?>