<!DOCTYPE html>
<html lang="en">
<head>
<?php echo renderSeoMeta(); ?>

<?php echo renderGoogleFont(); ?>

<?php echo renderCssVars(); ?>

<link rel="stylesheet" href="/assets/css/style.css?v=3">
<link rel="stylesheet" href="/assets/css/dashboard.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4/dist/chart.umd.min.js"></script>
</head>
<body>
<div class="app-layout">
  <header class="app-header">
    <div class="app-header-left"><div class="user-name">Wallet</div></div>
    <div class="app-header-right">
      <a href="/notifications" class="notif-btn"><i class="fa-solid fa-bell"></i><?php if($notifCount): ?><span class="notif-badge"><?php echo e($notifCount); ?></span><?php endif; ?></a>
    </div>
  </header>
  <main class="main-content">
    <!-- Summary -->
    <div class="wallet-summary">
      <div class="wallet-card"><div class="w-icon"><i class="fa-solid fa-coins"></i></div><div class="w-amount"><?php echo e(formatAmount((float)$user['balance'])); ?></div><div class="w-label">Available</div></div>
      <div class="wallet-card"><div class="w-icon"><i class="fa-solid fa-arrow-trend-up"></i></div><div class="w-amount"><?php echo e(formatAmount((float)$user['total_earned'])); ?></div><div class="w-label">Total Earned</div></div>
      <div class="wallet-card"><div class="w-icon"><i class="fa-solid fa-money-bill-transfer"></i></div><div class="w-amount"><?php echo e(formatAmount((float)$user['total_withdrawn'])); ?></div><div class="w-label">Withdrawn</div></div>
      <div class="wallet-card pending"><div class="w-icon"><i class="fa-solid fa-clock"></i></div><div class="w-amount"><?php echo e(formatAmount($pendingAmt)); ?></div><div class="w-label">Pending</div></div>
    </div>

    <div style="display:flex;gap:10px;margin-bottom:20px;">
      <a href="/add-money" class="btn btn-primary" style="flex:1;text-align:center;"><i class="fa-solid fa-circle-plus"></i> Add Money</a>
      <a href="/withdraw" class="btn btn-outline" style="flex:1;text-align:center;"><i class="fa-solid fa-money-bill-transfer"></i> Withdraw</a>
    </div>
    <?php if(walletActivationRequired() && empty($user['wallet_active'])): ?>
      <div style="background:rgba(255,165,2,.1);color:#b26a00;border:1px solid rgba(255,165,2,.3);border-radius:10px;padding:12px 14px;margin-bottom:20px;font-size:13px;font-weight:600;">
        <i class="fa-solid fa-lock"></i> Wallet inactive — add at least <?php echo e(formatAmount(walletActivationMin())); ?> to unlock withdrawals.
      </div>
    <?php endif; ?>

    <!-- Chart -->
    <?php if($chartData->count()): ?>
    <div class="chart-container" style="margin-bottom:20px;">
      <canvas id="income-chart"></canvas>
    </div>
    <?php endif; ?>

    <!-- Filter Tabs -->
    <div class="filter-tabs">
      <?php
      $types = ['all' => 'All', 'task_reward' => 'Tasks', 'referral_bonus' => 'Referral', 'daily_bonus' => 'Daily', 'spin_reward' => 'Spin', 'deposit' => 'Deposit', 'withdrawal' => 'Withdraw'];
      ?>
      <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="filter-tab <?php echo e($type === $k ? 'active' : ''); ?>" data-type="<?php echo e($k); ?>"><?php echo e($v); ?></div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- Transactions -->
    <?php if(!$transactions->count()): ?>
      <div style="text-align:center;padding:48px 20px;color:#888;"><i class="fa-solid fa-inbox" style="font-size:48px;display:block;margin-bottom:16px;opacity:.3"></i><p>No transactions found</p></div>
    <?php else: ?>
      <div class="activity-list">
        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php $pos = $tx['amount'] > 0; ?>
          <div class="activity-item">
            <div class="activity-icon <?php echo e($pos ? 'credit' : 'debit'); ?>">
              <i class="fa-solid <?php echo e(getTransactionIcon($tx['type'])); ?>"></i>
            </div>
            <div class="activity-info">
              <div class="activity-desc"><?php echo e($tx['description']); ?></div>
              <div class="activity-time"><?php echo e(date('M j, Y g:ia', strtotime($tx['created_at']))); ?></div>
            </div>
            <div class="activity-amount <?php echo e($pos ? 'pos' : 'neg'); ?>"><?php echo e($pos ? '+' : ''); ?><?php echo e(formatAmount(abs($tx['amount']))); ?></div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <?php echo paginationLinks($total, $page, $limit, '/wallet?type=' . urlencode($type)); ?>

    <?php endif; ?>
  </main>
  <nav class="bottom-nav">
    <a href="/dashboard" class="nav-item"><i class="fa-solid fa-house"></i>Home</a>
    <a href="/tasks" class="nav-item"><i class="fa-solid fa-list-check"></i>Tasks</a>
    <a href="/wallet" class="nav-item active"><i class="fa-solid fa-wallet"></i>Wallet</a>
    <a href="/leaderboard" class="nav-item"><i class="fa-solid fa-trophy"></i>Board</a>
    <a href="/profile" class="nav-item"><i class="fa-solid fa-user"></i>Profile</a>
  </nav>
</div>
<div id="toast-container"></div>
<script src="/assets/js/main.js"></script>
<?php if($chartData->count()): ?>
<script>
const ctx = document.getElementById('income-chart').getContext('2d');
const data = <?php echo json_encode(array_values(array_map(fn($r) => (float)$r['total'], $chartData->all()))); ?>;
const labels = <?php echo json_encode(array_values(array_map(fn($r) => ucwords(str_replace('_',' ',$r['type'])), $chartData->all()))); ?>;
const colors = ['#00C896','#FFA502','#FF4757','#9C27B0','#00B4D8','#FFD700'];
new Chart(ctx, { type:'doughnut', data:{ labels, datasets:[{ data, backgroundColor:colors.slice(0,data.length), borderWidth:0 }] }, options:{ responsive:true, maintainAspectRatio:false, cutout:'60%', plugins:{ legend:{ position:'bottom', labels:{ font:{ size:12 } } } } } });
</script>
<?php endif; ?>
</body>
</html>
<?php /**PATH /home/icxbdfsb/public_html/resources/views/wallet.blade.php ENDPATH**/ ?>