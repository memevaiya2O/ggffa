<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin Login — <?php echo e(getSetting('site_name','EarnBD')); ?></title>
<?php echo renderFavicon(); ?>

<?php echo renderGoogleFont(); ?>

<?php echo renderCssVars(); ?>

<link rel="stylesheet" href="/assets/css/style.css?v=3">
<link rel="stylesheet" href="/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="admin-login-page">
  <div class="admin-login-card">
    <div style="text-align:center;margin-bottom:28px;">
      <div style="font-size:28px;font-weight:900;background:linear-gradient(135deg,var(--primary),var(--secondary));-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;"><?php echo e(getSetting('site_name','EarnBD')); ?></div>
      <div style="font-size:12px;color:#888;text-transform:uppercase;letter-spacing:1px;margin-top:4px;">Admin Panel</div>
    </div>
    <?php if($error): ?><div class="alert alert-error"><?php echo e($error); ?></div><?php endif; ?>
    <form method="post" action="/Icxpanel/login">
      <?php echo csrfField(); ?>

      <div class="form-group">
        <label class="form-label">Username</label>
        <div class="input-group"><i class="input-icon fa-solid fa-user"></i>
          <input type="text" name="username" class="form-control" placeholder="admin" required autofocus value="<?php echo e(request()->input('username','')); ?>">
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Password</label>
        <div class="input-group"><i class="input-icon fa-solid fa-lock"></i>
          <input type="password" name="password" class="form-control" placeholder="••••••••" required>
        </div>
      </div>
      <button type="submit" class="btn btn-primary btn-block"><i class="fa-solid fa-right-to-bracket"></i> Login</button>
    </form>
    <div style="text-align:center;margin-top:16px;"><a href="/" style="color:#aaa;font-size:13px;">← Back to site</a></div>
  </div>
</div>
</body>
</html>
<?php /**PATH /home/icxbdfsb/public_html/resources/views/admin/login.blade.php ENDPATH**/ ?>