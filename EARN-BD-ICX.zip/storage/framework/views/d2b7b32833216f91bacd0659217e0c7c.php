<!DOCTYPE html>
<html lang="en">
<head>
<?php echo renderSeoMeta(); ?>

<?php echo renderGoogleFont(); ?>

<?php echo renderCssVars(); ?>

<link rel="stylesheet" href="/assets/css/style.css?v=3">
<link rel="stylesheet" href="/assets/css/dashboard.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="app-layout">
  <header class="app-header">
    <div class="app-header-left"><div class="user-name">Withdraw</div></div>
    <div class="app-header-right">
      <a href="/notifications" class="notif-btn"><i class="fa-solid fa-bell"></i><?php if($notifCount): ?><span class="notif-badge"><?php echo e($notifCount); ?></span><?php endif; ?></a>
    </div>
  </header>
  <main class="main-content">
    <?php if($error): ?><div class="alert alert-error"><?php echo e($error); ?></div><?php endif; ?>
    <?php if($success): ?><div class="alert alert-success"><?php echo e($success); ?></div><?php endif; ?>

    <!-- Balance -->
    <div class="balance-card" style="margin-bottom:20px;">
      <div class="balance-deco"><i class="fa-solid fa-money-bill"></i></div>
      <div class="balance-label">Available Balance</div>
      <div class="balance-amount"><?php echo e(formatAmount((float)$user['balance'])); ?></div>
      <div style="position:relative;z-index:1;font-size:13px;color:rgba(255,255,255,.7);margin-top:8px;">Daily Limit: <?php echo e(formatAmount((float)$user['daily_withdraw_limit'])); ?></div>
    </div>

    <?php if($walletLocked): ?>
    <div style="background:var(--card-bg);border-radius:var(--radius);padding:24px 20px;text-align:center;margin-bottom:20px;border:1px solid rgba(255,165,2,.35);">
      <i class="fa-solid fa-lock" style="font-size:34px;color:#FFA502;margin-bottom:10px;"></i>
      <h3 style="font-size:17px;font-weight:800;margin-bottom:8px;">Activate your wallet first</h3>
      <p style="font-size:14px;color:#777;line-height:1.6;margin-bottom:16px;">
        To make your first withdrawal, add at least <strong><?php echo e(formatAmount($activationMin)); ?></strong> to your wallet.
        You only need to do this once.
      </p>
      <a href="/add-money" class="btn btn-primary btn-lg"><i class="fa-solid fa-circle-plus"></i> Add Money</a>
    </div>
    <?php else: ?>
    <h3 style="margin-bottom:14px;font-size:16px;font-weight:800;">Select Payment Method</h3>
    <div class="method-list">
      <?php $__currentLoopData = $methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="method-card" data-id="<?php echo e($m['id']); ?>" data-min="<?php echo e($m['min_amount']); ?>">
          <i class="fa-solid <?php echo e($m['icon']); ?>"></i>
          <h4><?php echo e($m['name']); ?></h4>
          <p>Min: <?php echo e(formatAmount((float)$m['min_amount'])); ?></p>
          <p style="font-size:11px;color:#aaa;"><?php echo e($m['processing_time']); ?></p>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <form method="post" action="/withdraw" id="withdraw-form">
      <?php echo csrfField(); ?>

      <input type="hidden" name="method_id" id="method_id">
      <div class="form-group">
        <label class="form-label">Amount</label>
        <div class="input-group">
          <i class="input-icon fa-solid fa-coins"></i>
          <input type="number" name="amount" class="form-control" placeholder="Enter amount" step="0.01" min="1" max="<?php echo e($user['balance']); ?>">
        </div>
        <p style="font-size:12px;color:#888;margin-top:6px;">Minimum: <strong id="min-amount-label">—</strong></p>
      </div>
      <div class="form-group">
        <label class="form-label">Account / Wallet Address</label>
        <div class="input-group">
          <i class="input-icon fa-solid fa-address-card"></i>
          <input type="text" name="address" class="form-control" placeholder="Enter your number or wallet address">
        </div>
      </div>
      <button type="submit" class="btn btn-primary btn-block btn-lg">
        <i class="fa-solid fa-paper-plane"></i> Submit Withdrawal
      </button>
    </form>
    <?php endif; ?>

    <?php if($history->count()): ?>
    <h3 style="margin:24px 0 14px;font-size:16px;font-weight:800;">Withdrawal History</h3>
    <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="withdraw-item">
        <div class="withdraw-icon"><i class="fa-solid <?php echo e($w['method_icon'] ?? 'fa-wallet'); ?>"></i></div>
        <div class="withdraw-info">
          <div class="withdraw-method"><?php echo e($w['method_name'] ?? 'Unknown'); ?></div>
          <div class="withdraw-addr"><?php echo e(substr($w['address'],0,20)); ?>...</div>
        </div>
        <div class="withdraw-right">
          <div class="withdraw-amount"><?php echo e(formatAmount((float)$w['amount'])); ?></div>
          <span class="status-badge status-<?php echo e($w['status']); ?>"><?php echo e(ucfirst($w['status'])); ?></span>
          <div class="withdraw-date"><?php echo e(date('M j, Y', strtotime($w['created_at']))); ?></div>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
  </main>
  <nav class="bottom-nav">
    <a href="/dashboard" class="nav-item"><i class="fa-solid fa-house"></i>Home</a>
    <a href="/tasks" class="nav-item"><i class="fa-solid fa-list-check"></i>Tasks</a>
    <a href="/wallet" class="nav-item active"><i class="fa-solid fa-wallet"></i>Wallet</a>
    <a href="/leaderboard" class="nav-item"><i class="fa-solid fa-trophy"></i>Board</a>
    <a href="/profile" class="nav-item"><i class="fa-solid fa-user"></i>Profile</a>
  </nav>
</div>
<div id="toast-container"></div>
<script src="/assets/js/main.js"></script>
</body>
</html>
<?php /**PATH /home/icxbdfsb/public_html/resources/views/withdraw.blade.php ENDPATH**/ ?>