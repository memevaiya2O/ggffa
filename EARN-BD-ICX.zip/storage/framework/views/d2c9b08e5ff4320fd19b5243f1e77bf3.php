<?php echo $__env->make('admin.partials-header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php if($flash): ?><div class="alert alert-success" style="margin-bottom:20px;"><?php echo e($flash); ?></div><?php endif; ?>

<div class="admin-card">
  <div class="admin-card-header">
    <div class="admin-card-title">Submissions (<?php echo e(number_format($total)); ?>)</div>
  </div>
  <div class="admin-filters">
    <?php $__currentLoopData = ['pending'=>'⏳ Pending','approved'=>'✅ Approved','rejected'=>'❌ Rejected','all'=>'All']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <a href="?status=<?php echo e($k); ?>" class="filter-btn <?php echo e($status===$k?'filter-btn-primary':'filter-btn-outline'); ?>"><?php echo e($v); ?></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>

  <!-- Bulk action bar -->
  <div id="bulk-action-bar" style="display:none;background:rgba(0,200,150,.1);padding:12px 16px;border-radius:8px;margin-bottom:16px;align-items:center;gap:12px;">
    <span class="bulk-count" style="font-weight:700;"></span>
    <?php if($status === 'pending'): ?>
      <button id="bulk-approve-btn" class="action-btn-sm action-btn-approve"><i class="fa-solid fa-check"></i> Approve All</button>
      <button id="bulk-reject-btn" class="action-btn-sm action-btn-reject"><i class="fa-solid fa-times"></i> Reject All</button>
    <?php endif; ?>
  </div>
  <?php echo csrfField(); ?>


  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr>
        <?php if($status === 'pending'): ?><th><input type="checkbox" id="select-all"></th><?php endif; ?>
        <th>User</th><th>Task</th><th>Screenshot</th><th>Notes</th><th>Submitted</th><th>Status</th><th>Actions</th>
      </tr></thead>
      <tbody>
        <?php $__currentLoopData = $submissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <?php if($status === 'pending'): ?><td><input type="checkbox" class="row-checkbox" value="<?php echo e($s['id']); ?>"></td><?php endif; ?>
            <td>
              <div class="user-cell">
                <div class="table-avatar"><?php echo e(strtoupper(substr($s['user_name'],0,1))); ?></div>
                <div><?php echo e($s['user_name']); ?></div>
              </div>
            </td>
            <td style="font-size:13px;"><?php echo e($s['task_title']); ?><br><span style="color:var(--primary);font-weight:700"><?php echo e(formatAmount((float)$s['reward'])); ?></span></td>
            <td>
              <?php if($s['screenshot']): ?>
                <img src="<?php echo e($s['screenshot']); ?>" class="sub-screenshot" data-lightbox="<?php echo e($s['screenshot']); ?>" alt="" style="max-height:60px;border-radius:6px;cursor:pointer;">
              <?php else: ?><span style="color:#aaa;font-size:12px;">None</span><?php endif; ?>
            </td>
            <td style="font-size:13px;max-width:160px;overflow:hidden;text-overflow:ellipsis;"><?php echo $s['notes'] ? e(substr($s['notes'],0,60)) : '<span style="color:#aaa">—</span>'; ?></td>
            <td style="font-size:12px;color:#888"><?php echo e(timeAgo($s['created_at'])); ?></td>
            <td><span class="status-badge status-<?php echo e($s['status']); ?>"><?php echo e(ucfirst($s['status'])); ?></span><?php if($s['reject_reason']): ?><div style="font-size:11px;color:#888;margin-top:4px;"><?php echo e(substr($s['reject_reason'],0,40)); ?></div><?php endif; ?></td>
            <td>
              <?php if($s['status'] === 'pending'): ?>
                <div class="action-btns">
                  <form method="post" style="display:inline"><?php echo csrfField(); ?><input type="hidden" name="action" value="approve"><input type="hidden" name="sub_id" value="<?php echo e($s['id']); ?>"><button type="submit" class="action-btn-sm action-btn-approve" data-confirm="Approve this submission?"><i class="fa-solid fa-check"></i> Approve</button></form>
                  <button class="action-btn-sm action-btn-reject" onclick="openRejectModal(<?php echo e($s['id']); ?>)"><i class="fa-solid fa-times"></i> Reject</button>
                </div>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
  <?php echo paginationLinks($total,$page,$limit,'/Icxpanel/submissions?status='.$status); ?>

</div>

<!-- Reject Modal -->
<div class="modal-overlay" id="reject-modal">
  <div class="modal-box">
    <div class="modal-header"><h3>Reject Submission</h3><span class="modal-close"><i class="fa-solid fa-xmark"></i></span></div>
    <form method="post" action="/Icxpanel/submissions">
      <?php echo csrfField(); ?>

      <input type="hidden" name="action" value="reject">
      <input type="hidden" name="sub_id" id="reject-sid">
      <div class="form-group">
        <label class="form-label">Quick Templates</label>
        <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:10px;">
          <?php $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button type="button" class="filter-btn filter-btn-outline" style="font-size:12px;" onclick="document.getElementById('reject-reason').value='<?php echo e(addslashes($t['reason'])); ?>'"><?php echo e($t['reason']); ?></button>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
      <div class="form-group"><label class="form-label">Reason <span style="color:var(--danger)">*</span></label><textarea name="reason" id="reject-reason" class="form-control" rows="3" required placeholder="Enter rejection reason..."></textarea></div>
      <button type="submit" class="btn btn-danger btn-block">Reject Submission</button>
    </form>
  </div>
</div>
<?php $extraJs = '<script>function openRejectModal(sid){document.getElementById("reject-sid").value=sid;document.getElementById("reject-modal").classList.add("active");}</script>'; ?>
<?php echo $__env->make('admin.partials-footer', ['extraJs' => $extraJs], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH /home/icxbdfsb/public_html/resources/views/admin/submissions.blade.php ENDPATH**/ ?>