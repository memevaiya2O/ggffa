<!DOCTYPE html>
<html lang="en">
<head>
<?php echo renderSeoMeta(); ?>

<?php echo renderGoogleFont(); ?>

<?php echo renderCssVars(); ?>

<link rel="stylesheet" href="/assets/css/style.css?v=3">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<?php echo getSetting('custom_header_script'); ?>

</head>
<body>
<div class="auth-page">
  <div class="auth-card" style="max-width:460px;">
    <div class="auth-logo">
      <div class="brand-logo-wrap"><?php echo $__env->make('partials.brand-logo', ['size' => 'lg'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
    </div>
    <h2 class="auth-title">Create Account</h2>
    <p class="auth-subtitle">Join thousands of earners today — it's free!</p>

    <?php if($error): ?><div class="alert alert-error"><i class="fa-solid fa-circle-exclamation"></i> <?php echo e($error); ?></div><?php endif; ?>

    <form method="post" action="/register">
      <?php echo csrfField(); ?>

      <div class="form-group">
        <label class="form-label">Full Name <span style="color:var(--danger)">*</span></label>
        <div class="input-group">
          <i class="input-icon fa-solid fa-user"></i>
          <input type="text" name="name" class="form-control" placeholder="Your full name" value="<?php echo e($old['name']); ?>" required autofocus>
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Email Address <span style="color:var(--danger)">*</span></label>
        <div class="input-group">
          <i class="input-icon fa-solid fa-envelope"></i>
          <input type="email" name="email" class="form-control" placeholder="you@email.com" value="<?php echo e($old['email']); ?>" required>
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Mobile Number <span style="color:var(--danger)">*</span></label>
        <div class="input-group">
          <i class="input-icon fa-solid fa-phone"></i>
          <input type="tel" name="phone" class="form-control" placeholder="01XXXXXXXXX" value="<?php echo e($old['phone']); ?>" inputmode="numeric" maxlength="20" required>
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Password <span style="color:var(--danger)">*</span></label>
        <div class="input-group">
          <i class="input-icon fa-solid fa-lock"></i>
          <input type="password" name="password" class="form-control" placeholder="Min 6 characters" required>
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Confirm Password <span style="color:var(--danger)">*</span></label>
        <div class="input-group">
          <i class="input-icon fa-solid fa-lock"></i>
          <input type="password" name="confirm_password" class="form-control" placeholder="Re-enter password" required>
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Referral Code <span style="color:#aaa;font-weight:400">(optional)</span></label>
        <div class="input-group">
          <i class="input-icon fa-solid fa-user-plus"></i>
          <input type="text" name="referral_code" class="form-control" placeholder="Enter referral code" value="<?php echo e(request()->query('ref', request()->input('referral_code', ''))); ?>">
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Security Check <span style="color:var(--danger)">*</span></label>
        <div class="captcha-box">
          <span class="captcha-q">What is <?php echo e($captchaA); ?> + <?php echo e($captchaB); ?> ?</span>
          <input type="number" name="captcha" class="form-control" style="max-width:100px;text-align:center;font-size:18px;font-weight:700;" placeholder="?" required min="0">
        </div>
      </div>
      <button type="submit" class="btn btn-primary btn-block">
        <i class="fa-solid fa-user-plus"></i> Create Account
      </button>
      <p style="font-size:12px;color:#aaa;text-align:center;margin-top:12px;">By registering, you agree to our Terms &amp; Privacy Policy.</p>
    </form>
    <div class="auth-footer">
      Already have an account? <a href="/login">Login</a>
    </div>
  </div>
</div>
<div id="toast-container"></div>
<script src="/assets/js/main.js"></script>
<?php echo getSetting('custom_footer_script',''); ?>

</body>
</html>
<?php /**PATH /home/icxbdfsb/public_html/resources/views/register.blade.php ENDPATH**/ ?>