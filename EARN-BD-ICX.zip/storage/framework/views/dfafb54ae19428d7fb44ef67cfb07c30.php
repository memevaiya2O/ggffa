<?php echo $__env->make('admin.partials-header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<div style="display:flex;gap:12px;align-items:center;margin-bottom:20px;flex-wrap:wrap;">
  <strong>Date Range:</strong>
  <?php $__currentLoopData = ['7'=>'7 Days','30'=>'30 Days','90'=>'90 Days','365'=>'1 Year']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v => $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <a href="?range=<?php echo e($v); ?>" class="btn btn-sm <?php echo e($range==$v?'btn-primary':'btn-secondary'); ?>"><?php echo e($l); ?></a>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="admin-stats-grid" style="grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:16px;display:grid;margin-bottom:24px;">
  <div class="stat-card"><div class="stat-value"><?php echo e(number_format($totalUsers)); ?></div><div class="stat-label">Total Users</div></div>
  <div class="stat-card"><div class="stat-value"><?php echo e(number_format($newUsers)); ?></div><div class="stat-label">New Users (<?php echo e($days); ?>d)</div></div>
  <div class="stat-card"><div class="stat-value"><?php echo e(number_format($totalTasks)); ?></div><div class="stat-label">Active Tasks</div></div>
  <div class="stat-card"><div class="stat-value"><?php echo e(number_format($totalSubs)); ?></div><div class="stat-label">Total Submissions</div></div>
  <div class="stat-card"><div class="stat-value"><?php echo e(number_format($pendingSubs)); ?></div><div class="stat-label">Pending Review</div></div>
  <div class="stat-card"><div class="stat-value"><?php echo e(number_format($approvedSubs)); ?></div><div class="stat-label">Approved</div></div>
  <div class="stat-card"><div class="stat-value">৳<?php echo e(number_format($totalEarned,2)); ?></div><div class="stat-label">Total Earned</div></div>
  <div class="stat-card"><div class="stat-value">৳<?php echo e(number_format($totalWithdrawn,2)); ?></div><div class="stat-label">Total Withdrawn</div></div>
  <div class="stat-card"><div class="stat-value">৳<?php echo e(number_format($pendingWithdraw,2)); ?></div><div class="stat-label">Pending Withdraw</div></div>
  <div class="stat-card"><div class="stat-value"><?php echo e(number_format($totalSpins)); ?></div><div class="stat-label">Spins (<?php echo e($days); ?>d)</div></div>
</div>

<div class="admin-grid-2" style="display:grid;grid-template-columns:1fr 1fr;gap:24px;margin-bottom:24px;">
  <div class="admin-card">
    <div class="admin-card-header"><div class="admin-card-title">Registrations (<?php echo e($days); ?> days)</div></div>
    <div class="admin-card-body">
      <canvas id="reg-chart" height="200"></canvas>
    </div>
  </div>
  <div class="admin-card">
    <div class="admin-card-header"><div class="admin-card-title">Submissions (<?php echo e($days); ?> days)</div></div>
    <div class="admin-card-body">
      <canvas id="sub-chart" height="200"></canvas>
    </div>
  </div>
</div>

<div class="admin-grid-2" style="display:grid;grid-template-columns:1fr 1fr;gap:24px;">
  <div class="admin-card">
    <div class="admin-card-header"><div class="admin-card-title">Top 10 Tasks</div></div>
    <div class="admin-table-wrap">
      <table class="admin-table">
        <thead><tr><th>#</th><th>Task</th><th>Completions</th></tr></thead>
        <tbody>
          <?php $__currentLoopData = $topTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr><td><?php echo e($i+1); ?></td><td><?php echo e($t['title']); ?></td><td><?php echo e($t['cnt']); ?></td></tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
  <div class="admin-card">
    <div class="admin-card-header"><div class="admin-card-title">Top Earners</div></div>
    <div class="admin-table-wrap">
      <table class="admin-table">
        <thead><tr><th>#</th><th>User</th><th>Balance</th></tr></thead>
        <tbody>
          <?php $__currentLoopData = $topEarners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr><td><?php echo e($i+1); ?></td><td><?php echo e($u['name']); ?></td><td>৳<?php echo e(number_format($u['balance'],2)); ?></td></tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<div class="admin-card" style="margin-top:24px;">
  <div class="admin-card-header"><div class="admin-card-title">Withdrawals by Method</div></div>
  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>Method</th><th>Count</th><th>Total (BDT)</th></tr></thead>
      <tbody>
        <?php $__currentLoopData = $wByMethod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr><td><?php echo e($w['method']); ?></td><td><?php echo e($w['cnt']); ?></td><td>৳<?php echo e(number_format($w['total'],2)); ?></td></tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if(!$wByMethod->count()): ?><tr><td colspan="3" style="text-align:center;color:#888;">No data.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php
$extraJs = '<script src="https://cdn.jsdelivr.net/npm/chart.js@4/dist/chart.umd.min.js"></script>
<script>
const regLabels = ' . json_encode(array_column($dailyRegs->all(),'d')) . ';
const regData   = ' . json_encode(array_column($dailyRegs->all(),'cnt')) . ';
const subLabels = ' . json_encode(array_column($dailySubs->all(),'d')) . ';
const subData   = ' . json_encode(array_column($dailySubs->all(),'cnt')) . ';

new Chart(document.getElementById("reg-chart"), {
  type:"line",
  data:{ labels:regLabels, datasets:[{ label:"Registrations", data:regData, borderColor:"#667eea", backgroundColor:"rgba(102,126,234,0.1)", fill:true, tension:0.3 }] },
  options:{ responsive:true, plugins:{legend:{display:false}}, scales:{ y:{beginAtZero:true, ticks:{precision:0}} } }
});
new Chart(document.getElementById("sub-chart"), {
  type:"bar",
  data:{ labels:subLabels, datasets:[{ label:"Submissions", data:subData, backgroundColor:"#4CAF50" }] },
  options:{ responsive:true, plugins:{legend:{display:false}}, scales:{ y:{beginAtZero:true, ticks:{precision:0}} } }
});
</script>';
?>
<?php echo $__env->make('admin.partials-footer', ['extraJs' => $extraJs], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH /home/icxbdfsb/public_html/resources/views/admin/reports.blade.php ENDPATH**/ ?>