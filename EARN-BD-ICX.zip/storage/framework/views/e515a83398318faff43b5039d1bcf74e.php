<!DOCTYPE html>
<html lang="en">
<head>
<?php echo renderSeoMeta(); ?>

<?php echo renderGoogleFont(); ?>

<?php echo renderCssVars(); ?>

<link rel="stylesheet" href="/assets/css/style.css?v=3">
<link rel="stylesheet" href="/assets/css/dashboard.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="app-layout">
  <header class="app-header">
    <div class="app-header-left">
      <div class="user-name">Tasks</div>
    </div>
    <div class="app-header-right">
      <a href="/notifications" class="notif-btn"><i class="fa-solid fa-bell"></i><?php if($notifCount): ?><span class="notif-badge"><?php echo e($notifCount); ?></span><?php endif; ?></a>
    </div>
  </header>
  <main class="main-content">
    <!-- Category Tabs -->
    <div class="category-tabs">
      <a href="/tasks" class="cat-tab <?php echo e(!$catId ? 'active' : ''); ?>"><i class="fa-solid fa-border-all"></i> All</a>
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="/tasks?cat=<?php echo e($c['id']); ?>" class="cat-tab <?php echo e($catId == $c['id'] ? 'active' : ''); ?>">
          <i class="fa-solid <?php echo e($c['icon']); ?>" style="color:<?php echo e($c['color']); ?>"></i> <?php echo e($c['name']); ?>

        </a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- Search -->
    <div class="search-box">
      <i class="fa-solid fa-magnifying-glass"></i>
      <input type="text" class="form-control" placeholder="Search tasks..." id="task-search" value="<?php echo e($search); ?>">
    </div>

    <!-- Task List -->
    <?php if(!$tasks->count()): ?>
      <div style="text-align:center;padding:48px 20px;color:#888;"><i class="fa-solid fa-inbox" style="font-size:48px;display:block;margin-bottom:16px;opacity:.3"></i><p>No tasks available right now</p></div>
    <?php else: ?>
      <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
          $isDone = $t['user_sub_status'] === 'approved';
          $isPending = $t['user_sub_status'] === 'pending';
          $isLocked = $t['is_vip'] && !$user['can_access_vip'];
        ?>
        <a href="/task-detail?id=<?php echo e($t['id']); ?>" class="task-card <?php echo e($isDone ? 'completed' : ''); ?> <?php echo e($isLocked ? 'locked' : ''); ?>" style="text-decoration:none;display:flex;">
          <div class="task-thumb" style="<?php echo e($t['cat_color'] ? "background:linear-gradient(135deg,{$t['cat_color']}cc,{$t['cat_color']}88)" : ''); ?>">
            <?php if($t['thumbnail']): ?>
              <img src="<?php echo e($t['thumbnail']); ?>" alt="">
            <?php else: ?>
              <i class="fa-solid <?php echo e($t['cat_icon'] ?? 'fa-star'); ?>"></i>
            <?php endif; ?>
          </div>
          <div class="task-info">
            <div class="task-title"><?php echo e($t['title']); ?></div>
            <div class="task-meta">
              <span class="task-reward-tag"><?php echo e(formatAmount((float)$t['reward'])); ?></span>
              <span class="task-cat-badge"><i class="fa-solid <?php echo e($t['cat_icon'] ?? 'fa-tag'); ?>"></i> <?php echo e($t['cat_name'] ?? 'General'); ?></span>
            </div>
            <div class="task-ribbons">
              <?php if($t['is_hot']): ?><span class="badge badge-hot">🔥 HOT</span><?php endif; ?>
              <?php if($t['is_new']): ?><span class="badge badge-new">✨ NEW</span><?php endif; ?>
              <?php if($t['is_vip']): ?><span class="badge badge-vip">👑 VIP</span><?php endif; ?>
              <?php if($isDone): ?><span class="badge badge-success">✅ Done</span><?php endif; ?>
              <?php if($isPending): ?><span class="badge badge-warning">⏳ Pending</span><?php endif; ?>
              <?php if($isLocked): ?><span class="badge" style="background:rgba(0,0,0,.08);color:#888;"><i class="fa-solid fa-lock"></i> VIP Required</span><?php endif; ?>
            </div>
            <div class="task-progress" style="margin-top:6px;"><?php echo e($t['completion_count']); ?>/<?php echo e($t['max_total']); ?> completed</div>
          </div>
        </a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php echo paginationLinks($total, $page, $limit, '/tasks?' . http_build_query(['cat' => $catId, 'search' => $search])); ?>

    <?php endif; ?>
  </main>
  <nav class="bottom-nav">
    <a href="/dashboard" class="nav-item"><i class="fa-solid fa-house"></i>Home</a>
    <a href="/tasks" class="nav-item active"><i class="fa-solid fa-list-check"></i>Tasks</a>
    <a href="/wallet" class="nav-item"><i class="fa-solid fa-wallet"></i>Wallet</a>
    <a href="/leaderboard" class="nav-item"><i class="fa-solid fa-trophy"></i>Board</a>
    <a href="/profile" class="nav-item"><i class="fa-solid fa-user"></i>Profile</a>
  </nav>
</div>
<div id="toast-container"></div>
<script src="/assets/js/main.js"></script>
<script>
document.getElementById('task-search').addEventListener('keydown', e => {
  if (e.key === 'Enter') {
    const url = new URL(window.location.href);
    url.searchParams.set('search', e.target.value);
    url.searchParams.delete('page');
    window.location.href = url.toString();
  }
});
</script>
</body>
</html>
<?php /**PATH /home/icxbdfsb/public_html/resources/views/tasks.blade.php ENDPATH**/ ?>