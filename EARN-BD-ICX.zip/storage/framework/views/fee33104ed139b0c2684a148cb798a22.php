<?php echo $__env->make('admin.partials-header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $g = fn($k,$d='') => $s[$k] ?? $d; ?>
<?php if($flash): ?><div class="alert alert-success" style="margin-bottom:20px;"><?php echo e($flash); ?></div><?php endif; ?>

<div class="admin-grid-2" style="display:grid;grid-template-columns:1fr 1.5fr;gap:24px;">

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">Referral Settings</div></div>
  <div class="admin-card-body">
    <form method="post">
      <?php echo csrfField(); ?>

      <div class="form-group">
        <label>Referral System Enabled</label>
        <select name="referral_enabled" class="form-control">
          <option value="1" <?php echo e($g('referral_enabled','1')==='1'?'selected':''); ?>>Yes</option>
          <option value="0" <?php echo e($g('referral_enabled','1')==='0'?'selected':''); ?>>No</option>
        </select>
      </div>
      <div class="form-group">
        <label>Bonus for Referrer (BDT)</label>
        <input type="number" name="referral_bonus_referrer" class="form-control" value="<?php echo e($g('referral_bonus_referrer','10')); ?>" step="0.01" min="0">
      </div>
      <div class="form-group">
        <label>Bonus for Referee (BDT)</label>
        <input type="number" name="referral_bonus_referee" class="form-control" value="<?php echo e($g('referral_bonus_referee','5')); ?>" step="0.01" min="0">
      </div>
      <div class="form-group">
        <label>Max Referrals per User (0 = unlimited)</label>
        <input type="number" name="referral_max_per_user" class="form-control" value="<?php echo e($g('referral_max_per_user','0')); ?>" min="0">
      </div>
      <div class="form-group">
        <label>Bonus Triggered On</label>
        <select name="referral_bonus_on" class="form-control">
          <option value="register" <?php echo e($g('referral_bonus_on','register')==='register'?'selected':''); ?>>Registration</option>
          <option value="first_task" <?php echo e($g('referral_bonus_on','register')==='first_task'?'selected':''); ?>>First Task Approved</option>
        </select>
      </div>
      <div class="form-group">
        <label>Min Withdraw to Unlock Referral Bonus (0 = no min)</label>
        <input type="number" name="referral_min_withdraw" class="form-control" value="<?php echo e($g('referral_min_withdraw','0')); ?>" step="0.01" min="0">
      </div>
      <button class="btn btn-primary">Save Settings</button>
    </form>
  </div>
</div>

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">Top Referrers — Total Referred: <?php echo e($totalReferrals); ?></div></div>
  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>#</th><th>User</th><th>Referrals</th></tr></thead>
      <tbody>
        <?php $__currentLoopData = $topReferrers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr><td><?php echo e($i+1); ?></td><td><?php echo e($r['name']); ?></td><td><?php echo e($r['cnt']); ?></td></tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if(!$topReferrers->count()): ?><tr><td colspan="3" style="text-align:center;color:#888;">No referrals yet.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

</div>
<?php echo $__env->make('admin.partials-footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH /home/icxbdfsb/public_html/resources/views/admin/referral-config.blade.php ENDPATH**/ ?>