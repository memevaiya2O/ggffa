# ∞ INFINITY API HUB v3 — Pure Laravel 12

সম্পূর্ণ **Laravel 12** দিয়ে তৈরি প্রিমিয়াম **API সেলিং প্ল্যাটফর্ম**। প্রতিটা API-এর জন্য **আলাদা API Key**, আলাদা ক্রেডিট, আলাদা প্যাকেজ। ইউজার রেজিস্টার করলেই সব API-এর Key অটো-পেয়ে যায়।

> ⚙️ কোনো `install.php` নেই — সবকিছু **`.env` environment** ফাইলে। নিচের ধাপে ম্যানুয়ালি ইনস্টল করুন।

---

## ✨ Features

- 🔑 **Per-API keys** — রেজিস্টারে সব API-এর Key + বোনাস ক্রেডিট অটো-ইস্যু
- 🛒 **Per-API packages** — ফ্রি (অটো-অ্যাক্টিভ) + পেইড (bKash/Nagad/Rocket + TxnID)
- 🌐 প্রতিটা API-এর নিজস্ব পেজ: Key, ডকস, কোড স্যাম্পল, প্রাইসিং, লাইভ স্ট্যাটস
- 📊 Public **status page**, auto **docs**, key checker, invoice ডাউনলোড
- 🎫 **Support ticket system** (user + admin)
- 🛡️ Admin: ড্যাশবোর্ড, যেকোনো API যোগ, Keys, Orders (1-click approve), Logs + CSV, Reports, Notifications, Multi-admin, ফুল ডিজাইন কাস্টমাইজ, DB ব্যাকআপ
- ⚙️ Gateway: `GET /api/{service}?api_key=KEY&...` (+ `X-API-KEY` হেডার, POST সাপোর্ট), রেট-লিমিট, ক্রেডিট, ফুল লগিং
- ⏰ Artisan commands: `keys:expire`, `logs:prune` (+ scheduler)

## 📋 Requirements

- PHP **8.2+** with extensions: `mbstring`, `curl`, `xml`, `sqlite3`/`mysql`, `fileinfo`, `openssl`, `tokenizer`
- MySQL / MariaDB (production) — SQLite দিয়েও টেস্ট করা যায়
- Composer (শুধু প্রথমবার `vendor/` বানাতে — এই zip-এ vendor **সহই** দেওয়া আছে, তাই Composer না থাকলেও চলবে!)

## 🚀 Installation (VPS / যেকোনো সার্ভার)

```bash
# 1. Zip extract করুন, ভেতরে ঢুকুন
unzip infinity-api-hub-laravel.zip && cd infinity-api-hub-laravel

# 2. Environment ফাইল বানান
cp .env.example .env

# 3. .env এডিট করুন — DB তথ্য + APP_URL বসান:
#    DB_DATABASE=infinity_hub
#    DB_USERNAME=xxxx
#    DB_PASSWORD=xxxx
#    APP_URL=https://yourdomain.com
nano .env

# 4. App key + database
php artisan key:generate
php artisan migrate --force --seed

# 5. Permission (Linux)
chmod -R 775 storage bootstrap/cache public/uploads

# 6. Web server document-root → public/ ফোল্ডারে পয়েন্ট করুন
# টেস্ট করতে চাইলে: php artisan serve
```

**Login:** `admin@infinity.hub` / `admin123` ⚠️ (ঢুকেই বদলে নিন!)

> 💡 `vendor/` ফোল্ডার zip-এ **দেওয়াই আছে** — Composer না চালালেও চলবে। আপডেট করতে চাইলে শুধু `composer install` চালান।

## 🌐 cPanel Shared Hosting-এ চালানো

1. Zip extract করে সব ফাইল `public_html/infinity/` (বা যেকোনো ফোল্ডারে) রাখুন — **তবে `public/` ফোল্ডারের ভেতরের ফাইলগুলো** `public_html/` (document root)-এ রাখুন
2. `public_html/index.php`-তে path ঠিক করুন:
   ```php
   require __DIR__.'/../infinity/vendor/autoload.php';
   $app = require __DIR__.'/../infinity/bootstrap/app.php';
   ```
3. `.env` বানিয়ে DB তথ্য দিন, তারপর Terminal/SSH থেকে:
   `php artisan key:generate && php artisan migrate --force --seed`
   (SSH না থাকলে: লোকালে migrate করে DB export → phpMyAdmin-এ import করুন)

## ⏰ Cron (daily — key expire + log clean)

```
0 0 * * * cd /path/to/project && php artisan keys:expire >> /dev/null 2>&1
0 1 * * * cd /path/to/project && php artisan logs:prune --days=90 >> /dev/null 2>&1
```

## 🔌 API ব্যবহার

```
GET https://yourdomain.com/api/ff-uid?api_key=INF-FFUI-XXXX-XXXX-XXXX&uid=2535040417
```
- `api_key` এর বদলে `X-API-KEY:` হেডার বা `Authorization: Bearer` ও চলবে
- Response: provider-এর JSON হুবহু + `X-Credits-Left` হেডার
- Error সবসময়: `{"status":"error","message":"..."}`

## 📁 Structure

```
app/
├── Console/Commands/   # keys:expire, logs:prune
├── Helpers/helpers.php # setting(), taka(), badge()...
├── Http/Controllers/   # Auth, Api/Gateway, User/*, Admin/*
├── Http/Middleware/    # admin, active, maintenance
├── Models/             # User, ApiService, ServiceKey, Package, Order, ApiLog...
├── Providers/          # AppServiceProvider (custom pagination)
└── Services/           # ProviderGateway (cURL engine)
routes/  web.php • api.php • console.php
database/  migrations • seeders
resources/views/  layouts • pages • user • admin (Blade)
public/  index.php • assets • uploads
```

© 2026 INFINITY API HUB — Pure Laravel 💜
