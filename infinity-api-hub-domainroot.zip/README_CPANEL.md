# Infinity API Hub — cPanel Package

## Security cleanup applied to this package

The following were found in the original build and removed/fixed before packaging — see them as reasons to still follow the security steps below before going live:

- **`storage/admin-credentials.txt`** — contained the seeded admin's plaintext password. Deleted. The admin password must be changed on first login regardless (`admin@infinity.hub`).
- **`.env.temp`** — a leftover dev `.env` with a real `APP_KEY` and a dev/sandbox `APP_URL`. Deleted. Treat that key as burned; generate a fresh one with `php artisan key:generate` after deploying — do not reuse any key that shipped in this package.
- **`debug.php`** — a diagnostic script that echoed stack traces/paths with `display_errors` forced on. Deleted; do not re-add anything like it to the live document root.
- **`error_log`** and a duplicate, broken **`index.php`** — both hardcoded the previous hosting account's real path (`/home/icxbdfsb/...`). Deleted; the single `index.php` in this package is the correct front controller and already points at the paths used by this layout.
- **`framework/`** — an unused, non-standard duplicate cache directory (not referenced by any config). Removed for clarity.
- **`storage/app/private/invoices/*.html`** — sample invoices left over from testing. Deleted; new ones generate automatically on real orders.
- **Single-root layout** — this build is arranged to be extracted straight into your domain's document root: `index.php` sits next to `app/`, `vendor/`, `storage/`, etc., with no separate outside-webroot folder. Because of that, `.htaccess` now explicitly blocks direct HTTP access to `app/`, `bootstrap/`, `config/`, `database/`, `resources/`, `routes/`, `storage/`, `vendor/`, `.env`, `composer.json/.lock`, and `artisan` — see "Security before going live" below; do not remove those rules.
- **`bootstrap/app.php`** — uploads (logo, footer image, favicon) are now written to the same folder as `index.php` via an explicit `usePublicPath()`, so they're actually reachable by the browser instead of landing in an unused `public/` folder like the original build did.
- **SQL dump** — one real user record (id 5) had a genuine name/email/phone left in from testing. Anonymized to `Demo User` / `demo-user@example.com` while keeping its wallet, service-key, and API-log rows intact for referential integrity.
- **`.gitignore`** — extended so `.env.temp`, `debug.php`, `error_log`, admin credentials, invoices, and cache/session files won't get bundled into future exports.

Everything else in this package (migrations, seeders, the 15-table SQL dump) was cross-checked and matches — no schema drift.


This package is a Laravel + MySQL deployment for `https://icxbd.fsbd.pro/`, built to be extracted directly into your domain's document root (e.g. `public_html/`, or a subdomain's document root) as a single folder — no separate outside-webroot upload needed. Security that would normally come from placing the app outside the document root is instead enforced by the `.htaccess` rules described above, so **`.htaccess` support (`AllowOverride All`, `mod_rewrite`) is mandatory**, not optional, for this build.

## Requirements

Use cPanel PHP **8.2 or newer** (PHP 8.3 recommended) with `curl`, `fileinfo`, `mbstring`, `openssl`, `pdo_mysql`, `tokenizer`, `xml`, and `zip`. Apache must have `mod_rewrite` enabled, and the domain's `AllowOverride` must permit `.htaccess` (standard on cPanel shared hosting).

## Recommended cPanel layout

```text
/home/CPANEL_USER/public_html/        (or a subdomain's document root)
├── index.php            # front controller — from this package's root
├── .htaccess             # routes requests AND blocks the folders below from direct access
├── app/
├── bootstrap/
├── database/
├── resources/
├── routes/
├── storage/
├── vendor/
├── assets/, uploads/     # public, browser-reachable
└── artisan, composer.json, .env, ...
```

Everything in this package's root (this ZIP's top level) is uploaded as-is into the domain's document root — nothing is renamed or moved. The `.htaccess` in this package is what keeps `app/`, `database/`, `storage/`, `vendor/`, and `.env` from being directly downloadable even though they now live inside the web root.

## Installation

1. Create a MySQL database and database user in cPanel. Grant the user all privileges on the database.
2. Extract this package's contents directly into the domain's document root (`public_html/`, or the subdomain's document root) — same level as `index.php`.
3. Copy `.env.example` to `.env` in that same folder.
4. Edit `.env` and set `APP_KEY`, `DB_DATABASE`, `DB_USERNAME`, `DB_PASSWORD`, and mail/payment secrets. `APP_URL` is already set to `https://icxbd.fsbd.pro`; change it if the domain changes.
5. Import `database/infinity_api_hub.sql` through cPanel phpMyAdmin. The dump contains the current schema, settings, users, packages, and API records. Do not run migrations and import the dump together unless you know the database is empty and you intend to migrate instead.
6. Set permissions: `storage/` and `bootstrap/cache/` must be writable by the PHP process, commonly 755 or 775 depending on host configuration.
7. In cPanel MultiPHP Manager select PHP 8.2+ and enable the required extensions.
8. If Terminal/SSH is available, run `php artisan optimize:clear` from this folder. If it is not available, remove cached files under `bootstrap/cache/` and `storage/framework/views/` before the first request.
9. **Verify the security rules took effect** before going further: visit `https://yourdomain/.env` and `https://yourdomain/database/infinity_api_hub.sql` in a browser — both must return a 403 Forbidden, never the file contents. If either loads, `.htaccess`/`mod_rewrite` isn't active on your host; stop and fix that (or switch to a two-folder deployment with the app outside the document root) before importing real data.

## Managing APIs (no `.env` editing, no redeploy)

Every API — its provider URL, method, headers, params, credit cost, docs, and whether `http://` URLs are allowed — lives in the database and is fully managed from **Admin → API Management** and **Admin → Settings** after login. Adding, editing, or removing an API only takes effect there; `.env` no longer has (or needs) any API-provider variables, so there's nothing to sync between the two. Toggle "Allow insecure HTTP provider URLs" in Admin → Settings if a provider still uses `http://`; it's on by default in the seeded settings and doesn't require a server change either way.

The public API routes are:

```text
GET https://icxbd.fsbd.pro/api/ff-id-info?api_key=YOUR_API_KEY&uid=2535040417
GET https://icxbd.fsbd.pro/api/ff-name-check?api_key=YOUR_API_KEY&uid=2769409057
GET https://icxbd.fsbd.pro/api/ff-id-market-value?api_key=YOUR_API_KEY&uid=1704140050
```

## Security before going live

Generate a unique `APP_KEY` if the packaged key is empty or shared. Change the seeded administrator password immediately, rotate any Google OAuth and payment credentials, keep `APP_DEBUG=false`, and prefer HTTPS provider URLs. The SQL dump contains application data from the build environment; review or remove test data before importing if this is a new production installation. Because this layout serves the app root directly, also do step 9 above (confirm `.env` and `database/` 403) before pointing real traffic at the site — this is the one check that matters most for this build.

## Cron jobs

If cPanel Cron Jobs is available, configure the following using the real path to this folder (your document root):

```text
0 0 * * * cd /home/CPANEL_USER/public_html && php artisan keys:expire >/dev/null 2>&1
0 1 * * * cd /home/CPANEL_USER/public_html && php artisan logs:prune --days=90 >/dev/null 2>&1
```

## Note on `php artisan storage:link`

This app doesn't use Laravel's public storage disk or symlink (uploads go straight to a real, already-web-reachable `uploads/` folder), so `storage:link` isn't needed and shouldn't be run here — in this single-root layout, `public_path()` and `storage_path()` share the same `storage/` folder name, so the symlink command would try to link that folder to itself. If you later add a feature that needs `Storage::disk('public')`, use a different public folder name (e.g. `media/`) instead of `storage/storage`.

## Included API records

The SQL dump and fresh-install seeder include Free Fire ID Info, Free Fire Name Check, and Free Fire ID Market Value. They are editable later from Admin → API Management.
