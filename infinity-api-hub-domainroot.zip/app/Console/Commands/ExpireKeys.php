<?php

namespace App\Console\Commands;

use App\Models\ServiceKey;
use Illuminate\Console\Command;

class ExpireKeys extends Command
{
    protected $signature = 'keys:expire';
    protected $description = 'Mark past-expiry API keys as expired';

    public function handle(): int
    {
        $n = ServiceKey::where('status', 'active')
            ->whereNotNull('exp_date')
            ->where('exp_date', '<', today()->toDateString())
            ->update(['status' => 'expired']);

        $this->info("Expired {$n} key(s).");

        return self::SUCCESS;
    }
}
