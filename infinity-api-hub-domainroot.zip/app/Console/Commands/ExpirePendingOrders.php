<?php

namespace App\Console\Commands;

use App\Models\Order;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class ExpirePendingOrders extends Command
{
    protected $signature = 'orders:expire {--dry : Dry run}';
    protected $description = 'Auto-expire pending NagorikPay orders past configurable timeout';

    public function handle(): int
    {
        $minutes = max(1, (int) setting('nagorikpay_expire_minutes', 30));
        $threshold = now()->subMinutes($minutes);

        $query = Order::where('status', 'pending')
            ->where(function ($q) {
                $q->whereNotNull('expires_at')->where('expires_at', '<', now())
                  ->orWhere(function ($q2) {
                      // fallback: if expires_at null, use created_at + expire minutes
                      $minutes = max(1, (int) setting('nagorikpay_expire_minutes', 30));
                      $q2->whereNull('expires_at')->where('created_at', '<', now()->subMinutes($minutes));
                  });
            });

        $count = 0;
        foreach ($query->cursor() as $order) {
            if ($this->option('dry')) {
                $this->line("Would expire #{$order->id} created {$order->created_at}");
                $count++;
                continue;
            }
            $order->expire();
            $count++;
            Log::info('Order auto-expired', ['order' => $order->id]);
        }

        $this->info("Expired {$count} order(s) (threshold {$minutes} min).");
        return self::SUCCESS;
    }
}
