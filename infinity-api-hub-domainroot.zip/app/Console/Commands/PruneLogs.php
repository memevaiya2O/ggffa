<?php

namespace App\Console\Commands;

use App\Models\ApiLog;
use Illuminate\Console\Command;

class PruneLogs extends Command
{
    protected $signature = 'logs:prune {--days=90 : Delete logs older than N days}';
    protected $description = 'Delete old API logs to keep the database fast';

    public function handle(): int
    {
        $days = max(1, (int) $this->option('days'));
        $n = ApiLog::where('created_at', '<', now()->subDays($days))->delete();
        $this->info("Deleted {$n} log(s) older than {$days} days.");

        return self::SUCCESS;
    }
}
