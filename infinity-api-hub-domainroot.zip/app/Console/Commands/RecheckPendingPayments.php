<?php

namespace App\Console\Commands;

use App\Models\Order;
use App\Services\NagorikPayGateway;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class RecheckPendingPayments extends Command
{
    protected $signature = 'orders:recheck {--limit=20 : Max orders to recheck per run}';
    protected $description = 'Auto-recheck pending NagorikPay orders stuck beyond timeout';

    public function handle(): int
    {
        if (NagorikPayGateway::enabled() === false) {
            $this->warn('NagorikPay disabled – skipping recheck.');
            return self::SUCCESS;
        }

        $recheckMinutes = max(1, (int) setting('nagorikpay_recheck_minutes', 5));
        $threshold = now()->subMinutes($recheckMinutes);
        $limit = max(1, (int) $this->option('limit'));

        $orders = Order::pending()
            ->where('payment_method', 'nagorikpay')
            ->where('status', 'pending')
            ->where(function ($q) use ($threshold) {
                $q->where('created_at', '<', $threshold)
                  ->orWhere('updated_at', '<', $threshold);
            })
            ->whereNotNull('txn_id')
            ->where('txn_id', '!=', '')
            ->where('txn_id', 'not like', 'NP-ORDER-%') // avoid placeholder txns that were never replaced
            ->orderBy('updated_at')
            ->limit($limit)
            ->get();

        $this->info("Found {$orders->count()} pending order(s) to recheck (older than {$recheckMinutes} min).");

        $verified = 0;
        $failed = 0;
        $stillPending = 0;

        foreach ($orders as $order) {
            $tx = $order->txn_id ?: $order->nagorikpay_txn;
            $this->line("Rechecking #{$order->id} tx {$tx} ...");
            try {
                [$ok, $payload, $httpStatus, $isCompleted] = NagorikPayGateway::verify($tx);

                if ($ok && $isCompleted) {
                    // Use transactional complete
                    [$done, $msg] = Order::completeViaGateway($order->id, $tx, 'Auto-recheck verified ' . $tx);
                    if ($done) {
                        $verified++;
                        $this->info("  -> VERIFIED & credited");
                    } else {
                        $this->warn("  -> already processed: {$msg}");
                    }
                } elseif ($ok && !$isCompleted) {
                    $stillPending++;
                    $order->increment('attempts');
                    $this->comment("  -> still pending");
                } else {
                    // Check if payload indicates failure
                    $isFailed = is_array($payload) && isset($payload['status']) && in_array(strtolower((string)$payload['status']), ['failed','error','rejected','cancelled'], true);
                    if ($isFailed) {
                        $order->update(['status' => 'rejected', 'admin_note' => 'Auto-recheck: gateway marked as failed.', 'reviewed_at' => now()]);
                        $failed++;
                        $this->error("  -> failed/rejected");
                    } else {
                        $stillPending++;
                        $order->increment('attempts');
                        $this->comment("  -> verify not confirmed (http {$httpStatus})");
                    }
                }
            } catch (\Throwable $e) {
                Log::error('Recheck exception', ['order' => $order->id, 'error' => $e->getMessage()]);
                $this->error("  -> exception: ".$e->getMessage());
                $order->increment('attempts');
            }
        }

        $this->info("Done: {$verified} verified, {$failed} failed, {$stillPending} still pending.");
        return self::SUCCESS;
    }
}
