<?php

use App\Models\Setting;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;

if (!function_exists('encrypted_setting_keys')) {
    function encrypted_setting_keys(): array
    {
        return [
            'nagorikpay_api_key',
            'nagorikpay_api_key_live',
            'nagorikpay_api_key_sandbox',
            'nagorikpay_webhook_secret',
            'nagorikpay_webhook_secret_live',
            'nagorikpay_webhook_secret_sandbox',
            'google_client_secret',
        ];
    }
}

if (!function_exists('is_encrypted_setting')) {
    function is_encrypted_setting(string $key): bool
    {
        return in_array($key, encrypted_setting_keys(), true);
    }
}

if (!function_exists('decrypt_setting_value')) {
    function decrypt_setting_value(string $key, ?string $value): ?string
    {
        if ($value === null || $value === '' || !is_encrypted_setting($key)) {
            return $value;
        }
        // already decrypted cache path tries Crypt; if not encrypted, return as-is
        try {
            // heuristic: encrypted values are base64 and contain colon, try decrypt
            return Crypt::decryptString($value);
        } catch (\Throwable $e) {
            // value is plaintext (legacy) – return raw
            return $value;
        }
    }
}

if (!function_exists('encrypt_setting_value')) {
    function encrypt_setting_value(string $key, $value): string
    {
        $str = (string) $value;
        if (!is_encrypted_setting($key) || $str === '') {
            return $str;
        }
        try {
            return Crypt::encryptString($str);
        } catch (\Throwable $e) {
            return $str;
        }
    }
}

if (!function_exists('setting')) {
    /** Get a site setting from DB (request-cached, decrypted). */
    function setting(string $key, $default = null)
    {
        static $cache = null;
        if ($cache === null) {
            try {
                $raw = Setting::query()->pluck('setting_value', 'setting_key')->all();
                $cache = [];
                foreach ($raw as $k => $v) {
                    $cache[$k] = decrypt_setting_value($k, $v);
                }
            } catch (\Throwable $e) {
                $cache = [];
            }
        }
        // allow runtime override for testing
        if (array_key_exists($key, $cache) && $cache[$key] !== '' && $cache[$key] !== null) {
            return $cache[$key];
        }
        return $default;
    }
}

if (!function_exists('setting_raw')) {
    /** Get raw (encrypted) value directly from DB without decrypt – for admin display masking. */
    function setting_raw(string $key, $default = null)
    {
        try {
            $v = Setting::where('setting_key', $key)->value('setting_value');
            return $v !== null ? $v : $default;
        } catch (\Throwable $e) {
            return $default;
        }
    }
}

if (!function_exists('is_setting_encrypted')) {
    function is_setting_encrypted(string $key): bool
    {
        $raw = setting_raw($key, '');
        if ($raw === '' || !is_encrypted_setting($key)) return false;
        try {
            Crypt::decryptString($raw);
            return true;
        } catch (\Throwable $e) {
            return false;
        }
    }
}

if (!function_exists('update_setting')) {
    function update_setting(string $key, $value): void
    {
        $encrypted = encrypt_setting_value($key, $value);
        Setting::updateOrCreate(['setting_key' => $key], ['setting_value' => $encrypted]);
        // bust request cache by resetting static via reflection trick: not needed within same request as we update cache array if loaded
    }
}

if (!function_exists('mask_secret')) {
    function mask_secret(?string $value): string
    {
        $v = (string) $value;
        if ($v === '') return '— not set —';
        $len = mb_strlen($v);
        if ($len <= 8) return str_repeat('•', $len);
        return mb_substr($v, 0, 4) . str_repeat('•', max(4, $len - 8)) . mb_substr($v, -4);
    }
}

if (!function_exists('taka')) {
    function taka($amount): string
    {
        return '৳'.number_format((float) $amount, 0);
    }
}

if (!function_exists('fmt_num')) {
    function fmt_num($n): string
    {
        $n = (float) $n;
        if ($n >= 1000000) {
            return round($n / 1000000, 1).'M';
        }
        if ($n >= 1000) {
            return round($n / 1000, 1).'K';
        }

        return number_format($n);
    }
}

if (!function_exists('fmt_date')) {
    function fmt_date($d, bool $withTime = false): string
    {
        if (! $d) {
            return '—';
        }
        try {
            $c = $d instanceof \Carbon\Carbon ? $d : \Carbon\Carbon::parse($d);

            return $c->format($withTime ? 'd M Y, h:i A' : 'd M Y');
        } catch (\Throwable $e) {
            return '—';
        }
    }
}

if (!function_exists('badge')) {
    /** Small status badge HTML. */
    function badge(?string $text, string $type = 'info'): string
    {
        $text = (string) $text;
        $map = [
            'active' => 'success', 'success' => 'success', 'approved' => 'success', 'completed' => 'success',
            'answered' => 'success', 'open' => 'primary',
            'inactive' => 'gray', 'closed' => 'gray', 'user' => 'gray', 'cancelled' => 'gray',
            'expired' => 'danger', 'error' => 'danger', 'failed' => 'danger',
            'rejected' => 'danger', 'suspended' => 'danger',
            'pending' => 'warning', 'warning' => 'warning', 'verifying' => 'warning',
            'admin' => 'primary', 'primary' => 'primary', 'info' => 'info',
            'high' => 'danger', 'medium' => 'warning', 'low' => 'info',
        ];
        $cls = $map[strtolower($text)] ?? ($map[$type] ?? 'info');

        return '<span class="badge badge-'.e($cls).'">'.e(ucfirst($text)).'</span>';
    }
}

if (!function_exists('is_admin')) {
    function is_admin(): bool
    {
        return Auth::check() && Auth::user()->role === 'admin';
    }
}

if (!function_exists('order_status_badge')) {
    function order_status_badge(string $status): string
    {
        $labels = [
            'pending' => 'Pending Verification',
            'approved' => 'Success — Credits Added',
            'rejected' => 'Failed / Rejected',
            'expired' => 'Expired — Please Retry',
            'cancelled' => 'Cancelled',
        ];
        $label = $labels[$status] ?? ucfirst($status);
        return badge($label, $status);
    }
}
