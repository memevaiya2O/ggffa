<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AdminUserController extends Controller
{
    public function index()
    {
        return view('admin.admins', ['admins' => User::where('role', 'admin')->get()]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string|min:3|max:100',
            'email' => 'required|email|max:150|unique:users,email',
            'password' => 'required|string|min:6|max:100',
        ]);
        User::create(['name' => $data['name'], 'email' => $data['email'], 'phone' => '', 'password' => $data['password'], 'role' => 'admin', 'status' => 'active']);

        return back()->with('success', 'Admin added.');
    }

    public function demote(Request $request, User $user)
    {
        abort_if($user->id === $request->user()->id, 400, 'You cannot demote yourself.');
        $user->update(['role' => 'user']);

        return back()->with('success', 'Admin demoted to user.');
    }

    public function myPassword(Request $request)
    {
        $data = $request->validate(['current' => 'required', 'new' => 'required|string|min:6|max:100']);
        if (! Hash::check($data['current'], $request->user()->password)) {
            return back()->with('error', 'Current password wrong.');
        }
        $request->user()->update(['password' => $data['new']]);

        return back()->with('success', 'Your password changed.');
    }
}
