<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ApiLog;
use App\Models\ApiService;
use App\Models\Order;
use App\Models\ServiceKey;
use App\Models\User;

class DashboardController extends Controller
{
    public function index()
    {
        $total = ApiLog::count();
        $ok = ApiLog::where('status', 'success')->count();
        $chart = ApiLog::chart(14);
        $max = max(1, max(array_column($chart, 'total') ?: [1]));

        return view('admin.dashboard', [
            'users' => User::where('role', 'user')->count(),
            'admins' => User::where('role', 'admin')->count(),
            'keys' => ServiceKey::count(),
            'services' => ApiService::active()->count(),
            'today' => ApiLog::whereDate('created_at', today())->count(),
            'total' => $total,
            'rate' => $total ? round(($ok / $total) * 100, 1) : 100,
            'latency' => (int) (ApiLog::where('created_at', '>=', now()->subWeek())->avg('latency_ms') ?? 0),
            'pending' => Order::where('status', 'pending')->count(),
            'revenue' => (float) Order::where('status', 'approved')->sum('amount'),
            'revenueToday' => (float) Order::where('status', 'approved')->whereDate('reviewed_at', today())->sum('amount'),
            'chart' => $chart,
            'max' => $max,
            'recentLogs' => ApiLog::with(['user', 'service'])->latest('id')->take(8)->get(),
            'recentOrders' => Order::with(['user', 'package'])->latest()->take(5)->get(),
            'topSvc' => ApiService::withCount(['logs' => fn ($q) => $q->where('created_at', '>=', now()->subDays(30))])->orderByDesc('logs_count')->take(5)->get(),
            'topKeys' => ServiceKey::with(['user', 'service'])->orderByDesc('used_request')->take(5)->get(),
        ]);
    }
}
