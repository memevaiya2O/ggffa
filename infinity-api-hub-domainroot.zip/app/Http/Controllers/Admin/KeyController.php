<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ApiService;
use App\Models\ServiceKey;
use App\Models\User;
use Illuminate\Http\Request;

class KeyController extends Controller
{
    public function index(Request $request)
    {
        $q = ServiceKey::with(['user', 'service'])->latest();
        if ($s = trim($request->query('q', ''))) {
            $q->where(fn ($w) => $w->where('api_key', 'like', "%{$s}%")->orWhere('label', 'like', "%{$s}%")
                ->orWhereHas('user', fn ($u) => $u->where('email', 'like', "%{$s}%")->orWhere('name', 'like', "%{$s}%")));
        }
        if ($st = $request->query('status', '')) {
            $q->where('status', $st);
        }
        if ($svc = (int) $request->query('svc', 0)) {
            $q->where('service_id', $svc);
        }

        return view('admin.keys.index', [
            'keys' => $q->paginate(15)->withQueryString(),
            'services' => ApiService::orderBy('name')->get(),
        ]);
    }

    public function create()
    {
        return view('admin.keys.form', [
            'key' => new ServiceKey(),
            'services' => ApiService::orderBy('name')->get(),
        ]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'email' => 'required|email|exists:users,email',
            'service_id' => 'required|exists:api_services,id',
            'label' => 'required|string|max:60',
            'quota' => 'required|integer|min:0|max:100000000',
            'exp_date' => 'required|date',
            'custom' => 'nullable|string|min:6|max:100',
        ]);
        $user = User::where('email', $data['email'])->first();
        $service = ApiService::findOrFail($data['service_id']);

        if (ServiceKey::where('user_id', $user->id)->where('service_id', $service->id)->exists()) {
            return back()->with('error', 'This user already has a key for '.$service->name.'.')->withInput();
        }
        if (! empty($data['custom']) && ServiceKey::where('api_key', strtoupper(trim($data['custom'])))->exists()) {
            return back()->with('error', 'Custom key already exists.')->withInput();
        }

        $key = ServiceKey::create([
            'user_id' => $user->id,
            'service_id' => $service->id,
            'api_key' => ! empty($data['custom']) ? strtoupper(trim($data['custom'])) : ServiceKey::generateFor($service),
            'label' => $data['label'],
            'total_request' => $data['quota'],
            'used_request' => 0,
            'exp_date' => $data['exp_date'],
            'status' => 'active',
        ]);

        return redirect()->route('admin.keys.edit', $key)->with('success', 'Key created: '.$key->api_key);
    }

    public function edit(ServiceKey $key)
    {
        return view('admin.keys.form', [
            'key' => $key->load(['user', 'service']),
            'services' => ApiService::orderBy('name')->get(),
        ]);
    }

    public function update(Request $request, ServiceKey $key)
    {
        $data = $request->validate([
            'label' => 'required|string|max:60',
            'total_request' => 'required|integer|min:0|max:100000000',
            'used_request' => 'required|integer|min:0|max:100000000',
            'exp_date' => 'nullable|date',
            'status' => 'required|in:active,inactive,expired',
        ]);
        $key->update($data);

        return back()->with('success', 'Key updated.');
    }

    public function destroy(ServiceKey $key)
    {
        $key->delete();

        return redirect()->route('admin.keys')->with('success', 'Key deleted.');
    }

    public function regenerate(ServiceKey $key)
    {
        $key->update(['api_key' => ServiceKey::generateFor($key->service)]);

        return back()->with('success', 'Key regenerated: '.$key->api_key);
    }
}
