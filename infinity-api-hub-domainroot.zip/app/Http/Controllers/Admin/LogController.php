<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ApiLog;
use App\Models\ApiService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class LogController extends Controller
{
    protected function filtered(Request $request)
    {
        $q = ApiLog::with(['user', 'key', 'service'])->latest('id');
        if ($s = trim($request->query('q', ''))) {
            $q->where(fn ($w) => $w->where('param_summary', 'like', "%{$s}%")->orWhere('ip', 'like', "%{$s}%")
                ->orWhereHas('key', fn ($k) => $k->where('api_key', 'like', "%{$s}%"))
                ->orWhereHas('user', fn ($u) => $u->where('email', 'like', "%{$s}%")));
        }
        if ($st = $request->query('status', '')) {
            $q->where('status', $st);
        }
        if ($svc = (int) $request->query('svc', 0)) {
            $q->where('service_id', $svc);
        }

        return $q;
    }

    public function index(Request $request)
    {
        return view('admin.logs', [
            'logs' => $this->filtered($request)->paginate(20)->withQueryString(),
            'services' => ApiService::orderBy('name')->get(),
        ]);
    }

    public function nagorikpay(Request $request)
    {
        $q = DB::table('nagorikpay_logs')->orderByDesc('id');
        if ($s = trim($request->query('q', ''))) {
            $q->where(function ($w) use ($s) {
                $w->where('transaction_id', 'like', "%{$s}%")
                  ->orWhere('url', 'like', "%{$s}%")
                  ->orWhere('type', 'like', "%{$s}%");
            });
        }
        if ($type = $request->query('type', '')) {
            $q->where('type', $type);
        }
        $logs = $q->paginate(20)->withQueryString();
        return view('admin.nagorikpay-logs', compact('logs'));
    }

    public function export(Request $request)
    {
        $rows = $this->filtered($request)->take(5000)->get();
        $csv = "ID,Date,User,API Key,Service,Params,IP,Status,HTTP,Latency(ms),Credits,Source\n";
        foreach ($rows as $r) {
            $csv .= implode(',', array_map(fn ($v) => '"'.str_replace('"', '""', (string) $v).'"', [
                $r->id, $r->created_at, $r->user?->email, $r->key?->api_key, $r->service?->name,
                $r->param_summary, $r->ip, $r->status, $r->response_code, $r->latency_ms, $r->credits_used, $r->source,
            ]))."\n";
        }

        return response($csv, 200, [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => 'attachment; filename="api-logs-'.date('Y-m-d').'.csv"',
        ]);
    }

    public function clear(Request $request)
    {
        $days = max(1, (int) $request->input('days', 30));
        $n = ApiLog::where('created_at', '<', now()->subDays($days))->delete();

        return back()->with('success', "Deleted {$n} log(s) older than {$days} days.");
    }
}
