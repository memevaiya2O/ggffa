<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Notification;
use Illuminate\Http\Request;

class NotificationController extends Controller
{
    public function index()
    {
        return view('admin.notifications', [
            'list' => Notification::latest()->get(),
            'n' => new Notification(['type' => 'info', 'target' => 'all', 'status' => 'active']),
        ]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'title' => 'required|string|max:200',
            'message' => 'required|string|max:5000',
            'type' => 'required|in:info,success,warning,error',
            'target' => 'required|in:all,users',
        ]);
        $data['status'] = 'active';
        Notification::create($data);

        return back()->with('success', 'Notification published.');
    }

    public function edit(Notification $notification)
    {
        return view('admin.notifications', [
            'list' => Notification::latest()->get(),
            'n' => $notification,
        ]);
    }

    public function update(Request $request, Notification $notification)
    {
        $notification->update($request->validate([
            'title' => 'required|string|max:200',
            'message' => 'required|string|max:5000',
            'type' => 'required|in:info,success,warning,error',
            'target' => 'required|in:all,users',
            'status' => 'required|in:active,inactive',
        ]));

        return redirect()->route('admin.notifications')->with('success', 'Notification updated.');
    }

    public function destroy(Notification $notification)
    {
        $notification->delete();

        return back()->with('success', 'Notification deleted.');
    }
}
