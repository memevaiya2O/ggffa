<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Services\NagorikPayGateway;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function index(Request $request)
    {
        $q = Order::with(['user', 'package', 'service'])->latest();
        if ($st = $request->query('status', '')) {
            $q->where('status', $st);
        }
        if ($s = trim($request->query('q', ''))) {
            $q->where(fn ($w) => $w->where('txn_id', 'like', "%{$s}%")
                ->orWhere('nagorikpay_txn', 'like', "%{$s}%")
                ->orWhereHas('user', fn ($u) => $u->where('email', 'like', "%{$s}%")->orWhere('name', 'like', "%{$s}%")));
        }

        return view('admin.orders', [
            'orders' => $q->paginate(15)->withQueryString(),
            'revenue' => (float) Order::where('status', 'approved')->sum('amount'),
            'revenueToday' => (float) Order::where('status', 'approved')->whereDate('reviewed_at', today())->sum('amount'),
        ]);
    }

    public function approve(Request $request, Order $order)
    {
        [$ok, $msg] = $order->approve(trim($request->input('note', '')));

        return back()->with($ok ? 'success' : 'error', $msg);
    }

    public function reject(Request $request, Order $order)
    {
        $order->reject(trim($request->input('note', '')));

        return back()->with('success', 'Order rejected.');
    }

    public function recheck(Request $request, Order $order)
    {
        if ($order->payment_method !== 'nagorikpay') {
            return back()->with('error', 'Only NagorikPay orders can be rechecked.');
        }
        $tx = trim($order->txn_id ?: $order->nagorikpay_txn);
        if ($tx === '' || str_starts_with($tx, 'NP-PENDING') || str_starts_with($tx, 'NP-ORDER')) {
            return back()->with('error', 'No gateway transaction ID yet – customer may not have completed payment.');
        }

        [$verified, $payload, $httpStatus, $isCompleted] = NagorikPayGateway::verify($tx);

        if ($verified && $isCompleted) {
            [$ok, $msg] = \App\Models\Order::completeViaGateway($order->id, $tx, 'Admin recheck verified '.$tx);
            if ($ok) return back()->with('success', 'Payment verified and credits added.');
            return back()->with('warning', $msg);
        }
        if ($verified && !$isCompleted) {
            return back()->with('warning', 'Gateway says pending – will auto-complete when funds confirm.');
        }
        $msg = is_array($payload) ? ($payload['message'] ?? 'Verification failed') : 'Gateway unreachable';
        return back()->with('error', 'Recheck failed: '.$msg.' (HTTP '.$httpStatus.')');
    }

    public function expire(Request $request, Order $order)
    {
        if ($order->status !== 'pending') {
            return back()->with('error', 'Only pending orders can be expired.');
        }
        $order->expire();
        return back()->with('success', 'Order marked as expired.');
    }
}
