<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ApiService;
use App\Models\Package;
use Illuminate\Http\Request;

class PackageController extends Controller
{
    public function index(Request $request)
    {
        $q = Package::with('service')->orderBy('sort_order')->orderBy('price');
        if ($svc = (int) $request->query('svc', 0)) {
            $q->where('service_id', $svc);
        }

        return view('admin.packages.index', [
            'packages' => $q->get(),
            'services' => ApiService::orderBy('name')->get(),
        ]);
    }

    public function pricing(ApiService $service)
    {
        return view('admin.services.pricing', [
            'service' => $service,
            'packages' => $service->packages()->orderBy('sort_order')->orderBy('price')->get(),
        ]);
    }

    public function pricingCreate(ApiService $service)
    {
        return view('admin.packages.form', [
            'package' => new Package(['service_id' => $service->id]),
            'services' => collect([$service]),
            'pricingService' => $service,
        ]);
    }

    public function pricingStore(Request $request, ApiService $service)
    {
        $request->merge(['service_id' => $service->id]);
        Package::create($this->validated($request));

        return redirect()->route('admin.services.pricing', $service)->with('success', 'Product price card created.');
    }

    public function pricingEdit(ApiService $service, Package $package)
    {
        abort_unless((int) $package->service_id === (int) $service->id, 404);

        return view('admin.packages.form', [
            'package' => $package,
            'services' => collect([$service]),
            'pricingService' => $service,
        ]);
    }

    public function pricingUpdate(Request $request, ApiService $service, Package $package)
    {
        abort_unless((int) $package->service_id === (int) $service->id, 404);
        $request->merge(['service_id' => $service->id]);
        $package->update($this->validated($request));

        return redirect()->route('admin.services.pricing', $service)->with('success', 'Product price card updated.');
    }

    public function pricingDestroy(ApiService $service, Package $package)
    {
        abort_unless((int) $package->service_id === (int) $service->id, 404);
        $package->delete();

        return back()->with('success', 'Product price card deleted.');
    }

    public function create()
    {
        return view('admin.packages.form', ['package' => new Package(), 'services' => ApiService::orderBy('name')->get()]);
    }

    public function store(Request $request)
    {
        Package::create($this->validated($request));

        return redirect()->route('admin.packages')->with('success', 'Package created.');
    }

    public function edit(Package $package)
    {
        return view('admin.packages.form', ['package' => $package, 'services' => ApiService::orderBy('name')->get()]);
    }

    public function update(Request $request, Package $package)
    {
        $package->update($this->validated($request));

        return back()->with('success', 'Package updated.');
    }

    public function destroy(Package $package)
    {
        $package->delete();

        return back()->with('success', 'Package deleted.');
    }

    protected function validated(Request $request): array
    {
        $data = $request->validate([
            'service_id' => 'required|exists:api_services,id',
            'name' => 'required|string|max:100',
            'price' => 'required|numeric|min:0|max:10000000',
            'requests' => 'required|integer|min:1|max:100000000',
            'validity_days' => 'required|integer|min:1|max:3650',
            'features' => 'nullable|string',
            'highlight' => 'nullable|boolean',
            'status' => 'required|in:active,inactive',
            'sort_order' => 'nullable|integer|min:0|max:9999',
        ]);
        $data['highlight'] = (bool) ($data['highlight'] ?? false);
        $data['sort_order'] = (int) ($data['sort_order'] ?? 0);

        return $data;
    }
}
