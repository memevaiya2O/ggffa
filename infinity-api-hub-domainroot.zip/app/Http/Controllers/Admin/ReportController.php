<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ApiLog;
use App\Models\ApiService;
use App\Models\Order;
use Illuminate\Support\Facades\DB;

class ReportController extends Controller
{
    public function index()
    {
        $services = ApiService::withCount(['keys', 'logs'])->orderBy('name')->get();

        $sales = Order::where('status', 'approved')
            ->select('service_id', DB::raw('COUNT(*) orders'), DB::raw('SUM(amount) revenue'))
            ->groupBy('service_id')->get()->keyBy('service_id');

        $hits30 = ApiLog::where('created_at', '>=', now()->subDays(30))
            ->select('service_id', DB::raw('COUNT(*) hits'), DB::raw('AVG(latency_ms) ms'))
            ->groupBy('service_id')->get()->keyBy('service_id');

        $daily = Order::where('status', 'approved')->where('reviewed_at', '>=', now()->subDays(14))
            ->select(DB::raw('DATE(reviewed_at) d'), DB::raw('SUM(amount) revenue'))
            ->groupBy('d')->pluck('revenue', 'd')->all();
        $chart = [];
        for ($i = 13; $i >= 0; $i--) {
            $d = today()->subDays($i);
            $chart[] = ['label' => $d->format('d M'), 'total' => (float) ($daily[$d->toDateString()] ?? 0)];
        }

        return view('admin.reports', compact('services', 'sales', 'hits30', 'chart'));
    }
}
