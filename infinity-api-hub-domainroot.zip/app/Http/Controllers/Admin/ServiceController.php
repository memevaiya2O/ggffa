<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ApiService;
use App\Models\ServiceKey;
use App\Models\User;
use App\Services\ProviderGateway;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class ServiceController extends Controller
{
    public function index()
    {
        return view('admin.services.index', [
            'services' => ApiService::withCount('keys')->orderBy('sort_order')->orderBy('id')->get(),
        ]);
    }

    public function create()
    {
        return view('admin.services.form', ['service' => new ApiService()]);
    }

    public function store(Request $request)
    {
        $data = $this->validated($request);
        $service = ApiService::create($data);

        return redirect()->route('admin.services.edit', $service)->with('success', 'Service created! Test it now.');
    }

    public function edit(ApiService $service)
    {
        return view('admin.services.form', compact('service'));
    }

    public function update(Request $request, ApiService $service)
    {
        $service->update($this->validated($request, $service->id));

        return back()->with('success', 'Service updated.');
    }

    public function destroy(ApiService $service)
    {
        $service->delete();

        return redirect()->route('admin.services')->with('success', 'Service deleted.');
    }

    public function toggle(ApiService $service)
    {
        $service->update(['status' => $service->status === 'active' ? 'inactive' : 'active']);

        return back()->with('success', 'Service '.$service->status.'.');
    }

    public function testForm(ApiService $service)
    {
        return view('admin.services.test', ['service' => $service, 'result' => null]);
    }

    public function testRun(Request $request, ApiService $service)
    {
        $input = [];
        foreach ($service->paramList() as $p) {
            $v = trim((string) $request->input('p.'.$p['name'], ''));
            if ($v !== '') {
                $input[$p['name']] = $v;
            }
        }
        [$code, $body, $ms, $err] = ProviderGateway::request($service, $input);
        $decoded = json_decode($body, true);
        $pretty = json_last_error() === JSON_ERROR_NONE
            ? json_encode($decoded, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
            : $body;

        return view('admin.services.test', [
            'service' => $service,
            'result' => ['code' => $code, 'ms' => $ms, 'body' => $pretty, 'err' => $err, 'ok' => ($code === 200 && $err === '')],
        ]);
    }

    /** Issue keys to all users missing this service. */
    public function issueAll(ApiService $service)
    {
        $quota = (int) ($service->free_quota ?? setting('service_free_quota', 25));
        $valid = (int) setting('signup_validity', 30);
        $n = 0;
        $have = ServiceKey::where('service_id', $service->id)->pluck('user_id')->all();
        foreach (User::where('role', 'user')->whereNotIn('id', $have)->cursor() as $user) {
            ServiceKey::issue($user, $service, $quota, today()->addDays($valid)->toDateString());
            $n++;
        }

        return back()->with('success', "Issued keys to {$n} user(s).");
    }

    protected function validated(Request $request, ?int $ignoreId = null): array
    {
        $data = $request->validate([
            'name' => 'required|string|max:150',
            'slug' => ['required', 'alpha_dash', 'max:100', Rule::unique('api_services', 'slug')->ignore($ignoreId)],
            'description' => 'nullable|string|max:255',
            'docs_use_cases' => 'nullable|string|max:10000',
            'icon' => 'nullable|string|max:60',
            'provider_url' => 'required|string|max:2000',
            'provider_source' => 'required|in:file_manager,subdomain,external_api',
            'method' => 'required|in:GET,POST',
            'headers' => 'nullable|string',
            'provider_key' => 'nullable|string|max:255',
            'credits_per_hit' => 'required|integer|min:1|max:100000',
            'credit_price' => 'required|numeric|min:0.01|max:100000',
            'free_quota' => 'required|integer|min:0|max:10000000',
            'status' => 'required|in:active,inactive',
            'show_on_home' => 'nullable|boolean',
            'sort_order' => 'nullable|integer|min:0|max:9999',
            'docs_text' => 'nullable|string',
            'docs_markdown' => 'nullable|string',
            'sample_response' => 'nullable|string',
            'docs_rate_limit' => 'nullable|string|max:100',
            'docs_error_codes' => 'nullable|string',
            'p_name' => 'nullable|array',
            'p_name.*' => 'nullable|string|max:60',
            'p_label' => 'nullable|array',
            'p_req' => 'nullable|array',
            'p_ph' => 'nullable|array',
            'p_example' => 'nullable|array',
        ]);

        $params = [];
        foreach (($request->input('p_name', [])) as $i => $nm) {
            $nm = trim(preg_replace('/[^a-zA-Z0-9_]/', '', (string) $nm));
            if ($nm === '') {
                continue;
            }
            $params[] = [
                'name' => $nm,
                'label' => trim((string) ($request->input('p_label', [])[$i] ?? $nm)),
                'required' => isset($request->input('p_req', [])[$i]) ? 1 : 0,
                'placeholder' => trim((string) ($request->input('p_ph', [])[$i] ?? '')),
            ];
        }
        $headers = array_values(array_filter(array_map('trim', explode("\n", (string) ($data['headers'] ?? '')))));

        // Parse error codes textarea: each line as code|message|description or JSON
        $errorCodesRaw = trim((string) ($data['docs_error_codes'] ?? ''));
        $errorCodes = null;
        if ($errorCodesRaw !== '') {
            $decoded = json_decode($errorCodesRaw, true);
            if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                $errorCodes = $decoded;
            } else {
                $errorCodes = [];
                foreach (explode("\n", $errorCodesRaw) as $line) {
                    $line = trim($line);
                    if ($line === '') continue;
                    $parts = explode('|', $line, 3);
                    $errorCodes[] = [
                        'code' => trim($parts[0] ?? ''),
                        'message' => trim($parts[1] ?? ''),
                        'description' => trim($parts[2] ?? ''),
                    ];
                }
            }
        }

        // Example params: from p_example or fallback to placeholder
        $exampleParams = [];
        foreach ($params as $i => $p) {
            $ex = trim((string) ($request->input('p_example', [])[$i] ?? $p['placeholder'] ?? ''));
            if ($ex === '' || strlen($ex) > 64) $ex = $p['placeholder'] ?: '123456';
            $exampleParams[$p['name']] = $ex;
        }

        return [
            'name' => $data['name'],
            'slug' => strtolower(trim($data['slug'])),
            'description' => $data['description'] ?? '',
            'docs_use_cases' => trim((string) ($data['docs_use_cases'] ?? '')),
            'icon' => ($data['icon'] ?? '') !== '' ? $data['icon'] : 'fa-plug',
            'provider_url' => trim($data['provider_url']),
            'provider_source' => $data['provider_source'],
            'method' => $data['method'],
            'headers' => $headers,
            'provider_key' => trim($data['provider_key'] ?? ''),
            'params' => $params,
            'credits_per_hit' => $data['credits_per_hit'],
            'credit_price' => $data['credit_price'],
            'free_quota' => $data['free_quota'],
            'status' => $data['status'],
            'show_on_home' => (bool) ($data['show_on_home'] ?? false),
            'sort_order' => (int) ($data['sort_order'] ?? 0),
            'docs_text' => $data['docs_text'] ?? '',
            'docs_markdown' => $data['docs_markdown'] ?? $data['docs_text'] ?? '',
            'sample_response' => $data['sample_response'] ?? '',
            'docs_rate_limit' => $data['docs_rate_limit'] ?? '',
            'docs_error_codes' => $errorCodes,
            'docs_example_params' => $exampleParams,
        ];
    }
}
