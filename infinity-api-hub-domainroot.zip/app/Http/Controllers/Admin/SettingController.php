<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Services\NagorikPayGateway;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class SettingController extends Controller
{
    public function index(Request $request)
    {
        return view('admin.settings', ['tab' => $request->query('tab', 'general')]);
    }

    public function update(Request $request)
    {
        $vals = $request->input('s', []);
        foreach ($vals as $k => $v) {
            $k = preg_replace('/[^a-z0-9_]/', '', (string) $k);
            if ($k === '') {
                continue;
            }
            // For encrypted fields, ignore if masked placeholder sent (••••) and empty mask means not changed
            if (is_encrypted_setting($k)) {
                $incoming = is_string($v) ? trim($v) : $v;
                // If admin left the masked value (contains •) or empty and a value already exists, skip update
                if ($incoming === '' || str_contains($incoming, '•')) {
                    // If field was submitted as empty, don't overwrite existing encrypted value with empty unless explicitly clearing
                    // Check if they intended to clear: only clear if they submitted empty and we treat empty as clear
                    // For secrets, empty *should not* clear unless they click clear button – so skip
                    if ($incoming === '' && setting_raw($k, '') !== '') {
                        continue;
                    }
                }
                // Also skip if value is the masked placeholder
                if ($incoming !== '' && $incoming === mask_secret(setting($k, ''))) {
                    continue;
                }
            }
            update_setting($k, is_string($v) ? trim($v) : $v);
        }
        // unchecked checkboxes
        foreach (['registration_open', 'maintenance_mode'] as $cb) {
            if ($request->has('cb_'.$cb)) {
                update_setting($cb, $request->has("s.{$cb}") ? '1' : '0');
            }
        }

        // Handle NagorikPay mode toggle separately – ensure base URL consistency hint
        if ($request->has('s.nagorikpay_mode')) {
            $mode = strtolower(trim($request->input('s.nagorikpay_mode', '')));
            if (!in_array($mode, ['live','sandbox'], true)) $mode = 'sandbox';
            update_setting('nagorikpay_mode', $mode);
            // If base_url empty, set sensible default per mode
            $currentBase = trim((string) setting('nagorikpay_base_url', ''));
            if ($currentBase === '') {
                update_setting('nagorikpay_base_url', $mode === 'live' ? NagorikPayGateway::LIVE_BASE : NagorikPayGateway::SANDBOX_BASE);
            }
        }

        // Also handle explicit nagorikpay_enabled as checkbox-like
        if ($request->has('s.nagorikpay_enabled')) {
            $val = $request->input('s.nagorikpay_enabled');
            update_setting('nagorikpay_enabled', $val === '1' ? '1' : '0');
        }

        // Bust setting cache for this request – since helpers use static cache, we need to reset via reflection
        // Simplest: clear by not relying on cache after redirect – next request will reload.

        return back()->with('success', 'Settings saved.');
    }

    public function logo(Request $request)
    {
        $request->validate(['logo' => 'required|image|mimes:jpg,jpeg,png,webp,gif|max:2048']);
        $old = setting('logo', '');
        if ($old && file_exists(public_path('uploads/'.$old))) {
            @unlink(public_path('uploads/'.$old));
        }
        $name = 'logo_'.time().'_'.Str::random(6).'.'.$request->file('logo')->getClientOriginalExtension();
        $request->file('logo')->move(public_path('uploads'), $name);
        update_setting('logo', $name);

        return back()->with('success', 'Logo updated.');
    }

    public function logoRemove()
    {
        $old = setting('logo', '');
        if ($old && file_exists(public_path('uploads/'.$old))) {
            @unlink(public_path('uploads/'.$old));
        }
        update_setting('logo', '');

        return back()->with('success', 'Logo removed.');
    }

    public function icon(Request $request)
    {
        $request->validate(['icon' => 'required|file|mimes:jpg,jpeg,png,webp,gif,ico|max:1024']);
        $old = setting('site_icon', '');
        if ($old && file_exists(public_path('uploads/'.$old))) @unlink(public_path('uploads/'.$old));
        $name = 'icon_'.time().'_'.Str::random(6).'.'.$request->file('icon')->getClientOriginalExtension();
        $request->file('icon')->move(public_path('uploads'), $name);
        update_setting('site_icon', $name);
        return back()->with('success', 'Site icon updated.');
    }

    public function iconRemove()
    {
        $old = setting('site_icon', '');
        if ($old && file_exists(public_path('uploads/'.$old))) @unlink(public_path('uploads/'.$old));
        update_setting('site_icon', '');
        return back()->with('success', 'Site icon removed.');
    }

    public function footerLogo(Request $request)
    {
        $request->validate(['footer_logo' => 'required|image|mimes:jpg,jpeg,png,webp,gif|max:2048']);
        $old = setting('footer_logo', '');
        if ($old && file_exists(public_path('uploads/'.$old))) {
            @unlink(public_path('uploads/'.$old));
        }
        $name = 'footer_'.time().'_'.Str::random(6).'.'.$request->file('footer_logo')->getClientOriginalExtension();
        $request->file('footer_logo')->move(public_path('uploads'), $name);
        update_setting('footer_logo', $name);

        return back()->with('success', 'Footer logo updated.');
    }

    public function footerLogoRemove()
    {
        $old = setting('footer_logo', '');
        if ($old && file_exists(public_path('uploads/'.$old))) {
            @unlink(public_path('uploads/'.$old));
        }
        update_setting('footer_logo', '');

        return back()->with('success', 'Footer logo removed.');
    }

    public function clearNagorikPayKey(Request $request)
    {
        $key = preg_replace('/[^a-z0-9_]/', '', (string) $request->input('key', ''));
        if (is_encrypted_setting($key)) {
            update_setting($key, '');
            return back()->with('success', 'Credential cleared.');
        }
        return back()->with('error', 'Invalid key.');
    }

    public function backup()
    {
        $driver = DB::getDriverName();
        $sql = '-- INFINITY API HUB Backup ('.$driver.') — '.now()->toDateTimeString()."\n\n";

        if ($driver === 'mysql') {
            $tables = array_map('current', DB::select('SHOW TABLES'));
            $sql .= "SET FOREIGN_KEY_CHECKS=0;\n\n";
            foreach ($tables as $table) {
                $create = (array) DB::selectOne("SHOW CREATE TABLE `{$table}`");
                $sql .= 'DROP TABLE IF EXISTS `'.$table."`;\n".($create['Create Table'] ?? '').";\n\n";
                DB::table($table)->orderByRaw('1')->chunk(200, function ($rows) use ($table, &$sql) {
                    $rows = $rows->map(fn ($r) => (array) $r)->all();
                    if (! $rows) {
                        return;
                    }
                    $cols = '`'.implode('`, `', array_keys($rows[0])).'`';
                    $vals = [];
                    foreach ($rows as $r) {
                        $vals[] = '('.implode(', ', array_map(fn ($v) => $v === null ? 'NULL' : "'".str_replace(["\\", "'"], ["\\\\", "\\'"], (string) $v)."'", array_values($r))).')';
                    }
                    $sql .= "INSERT INTO `{$table}` ({$cols}) VALUES\n".implode(",\n", $vals).";\n";
                });
                $sql .= "\n";
            }
            $sql .= "SET FOREIGN_KEY_CHECKS=1;\n";
        } else {
            foreach (['users', 'api_services', 'service_keys', 'packages', 'orders', 'api_logs', 'notifications', 'settings', 'tickets', 'ticket_replies', 'nagorikpay_logs', 'invoices'] as $table) {
                try {
                    $rows = DB::table($table)->get()->map(fn ($r) => (array) $r)->all();
                } catch (\Throwable $e) {
                    continue;
                }
                $sql .= "-- TABLE: {$table} (".count($rows)." rows)\n";
                if (!count($rows)) { $sql .= "\n"; continue; }
                foreach (array_chunk($rows, 200) as $chunk) {
                    $cols = '"'.implode('", "', array_keys($chunk[0])).'"';
                    $vals = [];
                    foreach ($chunk as $r) {
                        $vals[] = '('.implode(', ', array_map(fn ($v) => $v === null ? 'NULL' : "'".str_replace("'", "''", (string) $v)."'", array_values($r))).')';
                    }
                    $sql .= "INSERT INTO \"{$table}\" ({$cols}) VALUES\n".implode(",\n", $vals).";\n";
                }
                $sql .= "\n";
            }
        }

        return response($sql, 200, [
            'Content-Type' => 'application/sql',
            'Content-Disposition' => 'attachment; filename="infinity-backup-'.date('Y-m-d-His').'.sql"',
        ]);
    }
}
