<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Ticket;
use Illuminate\Http\Request;

class TicketController extends Controller
{
    public function index(Request $request)
    {
        $q = Ticket::with(['user', 'service'])->latest();
        if ($st = $request->query('status', '')) {
            $q->where('status', $st);
        }

        return view('admin.tickets.index', ['tickets' => $q->paginate(15)->withQueryString()]);
    }

    public function show(Ticket $ticket)
    {
        return view('admin.tickets.show', ['ticket' => $ticket->load(['replies.user', 'user', 'service'])]);
    }

    public function reply(Request $request, Ticket $ticket)
    {
        $data = $request->validate(['message' => 'required|string|max:5000']);
        $ticket->replies()->create(['user_id' => $request->user()->id, 'is_admin' => true, 'message' => $data['message']]);
        $ticket->update(['status' => 'answered']);

        return back()->with('success', 'Reply sent.');
    }

    public function status(Request $request, Ticket $ticket)
    {
        $data = $request->validate(['status' => 'required|in:open,answered,closed']);
        $ticket->update(['status' => $data['status']]);

        return back()->with('success', 'Ticket '.$data['status'].'.');
    }
}
