<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Notification;
use App\Models\ServiceKey;
use App\Models\User;
use Illuminate\Http\Request;

class UserController extends Controller
{
    public function index(Request $request)
    {
        $q = User::withSum('keys as quota_total', 'total_request')
            ->withSum('keys as quota_used', 'used_request')
            ->latest();
        if ($s = trim($request->query('q', ''))) {
            $q->where(fn ($w) => $w->where('name', 'like', "%{$s}%")->orWhere('email', 'like', "%{$s}%")->orWhere('phone', 'like', "%{$s}%"));
        }
        if (in_array($request->query('status'), ['active', 'suspended'], true)) $q->where('status', $request->query('status'));
        if (in_array($request->query('role'), ['user', 'admin'], true)) $q->where('role', $request->query('role'));

        return view('admin.users.index', ['users' => $q->paginate(15)->withQueryString()]);
    }

    public function show(User $user)
    {
        return view('admin.users.show', [
            'u' => $user,
            'stats' => $user->stats(),
            'keys' => $user->keys()->with('service')->get(),
            'orders' => $user->orders()->with('package')->latest()->take(8)->get(),
            'notifications' => Notification::where('user_id', $user->id)->latest()->take(8)->get(),
            'wallet' => $user->wallet,
        ]);
    }

    public function toggleStatus(Request $request, User $user)
    {
        abort_if($user->id === $request->user()->id, 400, 'You cannot suspend yourself.');
        $user->update(['status' => $user->status === 'active' ? 'suspended' : 'active']);

        return back()->with('success', 'User status updated.');
    }

    public function toggleRole(Request $request, User $user)
    {
        abort_if($user->id === $request->user()->id, 400, 'You cannot change your own role.');
        $user->update(['role' => $user->role === 'admin' ? 'user' : 'admin']);

        return back()->with('success', 'User role updated.');
    }

    public function destroy(Request $request, User $user)
    {
        abort_if($user->id === $request->user()->id || $user->role === 'admin', 400, 'Cannot delete this user.');
        $user->delete();

        return redirect()->route('admin.users')->with('success', 'User deleted.');
    }

    public function resetPassword(Request $request, User $user)
    {
        $data = $request->validate(['newpass' => 'required|string|min:6|max:100']);
        $user->update(['password' => $data['newpass']]);

        return back()->with('success', 'Password reset successfully.');
    }

    public function bonus(Request $request, User $user)
    {
        $data = $request->validate([
            'key_id' => 'required|exists:service_keys,id',
            'qty' => 'required|integer|min:1|max:10000000',
            'days' => 'nullable|integer|min:0|max:3650',
        ]);
        $key = ServiceKey::findOrFail($data['key_id']);
        abort_unless($key->user_id === $user->id, 400);
        $key->addQuota($data['qty'], (int) ($data['days'] ?? 0));

        return back()->with('success', "Added {$data['qty']} credits to {$key->label}.");
    }

    public function notify(Request $request, User $user)
    {
        $data = $request->validate([
            'title' => 'required|string|max:200',
            'message' => 'required|string|max:5000',
            'type' => 'required|in:info,success,warning,error',
        ]);
        Notification::create($data + ['user_id' => $user->id, 'target' => 'users', 'status' => 'active']);
        return back()->with('success', 'Notification sent to '.$user->name.'.');
    }

    public function toggleKey(Request $request, User $user, ServiceKey $key)
    {
        abort_unless((int) $key->user_id === (int) $user->id, 404);
        $key->update(['status' => $key->status === 'active' ? 'inactive' : 'active']);
        return back()->with('success', 'API key status updated.');
    }

    public function regenerateKey(Request $request, User $user, ServiceKey $key)
    {
        abort_unless((int) $key->user_id === (int) $user->id, 404);
        $key->update(['api_key' => ServiceKey::generateFor($key->service)]);
        return back()->with('success', 'API key regenerated. The old key no longer works.');
    }
}
