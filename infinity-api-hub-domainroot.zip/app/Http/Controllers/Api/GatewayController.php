<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ApiLog;
use App\Models\ApiService;
use App\Models\ServiceKey;
use App\Services\ProviderGateway;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\RateLimiter;

class GatewayController extends Controller
{
    /**
     * Universal gateway: /api/{service}?api_key=KEY&param=...
     * Key also accepted via X-API-KEY / Authorization: Bearer / ?key= / ?token=
     * Includes IP-based throttling for invalid-key brute-force protection.
     */
    public function handle(Request $request, string $service)
    {
        // IP throttling: 60 req/min per IP (tunable via setting)
        $ip = $request->ip();
        $ipLimit = max(10, (int) setting('api_ip_rate_limit', 120));
        $ipKey = 'gw_ip:' . $ip;
        $ipHits = Cache::get($ipKey, 0);
        // Use simple counter; if we already handle via middleware, this is extra safety for brute-force
        // We'll enforce after key validation for invalid attempts

        $apiKey = trim($request->input('api_key', '') ?: $request->input('key', '') ?: $request->input('token', ''));
        if ($apiKey === '') {
            $apiKey = trim($request->header('X-API-KEY', ''));
        }
        if ($apiKey === '') {
            $bearer = trim($request->bearerToken() ?? '');
            $apiKey = $bearer;
        }
        if ($apiKey === '') {
            ApiLog::write(['summary' => $service, 'status' => 'error', 'snippet' => 'missing key', 'ip' => $ip]);
            $this->incrementIp($ip);
            return response()->json(['status' => 'error', 'message' => 'api_key is required.'], 400);
        }

        $svc = ApiService::where('slug', $service)->first();
        if (! $svc || $svc->status !== 'active') {
            ApiLog::write(['summary' => $service, 'status' => 'error', 'snippet' => 'unknown service', 'ip' => $ip]);
            return response()->json(['status' => 'error', 'message' => 'Unknown or disabled API.'], 404);
        }

        [$ok, $msg, $key] = ServiceKey::validate($apiKey, $svc->id);
        if (! $ok) {
            ApiLog::write([
                'user_id' => $key?->user_id, 'key_id' => $key?->id, 'service_id' => $svc->id,
                'summary' => $svc->slug, 'status' => 'error', 'snippet' => mb_substr($msg, 0, 200), 'ip' => $ip,
            ]);
            // IP throttling for invalid keys – prevent brute force
            $this->incrementIp($ip);
            if ($this->isIpThrottled($ip, $ipLimit)) {
                return response()->json(['status' => 'error', 'message' => 'Too many invalid attempts from this IP. Try again in a minute.'], 429);
            }
            return response()->json(['status' => 'error', 'message' => $msg], 401);
        }

        // Valid key – proceed, but still enforce IP overall limit (to prevent abuse even with valid key)
        if ($this->isIpThrottled($ip, $ipLimit)) {
            ApiLog::write(['user_id' => $key->user_id, 'key_id' => $key->id, 'service_id' => $svc->id, 'summary' => $svc->slug, 'status' => 'error', 'snippet' => 'ip rate limited', 'ip' => $ip]);
            return response()->json(['status' => 'error', 'message' => "IP rate limit exceeded. Max {$ipLimit} requests/minute per IP."], 429);
        }
        $this->incrementIp($ip); // count valid too for IP limit

        // Per-key rate limit (existing)
        $limit = max(1, (int) setting('api_rate_limit', 60));
        $hits = ApiLog::where('key_id', $key->id)->where('created_at', '>=', now()->subMinute())->count();
        if ($hits >= $limit) {
            ApiLog::write(['user_id' => $key->user_id, 'key_id' => $key->id, 'service_id' => $svc->id, 'summary' => $svc->slug, 'status' => 'error', 'snippet' => 'rate limited', 'ip' => $ip]);
            return response()->json(['status' => 'error', 'message' => "Rate limit exceeded. Max {$limit} requests/minute."], 429);
        }

        // Required params
        $params = [];
        foreach ($svc->paramList() as $p) {
            $v = trim((string) $request->input($p['name'], ''));
            if ($v === '' && ! empty($p['required'])) {
                ApiLog::write(['user_id' => $key->user_id, 'key_id' => $key->id, 'service_id' => $svc->id, 'summary' => $svc->slug, 'status' => 'error', 'snippet' => 'missing '.$p['name'], 'ip' => $ip]);
                return response()->json(['status' => 'error', 'message' => 'Missing required parameter: '.$p['name']], 400);
            }
            if ($v !== '') {
                $params[$p['name']] = $v;
            }
        }

        // Credits
        $credits = max(1, (int) $svc->credits_per_hit);
        if ($key->remaining() < $credits) {
            ApiLog::write(['user_id' => $key->user_id, 'key_id' => $key->id, 'service_id' => $svc->id, 'summary' => $svc->slug, 'status' => 'error', 'snippet' => 'no credits', 'ip' => $ip]);
            return response()->json(['status' => 'error', 'message' => 'Credit limit exceeded. Please top up this API key.'], 402);
        }

        [$httpCode, $body, $latency, $curlErr] = ProviderGateway::request($svc, $params);
        $summary = http_build_query(array_slice($params, 0, 3)) ?: $svc->slug;

        if ($httpCode === 200 && $curlErr === '' && $body !== '' && ! ProviderGateway::isAntiBotChallenge($body)) {
            $key->consume($credits);
            ApiLog::write([
                'user_id' => $key->user_id, 'key_id' => $key->id, 'service_id' => $svc->id,
                'summary' => $summary, 'status' => 'success', 'code' => $httpCode,
                'ms' => $latency, 'credits' => $credits, 'snippet' => $body, 'ip' => $ip,
            ]);

            $isJson = ($t = ltrim($body)) !== '' && ($t[0] === '{' || $t[0] === '[');

            return response($body, 200, [
                'Content-Type' => $isJson ? 'application/json; charset=utf-8' : 'text/plain; charset=utf-8',
                'X-Credits-Left' => (string) max(0, $key->fresh()->remaining()),
                'X-Response-Time' => $latency.'ms',
                'X-Powered-By' => (string) setting('site_name', 'INFINITY API HUB'),
                'Access-Control-Allow-Origin' => '*',
                'X-RateLimit-Limit' => (string) $limit,
                'X-RateLimit-Remaining' => (string) max(0, $limit - $hits - 1),
            ]);
        }

        $challenge = ProviderGateway::isAntiBotChallenge($body);
        $errMsg = $challenge
            ? 'Provider returned a browser verification page. Replace this provider with a direct JSON API endpoint.'
            : ($curlErr !== '' ? 'Provider connection failed.' : 'Provider returned HTTP '.$httpCode.'.');
        ApiLog::write([
            'user_id' => $key->user_id, 'key_id' => $key->id, 'service_id' => $svc->id,
            'summary' => $summary, 'status' => 'error', 'code' => $httpCode,
            'ms' => $latency, 'credits' => 0, 'snippet' => $challenge ? 'anti-bot challenge detected' : ($body ?: $curlErr), 'ip' => $ip,
        ]);

        return response()->json(['status' => 'error', 'message' => $errMsg], 502);
    }

    private function incrementIp(string $ip): void
    {
        $key = 'gw_ip:' . $ip;
        $resetKey = 'gw_ip_reset:' . $ip;
        $window = 60;
        $hits = Cache::get($key, 0);
        if ($hits === 0) {
            Cache::put($key, 1, $window);
            Cache::put($resetKey, time() + $window, $window);
        } else {
            Cache::increment($key);
        }
    }

    private function isIpThrottled(string $ip, int $limit): bool
    {
        $hits = (int) Cache::get('gw_ip:' . $ip, 0);
        $reset = (int) Cache::get('gw_ip_reset:' . $ip, 0);
        if ($reset && $reset < time()) {
            Cache::forget('gw_ip:' . $ip);
            Cache::forget('gw_ip_reset:' . $ip);
            return false;
        }
        return $hits >= $limit;
    }
}
