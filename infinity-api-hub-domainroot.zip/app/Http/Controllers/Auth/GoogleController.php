<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

class GoogleController extends Controller
{
    public function redirect(Request $request)
    {
        if (setting('google_oauth_enabled', '0') !== '1' || ! setting('google_client_id', '')) {
            return redirect()->route('login')->with('error', 'Google Login is not configured by the administrator yet.');
        }
        $state = Str::random(48);
        $request->session()->put('google_oauth_state', $state);
        $redirect = setting('google_redirect_url', route('google.callback')) ?: route('google.callback');
        $query = http_build_query([
            'client_id' => setting('google_client_id'),
            'redirect_uri' => $redirect,
            'response_type' => 'code',
            'scope' => 'openid email profile',
            'state' => $state,
            'access_type' => 'online',
            'prompt' => 'select_account',
        ]);
        return redirect()->away('https://accounts.google.com/o/oauth2/v2/auth?'.$query);
    }

    public function callback(Request $request)
    {
        if ($request->filled('error')) {
            return redirect()->route('login')->with('error', 'Google sign-in was cancelled or denied. Please try again.');
        }
        if (! $request->filled('code')) {
            return redirect()->route('login')->with('error', 'Google sign-in did not return an authorization code. Please try again.');
        }
        $state = (string) $request->session()->pull('google_oauth_state');
        if (! $state || ! hash_equals($state, (string) $request->query('state'))) {
            return redirect()->route('login')->with('error', 'Google Login session expired. Please try again.');
        }
        $redirect = setting('google_redirect_url', route('google.callback')) ?: route('google.callback');
        try {
            $tokenResponse = Http::asForm()->timeout(15)->post('https://oauth2.googleapis.com/token', [
                'code' => $request->query('code'),
                'client_id' => setting('google_client_id'),
                'client_secret' => setting('google_client_secret'),
                'redirect_uri' => $redirect,
                'grant_type' => 'authorization_code',
            ]);
            $token = $tokenResponse->json();
            $access = $token['access_token'] ?? '';
            if (! $access) {
                report(new \RuntimeException('Google token exchange failed: '.($token['error_description'] ?? $token['error'] ?? 'unknown provider response')));
                return redirect()->route('login')->with('error', 'Google sign-in could not be completed. Check the OAuth callback URL and Google Cloud credentials.');
            }
            $profile = Http::withToken($access)->timeout(15)->get('https://openidconnect.googleapis.com/v1/userinfo')->json();
            $email = strtolower(trim((string) ($profile['email'] ?? '')));
            if ($email === '' || empty($profile['email_verified'])) throw new \RuntimeException('Google email is not verified');
            $user = User::where('google_id', $profile['sub'] ?? '')->orWhere('email', $email)->first();
            if (! $user) {
                $user = User::create([
                    'name' => $profile['name'] ?? Str::before($email, '@'),
                    'email' => $email,
                    'password' => Str::random(64),
                    'role' => 'user',
                    'status' => 'active',
                    'google_id' => $profile['sub'] ?? null,
                ]);
            } else {
                $user->update(['google_id' => $profile['sub'] ?? $user->google_id, 'name' => $user->name ?: ($profile['name'] ?? Str::before($email, '@'))]);
            }
            Auth::login($user, true);
            $request->session()->regenerate();
            return redirect()->intended(route('user.dashboard'))->with('success', 'Signed in with Google.');
        } catch (\Throwable $e) {
            report($e);
            return redirect()->route('login')->with('error', 'Google sign-in could not be completed. Check the OAuth callback URL and Google Cloud credentials.');
        }
    }
}
