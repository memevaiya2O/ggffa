<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    public function show()
    {
        return view('auth.login');
    }

    public function login(Request $request)
    {
        $data = $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);

        if (! Auth::attempt($data, $request->boolean('remember'))) {
            return back()->withInput($request->only('email'))->with('error', 'Invalid email or password.');
        }

        $request->session()->regenerate();

        $user = Auth::user();
        if ($user->status !== 'active') {
            Auth::logout();

            return redirect()->route('login')->with('error', 'Your account is suspended. Contact support.');
        }

        // Force password change if flagged
        if ($user->must_change_password) {
            $target = $user->role === 'admin' ? route('admin.settings', ['tab' => 'security']) : route('user.profile');
            // But we prefer user.profile for password change; also allow admin to change via admin panel
            $target = route('user.profile');
            return redirect()->intended($target)->with('warning', 'For security, please change your default password before continuing. Your current password was flagged as insecure.');
        }

        return redirect()->intended($user->role === 'admin' ? route('admin.dashboard') : route('user.dashboard'))
            ->with('success', 'Welcome back, '.$user->name.'!');
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('home')->with('info', 'You have been logged out.');
    }
}
