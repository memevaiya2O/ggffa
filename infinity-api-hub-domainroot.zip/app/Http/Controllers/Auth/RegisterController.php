<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\ServiceKey;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rules\Password;

class RegisterController extends Controller
{
    public function show()
    {
        if (setting('registration_open', '1') !== '1') {
            return view('auth.closed');
        }

        return view('auth.register');
    }

    public function register(Request $request)
    {
        if (setting('registration_open', '1') !== '1') {
            abort(403, 'Registrations are closed.');
        }

        $data = $request->validate([
            'name' => 'required|string|min:3|max:100',
            'email' => 'required|email|max:150|unique:users,email',
            'phone' => 'nullable|string|max:30',
            'password' => ['required', 'confirmed', Password::min(6)],
        ]);

        $user = User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'phone' => $data['phone'] ?? '',
            'password' => $data['password'], // hashed via cast
            'role' => 'user',
            'status' => 'active',
        ]);

        // Auto-issue one API key per active service with signup bonus
        $n = ServiceKey::issueAllFor($user);

        Auth::login($user);

        return redirect()->route('user.dashboard')
            ->with('success', "Account created! {$n} API key(s) with ".setting('signup_bonus', 50).' bonus credits each are ready.');
    }
}
