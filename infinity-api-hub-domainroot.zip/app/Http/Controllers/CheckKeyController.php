<?php

namespace App\Http\Controllers;

use App\Models\ServiceKey;
use Illuminate\Http\Request;

class CheckKeyController extends Controller
{
    public function index()
    {
        return view('pages.check');
    }

    public function check(Request $request)
    {
        $request->validate(['api_key' => 'required|string|max:100']);
        $key = ServiceKey::with('service')->where('api_key', trim($request->api_key))->first();

        return view('pages.check', [
            'result' => $key,
            'searched' => true,
            'input' => trim($request->api_key),
        ])->with($key ? [] : ['error' => 'Key not found.']);
    }
}
