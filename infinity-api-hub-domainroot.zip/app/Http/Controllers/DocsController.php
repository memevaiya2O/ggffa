<?php

namespace App\Http\Controllers;

use App\Models\ApiService;
use App\Services\ProviderGateway;
use Illuminate\Http\Request;

class DocsController extends Controller
{
    public function index(Request $request)
    {
        $services = ApiService::active()->orderBy('sort_order')->orderBy('id')->get();

        return view('pages.docs', [
            'services' => $services,
            'rateLimit' => (int) setting('api_rate_limit', 60),
        ]);
    }

    /**
     * Live Try-It tester on docs page – gated by valid API key.
     * POST /docs/try with service_id, api_key, params...
     */
    public function try(Request $request)
    {
        $request->validate([
            'service_id' => 'required|exists:api_services,id',
            'api_key' => 'required|string|max:120',
        ]);

        $service = ApiService::findOrFail($request->input('service_id'));
        $apiKey = trim($request->input('api_key', ''));

        // Validate key belongs to this service
        [$ok, $msg, $key] = ServiceKey::validate($apiKey, $service->id);
        if (!$ok) {
            // Allow any valid key for trying – if not found in our DB, at least check format? But we require DB-validated
            return response()->json(['status' => 'error', 'message' => $msg], 401);
        }

        $input = [];
        foreach ($service->paramList() as $p) {
            $v = trim((string) $request->input('p.'.$p['name'], $request->input($p['name'], '')));
            if ($v === '' && !empty($p['required'])) {
                return response()->json(['status' => 'error', 'message' => 'Missing required param: '.$p['name']], 400);
            }
            if ($v !== '') $input[$p['name']] = $v;
        }

        $credits = max(1, (int) $service->credits_per_hit);
        if ($key->remaining() < $credits) {
            return response()->json(['status' => 'error', 'message' => 'Insufficient credits – please top up.'], 402);
        }

        [$code, $body, $ms, $err] = ProviderGateway::request($service, $input);

        // Log but don't consume credits for docs try? We do consume to mimic real call, but we can make it consume
        $success = ($code === 200 && $err === '' && $body !== '');
        if ($success) {
            $key->consume($credits);
            \App\Models\ApiLog::write([
                'user_id' => $key->user_id, 'key_id' => $key->id, 'service_id' => $service->id,
                'summary' => http_build_query(array_slice($input, 0, 3)) ?: $service->slug,
                'status' => 'success', 'code' => $code, 'ms' => $ms, 'credits' => $credits, 'snippet' => $body, 'source' => 'panel',
            ]);
        } else {
            \App\Models\ApiLog::write([
                'user_id' => $key->user_id, 'key_id' => $key->id, 'service_id' => $service->id,
                'summary' => http_build_query(array_slice($input, 0, 3)) ?: $service->slug,
                'status' => 'error', 'code' => $code, 'ms' => $ms, 'credits' => 0, 'snippet' => $body ?: $err, 'source' => 'panel',
            ]);
        }

        $isJson = ($t = ltrim($body)) !== '' && ($t[0] === '{' || $t[0] === '[');
        $pretty = $body;
        if (json_decode($body, true) !== null) {
            $pretty = json_encode(json_decode($body, true), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        }

        return response()->json([
            'status' => $success ? 'success' : 'error',
            'http_code' => $code,
            'latency' => $ms,
            'credits_used' => $success ? $credits : 0,
            'credits_left' => $key->fresh()->remaining(),
            'body' => $pretty,
            'raw' => $body,
            'is_json' => $isJson,
            'error' => $err,
        ]);
    }
}
