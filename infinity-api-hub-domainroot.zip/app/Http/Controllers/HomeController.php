<?php

namespace App\Http\Controllers;

use App\Models\ApiLog;
use App\Models\ApiService;
use App\Models\Notification;
use App\Models\Package;
use App\Models\User;

class HomeController extends Controller
{
    public function index()
    {
        $totalHits = ApiLog::count();
        $okHits = ApiLog::where('status', 'success')->count();

        return view('pages.home', [
            'services' => ApiService::active()->onHome()->orderBy('sort_order')->orderBy('id')->get(),
            'packages' => Package::active()->with('service')->orderBy('sort_order')->orderBy('price')->take(3)->get(),
            'notices' => Notification::active()->where('target', 'all')->latest()->take(1)->get(),
            'totalHits' => $totalHits,
            'totalUsers' => User::where('role', 'user')->count(),
            'totalSvc' => ApiService::active()->count(),
            'successRate' => $totalHits ? round(($okHits / $totalHits) * 100, 1) : 100,
            'heroTitle' => $this->heroTitle(),
        ]);
    }

    protected function heroTitle(): string
    {
        $html = e(setting('hero_title', 'Powerful APIs for {hl}Modern Apps{/hl}'));

        return preg_replace('/\{hl\}(.*?)\{\/hl\}/', '<span class="hl">$1</span>', $html);
    }
}
