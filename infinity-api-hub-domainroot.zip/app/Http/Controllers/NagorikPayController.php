<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Services\NagorikPayGateway;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class NagorikPayController extends Controller
{
    /**
     * Webhook endpoint: POST /payments/nagorikpay/{order}/webhook
     * Handles form-urlencoded POST from NagorikPay (paymentMethod, transactionId, status, etc.)
     * Must be idempotent and race-safe.
     */
    public function webhook(Request $request, Order $order)
    {
        // Validate signature first
        if (! NagorikPayGateway::validWebhook($request)) {
            Log::warning('NagorikPay webhook signature invalid', ['order' => $order->id, 'ip' => $request->ip()]);
            return response()->json(['status' => 'error', 'message' => 'Invalid webhook signature.'], 401);
        }

        // Extract fields – NagorikPay posts form-urlencoded: transactionId, paymentMethod, paymentAmount, paymentFee, status, method_transaction_id
        // Also fallback to JSON or query
        $status = strtolower(trim((string) ($request->input('status') ?: $request->input('paymentStatus') ?: $request->header('X-NagorikPay-Event') ?: '')));
        $transaction = trim((string) ($request->input('transactionId') ?: $request->input('transaction_id') ?: $request->input('method_transaction_id') ?: ''));
        $paymentMethod = trim((string) ($request->input('paymentMethod') ?: $request->input('payment_method') ?: 'nagorikpay'));
        $paymentAmount = (string) ($request->input('paymentAmount') ?: $request->input('payment_amount') ?: '');

        // If transaction empty, try raw body parse
        if ($transaction === '') {
            parse_str($request->getContent(), $parsed);
            $transaction = trim((string) ($parsed['transactionId'] ?? $parsed['transaction_id'] ?? ''));
            if ($status === '') $status = strtolower((string) ($parsed['status'] ?? ''));
        }

        Log::info('NagorikPay webhook received', ['order' => $order->id, 'status' => $status, 'txn' => $transaction, 'amount' => $paymentAmount]);

        // Update order with txn if present (even before verification, but lock-safe)
        if ($transaction !== '' && empty($order->txn_id)) {
            try {
                DB::transaction(function () use ($order, $transaction) {
                    $fresh = Order::where('id', $order->id)->lockForUpdate()->first();
                    if ($fresh && empty($fresh->txn_id)) {
                        $fresh->update(['txn_id' => $transaction, 'nagorikpay_txn' => $transaction, 'payment_method' => 'nagorikpay']);
                    }
                });
                $order->refresh();
            } catch (\Throwable $e) {
                Log::warning('Webhook txn save race', ['order' => $order->id, 'error' => $e->getMessage()]);
            }
        }

        // Handle terminal states before verification
        if (in_array($status, ['failed', 'cancelled', 'canceled', 'error'], true)) {
            DB::transaction(function () use ($order, $status) {
                $fresh = Order::where('id', $order->id)->lockForUpdate()->first();
                if ($fresh && $fresh->status === 'pending') {
                    $fresh->update(['status' => 'rejected', 'admin_note' => 'NagorikPay webhook: payment ' . $status, 'reviewed_at' => now()]);
                }
            });
            return response()->json(['status' => 'ok', 'message' => 'Order marked as ' . $status]);
        }

        // Only proceed to verify & complete if status is completed/success/pending
        if (!in_array($status, ['completed', 'success', 'pending', 'auto-completed'], true)) {
            // Unknown status – still acknowledge 2xx but log
            return response()->json(['status' => 'ok', 'message' => 'Unhandled status ' . $status]);
        }

        if ($status === 'pending') {
            // Pending – mark as verifying but don't credit yet; optionally try verify
            $order->update(['admin_note' => 'NagorikPay pending – awaiting verification.']);
            // Try to verify immediately – if already completed, we will credit
            if ($transaction !== '') {
                return $this->complete($order->fresh(), $transaction);
            }
            return response()->json(['status' => 'pending'], 202);
        }

        // status = completed/success/auto-completed => verify and credit race-safe
        if ($transaction === '') {
            Log::warning('Webhook completed but no transactionId', ['order' => $order->id]);
            return response()->json(['status' => 'ignored', 'message' => 'Missing transactionId; delivery acknowledged.'], 200);
        }

        return $this->complete($order->fresh(), $transaction);
    }

    /**
     * Success redirect: GET /payments/nagorikpay/{order}/success?transactionId=...&paymentMethod=...&paymentAmount=...&status=...
     * Called when customer returns from gateway. Must verify via API before crediting, and be idempotent.
     */
    public function success(Request $request, Order $order)
    {
        $transaction = trim((string) ($request->query('transactionId') ?: $request->query('transaction_id') ?: $request->input('transactionId') ?: ''));
        $status = strtolower((string) ($request->query('status') ?: ''));
        $paymentMethod = (string) $request->query('paymentMethod', 'nagorikpay');

        // If no transaction param, show pending view
        if ($transaction === '') {
            if ($order->status === 'approved') {
                return redirect()->route('user.orders')->with('success', 'Payment verified and credits added! Invoice emailed.');
            }
            if ($order->status === 'pending') {
                // Try to re-verify using stored txn if any
                if (!empty($order->txn_id)) {
                    $transaction = $order->txn_id;
                } else {
                    return view('user.payment-status', [
                        'order' => $order,
                        'status' => 'pending',
                        'title' => 'Payment Pending Verification',
                        'message' => 'Your payment is being verified. Credits will be added automatically once confirmed. You can also click “Recheck Status”.',
                        'transaction' => null,
                    ]);
                }
            } elseif ($order->status === 'expired') {
                return view('user.payment-status', [
                    'order' => $order,
                    'status' => 'expired',
                    'title' => 'Payment Expired',
                    'message' => 'This payment session expired. No credits were added. Please retry the purchase.',
                    'transaction' => $transaction,
                ]);
            } elseif (in_array($order->status, ['rejected','cancelled'], true)) {
                return view('user.payment-status', [
                    'order' => $order,
                    'status' => 'failed',
                    'title' => 'Payment Failed',
                    'message' => $order->admin_note ?: 'Payment was not successful. Please retry or contact support.',
                    'transaction' => $transaction,
                ]);
            }
        }

        if ($transaction !== '') {
            // Save txn for later rechecks if not yet saved
            if (empty($order->txn_id) || $order->txn_id !== $transaction) {
                try {
                    DB::transaction(function () use ($order, $transaction) {
                        $fresh = Order::where('id', $order->id)->lockForUpdate()->first();
                        if ($fresh && (empty($fresh->txn_id) || $fresh->txn_id !== $transaction)) {
                            $fresh->update(['txn_id' => $transaction, 'nagorikpay_txn' => $transaction, 'payment_method' => 'nagorikpay']);
                        }
                    });
                    $order->refresh();
                } catch (\Throwable $e) {}
            }

            // Verify via gateway – this also handles idempotency inside complete()
            $result = $this->complete($order->fresh(), $transaction);

            // If complete returned JSON (when called from webhook path), we are in success redirect context – adapt
            if ($result instanceof \Illuminate\Http\JsonResponse) {
                $data = $result->getData(true);
                $order->refresh();
                if ($order->status === 'approved') {
                    return view('user.payment-status', [
                        'order' => $order,
                        'status' => 'success',
                        'title' => 'Payment Successful!',
                        'message' => $order->order_kind === 'wallet_topup'
                            ? 'Your payment was verified and '.taka($order->amount).' was added to your wallet. An invoice has been emailed.'
                            : 'Your payment was verified and '.number_format((int) ($order->credit_quantity ?: ($order->package?->requests ?? 0))).' credits have been added to '.($order->service?->name ?? 'your API key').'. An invoice has been emailed.',
                        'transaction' => $transaction,
                    ]);
                }
                if (($data['status'] ?? '') === 'pending' || $order->status === 'pending') {
                    return view('user.payment-status', [
                        'order' => $order,
                        'status' => 'pending',
                        'title' => 'Payment Pending Verification',
                        'message' => $data['message'] ?? 'Payment received. Verification is pending. We will auto-verify shortly. You can also click “Recheck Status” or contact support.',
                        'transaction' => $transaction,
                    ]);
                }
                // failed
                return view('user.payment-status', [
                    'order' => $order,
                    'status' => 'failed',
                    'title' => 'Payment Not Verified',
                    'message' => $data['message'] ?? 'We could not verify this payment. If money was deducted, contact support with Transaction ID.',
                    'transaction' => $transaction,
                ]);
            }
        }

        // Fallback redirect with flash based on final status
        $order->refresh();
        if ($order->status === 'approved') {
            return redirect()->route('user.orders')->with('success', 'Payment verified and credits added.');
        }
        if ($order->status === 'pending') {
            return view('user.payment-status', [
                'order' => $order,
                'status' => 'pending',
                'title' => 'Payment Pending Verification',
                'message' => 'Payment received. Verification is pending. We will auto-verify shortly.',
                'transaction' => $transaction,
            ]);
        }
        if ($order->status === 'expired') {
            return view('user.payment-status', [
                'order' => $order,
                'status' => 'expired',
                'title' => 'Payment Expired',
                'message' => 'Payment expired — please retry. No money was deducted for this order.',
                'transaction' => $transaction,
            ]);
        }
        return view('user.payment-status', [
            'order' => $order,
            'status' => $order->status === 'rejected' ? 'failed' : $order->status,
            'title' => ucfirst($order->status),
            'message' => $order->admin_note ?: 'Order status: ' . $order->status,
            'transaction' => $transaction,
        ]);
    }

    public function cancel(Request $request, Order $order)
    {
        $status = strtolower((string) $request->query('status', 'cancelled'));
        // Mark as cancelled if still pending
        if ($order->status === 'pending') {
            $order->update(['status' => 'cancelled', 'admin_note' => 'Customer cancelled payment on gateway.', 'reviewed_at' => now()]);
        }

        return view('user.payment-status', [
            'order' => $order->fresh(),
            'status' => 'cancelled',
            'title' => 'Payment Cancelled',
            'message' => 'You cancelled the payment. No credits were added. You can retry anytime or contact support if you need help.',
            'transaction' => $request->query('transactionId'),
        ]);
    }

    /** Submit a Direct Payment TrxID and complete only after gateway confirmation. */
    public function submitTransaction(Request $request, Order $order)
    {
        $user = $request->user();
        if (!$user || ($user->id !== $order->user_id && $user->role !== 'admin')) abort(403);
        if ($order->status !== 'pending') return back()->with('info', 'This order is already ' . $order->status . '.');
        $data = $request->validate(['transaction_id' => 'required|string|max:120']);
        [$ok, $payload, $httpStatus] = NagorikPayGateway::submitDirectTransaction($order, $data['transaction_id']);
        $status = strtolower((string) ($payload['status'] ?? ''));
        if (in_array($status, ['paid', 'completed', 'success'], true)) {
            [$completed, $message] = Order::completeViaGateway($order->id, $data['transaction_id'], 'NagorikPay Direct Payment verified.');
            return back()->with($completed ? 'success' : 'warning', $message);
        }
        if (in_array($status, ['failed', 'expired', 'error'], true)) {
            return back()->with('error', (string) ($payload['message'] ?? 'Transaction could not be verified. No credit was added.'));
        }
        return back()->with('warning', (string) ($payload['message'] ?? 'Transaction submitted. Verification is still pending.'));
    }

    /**
     * Manual recheck action for user/admin.
     * POST /payments/nagorikpay/{order}/recheck
     */
    public function recheck(Request $request, Order $order)
    {
        // Authorization: owner or admin
        $user = $request->user();
        if (!$user || ($user->id !== $order->user_id && $user->role !== 'admin')) {
            abort(403);
        }

        if (!in_array($order->status, ['pending','expired'], true) && $order->status !== 'pending') {
            return back()->with('info', 'Order is already ' . $order->status . ' – no recheck needed.');
        }

        $tx = trim($order->txn_id ?: $order->nagorikpay_txn ?: (string) $request->input('transaction_id', ''));
        if ($tx === '') {
            return back()->with('error', 'No transaction ID found for this order. Payment may not have reached the gateway.');
        }

        $result = $this->complete($order->fresh(), $tx);
        if ($result instanceof \Illuminate\Http\JsonResponse) {
            $data = $result->getData(true);
            $order->refresh();
            if ($order->status === 'approved') {
                return back()->with('success', 'Payment verified! Credits added.');
            }
            if (($data['status'] ?? '') === 'pending') {
                return back()->with('warning', $data['message'] ?? 'Payment still pending – we will auto-retry.');
            }
            return back()->with('error', $data['message'] ?? 'Verification failed – try again later or contact support.');
        }

        return back()->with('info', 'Recheck completed. Status: ' . $order->fresh()->status);
    }

    /**
     * Race-safe completion: verifies via gateway and credits order inside DB transaction + lockForUpdate.
     * Returns JsonResponse for webhook context.
     */
    private function complete(Order $order, string $transaction)
    {
        // Fast idempotency check outside transaction
        if ($order->status !== 'pending') {
            return response()->json(['status' => 'ok', 'message' => 'Order already processed ('.$order->status.').'], 200);
        }

        // Verify via NagorikPay – must be called before DB lock to avoid holding lock during HTTP
        [$verified, $payload, $httpStatus, $isCompleted] = NagorikPayGateway::verify($transaction);

        // Check payload for duplicate txn guard inside transaction below

        // Never credit an order when the gateway reports a different merchant amount.
        if ($verified && is_array($payload)) {
            $reportedAmount = $payload['amount'] ?? $payload['expected_amount'] ?? ($payload['data']['amount'] ?? null);
            if ($reportedAmount !== null && is_numeric($reportedAmount) && abs((float) $reportedAmount - (float) $order->amount) > 0.009) {
                Log::warning('NagorikPay amount mismatch', ['order' => $order->id, 'expected' => (float) $order->amount, 'reported' => (float) $reportedAmount, 'txn' => $transaction]);
                $order->update(['status' => 'rejected', 'admin_note' => 'Gateway amount mismatch; no balance or credits added.', 'reviewed_at' => now()]);
                return response()->json(['status' => 'failed', 'message' => 'Payment amount did not match this order.'], 200);
            }
        }

        if (!$verified) {
            // If gateway says pending, keep order pending but increment attempts
            $msg = 'Verification pending – gateway not yet confirmed.';
            if (is_array($payload) && isset($payload['message'])) {
                $msg = $payload['message'];
            } elseif (is_array($payload) && isset($payload['status']) && is_string($payload['status'])) {
                $msg = 'Gateway status: ' . $payload['status'];
            }

            // If gateway explicitly failed/rejected
            if (is_array($payload) && isset($payload['status']) && in_array(strtolower((string)$payload['status']), ['failed','error','rejected'], true)) {
                DB::transaction(function () use ($order, $payload) {
                    $fresh = Order::where('id', $order->id)->lockForUpdate()->first();
                    if ($fresh && $fresh->status === 'pending') {
                        $fresh->update(['status' => 'rejected', 'admin_note' => 'NagorikPay verification failed: '.($payload['message'] ?? 'rejected'), 'reviewed_at' => now(), 'attempts' => $fresh->attempts + 1]);
                    }
                });
                return response()->json(['status' => 'failed', 'message' => $msg], 200);
            }

            // Else pending – update attempts and return 202
            try {
                $order->increment('attempts');
                $order->update(['admin_note' => 'NagorikPay verification pending (attempt '.$order->fresh()->attempts.').']);
            } catch (\Throwable $e) {}

            return response()->json(['status' => 'pending', 'message' => $msg], 202);
        }

        // Verified – now idempotent credit inside transaction with lock
        // Check isCompleted – if verify returned pending, don't credit yet
        if (!$isCompleted) {
            try {
                $order->increment('attempts');
                $order->update(['admin_note' => 'NagorikPay status pending – awaiting completion.']);
            } catch (\Throwable $e) {}
            return response()->json(['status' => 'pending', 'message' => 'Payment is pending – auto-verification will complete shortly.'], 202);
        }

        // Proceed to transactional complete
        try {
            [$ok, $message] = Order::completeViaGateway($order->id, $transaction, 'NagorikPay verified transaction '.$transaction);
        } catch (\Illuminate\Database\QueryException $e) {
            // Unique constraint violation = duplicate txn
            if (str_contains($e->getMessage(), 'UNIQUE') || str_contains($e->getMessage(), 'unique') || $e->getCode() == 23000) {
                Log::warning('Duplicate transaction blocked by DB unique', ['txn' => $transaction, 'order' => $order->id]);
                return response()->json(['status' => 'ok', 'message' => 'Transaction already processed.'], 200);
            }
            Log::error('Complete transaction error', ['order' => $order->id, 'error' => $e->getMessage()]);
            return response()->json(['status' => 'error', 'message' => 'Database error during completion.'], 500);
        } catch (\Throwable $e) {
            Log::error('Complete failed', ['order' => $order->id, 'error' => $e->getMessage()]);
            return response()->json(['status' => 'error', 'message' => $e->getMessage()], 500);
        }

        if ($ok) {
            return response()->json(['status' => 'completed', 'message' => $message], 200);
        }

        // Already processed case
        if (str_contains($message, 'already processed') || str_contains($message, 'already used')) {
            return response()->json(['status' => 'ok', 'message' => $message], 200);
        }

        return response()->json(['status' => 'pending', 'message' => $message], 202);
    }
}
