<?php

namespace App\Http\Controllers;

use App\Models\ApiService;

class ServiceController extends Controller
{
    public function show(string $slug)
    {
        $service = ApiService::where('slug', $slug)->where('status', 'active')->firstOrFail();
        $packages = $service->packages()->where('status', 'active')->orderBy('sort_order')->orderBy('price')->get();

        return view('pages.service-show', [
            'service' => $service,
            'packages' => $packages,
            'stats' => $service->liveStats(),
        ]);
    }
}
