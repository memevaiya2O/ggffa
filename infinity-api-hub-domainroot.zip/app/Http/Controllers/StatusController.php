<?php

namespace App\Http\Controllers;

use App\Models\ApiLog;
use App\Models\ApiService;

class StatusController extends Controller
{
    public function index()
    {
        $services = ApiService::orderBy('sort_order')->orderBy('id')->get();
        $rows = [];
        foreach ($services as $s) {
            $st = $s->liveStats();
            $rows[] = [
                'service' => $s,
                'stats' => $st,
                'operational' => $s->status === 'active' && $st['success_24h'] >= (float) setting('status_threshold', 50),
            ];
        }

        $total = ApiLog::count();
        $ok = ApiLog::where('status', 'success')->count();

        return view('pages.status', [
            'rows' => $rows,
            'allOk' => collect($rows)->every(fn ($r) => $r['operational']),
            'uptime' => $total ? round(($ok / $total) * 100, 2) : 100,
            'avgMs' => (int) (ApiLog::where('created_at', '>=', now()->subDay())->avg('latency_ms') ?? 0),
        ]);
    }
}
