<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\ApiService;
use App\Models\Order;
use App\Models\Package;
use App\Models\ServiceKey;
use App\Services\NagorikPayGateway;
use Illuminate\Http\Request;

class BuyController extends Controller
{
    public function index(Request $request)
    {
        $services = ApiService::active()->with(['packages' => fn ($q) => $q->active()->orderBy('sort_order')->orderBy('price')])
            ->orderBy('sort_order')->get();
        $serviceId = (int) $request->query('service', 0);

        return view('user.buy', compact('services', 'serviceId'));
    }

    public function checkout(Request $request, Package $package)
    {
        abort_unless($package->status === 'active' && $package->service?->status === 'active', 404);
        $key = ServiceKey::where('user_id', $request->user()->id)->where('service_id', $package->service_id)->first();

        return view('user.checkout', [
            'package' => $package->load('service'),
            'key' => $key,
            'methods' => $this->methods(),
            'nagorikpayEnabled' => NagorikPayGateway::enabled(),
            'isSandbox' => NagorikPayGateway::isSandbox(),
            'wallet' => $request->user()->walletAccount(),
        ]);
    }

    public function order(Request $request, Package $package)
    {
        abort_unless($package->status === 'active' && $package->service?->status === 'active', 404);
        $user = $request->user();

        // FREE package → instant, once per user
        if ($package->isFree()) {
            $claimed = Order::where('user_id', $user->id)->where('package_id', $package->id)->where('status', 'approved')->exists();
            if ($claimed) {
                return redirect()->route('user.orders')->with('warning', 'You already claimed this free package.');
            }
            $key = ServiceKey::where('user_id', $user->id)->where('service_id', $package->service_id)->first();
            if (! $key) {
                $key = ServiceKey::issue($user, $package->service, 0, today()->addDays(max(1, (int) $package->validity_days))->toDateString());
            }
            $order = Order::create([
                'user_id' => $user->id, 'service_id' => $package->service_id, 'package_id' => $package->id,
                'key_id' => $key->id, 'amount' => 0, 'payment_method' => 'free',
                'sender_number' => '', 'txn_id' => 'FREE-'.$package->id.'-'.$user->id.'-'.time(), 'status' => 'approved',
                'admin_note' => 'Auto-approved free package', 'reviewed_at' => now(),
            ]);
            $key->addQuota((int) $package->requests, (int) $package->validity_days);
            // Generate invoice for free as well
            try { \App\Services\InvoiceService::generateFor($order); } catch (\Throwable $e) {}

            return redirect()->route('user.orders')->with('success', 'Free package activated! '.number_format($package->requests).' credits added to '.$package->service->name.'.');
        }

        $paymentMethod = (string) $request->input('method', 'nagorikpay');
        // Existing keys are reused; approved orders create a key atomically if needed.
        $key = ServiceKey::where('user_id', $user->id)->where('service_id', $package->service_id)->first();
        if ($paymentMethod === 'wallet') {
            $amount = (float) $package->price;
            try {
                \Illuminate\Support\Facades\DB::transaction(function () use ($user, $package, $key, $amount) {
                    $order = Order::create([
                        'user_id'=>$user->id, 'service_id'=>$package->service_id, 'package_id'=>$package->id, 'key_id'=>$key?->id,
                        'amount'=>$amount, 'payment_method'=>'wallet', 'order_kind'=>'credit_purchase', 'credit_quantity'=>(int) $package->requests,
                        'unit_price'=>$package->requests > 0 ? $amount / $package->requests : 0, 'wallet_amount'=>$amount,
                        'sender_number'=>'', 'txn_id'=>'WALLET-PKG-'.$user->id.'-'.now()->format('YmdHis').'-'.\Illuminate\Support\Str::upper(\Illuminate\Support\Str::random(4)), 'status'=>'pending',
                    ]);
                    $user->walletAccount()->debit($amount, 'credit_purchase', $order, 'Package purchased from wallet', $order->txn_id, ['package_id'=>$package->id]);
                    $order->approve('Paid from wallet balance.');
                });
            } catch (\RuntimeException $e) {
                return back()->withInput()->with('error', $e->getMessage());
            }
            return redirect()->route('user.orders')->with('success', 'Package purchased from wallet. Credits added instantly.');
        }

        if (NagorikPayGateway::enabled() && $paymentMethod === 'nagorikpay') {
            $expireMinutes = max(5, (int) setting('nagorikpay_expire_minutes', 30));
            $order = Order::create([
                'user_id' => $user->id, 'service_id' => $package->service_id, 'package_id' => $package->id,
                'key_id' => $key?->id, 'amount' => $package->price, 'payment_method' => 'nagorikpay',
                'order_kind' => 'credit_purchase', 'credit_quantity' => (int) $package->requests,
                'unit_price' => $package->requests > 0 ? $package->price / $package->requests : 0,
                'sender_number' => '', 'txn_id' => 'NP-PENDING-'.$user->id.'-'.now()->format('YmdHis').'-'.strtoupper(\Illuminate\Support\Str::random(4)), 'status' => 'pending',
                'expires_at' => now()->addMinutes($expireMinutes),
                'attempts' => 0,
            ]);
            [$ok, $message, $payment] = NagorikPayGateway::createPayment($order);
            if (! $ok || ! $payment) {
                $order->delete();
                return back()->with('error', $message)->withInput();
            }
            // If gateway returned a transaction_id, store it (replace placeholder). Keep original if not.
            if (! empty($payment['transaction_id'])) {
                $order->update(['txn_id' => (string) $payment['transaction_id'], 'nagorikpay_txn' => (string) $payment['transaction_id']]);
            }
            // Redirect to gateway with intermediate "Redirecting..." view for better UX & to show spinner
            // But we can directly redirect away; middleware will handle UX states.
            // To enable proper "redirecting" UI we flash and show intermediate view
            return view('user.payment-redirect', [
                'order' => $order->fresh(),
                'paymentUrl' => $payment['url'],
                'isSandbox' => NagorikPayGateway::isSandbox(),
            ]);
        }

        return back()->withInput()->with('error', 'Only Wallet or Auto Payment is available. Please ask the administrator to configure Auto Payment.');
    }

    protected function methods(): array
    {
        $m = [];
        if (setting('pay_bkash', '')) {
            $m['bKash'] = setting('pay_bkash');
        }
        if (setting('pay_nagad', '')) {
            $m['Nagad'] = setting('pay_nagad');
        }
        if (setting('pay_rocket', '')) {
            $m['Rocket'] = setting('pay_rocket');
        }

        return $m;
    }
}
