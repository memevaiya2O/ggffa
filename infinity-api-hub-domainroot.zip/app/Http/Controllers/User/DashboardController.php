<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\ApiService;
use App\Models\Notification;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();

        return view('user.dashboard', [
            'stats' => $user->stats(),
            'keys' => $user->keys()->whereHas('service', fn ($q) => $q->where('status', 'active'))->with('service')->latest()->take(4)->get(),
            'recent' => $user->logs()->with('service')->latest('id')->take(8)->get(),
            'notices' => Notification::active()->forUser((int) $user->id)->latest()->take(3)->get(),
            'firstService' => ApiService::active()->orderBy('sort_order')->first(),
        ]);
    }
}
