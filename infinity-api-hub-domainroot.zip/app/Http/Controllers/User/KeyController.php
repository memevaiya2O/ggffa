<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\ApiService;
use App\Models\ServiceKey;
use Illuminate\Http\Request;

class KeyController extends Controller
{
    public function index(Request $request)
    {
        $keys = $request->user()->keys()->whereHas('service', fn ($q) => $q->where('status', 'active'))->with('service')->latest()->get();
        $missing = ApiService::active()->whereNotIn('id', $keys->pluck('service_id'))->orderBy('sort_order')->get();

        return view('user.keys', compact('keys', 'missing'));
    }

    /** Claim a key for a service the user doesn't have yet. */
    public function store(Request $request)
    {
        $data = $request->validate(['service_id' => 'required|exists:api_services,id']);
        $service = ApiService::findOrFail($data['service_id']);
        abort_unless($service->status === 'active', 404);

        $exists = ServiceKey::where('user_id', $request->user()->id)->where('service_id', $service->id)->first();
        if ($exists) {
            return back()->with('info', 'You already have a key for '.$service->name.'.');
        }

        $quota = (int) ($service->free_quota ?? setting('service_free_quota', 25));
        $valid = (int) setting('signup_validity', 30);
        ServiceKey::issue($request->user(), $service, $quota, today()->addDays($valid)->toDateString());

        return back()->with('success', "API key issued for {$service->name} with {$quota} free credits!");
    }

    public function update(Request $request, ServiceKey $key)
    {
        abort_unless($key->user_id === $request->user()->id, 403);
        $data = $request->validate(['label' => 'required|string|max:60']);
        $key->update(['label' => $data['label']]);

        return back()->with('success', 'Key renamed.');
    }

    public function destroy(Request $request, ServiceKey $key)
    {
        abort_unless($key->user_id === $request->user()->id, 403);
        $key->delete();

        return back()->with('success', 'Key deleted. You can claim it again anytime.');
    }

    public function regenerate(Request $request, ServiceKey $key)
    {
        abort_unless($key->user_id === $request->user()->id, 403);
        $key->update(['api_key' => ServiceKey::generateFor($key->service)]);

        return back()->with('success', 'Key regenerated. Update it everywhere you use it.');
    }
}
