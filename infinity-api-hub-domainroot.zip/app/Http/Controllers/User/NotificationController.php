<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Notification;

class NotificationController extends Controller
{
    public function index(\Illuminate\Http\Request $request)
    {
        return view('user.notifications', [
            'list' => Notification::active()->forUser((int) $request->user()->id)->latest()->get(),
        ]);
    }
}
