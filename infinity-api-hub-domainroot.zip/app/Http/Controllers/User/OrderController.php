<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Invoice;
use App\Services\InvoiceService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class OrderController extends Controller
{
    public function index(Request $request)
    {
        return view('user.orders', [
            'orders' => $request->user()->orders()->with(['package', 'service', 'invoice'])->latest()->get(),
        ]);
    }

    public function invoice(Request $request, Order $order)
    {
        abort_unless($order->user_id === $request->user()->id || $request->user()->role === 'admin', 403);
        $order->load(['package', 'service', 'user']);
        $invoice = Invoice::where('order_id', $order->id)->first();
        if (!$invoice) {
            $invoice = InvoiceService::generateFor($order);
        }
        return view('user.invoice', ['order' => $order, 'invoice' => $invoice]);
    }

    public function invoiceDownload(Request $request, Order $order)
    {
        abort_unless($order->user_id === $request->user()->id || $request->user()->role === 'admin', 403);
        $invoice = Invoice::where('order_id', $order->id)->first();
        if (!$invoice) {
            $invoice = InvoiceService::generateFor($order->load(['package','service','user']));
        }
        if (!$invoice || !Storage::disk('local')->exists($invoice->pdf_path)) {
            // regenerate
            $invoice = InvoiceService::generateFor($order->load(['package','service','user']));
        }
        $path = storage_path('app/private/' . $invoice->pdf_path);
        if (!file_exists($path)) $path = storage_path('app/' . $invoice->pdf_path);
        if (!file_exists($path)) {
            return back()->with('error', 'Invoice file not found – please contact support.');
        }
        $isPdf = str_ends_with($invoice->pdf_path, '.pdf');
        return response()->download($path, $invoice->invoice_number . ($isPdf ? '.pdf' : '.html'));
    }

    public function recheck(Request $request, Order $order)
    {
        abort_unless($order->user_id === $request->user()->id, 403);
        if ($order->status !== 'pending') {
            return back()->with('info', 'Order is already ' . $order->status);
        }
        if ($order->payment_method !== 'nagorikpay') {
            return back()->with('error', 'Only Auto Payment orders can be rechecked.');
        }
        $tx = trim($order->txn_id ?: $order->nagorikpay_txn);
        if ($tx === '' || str_starts_with($tx, 'NP-PENDING')) {
            return back()->with('error', 'No transaction ID yet – payment may not have reached gateway.');
        }
        // Delegate to NagorikPayController logic via service
        $gatewayTx = $tx;
        [$verified, $payload, $http, $isCompleted] = \App\Services\NagorikPayGateway::verify($gatewayTx);
        if ($verified && $isCompleted) {
            [$ok, $msg] = Order::completeViaGateway($order->id, $gatewayTx, 'User recheck verified '.$gatewayTx);
            return back()->with($ok ? 'success' : 'warning', $msg);
        }
        if ($verified && !$isCompleted) {
            return back()->with('warning', 'Payment still pending – we will auto-verify shortly.');
        }
        return back()->with('error', 'Verification failed: ' . (is_array($payload) ? ($payload['message'] ?? 'pending') : 'try again later'));
    }
}
