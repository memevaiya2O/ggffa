<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;

class ProfileController extends Controller
{
    public function index()
    {
        return view('user.profile');
    }

    public function updateInfo(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string|min:3|max:100',
            'phone' => 'nullable|string|max:30',
        ]);
        $request->user()->update($data);

        return back()->with('success', 'Profile updated.');
    }

    public function updatePassword(Request $request)
    {
        $data = $request->validate([
            'current' => 'required',
            'new' => ['required', 'confirmed', Password::min(8)],
        ]);
        if (! Hash::check($data['current'], $request->user()->password)) {
            return back()->with('error', 'Current password is wrong.');
        }
        // Prevent reusing default
        if (Hash::check($data['new'], $request->user()->password)) {
            return back()->with('error', 'New password must be different.');
        }
        $request->user()->update(['password' => $data['new']]);
        // Clear forced flag
        if ($request->user()->must_change_password) {
            $request->user()->markPasswordChanged();
        } else {
            $request->user()->forceFill(['password_changed_at' => now()])->save();
        }

        return back()->with('success', 'Password changed successfully.');
    }
}
