<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\ApiLog;
use App\Models\ApiService;
use App\Models\ServiceKey;
use App\Services\ProviderGateway;
use Illuminate\Http\Request;

class TesterController extends Controller
{
    public function index(Request $request)
    {
        $keys = $request->user()->keys()->with('service')->get();

        return view('user.test', [
            'keys' => $keys,
            'selKey' => (int) $request->query('key', $keys->first()?->id ?? 0),
            'result' => null,
            'posted' => [],
        ]);
    }

    public function run(Request $request)
    {
        $data = $request->validate(['key_id' => 'required|exists:service_keys,id']);
        $key = ServiceKey::with('service')->findOrFail($data['key_id']);
        abort_unless($key->user_id === $request->user()->id, 403);

        $svc = $key->service;
        if (! $svc || $svc->status !== 'active') {
            return back()->with('error', 'This API is currently disabled.');
        }

        $input = [];
        foreach ($svc->paramList() as $p) {
            $v = trim((string) $request->input('p.'.$p['name'], ''));
            if ($v === '' && ! empty($p['required'])) {
                return back()->with('error', 'Please fill: '.($p['label'] ?? $p['name']))->withInput();
            }
            if ($v !== '') {
                $input[$p['name']] = $v;
            }
        }

        [$ok, $msg, $row] = ServiceKey::validate($key->api_key, $svc->id);
        if (! $ok) {
            return back()->with('error', $msg)->withInput();
        }

        $credits = max(1, (int) $svc->credits_per_hit);
        [$code, $body, $ms, $err] = ProviderGateway::request($svc, $input);
        $success = ($code === 200 && $err === '' && $body !== '');

        ApiLog::write([
            'user_id' => $request->user()->id, 'key_id' => $key->id, 'service_id' => $svc->id,
            'summary' => http_build_query(array_slice($input, 0, 3)) ?: $svc->slug,
            'status' => $success ? 'success' : 'error', 'code' => $code,
            'ms' => $ms, 'credits' => $success ? $credits : 0, 'snippet' => $body, 'source' => 'panel',
        ]);
        if ($success) {
            $key->consume($credits);
        }

        $decoded = json_decode($body, true);
        $pretty = json_last_error() === JSON_ERROR_NONE
            ? json_encode($decoded, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
            : $body;

        return view('user.test', [
            'keys' => $request->user()->keys()->with('service')->get(),
            'selKey' => $key->id,
            'result' => ['code' => $code, 'ms' => $ms, 'body' => $pretty, 'err' => $err, 'credits' => $success ? $credits : 0, 'ok' => $success],
            'posted' => $request->input('p', []),
        ]);
    }
}
