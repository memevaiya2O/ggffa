<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\ApiService;
use App\Models\Ticket;
use Illuminate\Http\Request;

class TicketController extends Controller
{
    public function index(Request $request)
    {
        return view('user.tickets.index', [
            'tickets' => $request->user()->tickets()->with('service')->latest()->paginate(12),
            'services' => ApiService::active()->orderBy('name')->get(),
        ]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'subject' => 'required|string|max:200',
            'message' => 'required|string|max:5000',
            'service_id' => 'nullable|exists:api_services,id',
            'priority' => 'required|in:low,medium,high',
        ]);
        $ticket = Ticket::create([
            'user_id' => $request->user()->id,
            'service_id' => $data['service_id'] ?? null,
            'subject' => $data['subject'],
            'priority' => $data['priority'],
            'status' => 'open',
        ]);
        $ticket->replies()->create(['user_id' => $request->user()->id, 'is_admin' => false, 'message' => $data['message']]);

        return redirect()->route('user.tickets.show', $ticket)->with('success', 'Ticket created. We will reply soon!');
    }

    public function show(Request $request, Ticket $ticket)
    {
        abort_unless($ticket->user_id === $request->user()->id, 403);

        return view('user.tickets.show', ['ticket' => $ticket->load(['replies.user', 'service'])]);
    }

    public function reply(Request $request, Ticket $ticket)
    {
        abort_unless($ticket->user_id === $request->user()->id, 403);
        abort_if($ticket->status === 'closed', 400, 'Ticket is closed.');
        $data = $request->validate(['message' => 'required|string|max:5000']);
        $ticket->replies()->create(['user_id' => $request->user()->id, 'is_admin' => false, 'message' => $data['message']]);
        $ticket->update(['status' => 'open']);

        return back()->with('success', 'Reply sent.');
    }

    public function close(Request $request, Ticket $ticket)
    {
        abort_unless($ticket->user_id === $request->user()->id, 403);
        $ticket->update(['status' => 'closed']);

        return back()->with('success', 'Ticket closed.');
    }
}
