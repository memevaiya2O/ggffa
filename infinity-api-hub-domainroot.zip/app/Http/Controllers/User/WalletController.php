<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\ApiService;
use App\Models\Order;
use App\Models\ServiceKey;
use App\Models\Wallet;
use App\Services\NagorikPayGateway;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use RuntimeException;

class WalletController extends Controller
{
    public function index(Request $request)
    {
        $wallet = $request->user()->walletAccount();
        $transactions = $wallet->transactions()->latest()->paginate(20);
        $services = ApiService::active()->orderBy('sort_order')->get();
        return view('user.wallet', compact('wallet', 'transactions', 'services'));
    }

    public function purchase(Request $request)
    {
        $data = $request->validate([
            'kind' => 'required|in:credit_purchase,wallet_topup',
            'payment_type' => 'required|in:wallet,gateway',
            'service_id' => 'nullable|integer|exists:api_services,id',
            'quantity' => 'nullable|integer|min:1|max:10000000',
            'amount' => 'nullable|numeric|min:1|max:1000000',
        ]);

        $user = $request->user();
        $kind = $data['kind'];
        $service = null;
        $quantity = 0;
        $unitPrice = 0.0;
        $amount = 0.0;
        $key = null;

        if ($kind === 'wallet_topup') {
            $amount = round((float) ($data['amount'] ?? 0), 2);
            $min = (float) setting('wallet_min_topup', 10);
            $max = (float) setting('wallet_max_topup', 100000);
            if ($amount < $min || $amount > $max) {
                return back()->withInput()->with('error', 'Wallet top-up must be between '.taka($min).' and '.taka($max).'.');
            }
        } else {
            $service = ApiService::active()->findOrFail((int) ($data['service_id'] ?? 0));
            $quantity = (int) ($data['quantity'] ?? 0);
            if ($quantity < 1) return back()->withInput()->with('error', 'Enter how many credits you want to buy.');
            $unitPrice = (float) ($service->credit_price ?: setting('credit_price_default', 1));
            $amount = round($quantity * $unitPrice, 2);
            // Create/reuse the key inside the wallet transaction so failed payments roll it back.
            $key = null;
        }

        if ($data['payment_type'] === 'wallet') {
            if ($kind !== 'credit_purchase') return back()->withInput()->with('error', 'Wallet top-up requires Auto Payment.');
            try {
                DB::transaction(function () use ($user, $service, $quantity, $unitPrice, $amount) {
                    $key = ServiceKey::where('user_id', $user->id)->where('service_id', $service->id)->first();
                    if (! $key) {
                        $key = ServiceKey::issue($user, $service, 0, today()->addDays((int) setting('signup_validity', 30))->toDateString());
                    }
                    $order = Order::create([
                        'user_id'=>$user->id, 'service_id'=>$service->id, 'package_id'=>null, 'key_id'=>$key->id,
                        'amount'=>$amount, 'payment_method'=>'wallet', 'order_kind'=>'credit_purchase',
                        'credit_quantity'=>$quantity, 'unit_price'=>$unitPrice, 'wallet_amount'=>$amount,
                        'sender_number'=>'', 'txn_id'=>'WALLET-'.now()->format('YmdHis').'-'.Str::upper(Str::random(6)),
                        'status'=>'pending', 'admin_note'=>'Wallet payment awaiting internal settlement.',
                    ]);
                    $user->walletAccount()->debit($amount, 'credit_purchase', $order, 'Credits purchased from wallet', $order->txn_id, ['service_id'=>$service->id, 'quantity'=>$quantity]);
                    $order->approve('Paid from wallet balance.');
                });
            } catch (RuntimeException $e) {
                return back()->withInput()->with('error', $e->getMessage());
            }
            return redirect()->route('user.wallet')->with('success', number_format($quantity).' credits added to '.$service->name.'.');
        }

        if (! NagorikPayGateway::enabled()) {
            return back()->withInput()->with('error', 'Auto Payment is not configured yet. Please contact the administrator.');
        }

        $order = Order::create([
            'user_id'=>$user->id, 'service_id'=>$service?->id, 'package_id'=>null, 'key_id'=>null,
            'amount'=>$amount, 'payment_method'=>'nagorikpay', 'order_kind'=>$kind,
            'credit_quantity'=>$quantity, 'unit_price'=>$unitPrice, 'wallet_amount'=>($kind === 'wallet_topup' ? $amount : 0),
            'sender_number'=>'', 'txn_id'=>'PAY-PENDING-'.$user->id.'-'.now()->format('YmdHis').'-'.Str::upper(Str::random(4)),
            'status'=>'pending', 'expires_at'=>now()->addMinutes(max(5, (int) setting('nagorikpay_expire_minutes', 30))), 'attempts'=>0,
        ]);

        [$ok, $message, $payment] = NagorikPayGateway::createPayment($order);
        if (! $ok || ! $payment) {
            $order->delete();
            return back()->withInput()->with('error', $message);
        }
        if (! empty($payment['transaction_id'])) $order->update(['txn_id'=>(string) $payment['transaction_id'], 'nagorikpay_txn'=>(string) $payment['transaction_id']]);
        if (($payment['mode'] ?? '') === 'direct') {
            $order->update(['gateway_payment_id' => (string) $payment['payment_id']]);
            return view('user.payment-direct', ['order' => $order->fresh(), 'payment' => $payment, 'isSandbox' => NagorikPayGateway::isSandbox()]);
        }
        return view('user.payment-redirect', ['order'=>$order->fresh(), 'paymentUrl'=>$payment['url'], 'isSandbox'=>NagorikPayGateway::isSandbox()]);
    }
}
