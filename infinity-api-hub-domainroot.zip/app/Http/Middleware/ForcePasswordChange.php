<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class ForcePasswordChange
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();
        if ($user && $user->must_change_password) {
            $allowed = [
                'user.profile',
                'user.profile.password',
                'user.profile.info',
                'logout',
                'admin.admins.mypass',
            ];
            $routeName = $request->route()?->getName();
            // Allow password change routes and logout; allow viewing profile pages
            if (!in_array($routeName, $allowed, true)
                && !$request->is('user/profile*')
                && !$request->is('admin/admins/password')
                && !$request->is('logout')
                && !$request->is('*.password*')
            ) {
                if ($request->expectsJson()) {
                    return response()->json(['message' => 'Password change required.'], 403);
                }
                return redirect()->route('user.profile')->with('warning', 'For security, please change your default password before continuing.');
            }
        }
        return $next($request);
    }
}
