<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class SiteMaintenance
{
    public function handle(Request $request, Closure $next): Response
    {
        // API gateway always stays up; admin area always accessible.
        if ($request->is('api/*') || $request->is('admin/*') || $request->is('up')) {
            return $next($request);
        }

        try {
            $on = setting('maintenance_mode', '0') === '1';
        } catch (\Throwable $e) {
            return $next($request); // DB not installed yet
        }

        if ($on && (! $request->user() || $request->user()->role !== 'admin')) {
            return response()->view('errors.503', [], 503);
        }

        return $next($request);
    }
}
