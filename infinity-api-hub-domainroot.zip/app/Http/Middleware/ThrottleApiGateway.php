<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Symfony\Component\HttpFoundation\Response;

class ThrottleApiGateway
{
    /**
     * Throttle invalid-key and brute-force attempts by IP.
     * Applies in addition to per-key rate limit inside GatewayController.
     */
    public function handle(Request $request, Closure $next): Response
    {
        $ip = $request->ip();
        $key = 'api_gateway_ip:' . $ip;

        $attempts = (int) Cache::get($key, 0);
        // Allow 30 invalid attempts per minute per IP; valid requests are not counted here (controller handles per-key limit)
        // But we need to count after we know it's invalid – so we do lightweight pre-check
        // For simplicity, apply fixed window: 60 req/min per IP overall (including valid)
        // This prevents brute-force enumeration of api_key values.

        $limit = max(10, (int) setting('api_ip_rate_limit', 60));
        $window = 60; // seconds

        // Use Laravel rate limiter via Cache
        $hits = Cache::get("gw_ip_hits:{$ip}", 0);
        $resetAt = Cache::get("gw_ip_reset:{$ip}", 0);

        if ($resetAt && $resetAt < time()) {
            Cache::forget("gw_ip_hits:{$ip}");
            Cache::forget("gw_ip_reset:{$ip}");
            $hits = 0;
        }

        if ($hits >= $limit) {
            return response()->json([
                'status' => 'error',
                'message' => 'Too many requests from this IP. Please slow down.',
                'retry_after' => max(1, $resetAt - time()),
            ], 429)->withHeaders([
                'Retry-After' => (string) max(1, $resetAt - time()),
                'X-RateLimit-Limit' => (string) $limit,
                'X-RateLimit-Remaining' => '0',
            ]);
        }

        $response = $next($request);

        // Count only if response was 401/400 due to key issues – we can inspect response status
        $status = $response->getStatusCode();
        $shouldCount = in_array($status, [400, 401, 429], true);

        // Increment counter
        $current = Cache::get("gw_ip_hits:{$ip}", 0);
        if ($current === 0) {
            Cache::put("gw_ip_hits:{$ip}", 1, $window);
            Cache::put("gw_ip_reset:{$ip}", time() + $window, $window);
        } else {
            Cache::increment("gw_ip_hits:{$ip}");
        }

        // Add headers for valid responses too
        $remaining = max(0, $limit - Cache::get("gw_ip_hits:{$ip}", 0));
        $response->headers->set('X-RateLimit-Limit', (string) $limit);
        $response->headers->set('X-RateLimit-Remaining', (string) $remaining);
        $response->headers->set('X-RateLimit-IP', $ip);

        return $response;
    }
}
