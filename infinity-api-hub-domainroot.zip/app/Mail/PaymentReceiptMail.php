<?php

namespace App\Mail;

use App\Models\Order;
use App\Models\Invoice;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Mail\Mailables\Attachment;
use Illuminate\Queue\SerializesModels;

class PaymentReceiptMail extends Mailable
{
    use Queueable, SerializesModels;

    public function __construct(public Order $order, public ?Invoice $invoice = null)
    {
        $this->order->loadMissing(['user', 'package', 'service']);
        $this->invoice = $invoice ?: Invoice::where('order_id', $this->order->id)->first();
    }

    public function envelope(): Envelope
    {
        $site = setting('site_name', 'INFINITY API HUB');
        return new Envelope(
            subject: 'Payment Receipt — ' . $this->order->package->name . ' — ' . $site,
        );
    }

    public function content(): Content
    {
        return new Content(
            view: 'emails.payment-receipt',
            with: ['order' => $this->order, 'invoice' => $this->invoice]
        );
    }

    public function attachments(): array
    {
        if ($this->invoice && $this->invoice->pdf_path && \Illuminate\Support\Facades\Storage::disk('local')->exists($this->invoice->pdf_path)) {
            $path = storage_path('app/private/' . $this->invoice->pdf_path);
            if (!file_exists($path)) $path = storage_path('app/' . $this->invoice->pdf_path);
            if (file_exists($path)) {
                return [Attachment::fromPath($path)->as($this->invoice->invoice_number . '.pdf')->withMime('application/pdf')];
            }
        }
        return [];
    }
}
