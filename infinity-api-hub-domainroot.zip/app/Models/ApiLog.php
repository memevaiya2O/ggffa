<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ApiLog extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'user_id', 'key_id', 'service_id', 'param_summary', 'ip', 'status',
        'response_code', 'latency_ms', 'credits_used', 'response_snippet', 'source', 'created_at',
    ];

    protected function casts(): array
    {
        return ['created_at' => 'datetime'];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function key(): BelongsTo
    {
        return $this->belongsTo(ServiceKey::class, 'key_id');
    }

    public function service(): BelongsTo
    {
        return $this->belongsTo(ApiService::class, 'service_id');
    }

    public static function write(array $d): void
    {
        self::create([
            'user_id' => $d['user_id'] ?? null,
            'key_id' => $d['key_id'] ?? null,
            'service_id' => $d['service_id'] ?? null,
            'param_summary' => mb_substr($d['summary'] ?? '-', 0, 240),
            'ip' => $d['ip'] ?? request()->ip(),
            'status' => $d['status'] ?? 'success',
            'response_code' => $d['code'] ?? 0,
            'latency_ms' => $d['ms'] ?? 0,
            'credits_used' => $d['credits'] ?? 0,
            'response_snippet' => isset($d['snippet']) ? mb_substr($d['snippet'], 0, 500) : null,
            'source' => $d['source'] ?? 'api',
            'created_at' => now(),
        ]);
    }

    /** Requests per day for last N days. */
    public static function chart(int $days = 14): array
    {
        $rows = self::where('created_at', '>=', today()->subDays($days - 1))
            ->selectRaw('DATE(created_at) d, COUNT(*) c')
            ->groupBy('d')->pluck('c', 'd')->all();
        $out = [];
        for ($i = $days - 1; $i >= 0; $i--) {
            $d = today()->subDays($i);
            $out[] = ['label' => $d->format('d M'), 'total' => (int) ($rows[$d->toDateString()] ?? 0)];
        }

        return $out;
    }
}
