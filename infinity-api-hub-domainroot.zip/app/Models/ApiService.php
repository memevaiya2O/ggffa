<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ApiService extends Model
{
    protected $fillable = [
        'name', 'slug', 'description', 'docs_use_cases', 'icon', 'provider_url', 'method',
        'headers', 'provider_key', 'provider_source', 'params', 'credits_per_hit', 'credit_price', 'free_quota',
        'status', 'show_on_home', 'sort_order', 'docs_text', 'sample_response',
        'docs_markdown', 'docs_error_codes', 'docs_rate_limit', 'docs_example_params',
    ];

    protected function casts(): array
    {
        return [
            'headers' => 'array',
            'params' => 'array',
            'show_on_home' => 'boolean',
            'docs_error_codes' => 'array',
            'docs_example_params' => 'array',
        ];
    }

    public function keys(): HasMany
    {
        return $this->hasMany(ServiceKey::class, 'service_id');
    }

    public function packages(): HasMany
    {
        return $this->hasMany(Package::class, 'service_id');
    }

    public function logs(): HasMany
    {
        return $this->hasMany(ApiLog::class, 'service_id');
    }

    public function scopeActive($q)
    {
        return $q->where('status', 'active');
    }

    public function scopeOnHome($q)
    {
        return $q->where('show_on_home', true);
    }

    public function paramList(): array
    {
        return is_array($this->params) ? $this->params : [];
    }

    public function headerList(): array
    {
        return is_array($this->headers) ? $this->headers : [];
    }

    public function gatewayUrl(): string
    {
        return url('/api/'.$this->slug);
    }

    /** Live computed stats for status page / service page. */
    public function liveStats(): array
    {
        $total = $this->logs()->where('created_at', '>=', now()->subDay())->count();
        $ok = $this->logs()->where('created_at', '>=', now()->subDay())->where('status', 'success')->count();

        return [
            'calls_24h' => $total,
            'success_24h' => $total ? round(($ok / $total) * 100, 1) : 100,
            'avg_ms' => (int) ($this->logs()->where('created_at', '>=', now()->subDay())->avg('latency_ms') ?? 0),
            'total_calls' => $this->logs()->count(),
        ];
    }

    /** Error codes array: each item [code, message, description] */
    public function errorCodes(): array
    {
        if (is_array($this->docs_error_codes)) return $this->docs_error_codes;
        // fallback default error codes
        return [
            ['code' => '401', 'message' => 'Invalid API key', 'description' => 'The api_key header or query param is missing or invalid.'],
            ['code' => '402', 'message' => 'Credit limit exceeded', 'description' => 'Your key has no remaining credits for this API.'],
            ['code' => '429', 'message' => 'Rate limit exceeded', 'description' => 'Max '.setting('api_rate_limit',60).' requests/minute per key.'],
            ['code' => '400', 'message' => 'Missing required parameter', 'description' => 'One of the required parameters listed in docs was not provided.'],
        ];
    }

    public function docsMarkdown(): string
    {
        return (string) ($this->docs_markdown ?: $this->docs_text ?: '');
    }

    public function useCaseList(): array
    {
        return array_values(array_filter(array_map('trim', preg_split('/\r?\n/', (string) $this->docs_use_cases))));
    }

    public function exampleParams(): array
    {
        if (is_array($this->docs_example_params) && !empty($this->docs_example_params)) {
            return $this->docs_example_params;
        }
        // build from param list placeholders
        $out = [];
        foreach ($this->paramList() as $p) {
            $sample = $p['placeholder'] ?? '';
            if ($sample === '' || strlen($sample) > 24) $sample = '123456';
            $out[$p['name']] = $sample;
        }
        return $out;
    }

    /** Generate code samples dynamically */
    public function codeSamples(string $apiKey = 'YOUR_API_KEY'): array
    {
        $gw = $this->gatewayUrl();
        $params = $this->paramList();
        $examples = $this->exampleParams();
        $parts = ['api_key='.$apiKey];
        foreach ($params as $p) {
            $val = $examples[$p['name']] ?? '123456';
            $parts[] = $p['name'].'='.urlencode($val);
        }
        $q = implode('&', $parts);
        $fullUrl = $gw.'?'.$q;
        $isPost = strtoupper($this->method) === 'POST';
        $first = $params[0]['name'] ?? null;
        $firstVal = $first ? ($examples[$first] ?? '123456') : '';
        $curlCode = $isPost
            ? "curl -X POST \"{$gw}\" \\\n  -H \"X-API-KEY: {$apiKey}\" \\\n  -d \"api_key={$apiKey}\"".($first ? " \\\n  -d \"{$first}={$firstVal}\"" : '')
            : "curl -G \"{$gw}\" \\\n  --data-urlencode \"api_key={$apiKey}\"".($first ? " \\\n  --data-urlencode \"{$first}={$firstVal}\"" : '');
        // Multi-param variant
        $curlFull = $isPost
            ? "curl -X POST \"{$gw}\" \\\n  -H \"Content-Type: application/x-www-form-urlencoded\" \\\n  -H \"X-API-KEY: {$apiKey}\" \\\n  -d \"".implode('&', $parts)."\""
            : "curl \"{$fullUrl}\"";

        $phpCode = $isPost
            ? "// PHP (cURL POST)\n\$url = \"{$gw}\";\n\$data = \"".implode('&', $parts)."\";\n\$ch = curl_init(\$url);\ncurl_setopt(\$ch, CURLOPT_POST, true);\ncurl_setopt(\$ch, CURLOPT_POSTFIELDS, \$data);\ncurl_setopt(\$ch, CURLOPT_HTTPHEADER, [\"X-API-KEY: {$apiKey}\"]);\ncurl_setopt(\$ch, CURLOPT_RETURNTRANSFER, true);\n\$res = curl_exec(\$ch);\ncurl_close(\$ch);\n\$json = json_decode(\$res, true);\nprint_r(\$json);"
            : "// PHP (GET)\n\$url = \"{$fullUrl}\";\n\$res = file_get_contents(\$url);\n\$json = json_decode(\$res, true);\nprint_r(\$json);";

        $jsCode = " // JavaScript (fetch)\nconst url = \"{$fullUrl}\";\nfetch(url, { headers: { \"X-API-KEY\": \"{$apiKey}\" } })\n  .then(r => r.json())\n  .then(data => console.log(data))\n  .catch(err => console.error(err));";

        $fetchPost = " // JavaScript (fetch POST)\nfetch(\"{$gw}\", {\n  method: \"POST\",\n  headers: { \"Content-Type\": \"application/x-www-form-urlencoded\", \"X-API-KEY\": \"{$apiKey}\" },\n  body: \"".implode('&', $parts)."\"\n})\n.then(r => r.json())\n.then(console.log);";

        $pyCode = "# Python (requests)\nimport requests\nurl = \"{$fullUrl}\"\nheaders = {\"X-API-KEY\": \"{$apiKey}\"}\nres = requests.get(url, headers=headers, timeout=20)\nprint(res.json())";

        $pyPost = "# Python (POST)\nimport requests\nurl = \"{$gw}\"\ndata = {".implode(', ', array_map(fn($k,$v)=> "\"{$k}\": \"{$v}\"", array_keys($examples), $examples)).", \"api_key\": \"{$apiKey}\"}\nheaders = {\"X-API-KEY\": \"{$apiKey}\"}\nres = requests.post(url, data=data, headers=headers)\nprint(res.json())";

        $nodeCode = "// Node.js (axios)\nconst axios = require('axios');\naxios.get(\"{$fullUrl}\", { headers: { \"X-API-KEY\": \"{$apiKey}\" } })\n  .then(r => console.log(r.data));";

        return [
            'curl' => $isPost ? $curlFull : $curlCode,
            'curl_full' => $curlFull,
            'php' => $phpCode,
            'js' => $isPost ? $fetchPost : $jsCode,
            'python' => $isPost ? $pyPost : $pyCode,
            'node' => $nodeCode,
            'full_url' => $fullUrl,
        ];
    }
}
