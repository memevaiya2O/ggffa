<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Notification extends Model
{
    protected $fillable = ['user_id', 'title', 'message', 'type', 'target', 'status'];

    public function user(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function scopeActive($q)
    {
        return $q->where('status', 'active');
    }

    public function scopeForUsers($q)
    {
        return $q->whereIn('target', ['all', 'users']);
    }

    public function scopeForUser($q, int $userId)
    {
        return $q->where(function ($w) use ($userId) {
            $w->whereNull('user_id')->whereIn('target', ['all', 'users'])
              ->orWhere('user_id', $userId);
        });
    }
}
