<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Services\InvoiceService;

class Order extends Model
{
    protected $fillable = [
        'user_id', 'service_id', 'package_id', 'key_id', 'amount',
        'payment_method', 'order_kind', 'credit_quantity', 'unit_price', 'wallet_amount', 'sender_number', 'txn_id', 'status', 'admin_note', 'reviewed_at',
        'expires_at', 'nagorikpay_txn', 'gateway_payment_id', 'attempts',
    ];

    protected function casts(): array
    {
        return ['reviewed_at' => 'datetime', 'expires_at' => 'datetime', 'amount' => 'decimal:2', 'unit_price' => 'decimal:2', 'wallet_amount' => 'decimal:2', 'credit_quantity' => 'integer', 'attempts' => 'integer'];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function service(): BelongsTo
    {
        return $this->belongsTo(ApiService::class, 'service_id');
    }

    public function package(): BelongsTo
    {
        return $this->belongsTo(Package::class);
    }

    public function key(): BelongsTo
    {
        return $this->belongsTo(ServiceKey::class, 'key_id');
    }

    public function invoice(): \Illuminate\Database\Eloquent\Relations\HasOne
    {
        return $this->hasOne(Invoice::class);
    }

    public function isExpired(): bool
    {
        return $this->status === 'pending' && $this->expires_at && $this->expires_at->isPast();
    }

    public function isPending(): bool
    {
        return $this->status === 'pending';
    }

    /**
     * Idempotent, race-safe approve. Wraps in transaction + lockForUpdate.
     * Returns [ok, msg].
     * Should be called within DB::transaction or we create one.
     */
    public function approve(string $note = ''): array
    {
        return DB::transaction(function () use ($note) {
            // Lock the row for update to prevent race between webhook and success redirect
            $fresh = self::where('id', $this->id)->lockForUpdate()->first();
            if (!$fresh) {
                return [false, 'Order not found.'];
            }
            if ($fresh->status !== 'pending') {
                return [false, 'Order is not pending (already ' . $fresh->status . ').'];
            }

            if ($fresh->order_kind === 'wallet_topup') {
                $fresh->user->walletAccount()->credit(
                    (float) $fresh->amount,
                    'gateway_topup',
                    $fresh,
                    'Wallet balance added after payment verification',
                    $fresh->txn_id ?: 'order-'.$fresh->id
                );
            } else {
                $key = $fresh->key;
                if (!$key) {
                    $key = ServiceKey::issue($fresh->user, $fresh->service, 0);
                    $fresh->key_id = $key->id;
                }
                $quantity = (int) ($fresh->credit_quantity ?: ($fresh->package?->requests ?? 0));
                $validity = (int) ($fresh->package?->validity_days ?? setting('signup_validity', 30));
                $key->addQuota($quantity, $validity);
            }
            $fresh->update(['status' => 'approved', 'admin_note' => $note, 'reviewed_at' => now()]);

            // Update current instance
            $this->setRawAttributes($fresh->fresh()->getAttributes(), true);

            // Post-approve hooks: invoice + notification + email (non-blocking)
            try {
                // Generate invoice record / file path (stored in storage)
                InvoiceService::generateFor($fresh->fresh());
                // Notify user
                $fresh->user->notify(new \App\Notifications\PaymentConfirmed($fresh->fresh()));
            } catch (\Throwable $e) {
                Log::warning('Post-approve hooks failed', ['order' => $fresh->id, 'error' => $e->getMessage()]);
            }

            // Send email if mail configured
            try {
                if (config('mail.mailers.smtp.host') || config('mail.default') !== 'log') {
                    \Illuminate\Support\Facades\Mail::to($fresh->user->email)->queue(new \App\Mail\PaymentReceiptMail($fresh->fresh()));
                } else {
                    // Use log mailer fallback: still queue
                    \Illuminate\Support\Facades\Mail::to($fresh->user->email)->send(new \App\Mail\PaymentReceiptMail($fresh->fresh()));
                }
            } catch (\Throwable $e) {
                Log::warning('Payment receipt email failed', ['order' => $fresh->id, 'error' => $e->getMessage()]);
            }

            return [true, 'Order approved & credits added.'];
        });
    }

    /**
     * Complete order via NagorikPay verification – idempotent transactional wrapper.
     * Used by webhook and success redirect; ensures double-credit never happens.
     */
    public static function completeViaGateway(int $orderId, string $transactionId, string $verifiedNote = ''): array
    {
        return DB::transaction(function () use ($orderId, $transactionId, $verifiedNote) {
            $order = self::where('id', $orderId)->lockForUpdate()->first();
            if (!$order) return [false, 'Order not found.'];
            if ($order->status !== 'pending') {
                return [false, 'Order already processed (' . $order->status . ').'];
            }
            // Check unique txn constraint would be enforced at DB level; but also check duplicate txn reuse
            if ($transactionId !== '' && self::where('txn_id', $transactionId)->where('id', '!=', $order->id)->where('status', 'approved')->exists()) {
                Log::warning('Duplicate txn blocked', ['txn' => $transactionId, 'order' => $order->id]);
                return [false, 'Transaction ID already used.'];
            }
            if ($transactionId !== '') {
                $order->txn_id = $transactionId;
                $order->nagorikpay_txn = $transactionId;
                $order->payment_method = 'nagorikpay';
                $order->save();
            }
            return $order->approve($verifiedNote ?: 'NagorikPay verified transaction ' . $transactionId);
        });
    }

    public function reject(string $note = ''): void
    {
        $this->update(['status' => 'rejected', 'admin_note' => $note ?: 'Payment not verified', 'reviewed_at' => now()]);
    }

    public function expire(): void
    {
        if ($this->status !== 'pending') return;
        $this->update(['status' => 'expired', 'admin_note' => 'Payment expired — not completed within ' . (int) setting('nagorikpay_expire_minutes', 30) . ' minutes. Please retry.', 'reviewed_at' => now()]);
    }

    public function canRecheck(): bool
    {
        return $this->status === 'pending' && $this->payment_method === 'nagorikpay' && !empty($this->txn_id) && !$this->isExpired();
    }

    public function scopePending($q)
    {
        return $q->where('status', 'pending');
    }

    public function scopeNagorikPay($q)
    {
        return $q->where('payment_method', 'nagorikpay');
    }
}
