<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Package extends Model
{
    protected $fillable = [
        'service_id', 'name', 'price', 'requests', 'validity_days',
        'features', 'highlight', 'status', 'sort_order',
    ];

    protected function casts(): array
    {
        return ['highlight' => 'boolean', 'price' => 'decimal:2'];
    }

    public function service(): BelongsTo
    {
        return $this->belongsTo(ApiService::class, 'service_id');
    }

    public function scopeActive($q)
    {
        return $q->where('status', 'active');
    }

    public function featureList(): array
    {
        return array_values(array_filter(array_map('trim', explode("\n", (string) $this->features))));
    }

    public function isFree(): bool
    {
        return (float) $this->price <= 0;
    }
}
