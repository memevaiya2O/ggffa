<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ServiceKey extends Model
{
    protected $fillable = [
        'user_id', 'service_id', 'api_key', 'label',
        'total_request', 'used_request', 'exp_date', 'status', 'last_used_at',
    ];

    protected function casts(): array
    {
        return [
            'exp_date' => 'date',
            'last_used_at' => 'datetime',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function service(): BelongsTo
    {
        return $this->belongsTo(ApiService::class, 'service_id');
    }

    public function remaining(): int
    {
        return max(0, (int) $this->total_request - (int) $this->used_request);
    }

    public function usagePercent(): int
    {
        $total = (int) $this->total_request;
        if ($total <= 0) {
            return 100;
        }

        return min(100, (int) round(((int) $this->used_request / $total) * 100));
    }

    public function isExpired(): bool
    {
        return $this->exp_date && $this->exp_date->isPast();
    }

    /** Generate a unique key like INF-FFUI-XXXX-XXXX-XXXX */
    public static function generateFor(ApiService $service): string
    {
        $prefix = setting('key_prefix', 'INF-');
        $code = strtoupper(substr(preg_replace('/[^A-Z0-9]/', '', strtoupper($service->slug)), 0, 4));
        $code = str_pad($code, 4, 'X');
        $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        do {
            $rand = '';
            for ($i = 0; $i < 12; $i++) {
                $rand .= $chars[random_int(0, strlen($chars) - 1)];
            }
            $key = $prefix.$code.'-'.substr($rand, 0, 4).'-'.substr($rand, 4, 4).'-'.substr($rand, 8, 4);
        } while (self::where('api_key', $key)->exists());

        return $key;
    }

    /** Issue a key for a user+service (one key per pair). Returns the key model. */
    public static function issue(User $user, ApiService $service, int $quota, ?string $expDate = null, string $label = 'My API Key'): self
    {
        $existing = self::where('user_id', $user->id)->where('service_id', $service->id)->first();
        if ($existing) {
            return $existing;
        }

        return self::create([
            'user_id' => $user->id,
            'service_id' => $service->id,
            'api_key' => self::generateFor($service),
            'label' => $label,
            'total_request' => max(0, $quota),
            'used_request' => 0,
            'exp_date' => $expDate,
            'status' => 'active',
        ]);
    }

    /** Issue keys for ALL active services (used on registration). */
    public static function issueAllFor(User $user): int
    {
        $bonus = (int) setting('signup_bonus', 50);
        $valid = (int) setting('signup_validity', 30);
        $n = 0;
        foreach (ApiService::active()->get() as $service) {
            self::issue($user, $service, $bonus, today()->addDays($valid)->toDateString());
            $n++;
        }

        return $n;
    }

    public function consume(int $credits = 1): void
    {
        $this->increment('used_request', max(1, $credits));
        $this->forceFill(['last_used_at' => now()])->save();
    }

    public function addQuota(int $quota, int $validityDays = 0): void
    {
        $this->increment('total_request', $quota);
        if ($validityDays > 0) {
            $base = ($this->exp_date && $this->exp_date->isFuture()) ? $this->exp_date : today();
            $this->exp_date = $base->copy()->addDays($validityDays);
        }
        if ($this->status === 'expired') {
            $this->status = 'active';
        }
        $this->save();
    }

    /** Validate for gateway. Returns [ok, message, key|null]. */
    public static function validate(string $apiKey, int $serviceId): array
    {
        $row = self::with('user')->where('api_key', $apiKey)->first();
        if (! $row) {
            return [false, 'Invalid API key.', null];
        }
        if ((int) $row->service_id !== $serviceId) {
            return [false, 'This key belongs to a different API.', $row];
        }
        if ($row->status !== 'active') {
            return [false, 'Key is '.$row->status.'.', $row];
        }
        if ($row->user && $row->user->status !== 'active') {
            return [false, 'Account suspended.', $row];
        }
        if ($row->isExpired()) {
            $row->update(['status' => 'expired']);

            return [false, 'Key has expired. Please renew.', $row];
        }
        if ((int) $row->used_request >= (int) $row->total_request) {
            return [false, 'Credit limit exceeded. Please top up.', $row];
        }

        return [true, 'OK', $row];
    }
}
