<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use Notifiable;

    protected $fillable = ['name', 'email', 'phone', 'password', 'role', 'status', 'google_id', 'password_changed_at', 'must_change_password'];

    protected $hidden = ['password', 'remember_token'];

    protected function casts(): array
    {
        return [
            'password' => 'hashed',
            'password_changed_at' => 'datetime',
            'must_change_password' => 'boolean',
        ];
    }

    public function keys(): HasMany
    {
        return $this->hasMany(ServiceKey::class);
    }

    public function orders(): HasMany
    {
        return $this->hasMany(Order::class);
    }

    public function wallet(): \Illuminate\Database\Eloquent\Relations\HasOne
    {
        return $this->hasOne(Wallet::class);
    }

    public function walletAccount(): Wallet
    {
        return Wallet::forUser($this);
    }

    public function logs(): HasMany
    {
        return $this->hasMany(ApiLog::class);
    }

    public function tickets(): HasMany
    {
        return $this->hasMany(Ticket::class);
    }

    public function isAdmin(): bool
    {
        return $this->role === 'admin';
    }

    public function needsPasswordChange(): bool
    {
        return (bool) $this->must_change_password;
    }

    public function markPasswordChanged(): void
    {
        $this->forceFill(['must_change_password' => false, 'password_changed_at' => now()])->save();
    }

    /** Lifetime usage stats. */
    public function stats(): array
    {
        $quota = (int) $this->keys()->whereHas('service', fn ($q) => $q->where('status', 'active'))->sum('total_request');
        $used = (int) $this->keys()->whereHas('service', fn ($q) => $q->where('status', 'active'))->sum('used_request');

        return [
            'keys' => $this->keys()->whereHas('service', fn ($q) => $q->where('status', 'active'))->count(),
            'quota' => $quota,
            'used' => $used,
            'left' => max(0, $quota - $used),
            'today' => $this->logs()->whereDate('created_at', today())->count(),
            'total_hits' => $this->logs()->count(),
        ];
    }
}
