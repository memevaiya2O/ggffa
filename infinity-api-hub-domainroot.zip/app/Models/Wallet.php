<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Facades\DB;
use RuntimeException;

class Wallet extends Model
{
    protected $fillable = ['user_id', 'balance'];
    protected function casts(): array { return ['balance' => 'decimal:2']; }
    public function user(): BelongsTo { return $this->belongsTo(User::class); }
    public function transactions(): HasMany { return $this->hasMany(WalletTransaction::class); }

    public static function forUser(User $user): self
    {
        return self::firstOrCreate(['user_id' => $user->id], ['balance' => 0]);
    }

    public function credit(float $amount, string $type, ?Order $order = null, string $description = '', ?string $reference = null, array $metadata = []): WalletTransaction
    {
        if ($amount <= 0) throw new RuntimeException('Wallet credit must be positive.');
        return DB::transaction(function () use ($amount, $type, $order, $description, $reference, $metadata) {
            $wallet = self::whereKey($this->id)->lockForUpdate()->firstOrFail();
            $wallet->increment('balance', $amount);
            $wallet->refresh();
            return $wallet->transactions()->create([
                'user_id' => $wallet->user_id, 'order_id' => $order?->id, 'type' => $type,
                'amount' => $amount, 'balance_after' => $wallet->balance, 'reference' => $reference,
                'description' => $description, 'metadata' => $metadata ?: null,
            ]);
        });
    }

    public function debit(float $amount, string $type, ?Order $order = null, string $description = '', ?string $reference = null, array $metadata = []): WalletTransaction
    {
        if ($amount <= 0) throw new RuntimeException('Wallet debit must be positive.');
        return DB::transaction(function () use ($amount, $type, $order, $description, $reference, $metadata) {
            $wallet = self::whereKey($this->id)->lockForUpdate()->firstOrFail();
            if ((float) $wallet->balance < $amount) throw new RuntimeException('Insufficient wallet balance.');
            $wallet->decrement('balance', $amount);
            $wallet->refresh();
            return $wallet->transactions()->create([
                'user_id' => $wallet->user_id, 'order_id' => $order?->id, 'type' => $type,
                'amount' => -$amount, 'balance_after' => $wallet->balance, 'reference' => $reference,
                'description' => $description, 'metadata' => $metadata ?: null,
            ]);
        });
    }
}
