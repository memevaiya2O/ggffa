<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class WalletTransaction extends Model
{
    protected $fillable = ['wallet_id','user_id','order_id','type','amount','balance_after','reference','description','metadata'];
    protected function casts(): array { return ['amount'=>'decimal:2','balance_after'=>'decimal:2','metadata'=>'array']; }
    public function wallet(): BelongsTo { return $this->belongsTo(Wallet::class); }
    public function user(): BelongsTo { return $this->belongsTo(User::class); }
    public function order(): BelongsTo { return $this->belongsTo(Order::class); }
}
