<?php

namespace App\Notifications;

use App\Models\Order;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Notifications\Messages\DatabaseMessage;

class PaymentConfirmed extends Notification
{
    use Queueable;

    public function __construct(public Order $order) {}

    public function via(object $notifiable): array
    {
        return ['database'];
    }

    public function toDatabase(object $notifiable): array
    {
        return [
            'title' => 'Payment Confirmed — Credits Added',
            'message' => $this->order->order_kind === 'wallet_topup'
                ? 'Your payment was verified and '.taka($this->order->amount).' was added to your wallet. Transaction: '.$this->order->txn_id
                : 'Your payment for '.($this->order->package?->name ?? 'custom credits').' ('.number_format((int) ($this->order->credit_quantity ?: ($this->order->package?->requests ?? 0))).' credits) was verified. Transaction: '.$this->order->txn_id,
            'order_id' => $this->order->id,
            'type' => 'success',
        ];
    }

    // For compatibility with simple notifications table via manual insert, we also provide toArray
    public function toArray(object $notifiable): array
    {
        return $this->toDatabase($notifiable);
    }
}
