<?php

namespace App\Providers;

use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\URL;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        // Use cached app.url as the source of truth so HTTPS still works in production
        // after `php artisan config:cache` (env() is not reloaded in that mode).
        $appUrl = (string) config('app.url', '');
        if (env('APP_FORCE_HTTPS', false) || parse_url($appUrl, PHP_URL_SCHEME) === 'https') {
            URL::forceScheme('https');
        }
        RateLimiter::for('api', function (Request $request) {
            return Limit::perMinute((int) setting('api_ip_rate_limit', 120))->by($request->ip());
        });
        Paginator::defaultView('vendor.pagination.custom');
        Paginator::defaultSimpleView('vendor.pagination.custom');
    }
}
