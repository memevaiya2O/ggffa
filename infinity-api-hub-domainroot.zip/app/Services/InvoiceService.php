<?php

namespace App\Services;

use App\Models\Order;
use App\Models\Invoice;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class InvoiceService
{
    public static function generateFor(Order $order): ?Invoice
    {
        $order->loadMissing(['user', 'package', 'service']);
        $invoiceNumber = 'INV-' . date('Ym') . '-' . str_pad((string) $order->id, 6, '0', STR_PAD_LEFT) . '-' . strtoupper(Str::random(4));

        // Check if invoice already exists for this order
        $existing = Invoice::where('order_id', $order->id)->first();
        if ($existing) {
            return $existing;
        }

        $invoice = Invoice::create([
            'order_id' => $order->id,
            'user_id' => $order->user_id,
            'invoice_number' => $invoiceNumber,
            'pdf_path' => '',
        ]);

        // Generate HTML content for PDF
        $html = view('user.invoice-pdf', ['order' => $order, 'invoice' => $invoice])->render();

        $filename = 'invoices/' . $invoice->invoice_number . '.html';
        // Store as HTML; PDF generation can be done via browser print or dompdf if installed
        Storage::disk('local')->put($filename, $html);
        $invoice->update(['pdf_path' => $filename]);

        // If dompdf is available, generate real PDF
        if (class_exists(\Dompdf\Dompdf::class)) {
            try {
                $dompdf = new \Dompdf\Dompdf(['enable_remote' => true]);
                $dompdf->loadHtml($html);
                $dompdf->setPaper('A4', 'portrait');
                $dompdf->render();
                $pdfFilename = 'invoices/' . $invoice->invoice_number . '.pdf';
                Storage::disk('local')->put($pdfFilename, $dompdf->output());
                $invoice->update(['pdf_path' => $pdfFilename]);
            } catch (\Throwable $e) {
                \Illuminate\Support\Facades\Log::warning('PDF generation failed', ['invoice' => $invoice->id, 'error' => $e->getMessage()]);
            }
        }

        return $invoice;
    }

    public static function pdfPath(Invoice $invoice): string
    {
        return storage_path('app/private/' . $invoice->pdf_path) ?: storage_path('app/' . $invoice->pdf_path);
    }

    public static function exists(Invoice $invoice): bool
    {
        return Storage::disk('local')->exists($invoice->pdf_path);
    }
}
