<?php

namespace App\Services;

use App\Models\Order;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

class NagorikPayGateway
{
    // Per https://nagorikpay.com/developers/docs – Live: https://secure-pay.nagorikpay.com/api/payment/*
    public const LIVE_BASE = 'https://secure-pay.nagorikpay.com/';
    public const SANDBOX_BASE = 'https://sandbox-api.nagorikpay.com/'; // sandbox mirror; configurable via setting nagorikpay_base_url

    /**
     * Return current mode: sandbox or live
     */
    public static function mode(): string
    {
        $m = strtolower(trim((string) setting('nagorikpay_mode', 'sandbox')));
        return in_array($m, ['live', 'production'], true) ? 'live' : 'sandbox';
    }

    public static function isSandbox(): bool
    {
        return self::mode() === 'sandbox';
    }

    public static function baseUrl(): string
    {
        // Prefer explicit base_url setting if present, else infer from mode
        $custom = trim((string) setting('nagorikpay_base_url', ''));
        if ($custom !== '') {
            // If mode is sandbox but custom is live base, still respect explicit – but offer helper
            return rtrim($custom, '/') . '/';
        }
        return self::isSandbox() ? self::SANDBOX_BASE : self::LIVE_BASE;
    }

    public static function apiKey(): string
    {
        if (self::isSandbox()) {
            $sandbox = trim((string) setting('nagorikpay_api_key_sandbox', ''));
            if ($sandbox !== '') return $sandbox;
            // fallback to legacy single key
            return trim((string) setting('nagorikpay_api_key', ''));
        }
        $live = trim((string) setting('nagorikpay_api_key_live', ''));
        if ($live !== '') return $live;
        return trim((string) setting('nagorikpay_api_key', ''));
    }

    public static function webhookSecret(): string
    {
        if (self::isSandbox()) {
            $s = trim((string) setting('nagorikpay_webhook_secret_sandbox', ''));
            if ($s !== '') return $s;
            return trim((string) setting('nagorikpay_webhook_secret', '')) ?: self::apiKey();
        }
        $s = trim((string) setting('nagorikpay_webhook_secret_live', ''));
        if ($s !== '') return $s;
        return trim((string) setting('nagorikpay_webhook_secret', '')) ?: self::apiKey();
    }

    public static function enabled(): bool
    {
        return setting('nagorikpay_enabled', '0') === '1' && self::apiKey() !== '';
    }

    public static function flow(): string
    {
        return setting('nagorikpay_payment_flow', 'hosted') === 'direct' ? 'direct' : 'hosted';
    }

    public static function callbackUrl(string $routeName, array $parameters): string
    {
        $default = route($routeName, $parameters);
        $base = trim((string) setting('nagorikpay_callback_base_url', ''));
        if ($base === '' || !filter_var($base, FILTER_VALIDATE_URL)) return $default;
        $path = parse_url($default, PHP_URL_PATH) ?: '/';
        return rtrim($base, '/') . $path;
    }

    /**
     * Create payment via NagorikPay.
     * Returns [ok:boolean, message:string, data:array|null, httpStatus:int]
     * data = ['url'=>payment_url, 'transaction_id'=>..., 'raw'=>...]
     */
    public static function createPayment(Order $order): array
    {
        if (self::flow() === 'direct') {
            return self::createDirectPayment($order);
        }
        $base = rtrim(self::baseUrl(), '/');
        $path = '/' . ltrim((string) setting('nagorikpay_create_path', 'api/payment/create'), '/');
        $url = $base . $path;

        // Amount must be string without trailing zeros for integers per docs; but gateway accepts float string
        $amount = number_format((float) $order->amount, 2, '.', '');
        // remove trailing zeros: 10.00 => 10, 10.50 => 10.5
        $amount = rtrim(rtrim($amount, '0'), '.');

        $payload = [
            // Required per official docs table but sample omits cus_name/cus_email – we send both for compatibility
            'cus_name' => $order->user->name ?: 'Customer',
            'cus_email' => $order->user->email ?: 'customer@example.com',
            'amount' => $amount,
            'success_url' => self::callbackUrl('payments.nagorikpay.success', ['order' => $order->id]),
            'cancel_url' => self::callbackUrl('payments.nagorikpay.cancel', ['order' => $order->id]),
            'webhook_url' => self::callbackUrl('payments.nagorikpay.webhook', ['order' => $order->id]),
            'metadata' => ['order_id' => (string) $order->id, 'package_id' => (string) $order->package_id, 'user_id' => (string) $order->user_id],
        ];

        // Brand ID optional
        $brandId = trim((string) setting('nagorikpay_brand_id', ''));
        if ($brandId !== '') {
            $payload['brand_id'] = $brandId;
        }

        $apiKey = self::apiKey();

        // Log request (without leaking full key)
        self::logCall('create', $url, $payload, null, 0, $order->id);

        try {
            $response = Http::asJson()
                ->acceptJson()
                ->timeout(20)
                ->withHeaders([
                    'API-KEY' => $apiKey,
                    'Content-Type' => 'application/json',
                ])->post($url, $payload);

            $json = $response->json();
            $status = $response->status();

            // Mask key for log
            self::logCall('create', $url, $payload, $json, $status, $order->id);

            if (!$response->successful() || !is_array($json)) {
                $msg = is_array($json) ? ($json['message'] ?? 'Payment initialization failed.') : 'NagorikPay unreachable.';
                Log::warning('NagorikPay create failed', ['order' => $order->id, 'status' => $status, 'resp' => $json]);
                return [false, (string) $msg, null, $status];
            }

            // Official success shape: status = true, payment_url = string
            $ok = (bool) ($json['status'] ?? false);
            // Some sandbox returns status true as bool, some as string; handle both
            if (isset($json['status']) && is_string($json['status'])) {
                $ok = in_array(strtolower($json['status']), ['true', '1', 'success', 'completed'], true) || $json['status'] === 'true';
            }

            if (!$ok) {
                $msg = (string) ($json['message'] ?? 'NagorikPay rejected the request.');
                return [false, $msg, null, $status];
            }

            // Extract payment URL – official field is payment_url
            $paymentUrl = $json['payment_url'] ?? $json['paymentUrl'] ?? $json['url'] ?? $json['redirect_url'] ?? $json['payment_link'] ?? null;

            if (!is_string($paymentUrl) || !filter_var($paymentUrl, FILTER_VALIDATE_URL)) {
                // Fallback: some responses embed url in data.payment_url
                if (isset($json['data']) && is_array($json['data'])) {
                    $paymentUrl = $json['data']['payment_url'] ?? $json['data']['url'] ?? null;
                }
            }

            if (!is_string($paymentUrl) || !filter_var($paymentUrl, FILTER_VALIDATE_URL)) {
                return [false, (string) ($json['message'] ?? 'NagorikPay did not return a payment URL.'), ['raw' => $json], $status];
            }

            $transaction = $json['transaction_id'] ?? $json['transactionId'] ?? $json['invoice_id'] ?? $json['data']['transaction_id'] ?? null;
            // transaction may be empty at create time – gateway will generate and return via redirect query. Store what we have.

            return [true, 'Payment link created.', ['url' => $paymentUrl, 'transaction_id' => $transaction ? (string) $transaction : null, 'raw' => $json], $status];
        } catch (\Throwable $e) {
            Log::error('NagorikPay create payment exception', ['order' => $order->id, 'error' => $e->getMessage()]);
            self::logCall('create', $url, $payload, ['exception' => $e->getMessage()], 0, $order->id);
            return [false, 'Could not connect to NagorikPay. Check gateway settings. (' . $e->getMessage() . ')', null, 0];
        }
    }

    /** Create a no-redirect payment request (payment number + exact payable amount). */
    public static function createDirectPayment(Order $order): array
    {
        $phone = trim((string) ($order->user->phone ?? ''));
        if ($phone === '') return [false, 'Please add a phone number to your profile before using Direct Payment.', null, 422];
        $url = rtrim(self::baseUrl(), '/') . '/' . ltrim((string) setting('nagorikpay_create_request_path', 'api/payment/create-request'), '/');
        $payload = [
            'amount' => rtrim(rtrim(number_format((float) $order->amount, 2, '.', ''), '0'), '.'),
            'cus_name' => $order->user->name ?: 'Customer', 'cus_phone' => $phone,
            'webhook_url' => self::callbackUrl('payments.nagorikpay.webhook', ['order' => $order->id]),
            'metadata' => ['order_id' => (string) $order->id, 'user_id' => (string) $order->user_id],
            'account_type' => setting('nagorikpay_account_type', 'personal'),
        ];
        $method = strtolower(trim((string) setting('nagorikpay_payment_method', 'auto')));
        if ($method !== '' && $method !== 'auto') $payload['payment_method'] = $method;
        self::logCall('direct_create', $url, $payload, null, 0, $order->id);
        try {
            $response = Http::asJson()->acceptJson()->timeout(20)->withHeaders(['API-KEY' => self::apiKey(), 'Content-Type' => 'application/json'])->post($url, $payload);
            $json = $response->json(); $status = $response->status();
            self::logCall('direct_create', $url, $payload, is_array($json) ? $json : ['raw' => $response->body()], $status, $order->id);
            if (!$response->successful() || !is_array($json)) return [false, (string) ($json['message'] ?? 'Direct payment request failed.'), null, $status];
            $nested = is_array($json['data'] ?? null) ? $json['data'] : [];
            $ok = strtolower((string) ($json['status'] ?? '')) === 'success' || $json['status'] === true;
            $paymentId = $json['payment_id'] ?? $json['paymentId'] ?? ($nested['payment_id'] ?? null);
            $number = $json['payment_number'] ?? $json['paymentNumber'] ?? ($nested['payment_number'] ?? null);
            $payAmount = $json['pay_amount'] ?? $json['total_amount'] ?? ($nested['pay_amount'] ?? $order->amount);
            if (!$ok || !$paymentId || !$number) return [false, (string) ($json['message'] ?? 'Direct payment details were incomplete.'), ['raw' => $json], $status];
            return [true, 'Direct payment request created.', ['mode' => 'direct', 'payment_id' => (string) $paymentId, 'payment_number' => (string) $number, 'pay_amount' => (string) $payAmount, 'expires_at' => $json['expires_at'] ?? null, 'raw' => $json], $status];
        } catch (\Throwable $e) {
            Log::error('NagorikPay direct create exception', ['order' => $order->id, 'error' => $e->getMessage()]);
            return [false, 'Could not connect to NagorikPay Direct Payment. Check gateway settings.', null, 0];
        }
    }

    /** Submit a customer TrxID and return the gateway status. */
    public static function submitDirectTransaction(Order $order, string $transactionId): array
    {
        $paymentId = trim((string) $order->gateway_payment_id); $transactionId = trim($transactionId);
        if ($paymentId === '' || $transactionId === '') return [false, ['status' => 'failed', 'message' => 'Payment ID and Transaction ID are required.'], 422];
        $url = rtrim(self::baseUrl(), '/') . '/' . ltrim((string) setting('nagorikpay_submit_transaction_path', 'api/payment-submit-transaction'), '/');
        $payload = ['payment_id' => $paymentId, 'transaction_id' => $transactionId];
        self::logCall('direct_submit', $url, $payload, null, 0, $order->id, $transactionId);
        try {
            $response = Http::asJson()->acceptJson()->timeout(20)->withHeaders(['API-KEY' => self::apiKey(), 'Content-Type' => 'application/json'])->post($url, $payload);
            $json = $response->json(); $status = $response->status();
            self::logCall('direct_submit', $url, $payload, is_array($json) ? $json : ['raw' => $response->body()], $status, $order->id, $transactionId);
            return [$response->successful() && is_array($json), is_array($json) ? $json : ['status' => 'failed', 'message' => 'Invalid gateway response.'], $status];
        } catch (\Throwable $e) {
            Log::error('NagorikPay direct submit exception', ['order' => $order->id, 'error' => $e->getMessage()]);
            return [false, ['status' => 'pending', 'message' => 'Gateway verification is temporarily unavailable.'], 0];
        }
    }

    /**
     * Verify a transaction via NagorikPay verify endpoint.
     * Returns [verified:bool, payload:array|null, httpStatus:int, isCompleted:bool]
     */
    public static function verify(string $transactionId): array
    {
        $transactionId = trim($transactionId);
        if ($transactionId === '') {
            return [false, null, 0, false];
        }

        $base = rtrim(self::baseUrl(), '/');
        $path = '/' . ltrim((string) setting('nagorikpay_verify_path', 'api/payment/verify'), '/');
        $url = $base . $path;

        $payload = ['transaction_id' => $transactionId];
        $apiKey = self::apiKey();

        self::logCall('verify', $url, $payload, null, 0, null, $transactionId);

        try {
            $response = Http::asJson()
                ->acceptJson()
                ->timeout(20)
                ->withHeaders([
                    'API-KEY' => $apiKey,
                    'Content-Type' => 'application/json',
                ])->post($url, $payload);

            $json = $response->json();
            $status = $response->status();

            self::logCall('verify', $url, $payload, $json, $status, null, $transactionId);

            if (!$response->successful() || !is_array($json)) {
                Log::warning('NagorikPay verify failed', ['txn' => $transactionId, 'status' => $status, 'resp' => $json]);
                return [false, $json, $status, false];
            }

            // Official verify success: status = COMPLETED | PENDING | ERROR (string)
            // Docs sample: { "status": "COMPLETED", "transaction_id": "...", ... }
            // Error shape: { status: false, message: "..." }
            $rawStatus = $json['status'] ?? null;

            if ($rawStatus === false || $rawStatus === 'false' || $rawStatus === 0) {
                return [false, $json, $status, false];
            }

            if (is_string($rawStatus)) {
                $lower = strtolower($rawStatus);
                if ($lower === 'completed' || $lower === 'success' || $lower === 'paid') {
                    return [true, $json, $status, true];
                }
                if ($lower === 'pending' || $lower === 'processing') {
                    // Verified but not yet completed – not a failure
                    return [true, $json, $status, false];
                }
                if ($lower === 'failed' || $lower === 'error' || $lower === 'cancelled' || $lower === 'canceled') {
                    return [false, $json, $status, false];
                }
                // Unknown string but response is 200 – treat as verified
                return [true, $json, $status, true];
            }

            if ($rawStatus === true || $rawStatus === 1) {
                return [true, $json, $status, true];
            }

            // If no explicit status field, consider successful if HTTP 200 and contains transaction_id
            if (isset($json['transaction_id']) || isset($json['transactionId'])) {
                return [true, $json, $status, true];
            }

            return [true, $json, $status, true];
        } catch (\Throwable $e) {
            Log::error('NagorikPay verification exception', ['transaction_id' => $transactionId, 'error' => $e->getMessage()]);
            self::logCall('verify', $url, $payload, ['exception' => $e->getMessage()], 0, null, $transactionId);
            return [false, null, 0, false];
        }
    }

    /**
     * Validate webhook signature per NagorikPay docs:
     *    signature = HMAC_SHA256(key=webhook_secret, message= timestamp + "." + raw_body)
     *    header = "sha256=" + hex(signature)
     * Headers: X-NagorikPay-Timestamp, X-NagorikPay-Signature, X-NagorikPay-Event (optional)
     */
    public static function validWebhook(\Illuminate\Http\Request $request): bool
    {
        $secret = self::webhookSecret();
        $timestamp = (string) $request->header('X-NagorikPay-Timestamp', '');
        $given = (string) $request->header('X-NagorikPay-Signature', '');

        if ($secret === '' || $timestamp === '' || $given === '') {
            return false;
        }

        // Replay protection: 5 minutes
        if (abs(time() - (int) $timestamp) > 300) {
            return false;
        }

        $rawBody = $request->getContent();
        // raw body may be form-urlencoded string or JSON; use exactly as sent
        $expected = 'sha256=' . hash_hmac('sha256', $timestamp . '.' . $rawBody, $secret);
        return hash_equals($expected, $given);
    }

    /**
     * Log NagorikPay API call without leaking full API key.
     * Stores to nagorikpay_logs table if exists, else to Laravel log.
     */
    public static function logCall(string $type, string $url, ?array $requestPayload, $responsePayload, int $httpStatus, ?int $orderId = null, ?string $transactionId = null): void
    {
        // Mask API key in logs
        $maskedKey = $type === 'create' || $type === 'verify' ? self::maskedApiKey() : null;

        $logData = [
            'type' => $type,
            'url' => $url,
            'order_id' => $orderId,
            'transaction_id' => $transactionId,
            'http_status' => $httpStatus,
            'api_key_masked' => $maskedKey,
            'request' => $requestPayload ? json_encode($requestPayload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) : null,
            'response' => $responsePayload ? json_encode($responsePayload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) : null,
        ];

        try {
            // Try DB log
            if (DB::getSchemaBuilder()->hasTable('nagorikpay_logs')) {
                DB::table('nagorikpay_logs')->insert([
                    'type' => $type,
                    'url' => $url,
                    'order_id' => $orderId,
                    'transaction_id' => $transactionId,
                    'http_status' => $httpStatus,
                    'api_key_masked' => $maskedKey,
                    'request_payload' => $logData['request'],
                    'response_payload' => $logData['response'],
                    'ip' => request()?->ip() ?? '',
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            }
        } catch (\Throwable $e) {
            // fallback to file log
        }

        // Always write to Laravel log for debugging (without sensitive data)
        Log::info('NagorikPay ' . $type, $logData);
    }

    public static function maskedApiKey(): string
    {
        $k = self::apiKey();
        if ($k === '') return '';
        $len = strlen($k);
        if ($len <= 8) return str_repeat('*', $len);
        return substr($k, 0, 4) . str_repeat('*', $len - 8) . substr($k, -4);
    }

    public static function testModeBadge(): string
    {
        if (!self::enabled()) return '';
        if (self::isSandbox()) {
            return '<span class="badge badge-warning" style="font-size:11px;vertical-align:middle;margin-left:8px"><i class="fa-solid fa-flask"></i> TEST MODE • Sandbox</span>';
        }
        return '<span class="badge badge-success" style="font-size:11px;vertical-align:middle;margin-left:8px"><i class="fa-solid fa-shield-halved"></i> LIVE</span>';
    }
}
