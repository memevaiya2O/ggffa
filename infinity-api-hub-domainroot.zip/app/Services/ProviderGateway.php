<?php

namespace App\Services;

use App\Models\ApiService;

/**
 * Forwards requests to provider APIs.
 * Replaces {param} and {provider_key} placeholders in the provider URL.
 */
class ProviderGateway
{
    /**
     * @return array [http_code, body, latency_ms, error]
     */
    public static function request(ApiService $service, array $input): array
    {
        $url = $service->provider_url;
        $providerKey = $service->provider_key ?: setting('global_provider_key', '');

        $replacements = ['provider_key' => $providerKey] + $input;
        foreach ($replacements as $k => $v) {
            $url = str_replace('{'.$k.'}', rawurlencode((string) $v), $url);
        }
        $url = preg_replace('/\{[a-zA-Z0-9_]+\}/', '', $url);
        $parts = parse_url($url);
        $scheme = strtolower((string) ($parts['scheme'] ?? ''));
        $host = (string) ($parts['host'] ?? '');
        if (!in_array($scheme, ['https', 'http'], true) || $host === '') {
            return [0, '', 0, 'Provider URL must be a valid HTTP(S) URL.'];
        }
        if ($scheme === 'http' && setting('api_allow_http', '0') !== '1') {
            return [0, '', 0, 'Insecure HTTP provider URLs are disabled by the administrator.'];
        }
        $resolved = gethostbyname($host);
        if (filter_var($resolved, FILTER_VALIDATE_IP) && ! filter_var($resolved, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
            return [0, '', 0, 'Private or reserved provider hosts are blocked for security.'];
        }

        $method = strtoupper($service->method ?? 'GET');
        $headers = [];
        foreach ($service->headerList() as $h) {
            $h = trim((string) $h);
            if ($h !== '') {
                $headers[] = str_replace('{provider_key}', $providerKey, $h);
            }
        }

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 25);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_REDIR_PROTOCOLS, CURLPROTO_HTTPS);
        curl_setopt($ch, CURLOPT_USERAGENT, 'InfinityAPIHub/3.0');
        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($input));
        }
        if ($headers) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        }

        $start = microtime(true);
        $body = curl_exec($ch);
        $latency = (int) round((microtime(true) - $start) * 1000);
        $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch) ?: '';
        curl_close($ch);

        return [$httpCode, $body === false ? '' : $body, $latency, $err];
    }

    /** Quick health probe with sample values (for admin test + status). */
    public static function probe(ApiService $service, array $input = []): array
    {
        if (! $input) {
            foreach ($service->paramList() as $p) {
                $sample = $p['placeholder'] ?? '';
                $input[$p['name']] = ($sample === '' || strlen($sample) > 24) ? '123456' : $sample;
            }
        }

        return self::request($service, $input);
    }

    /** Browser anti-bot pages are not API responses and cannot be solved server-side. */
    public static function isAntiBotChallenge(string $body): bool
    {
        $sample = strtolower(substr(ltrim($body), 0, 1200));

        return str_contains($sample, 'slowaes.decrypt')
            || str_contains($sample, 'src="/aes.js"')
            || str_contains($sample, "src='/aes.js'")
            || (str_contains($sample, '<html') && str_contains($sample, 'document.cookie'));
    }
}
