/* INFINITY API HUB — App JS */
document.addEventListener('DOMContentLoaded', function () {
  // Mobile nav
  var burger = document.getElementById('burger');
  var nav = document.getElementById('navLinks');
  var sidebar = document.getElementById('sidebar');
  var overlay = document.getElementById('sideOverlay');
  var savedScrollY = 0;
  function lockPage(locked) {
    if (locked) {
      savedScrollY = window.scrollY || window.pageYOffset || 0;
      document.body.style.top = '-' + savedScrollY + 'px';
    } else {
      document.body.style.top = '';
    }
    document.documentElement.classList.toggle('menu-scroll-locked', locked);
    document.body.classList.toggle('menu-scroll-locked', locked);
    if (!locked && savedScrollY) window.scrollTo(0, savedScrollY);
  }
  function setNav(open) {
    if (!nav || !burger) return;
    if (sidebar) {
      if (open) sidebar.scrollTop = 0;
      sidebar.classList.toggle('open', open);
      if (overlay) overlay.classList.toggle('show', open);
      lockPage(open);
    } else {
      nav.classList.toggle('open', open);
      lockPage(open);
    }
    burger.setAttribute('aria-controls', sidebar ? 'sidebar' : 'navLinks');
    burger.setAttribute('aria-expanded', open ? 'true' : 'false');
    burger.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    var icon = burger.querySelector('i');
    if (icon) { icon.classList.toggle('fa-bars', !open); icon.classList.toggle('fa-xmark', open); }
  }
  if (burger && nav) burger.addEventListener('click', function () { setNav(sidebar ? !sidebar.classList.contains('open') : !nav.classList.contains('open')); });
  if (nav) nav.querySelectorAll('a').forEach(function (a) { a.addEventListener('click', function () { setNav(false); }); });
  document.querySelectorAll('[data-menu-close]').forEach(function (btn) { btn.addEventListener('click', function () { closeSide(); setNav(false); }); });

  // Sidebar (dashboard)
  function closeSide() { if (sidebar) sidebar.classList.remove('open'); if (overlay) overlay.classList.remove('show'); lockPage(false); if (burger) { burger.setAttribute('aria-expanded', 'false'); burger.setAttribute('aria-label', 'Open menu'); var icon = burger.querySelector('i'); if (icon) { icon.classList.add('fa-bars'); icon.classList.remove('fa-xmark'); } } }
  if (overlay) overlay.addEventListener('click', closeSide);
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') { closeSide(); setNav(false); document.querySelectorAll('.modal-bg.show').forEach(function (m) { m.classList.remove('show'); }); } });

  // Auto-hide toasts
  setTimeout(function () {
    document.querySelectorAll('.toast').forEach(function (t) {
      t.style.transition = 'all .4s ease'; t.style.opacity = '0'; t.style.transform = 'translateX(40px)';
      setTimeout(function () { t.remove(); }, 400);
    });
  }, 5000);

  // FAQ accordion
  document.querySelectorAll('.faq-q').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var item = btn.closest('.faq-item');
      var ans = item.querySelector('.faq-a');
      var isOpen = item.classList.contains('open');
      document.querySelectorAll('.faq-item.open').forEach(function (o) { o.classList.remove('open'); o.querySelector('.faq-a').style.maxHeight = null; });
      if (!isOpen) { item.classList.add('open'); ans.style.maxHeight = ans.scrollHeight + 'px'; }
    });
  });

  // Tabs
  document.querySelectorAll('[data-tab]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var group = btn.closest('[data-tabs]');
      var target = btn.getAttribute('data-tab');
      group.querySelectorAll('[data-tab]').forEach(function (b) { b.classList.remove('active'); });
      group.querySelectorAll('.tab-pane').forEach(function (p) { p.classList.remove('active'); });
      btn.classList.add('active');
      var pane = group.querySelector('#' + target);
      if (pane) pane.classList.add('active');
    });
  });

  // Confirm deletes
  document.querySelectorAll('[data-confirm]').forEach(function (el) {
    el.addEventListener('click', function (ev) {
      if (!confirm(el.getAttribute('data-confirm') || 'Are you sure?')) ev.preventDefault();
    });
  });

  // Docs nav active on scroll
  var docLinks = document.querySelectorAll('.docs-nav a[href^="#"]');
  if (docLinks.length) {
    window.addEventListener('scroll', function () {
      var cur = '';
      document.querySelectorAll('.doc-sec[id]').forEach(function (s) {
        if (window.scrollY >= s.offsetTop - 140) cur = s.id;
      });
      docLinks.forEach(function (a) { a.classList.toggle('active', a.getAttribute('href') === '#' + cur); });
    }, { passive: true });
  }
});

// Copy to clipboard
function copyText(text, btn) {
  var done = function () {
    if (btn) {
      var old = btn.innerHTML;
      btn.innerHTML = '<i class="fa-solid fa-check"></i> Copied';
      setTimeout(function () { btn.innerHTML = old; }, 1600);
    }
    toast('Copied to clipboard', 'success');
  };
  if (navigator.clipboard && window.isSecureContext) {
    navigator.clipboard.writeText(text).then(done).catch(function () { fallbackCopy(text); done(); });
  } else { fallbackCopy(text); done(); }
}
function fallbackCopy(text) {
  var ta = document.createElement('textarea');
  ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
  document.body.appendChild(ta); ta.select();
  try { document.execCommand('copy'); } catch (e) {}
  document.body.removeChild(ta);
}
// Tiny toast from JS
function toast(msg, type) {
  type = type || 'info';
  var wrap = document.querySelector('.toast-wrap');
  if (!wrap) { wrap = document.createElement('div'); wrap.className = 'toast-wrap'; document.body.appendChild(wrap); }
  var icons = { success: 'fa-circle-check', error: 'fa-circle-exclamation', warning: 'fa-triangle-exclamation', info: 'fa-circle-info' };
  var d = document.createElement('div');
  d.className = 'toast toast-' + type;
  d.innerHTML = '<i class="fa-solid ' + (icons[type] || icons.info) + '"></i><span></span>';
  d.querySelector('span').textContent = msg;
  wrap.appendChild(d);
  setTimeout(function () { d.style.opacity = '0'; setTimeout(function () { d.remove(); }, 400); }, 3200);
}
// Modal helpers
function openModal(id) { var m = document.getElementById(id); if (m) m.classList.add('show'); }
function closeModal(id) { var m = document.getElementById(id); if (m) m.classList.remove('show'); }
document.addEventListener('click', function (e) {
  if (e.target.classList && e.target.classList.contains('modal-bg')) e.target.classList.remove('show');
});


// Live API carousel: advances every five seconds and pauses while the user interacts.
document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('[data-api-carousel]').forEach(function (carousel) {
    var track = carousel.querySelector('.api-carousel-track');
    var slides = Array.prototype.slice.call(carousel.querySelectorAll('.api-slide'));
    var dots = carousel.querySelector('[data-api-dots]');
    var prev = document.querySelector('[data-api-prev]');
    var next = document.querySelector('[data-api-next]');
    if (!track || slides.length < 2) return;
    var index = 0, timer = null, perView = 3;
    function visible() { return window.innerWidth <= 640 ? 1 : (window.innerWidth <= 1024 ? 2 : 2); }
    function maxIndex() { return Math.max(0, slides.length - perView); }
    function renderDots() {
      if (!dots) return;
      dots.innerHTML = '';
      slides.forEach(function (_, i) {
        var dot = document.createElement('button'); dot.type = 'button'; dot.className = 'carousel-dot';
        dot.setAttribute('aria-label', 'Show API slide ' + (i + 1));
        dot.addEventListener('click', function () { index = Math.min(i, maxIndex()); render(); restart(); });
        dots.appendChild(dot);
      });
    }
    function render() {
      perView = visible(); index = Math.min(index, maxIndex());
      var gap = parseFloat(getComputedStyle(track).gap) || 0;
      var width = slides[0].getBoundingClientRect().width + gap;
      track.style.transform = 'translate3d(' + (-index * width) + 'px,0,0)';
      slides.forEach(function (slide, i) { slide.setAttribute('aria-hidden', i < index || i >= index + perView ? 'true' : 'false'); });
      if (dots) Array.prototype.forEach.call(dots.children, function (dot, i) { dot.classList.toggle('active', i === index); });
    }
    function step(dir) { index = index + dir; if (index > maxIndex()) index = 0; if (index < 0) index = maxIndex(); render(); }
    function restart() { clearInterval(timer); timer = setInterval(function () { step(1); }, parseInt(carousel.dataset.interval || '5000', 10)); }
    if (prev) prev.addEventListener('click', function () { step(-1); restart(); });
    if (next) next.addEventListener('click', function () { step(1); restart(); });
    carousel.addEventListener('mouseenter', function () { clearInterval(timer); });
    carousel.addEventListener('mouseleave', restart);
    window.addEventListener('resize', render);
    renderDots(); render(); restart();
  });
});


// Pricing carousel: the side slider belongs to pricing plans and advances every five seconds.
document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('[data-pricing-carousel]').forEach(function (carousel) {
    var track = carousel.querySelector('.pricing-track');
    var slides = Array.prototype.slice.call(carousel.querySelectorAll('.pricing-slide'));
    var dots = carousel.querySelector('[data-pricing-dots]');
    var prev = document.querySelector('[data-pricing-prev]');
    var next = document.querySelector('[data-pricing-next]');
    if (!track || slides.length < 2) return;
    var index = 0, timer = null, perView = 3;
    function visible() { return window.innerWidth <= 640 ? 1 : (window.innerWidth <= 1024 ? 2 : 2); }
    function maxIndex() { return Math.max(0, slides.length - perView); }
    function renderDots() {
      if (!dots) return;
      dots.innerHTML = '';
      slides.forEach(function (_, i) {
        var dot = document.createElement('button'); dot.type = 'button'; dot.className = 'carousel-dot';
        dot.setAttribute('aria-label', 'Show pricing slide ' + (i + 1));
        dot.addEventListener('click', function () { index = Math.min(i, maxIndex()); render(); restart(); });
        dots.appendChild(dot);
      });
    }
    function render() {
      perView = visible(); index = Math.min(index, maxIndex());
      var gap = parseFloat(getComputedStyle(track).gap) || 0;
      var width = slides[0].getBoundingClientRect().width + gap;
      track.style.transform = 'translate3d(' + (-index * width) + 'px,0,0)';
      slides.forEach(function (slide, i) { slide.setAttribute('aria-hidden', i < index || i >= index + perView ? 'true' : 'false'); });
      if (dots) Array.prototype.forEach.call(dots.children, function (dot, i) { dot.classList.toggle('active', i === index); });
    }
    function step(dir) { index += dir; if (index > maxIndex()) index = 0; if (index < 0) index = maxIndex(); render(); }
    function restart() { clearInterval(timer); timer = setInterval(function () { step(1); }, parseInt(carousel.dataset.interval || '5000', 10)); }
    if (prev) prev.addEventListener('click', function () { step(-1); restart(); });
    if (next) next.addEventListener('click', function () { step(1); restart(); });
    carousel.addEventListener('mouseenter', function () { clearInterval(timer); });
    carousel.addEventListener('mouseleave', restart);
    window.addEventListener('resize', render);
    renderDots(); render(); restart();
  });
});


// Shared mobile swipe gestures for every homepage horizontal card slider.
document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('[data-api-carousel], [data-pricing-carousel]').forEach(function (carousel) {
    var startX = 0, startY = 0;
    carousel.addEventListener('touchstart', function (e) {
      var t = e.changedTouches[0];
      startX = t.clientX;
      startY = t.clientY;
    }, { passive: true });
    carousel.addEventListener('touchend', function (e) {
      var t = e.changedTouches[0];
      var dx = t.clientX - startX;
      var dy = t.clientY - startY;
      if (Math.abs(dx) < 42 || Math.abs(dx) < Math.abs(dy)) return;
      var selector = carousel.hasAttribute('data-api-carousel') ? '[data-api-next]' : '[data-pricing-next]';
      var reverse = carousel.hasAttribute('data-api-carousel') ? '[data-api-prev]' : '[data-pricing-prev]';
      var button = document.querySelector(dx < 0 ? selector : reverse);
      if (button) button.click();
    }, { passive: true });
  });
});


// User Buy page: each API gets its own complete pricing slider.
document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('[data-buy-carousel]').forEach(function (carousel) {
    var track = carousel.querySelector('.buy-track');
    var slides = Array.prototype.slice.call(carousel.querySelectorAll('.buy-slide'));
    var dots = carousel.querySelector('[data-buy-dots]');
    var prev = carousel.querySelector('[data-buy-prev]');
    var next = carousel.querySelector('[data-buy-next]');
    if (!track || slides.length < 2) return;
    var index = 0, timer = null;
    function visible() { return window.innerWidth <= 640 ? 1 : 2; }
    function maxIndex() { return Math.max(0, slides.length - visible()); }
    function renderDots() {
      if (!dots) return;
      dots.innerHTML = '';
      slides.forEach(function (_, i) {
        var dot = document.createElement('button'); dot.type = 'button'; dot.className = 'carousel-dot';
        dot.setAttribute('aria-label', 'Show package ' + (i + 1));
        dot.addEventListener('click', function () { index = Math.min(i, maxIndex()); render(); restart(); });
        dots.appendChild(dot);
      });
    }
    function render() {
      index = Math.min(index, maxIndex());
      var gap = parseFloat(getComputedStyle(track).gap) || 0;
      var width = slides[0].getBoundingClientRect().width + gap;
      track.style.transform = 'translate3d(' + (-index * width) + 'px,0,0)';
      slides.forEach(function (slide, i) { slide.setAttribute('aria-hidden', i < index || i >= index + visible() ? 'true' : 'false'); });
      if (dots) Array.prototype.forEach.call(dots.children, function (dot, i) { dot.classList.toggle('active', i === index); });
    }
    function step(dir) { index += dir; if (index > maxIndex()) index = 0; if (index < 0) index = maxIndex(); render(); }
    function restart() { clearInterval(timer); timer = setInterval(function () { step(1); }, 5000); }
    if (prev) prev.addEventListener('click', function () { step(-1); restart(); });
    if (next) next.addEventListener('click', function () { step(1); restart(); });
    var sx = 0, sy = 0;
    carousel.addEventListener('touchstart', function (e) { sx = e.changedTouches[0].clientX; sy = e.changedTouches[0].clientY; clearInterval(timer); }, { passive: true });
    carousel.addEventListener('touchend', function (e) { var dx = e.changedTouches[0].clientX - sx, dy = e.changedTouches[0].clientY - sy; if (Math.abs(dx) > 42 && Math.abs(dx) > Math.abs(dy)) step(dx < 0 ? 1 : -1); restart(); }, { passive: true });
    window.addEventListener('resize', function () { renderDots(); render(); });
    renderDots(); render(); restart();
  });
});

// Stable copy handlers for dynamically rendered code samples.
document.addEventListener('click', function (event) {
  var btn = event.target.closest && event.target.closest('.quick-copy-btn');
  if (!btn) return;
  event.preventDefault();
  var target = document.getElementById(btn.getAttribute('data-copy-target'));
  if (target) copyText(target.textContent || target.innerText || '', btn);
});
