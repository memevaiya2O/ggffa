<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    // This package runs with the app root itself as the web-served folder
    // (single domain-root deployment), so admin uploads written via
    // public_path() land in the same folder as index.php, where the
    // browser can actually reach them.
    ->usePublicPath(dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware) {
        $middleware->validateCsrfTokens(except: ['payments/nagorikpay/*/webhook']);
        $middleware->alias([
            'admin' => \App\Http\Middleware\AdminMiddleware::class,
            'active' => \App\Http\Middleware\EnsureActiveUser::class,
            'force.password' => \App\Http\Middleware\ForcePasswordChange::class,
            'throttle.gateway' => \App\Http\Middleware\ThrottleApiGateway::class,
        ]);
        $middleware->web(append: [
            \App\Http\Middleware\SiteMaintenance::class,
            \App\Http\Middleware\ForcePasswordChange::class,
        ]);
        $middleware->api(append: [
            \App\Http\Middleware\ThrottleApiGateway::class,
        ]);
        $middleware->throttleApi();
    })
    ->withExceptions(function (Exceptions $exceptions) {
        //
    })->create();
