<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('api_services', function (Blueprint $table) {
            $table->id();
            $table->string('name', 150);
            $table->string('slug', 100)->unique();
            $table->string('description', 255)->default('');
            $table->string('icon', 60)->default('fa-plug');
            $table->text('provider_url');
            $table->enum('method', ['GET', 'POST'])->default('GET');
            $table->text('headers')->nullable();
            $table->string('provider_key')->default('');
            $table->text('params')->nullable();
            $table->integer('credits_per_hit')->default(1);
            $table->integer('free_quota')->default(25);
            $table->enum('status', ['active', 'inactive'])->default('active');
            $table->boolean('show_on_home')->default(true);
            $table->integer('sort_order')->default(0);
            $table->text('docs_text')->nullable();
            $table->text('sample_response')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('api_services');
    }
};
