<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('service_keys', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('service_id')->constrained('api_services')->cascadeOnDelete();
            $table->string('api_key', 100)->unique();
            $table->string('label', 100)->default('My API Key');
            $table->integer('total_request')->default(0);
            $table->integer('used_request')->default(0);
            $table->date('exp_date')->nullable();
            $table->enum('status', ['active', 'inactive', 'expired'])->default('active');
            $table->dateTime('last_used_at')->nullable();
            $table->timestamps();
            $table->unique(['user_id', 'service_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('service_keys');
    }
};
