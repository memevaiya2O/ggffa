<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('service_id')->nullable()->constrained('api_services')->nullOnDelete();
            $table->foreignId('package_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignId('key_id')->nullable()->constrained('service_keys')->nullOnDelete();
            $table->decimal('amount', 10, 2)->default(0);
            $table->string('payment_method', 30)->default('');
            $table->string('sender_number', 30)->default('');
            $table->string('txn_id', 100)->default('');
            $table->enum('status', ['pending', 'approved', 'rejected'])->default('pending');
            $table->string('admin_note', 255)->default('');
            $table->timestamps();
            $table->dateTime('reviewed_at')->nullable();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('orders');
    }
};
