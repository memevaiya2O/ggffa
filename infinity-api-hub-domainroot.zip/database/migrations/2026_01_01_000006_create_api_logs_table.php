<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('api_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->nullable()->constrained()->cascadeOnDelete();
            $table->foreignId('key_id')->nullable()->constrained('service_keys')->cascadeOnDelete();
            $table->foreignId('service_id')->nullable()->constrained('api_services')->nullOnDelete();
            $table->string('param_summary', 255)->default('');
            $table->string('ip', 45)->default('');
            $table->enum('status', ['success', 'error'])->default('success');
            $table->integer('response_code')->default(0);
            $table->integer('latency_ms')->default(0);
            $table->integer('credits_used')->default(0);
            $table->text('response_snippet')->nullable();
            $table->enum('source', ['api', 'panel'])->default('api');
            $table->timestamp('created_at')->useCurrent();
            $table->index('created_at');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('api_logs');
    }
};
