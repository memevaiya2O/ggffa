<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        // --- orders: add hardening columns + expand status enum + unique index
        Schema::table('orders', function (Blueprint $table) {
            if (!Schema::hasColumn('orders', 'expires_at')) {
                $table->dateTime('expires_at')->nullable()->after('reviewed_at');
            }
            if (!Schema::hasColumn('orders', 'nagorikpay_txn')) {
                $table->string('nagorikpay_txn', 120)->default('')->after('txn_id');
            }
            if (!Schema::hasColumn('orders', 'attempts')) {
                $table->integer('attempts')->default(0)->after('admin_note');
            }
        });

        // Expand status enum – handle both MySQL and SQLite
        $driver = DB::getDriverName();
        if ($driver === 'mysql') {
            DB::statement("ALTER TABLE `orders` MODIFY `status` ENUM('pending','approved','rejected','expired','cancelled') NOT NULL DEFAULT 'pending'");
        } elseif ($driver === 'sqlite') {
            // SQLite has no enum – the check constraint is loose; we just ensure column exists.
            // No action needed – Eloquent validation will enforce.
        }

        // Unique composite on payment_method + txn_id where txn_id not empty and not FREE-like
        // MySQL partial index not supported; create unique index and handle via app-level + DB-level where possible
        try {
            // Create unique index that will prevent duplicate txn among same method
            // For SQLite, create same; duplicates with empty txn will be prevented by app – add filtered unique via trigger if needed
            Schema::table('orders', function (Blueprint $table) {
                $table->unique(['payment_method', 'txn_id'], 'orders_payment_method_txn_unique');
            });
        } catch (\Throwable $e) {
            // index may already exist or fail on existing duplicates – log and continue
            \Illuminate\Support\Facades\Log::warning('orders unique index creation skipped: '.$e->getMessage());
        }

        // --- users: add password change enforcement
        Schema::table('users', function (Blueprint $table) {
            if (!Schema::hasColumn('users', 'password_changed_at')) {
                $table->dateTime('password_changed_at')->nullable()->after('remember_token');
            }
            if (!Schema::hasColumn('users', 'must_change_password')) {
                $table->boolean('must_change_password')->default(false)->after('password_changed_at');
            }
        });

        // --- api_services: expand docs fields
        Schema::table('api_services', function (Blueprint $table) {
            if (!Schema::hasColumn('api_services', 'docs_markdown')) {
                $table->text('docs_markdown')->nullable()->after('docs_text');
            }
            if (!Schema::hasColumn('api_services', 'docs_error_codes')) {
                $table->text('docs_error_codes')->nullable()->after('docs_markdown');
            }
            if (!Schema::hasColumn('api_services', 'docs_rate_limit')) {
                $table->string('docs_rate_limit', 100)->default('')->after('docs_error_codes');
            }
            if (!Schema::hasColumn('api_services', 'docs_example_params')) {
                $table->text('docs_example_params')->nullable()->after('docs_rate_limit');
            }
        });

        // --- nagorikpay_logs
        if (!Schema::hasTable('nagorikpay_logs')) {
            Schema::create('nagorikpay_logs', function (Blueprint $table) {
                $table->id();
                $table->string('type', 20)->default('create'); // create, verify, webhook
                $table->string('url', 500)->default('');
                $table->foreignId('order_id')->nullable()->constrained('orders')->nullOnDelete();
                $table->string('transaction_id', 120)->default('');
                $table->integer('http_status')->default(0);
                $table->string('api_key_masked', 60)->default('');
                $table->text('request_payload')->nullable();
                $table->text('response_payload')->nullable();
                $table->string('ip', 45)->default('');
                $table->timestamps();
                $table->index('order_id');
                $table->index('transaction_id');
                $table->index('created_at');
            });
        }

        // --- payment invoices meta (simple table for PDF path + email sent)
        if (!Schema::hasTable('invoices')) {
            Schema::create('invoices', function (Blueprint $table) {
                $table->id();
                $table->foreignId('order_id')->constrained()->cascadeOnDelete();
                $table->foreignId('user_id')->constrained()->cascadeOnDelete();
                $table->string('invoice_number', 40)->unique();
                $table->string('pdf_path', 255)->default('');
                $table->dateTime('emailed_at')->nullable();
                $table->timestamps();
            });
        }

        // --- seed new settings defaults for nagorikpay hardening if not present
        $defaults = [
            'nagorikpay_enabled' => '0',
            'nagorikpay_mode' => 'sandbox',
            'nagorikpay_base_url' => '',
            'nagorikpay_create_path' => 'api/payment/create',
            'nagorikpay_verify_path' => 'api/payment/verify',
            'nagorikpay_api_key' => '',
            'nagorikpay_api_key_live' => '',
            'nagorikpay_api_key_sandbox' => '',
            'nagorikpay_webhook_secret' => '',
            'nagorikpay_webhook_secret_live' => '',
            'nagorikpay_webhook_secret_sandbox' => '',
            'nagorikpay_brand_id' => '',
            'nagorikpay_expire_minutes' => '30',
            'nagorikpay_recheck_minutes' => '5',
            'nagorikpay_auto_verify' => '1',
        ];
        foreach ($defaults as $k => $v) {
            if (!DB::table('settings')->where('setting_key', $k)->exists()) {
                DB::table('settings')->insert(['setting_key' => $k, 'setting_value' => $v]);
            }
        }

        // Force existing admin to must_change_password if still using default
        try {
            $admin = DB::table('users')->where('email', 'admin@infinity.hub')->first();
            if ($admin && \Illuminate\Support\Facades\Hash::check('admin123', $admin->password)) {
                DB::table('users')->where('id', $admin->id)->update(['must_change_password' => 1]);
            }
        } catch (\Throwable $e) {}
    }

    public function down(): void
    {
        Schema::dropIfExists('nagorikpay_logs');
        Schema::dropIfExists('invoices');
        Schema::table('orders', function (Blueprint $table) {
            try { $table->dropUnique('orders_payment_method_txn_unique'); } catch (\Throwable $e) {}
            if (Schema::hasColumn('orders', 'expires_at')) $table->dropColumn('expires_at');
            if (Schema::hasColumn('orders', 'nagorikpay_txn')) $table->dropColumn('nagorikpay_txn');
            if (Schema::hasColumn('orders', 'attempts')) $table->dropColumn('attempts');
        });
        Schema::table('users', function (Blueprint $table) {
            if (Schema::hasColumn('users', 'password_changed_at')) $table->dropColumn('password_changed_at');
            if (Schema::hasColumn('users', 'must_change_password')) $table->dropColumn('must_change_password');
        });
        Schema::table('api_services', function (Blueprint $table) {
            if (Schema::hasColumn('api_services', 'docs_markdown')) $table->dropColumn('docs_markdown');
            if (Schema::hasColumn('api_services', 'docs_error_codes')) $table->dropColumn('docs_error_codes');
            if (Schema::hasColumn('api_services', 'docs_rate_limit')) $table->dropColumn('docs_rate_limit');
            if (Schema::hasColumn('api_services', 'docs_example_params')) $table->dropColumn('docs_example_params');
        });
    }
};
