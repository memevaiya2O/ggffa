<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('wallets', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->unique()->constrained()->cascadeOnDelete();
            $table->decimal('balance', 12, 2)->default(0);
            $table->timestamps();
        });

        Schema::create('wallet_transactions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('wallet_id')->constrained('wallets')->cascadeOnDelete();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('order_id')->nullable()->constrained('orders')->nullOnDelete();
            $table->string('type', 30);
            $table->decimal('amount', 12, 2);
            $table->decimal('balance_after', 12, 2)->default(0);
            $table->string('reference', 120)->nullable()->unique();
            $table->string('description', 255)->default('');
            $table->json('metadata')->nullable();
            $table->timestamps();
        });

        Schema::table('api_services', function (Blueprint $table) {
            $table->decimal('credit_price', 10, 2)->default(1.00)->after('credits_per_hit');
        });

        Schema::table('orders', function (Blueprint $table) {
            $table->string('order_kind', 30)->default('credit_purchase')->after('payment_method');
            $table->unsignedInteger('credit_quantity')->default(0)->after('order_kind');
            $table->decimal('unit_price', 10, 2)->default(0)->after('credit_quantity');
            $table->decimal('wallet_amount', 12, 2)->default(0)->after('unit_price');
        });

        foreach (['wallet_min_topup' => '10', 'wallet_max_topup' => '100000', 'credit_price_default' => '1'] as $key => $value) {
            if (Schema::hasTable('settings') && !DB::table('settings')->where('setting_key', $key)->exists()) {
                DB::table('settings')->insert(['setting_key' => $key, 'setting_value' => $value]);
            }
        }
    }

    public function down(): void
    {
        Schema::table('orders', function (Blueprint $table) {
            $table->dropColumn(['order_kind', 'credit_quantity', 'unit_price', 'wallet_amount']);
        });
        Schema::table('api_services', function (Blueprint $table) {
            $table->dropColumn('credit_price');
        });
        Schema::dropIfExists('wallet_transactions');
        Schema::dropIfExists('wallets');
    }
};
