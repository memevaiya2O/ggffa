<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasColumn('api_services', 'docs_use_cases')) {
            Schema::table('api_services', function (Blueprint $table) {
                $table->text('docs_use_cases')->nullable()->after('description');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('api_services', 'docs_use_cases')) {
            Schema::table('api_services', function (Blueprint $table) {
                $table->dropColumn('docs_use_cases');
            });
        }
    }
};
