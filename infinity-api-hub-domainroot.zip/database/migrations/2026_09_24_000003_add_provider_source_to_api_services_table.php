<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasColumn('api_services', 'provider_source')) {
            Schema::table('api_services', function (Blueprint $table) {
                $table->string('provider_source', 30)->default('external_api')->after('provider_url');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('api_services', 'provider_source')) {
            Schema::table('api_services', function (Blueprint $table) {
                $table->dropColumn('provider_source');
            });
        }
    }
};
