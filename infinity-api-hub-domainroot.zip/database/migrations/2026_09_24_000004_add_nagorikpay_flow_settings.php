<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    public function up(): void
    {
        $defaults = [
            'nagorikpay_payment_flow' => 'hosted',
            'nagorikpay_payment_method' => 'auto',
            'nagorikpay_account_type' => 'personal',
            'nagorikpay_create_request_path' => 'api/payment/create-request',
            'nagorikpay_submit_transaction_path' => 'api/payment-submit-transaction',
            'nagorikpay_callback_base_url' => '',
        ];
        foreach ($defaults as $key => $value) {
            if (!DB::table('settings')->where('setting_key', $key)->exists()) {
                DB::table('settings')->insert([
                    'setting_key' => $key,
                    'setting_value' => $value,
                ]);
            }
        }
    }

    public function down(): void
    {
        DB::table('settings')->whereIn('setting_key', [
            'nagorikpay_payment_flow', 'nagorikpay_payment_method', 'nagorikpay_account_type',
            'nagorikpay_create_request_path', 'nagorikpay_submit_transaction_path', 'nagorikpay_callback_base_url',
        ])->delete();
    }
};
