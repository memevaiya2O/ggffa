<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasColumn('orders', 'gateway_payment_id')) {
            Schema::table('orders', function (Blueprint $table) {
                $table->string('gateway_payment_id', 120)->nullable()->after('nagorikpay_txn');
                $table->index('gateway_payment_id');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('orders', 'gateway_payment_id')) {
            Schema::table('orders', function (Blueprint $table) {
                $table->dropIndex(['gateway_payment_id']);
                $table->dropColumn('gateway_payment_id');
            });
        }
    }
};
