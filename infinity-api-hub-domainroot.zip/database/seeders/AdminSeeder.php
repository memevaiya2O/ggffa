<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class AdminSeeder extends Seeder
{
    public function run(): void
    {
        $existing = User::where('email', 'admin@infinity.hub')->first();

        if ($existing) {
            // If still using default password, force change
            if (Hash::check('admin123', $existing->password)) {
                $existing->forceFill(['must_change_password' => true])->save();
                $this->command?->warn('Admin account admin@infinity.hub still uses default password – flagged for mandatory change.');
            }
            return;
        }

        // Generate a strong random password, show once via console + log
        $randomPassword = Str::random(14) . '!' . Str::random(2);
        $user = User::create([
            'name' => 'Super Admin',
            'email' => 'admin@infinity.hub',
            'phone' => '',
            'password' => $randomPassword,
            'role' => 'admin',
            'status' => 'active',
            'must_change_password' => true, // force change on first login even though password is random
            'password_changed_at' => null,
        ]);

        // Output to console – visible once during seed
        $msg = "ADMIN CREATED — email: admin@infinity.hub | password: {$randomPassword} | MUST CHANGE ON FIRST LOGIN";
        $this->command?->info($msg);
        $this->command?->warn('Store this password securely – it is shown only once. You must change it after first login.');
        \Illuminate\Support\Facades\Log::info($msg);

        // Also write to storage so deployer can retrieve if missed console output
        try {
            \Illuminate\Support\Facades\File::put(storage_path('admin-credentials.txt'), $msg . PHP_EOL . 'Generated at: ' . now()->toDateTimeString() . PHP_EOL);
        } catch (\Throwable $e) {}
    }
}
