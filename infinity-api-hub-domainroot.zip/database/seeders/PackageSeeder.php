<?php

namespace Database\Seeders;

use App\Models\ApiService;
use App\Models\Package;
use Illuminate\Database\Seeder;

class PackageSeeder extends Seeder
{
    public function run(): void
    {
        $plans = [
            ['name' => 'Free Starter', 'price' => 0, 'requests' => 100, 'validity_days' => 7, 'highlight' => false, 'features' => "Instant activation\nCommunity support"],
            ['name' => 'Basic', 'price' => 100, 'requests' => 1000, 'validity_days' => 30, 'highlight' => false, 'features' => "Instant activation\nEmail support"],
            ['name' => 'Pro', 'price' => 400, 'requests' => 5000, 'validity_days' => 30, 'highlight' => true, 'features' => "Priority speed\nPriority support"],
            ['name' => 'Business', 'price' => 1200, 'requests' => 20000, 'validity_days' => 60, 'highlight' => false, 'features' => "Highest speed\nDedicated support"],
        ];

        foreach (ApiService::all() as $i => $service) {
            foreach ($plans as $j => $p) {
                Package::firstOrCreate(
                    ['service_id' => $service->id, 'name' => $p['name']],
                    [...$p, 'status' => 'active', 'sort_order' => ($j + 1)]
                );
            }
        }
    }
}
