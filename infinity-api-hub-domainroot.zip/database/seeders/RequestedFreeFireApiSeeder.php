<?php

namespace Database\Seeders;

use App\Models\ApiService;
use Illuminate\Database\Seeder;

class RequestedFreeFireApiSeeder extends Seeder
{
    public function run(): void
    {
        $services = [
            [
                'slug' => 'ff-uid-lookup',
                'name' => 'FF UID Lookup',
                'description' => 'Look up a Free Fire player profile by UID.',
                'icon' => 'fa-gamepad',
                'provider_url' => 'http://ixbd.qd.je/ff.php?uid={uid}',
                'sample_response' => '{"uid":"2769409057","name":"Player Name"}',
                'sort_order' => 3,
            ],
            [
                'slug' => 'ff-player-info',
                'name' => 'FF Player Info',
                'description' => 'Get detailed Free Fire profile, rank and account information.',
                'icon' => 'fa-id-card',
                'provider_url' => 'https://ffxinfo-ffx.ffxapis.workers.dev/ffinfo?uid={uid}',
                'sample_response' => '{"error":false,"status":200,"data":{"identity":{"uid":"2769409057"}}}',
                'sort_order' => 4,
            ],
            [
                'slug' => 'ff-market-value',
                'name' => 'FF Market Value',
                'description' => 'Estimate a Free Fire account market value by UID.',
                'icon' => 'fa-chart-line',
                'provider_url' => 'https://market-value-api.ffxapis.workers.dev/market-value?uid={uid}',
                'sample_response' => '{"uid":"1704140050","name":"Player Name","market_value":"5,541 TK"}',
                'sort_order' => 5,
            ],
        ];

        foreach ($services as $item) {
            ApiService::updateOrCreate(
                ['slug' => $item['slug']],
                array_merge($item, [
                    'method' => 'GET',
                    'headers' => [],
                    'provider_key' => '',
                    'params' => [['name' => 'uid', 'label' => 'Player UID', 'required' => 1, 'placeholder' => '2769409057']],
                    'credits_per_hit' => 1,
                    'free_quota' => 25,
                    'status' => 'active',
                    'show_on_home' => true,
                    'docs_text' => 'Send a Free Fire UID to receive the provider response. Use a valid UID for the selected region.',
                ])
            );
        }
    }
}
