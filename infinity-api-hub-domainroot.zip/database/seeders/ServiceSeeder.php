<?php

namespace Database\Seeders;

use App\Models\ApiService;
use Illuminate\Database\Seeder;

class ServiceSeeder extends Seeder
{
    public function run(): void
    {
        $services = [
            [
                'slug' => 'ff-uid', 'name' => 'Free Fire UID Check', 'description' => 'Get Free Fire player nickname from UID instantly.', 'icon' => 'fa-gamepad',
                'provider_url' => 'https://nanobd.shop/ffnamecheck/api.php?uid={uid}&key={provider_key}&type=rs', 'method' => 'GET', 'headers' => [], 'provider_key' => '',
                'params' => [['name'=>'uid','label'=>'Player UID','required'=>1,'placeholder'=>'2535040417']], 'credits_per_hit'=>1, 'free_quota'=>25, 'status'=>'active', 'show_on_home'=>true, 'sort_order'=>1,
                'docs_text'=>'Enter the player UID to get the current nickname. Works for all regions.', 'sample_response'=>'{"status": true, "data": {"username": "Player Name Here"}}',
            ],
            [
                'slug' => 'ip-info', 'name' => 'IP Information', 'description' => 'Get country, city and ISP info of any IP address.', 'icon' => 'fa-location-dot',
                'provider_url' => 'http://ip-api.com/json/{ip}?fields=status,country,city,isp,query', 'method' => 'GET', 'headers' => [], 'provider_key' => '',
                'params' => [['name'=>'ip','label'=>'IP Address','required'=>1,'placeholder'=>'8.8.8.8']], 'credits_per_hit'=>1, 'free_quota'=>25, 'status'=>'active', 'show_on_home'=>true, 'sort_order'=>2,
                'docs_text'=>'Pass any public IPv4 address to get geolocation details. No provider key needed.', 'sample_response'=>'{"status": "success", "country": "United States", "city": "Ashburn", "isp": "Google LLC", "query": "8.8.8.8"}',
            ],
            [
                'slug'=>'ff-id-info', 'name'=>'Free Fire ID Info', 'description'=>'Get Free Fire player information by UID.', 'docs_use_cases'=>"Player profile lookup\nFree Fire UID verification\nGame information display", 'icon'=>'fa-id-card',
                'provider_url'=>'https://ffxinfo-ffx.ffxapis.workers.dev/ffinfo?uid={uid}', 'provider_source'=>'subdomain', 'method'=>'GET', 'headers'=>[], 'provider_key'=>'',
                'params'=>[['name'=>'uid','label'=>'Free Fire UID','required'=>1,'placeholder'=>'2535040417']], 'credits_per_hit'=>1, 'credit_price'=>1, 'free_quota'=>25, 'status'=>'active', 'show_on_home'=>true, 'sort_order'=>10,
                'docs_text'=>'Returns Free Fire player information for the supplied UID.', 'docs_markdown'=>'Use this API to retrieve Free Fire player information by UID.\n\n**Required parameter:** `uid`', 'docs_error_codes'=>"400|Invalid UID\n404|Player not found\n429|Rate limited", 'docs_rate_limit'=>'60 requests/minute', 'docs_example_params'=>['uid'=>'2535040417'], 'sample_response'=>'{"status":"success","uid":"2535040417"}',
            ],
            [
                'slug'=>'ff-name-check', 'name'=>'Free Fire Name Check', 'description'=>'Check Free Fire player name by UID.', 'docs_use_cases'=>"Player name lookup\nUID ownership check\nGaming profile tools", 'icon'=>'fa-user-check',
                'provider_url'=>'http://ixbd.qd.je/ff.php?uid={uid}', 'provider_source'=>'subdomain', 'method'=>'GET', 'headers'=>[], 'provider_key'=>'',
                'params'=>[['name'=>'uid','label'=>'Free Fire UID','required'=>1,'placeholder'=>'2769409057']], 'credits_per_hit'=>1, 'credit_price'=>1, 'free_quota'=>25, 'status'=>'active', 'show_on_home'=>true, 'sort_order'=>11,
                'docs_text'=>'Checks the current Free Fire player name for a UID.', 'docs_markdown'=>'Check a Free Fire player name with a single UID parameter.\n\n**Required parameter:** `uid`', 'docs_error_codes'=>"400|Invalid UID\n404|Player not found\n429|Rate limited", 'docs_rate_limit'=>'60 requests/minute', 'docs_example_params'=>['uid'=>'2769409057'], 'sample_response'=>'{"status":"success","uid":"2769409057"}',
            ],
            [
                'slug'=>'ff-id-market-value', 'name'=>'Free Fire ID Market Value', 'description'=>'Estimate Free Fire ID market value by UID.', 'docs_use_cases'=>"Player ID valuation\nGaming marketplace tools\nAccount value display", 'icon'=>'fa-chart-line',
                'provider_url'=>'http://market-value-api.ffxapis.workers.dev/market-value?uid={uid}', 'provider_source'=>'subdomain', 'method'=>'GET', 'headers'=>[], 'provider_key'=>'',
                'params'=>[['name'=>'uid','label'=>'Free Fire UID','required'=>1,'placeholder'=>'1704140050']], 'credits_per_hit'=>1, 'credit_price'=>1, 'free_quota'=>25, 'status'=>'active', 'show_on_home'=>true, 'sort_order'=>12,
                'docs_text'=>'Returns the estimated market value for a Free Fire ID.', 'docs_markdown'=>'Estimate a Free Fire ID market value by UID.\n\n**Required parameter:** `uid`', 'docs_error_codes'=>"400|Invalid UID\n404|Player not found\n429|Rate limited", 'docs_rate_limit'=>'60 requests/minute', 'docs_example_params'=>['uid'=>'1704140050'], 'sample_response'=>'{"status":"success","uid":"1704140050"}',
            ],
        ];

        foreach ($services as $service) {
            ApiService::updateOrCreate(['slug' => $service['slug']], $service);
        }
    }
}
