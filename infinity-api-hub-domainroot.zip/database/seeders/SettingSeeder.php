<?php

namespace Database\Seeders;

use App\Models\Notification;
use App\Models\Setting;
use Illuminate\Database\Seeder;

class SettingSeeder extends Seeder
{
    public function run(): void
    {
        $rows = [
            'site_name' => 'INFINITY API HUB',
            'site_tagline' => 'Premium API Platform',
            'logo' => '',
            'announcement' => '',
            'registration_open' => '1',
            'primary_color' => '#2563eb',
            'hero_badge' => 'Trusted API Platform',
            'hero_title' => 'Powerful APIs for {hl}Modern Apps{/hl}',
            'hero_subtitle' => 'One key per API. Blazing-fast gaming, verification and utility APIs with simple integration and instant delivery.',
            'feat1_title' => 'Lightning Fast',
            'feat1_desc' => 'Optimized gateway with millisecond response times.',
            'feat2_title' => 'Secure Keys',
            'feat2_desc' => 'Dedicated key per API with expiry and limits.',
            'feat3_title' => 'Easy Integration',
            'feat3_desc' => 'Copy-paste code samples for PHP, JS and Python.',
            'feat4_title' => '24/7 Support',
            'feat4_desc' => 'Tickets plus Telegram and WhatsApp support.',
            'footer_text' => 'Fast, reliable and developer-friendly APIs with instant delivery, live monitoring and 24/7 support.',
            'custom_css' => '',
            'pay_bkash' => '01XXXXXXXXX',
            'pay_nagad' => '',
            'pay_rocket' => '',
            'pay_instruction' => 'Send Money to the number below, then submit the Transaction ID.',
            'global_provider_key' => '',
            'key_prefix' => 'INF-',
            'api_rate_limit' => '60',
            'signup_bonus' => '50',
            'signup_validity' => '30',
            'service_free_quota' => '25',
            'status_threshold' => '50',
            'support_telegram' => '',
            'support_whatsapp' => '',
            'support_facebook' => '',
            'support_youtube' => '',
            'maintenance_mode' => '0',
            'maintenance_msg' => 'We are upgrading our systems. Please come back soon.',
            'api_allow_http' => '1',
        ];

        foreach ($rows as $k => $v) {
            Setting::updateOrCreate(['setting_key' => $k], ['setting_value' => $v]);
        }

        Notification::firstOrCreate(
            ['title' => 'Welcome to INFINITY API HUB!'],
            ['message' => 'Create a free account and instantly get an API key for every service with bonus credits. Open any API page to start.', 'type' => 'success', 'target' => 'all', 'status' => 'active']
        );
    }
}
