@extends('layouts.dash')
@section('title', 'Admins')
@section('content')
<div class="page-head"><div><h1>Administrators</h1><p>Manage who can access this panel.</p></div></div>
<div class="grid-2" style="align-items:start">
  <div>
    <div class="card">
      <div class="card-title"><i class="fa-solid fa-user-plus"></i>Add New Admin</div>
      <form method="POST" action="{{ route('admin.admins.store') }}" class="mt">
        @csrf
        <div class="form-group"><label>Name</label><input type="text" name="name" class="form-control" required></div>
        <div class="form-group"><label>Email</label><input type="email" name="email" class="form-control" required></div>
        <div class="form-group"><label>Password</label><input type="text" name="password" class="form-control" required placeholder="Min 6 characters"></div>
        <button class="btn btn-primary btn-block" type="submit"><i class="fa-solid fa-plus"></i>Add Admin</button>
      </form>
    </div>
    <div class="card mt">
      <div class="card-title"><i class="fa-solid fa-lock"></i>Change My Password</div>
      <form method="POST" action="{{ route('admin.admins.mypass') }}" class="mt">
        @csrf @method('PATCH')
        <div class="form-group"><label>Current Password</label><input type="password" name="current" class="form-control" required></div>
        <div class="form-group"><label>New Password</label><input type="password" name="new" class="form-control" required></div>
        <button class="btn btn-outline btn-block" type="submit"><i class="fa-solid fa-key"></i>Update Password</button>
      </form>
    </div>
  </div>
  <div class="card">
    <div class="card-title"><i class="fa-solid fa-user-shield"></i>All Admins ({{ $admins->count() }})</div>
    @foreach($admins as $a)
    <div class="flex between center" style="padding:13px 0;border-bottom:1px solid #f1f5f9">
      <div class="flex center gap"><div class="avatar" style="width:40px;height:40px;font-size:16px">{{ strtoupper(substr($a->name, 0, 1)) }}</div><div><b>{{ $a->name }}</b>@if($a->id === auth()->id()) <span class="mini-tag blue">You</span>@endif<br><small class="text-gray">{{ $a->email }}</small></div></div>
      @if($a->id !== auth()->id())
      <form action="{{ route('admin.admins.demote', $a) }}" method="POST" onsubmit="return confirm('Demote to normal user?')">@csrf<button class="btn btn-warning btn-xs">Demote</button></form>
      @endif
    </div>
    @endforeach
  </div>
</div>
@endsection
