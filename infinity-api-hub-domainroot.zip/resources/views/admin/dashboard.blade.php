@extends('layouts.dash')
@section('title', 'Admin Dashboard')
@section('content')
<div class="page-head">
  <div><h1>Admin Dashboard 📊</h1><p>Full control of your API business at a glance.</p></div>
  <div class="flex gap wrap-x">
    <a class="btn btn-outline btn-sm" href="{{ route('admin.services.create') }}"><i class="fa-solid fa-plus"></i>New API</a>
    <a class="btn btn-primary btn-sm" href="{{ route('admin.keys.create') }}"><i class="fa-solid fa-key"></i>New Key</a>
  </div>
</div>

@if($pending > 0)
<div class="alert alert-warning"><i class="fa-solid fa-bell"></i><div><b>{{ $pending }} order(s) waiting for approval.</b> <a href="{{ route('admin.orders', ['status' => 'pending']) }}" style="font-weight:800">Review now →</a></div></div>
@endif

<div class="stat-grid">
  <div class="stat-card"><div class="top"><div class="sic bg-blue"><i class="fa-solid fa-users"></i></div><span class="trend bg-blue">+{{ $admins }} admins</span></div><h3>{{ number_format($users) }}</h3><p>Total Users</p></div>
  <div class="stat-card"><div class="top"><div class="sic bg-sky"><i class="fa-solid fa-bolt"></i></div><span class="trend bg-sky">{{ $rate }}% ok</span></div><h3>{{ number_format($today) }}</h3><p>Requests Today ({{ fmt_num($total) }} total)</p></div>
  <div class="stat-card"><div class="top"><div class="sic bg-green"><i class="fa-solid fa-bangladeshi-taka-sign"></i></div><span class="trend bg-green">{{ taka($revenueToday) }} today</span></div><h3>{{ taka($revenue) }}</h3><p>Total Revenue</p></div>
  <div class="stat-card"><div class="top"><div class="sic bg-amber"><i class="fa-solid fa-layer-group"></i></div><span class="trend bg-amber">{{ $keys }} keys</span></div><h3>{{ $services }}</h3><p>Active APIs ({{ $latency }}ms avg)</p></div>
</div>

<div class="card mb">
  <div class="card-title"><i class="fa-solid fa-chart-column"></i>Requests — Last 14 Days</div>
  <div class="chart-bars">
    @foreach($chart as $c)
    <div class="chart-col">
      <div class="chart-bar" style="height:{{ max(3, round(($c['total'] / $max) * 100)) }}%"><span class="tip">{{ $c['label'] }}: {{ $c['total'] }} hits</span></div>
      <span class="d">{{ \Carbon\Carbon::parse($c['label'])->format('d') }}</span>
    </div>
    @endforeach
  </div>
</div>

<div class="grid-2">
  <div class="card">
    <div class="card-title"><i class="fa-solid fa-clock-rotate-left"></i>Recent API Calls</div>
    <div class="table-wrap mt"><table class="tbl" style="min-width:0">
      <tr><th>User</th><th>API</th><th>Status</th><th>Time</th></tr>
      @forelse($recentLogs as $l)
      <tr>
        <td class="text-sm"><b>{{ $l->user->name ?? 'Guest' }}</b></td>
        <td class="text-sm">{{ $l->service->name ?? '—' }}</td>
        <td>{!! badge($l->status) !!}</td>
        <td class="text-sm text-gray">{{ $l->created_at->diffForHumans() }}</td>
      </tr>
      @empty
      <tr><td colspan="4" class="text-gray" style="text-align:center">No requests yet.</td></tr>
      @endforelse
    </table></div>
    <a class="btn btn-ghost btn-sm btn-block mt" href="{{ route('admin.logs') }}">View All Logs</a>
  </div>
  <div class="card">
    <div class="card-title"><i class="fa-solid fa-receipt"></i>Recent Orders</div>
    <div class="table-wrap mt"><table class="tbl" style="min-width:0">
      <tr><th>User</th><th>Package</th><th>Amount</th><th>Status</th></tr>
      @forelse($recentOrders as $o)
      <tr>
        <td class="text-sm"><b>{{ $o->user->name }}</b></td>
        <td class="text-sm">{{ $o->order_kind === 'wallet_topup' ? 'Wallet top-up' : ($o->package?->name ?? 'Custom credits') }}</td>
        <td class="text-sm"><b>{{ $o->amount > 0 ? taka($o->amount) : 'FREE' }}</b></td>
        <td>{!! badge($o->status) !!}</td>
      </tr>
      @empty
      <tr><td colspan="4" class="text-gray" style="text-align:center">No orders yet.</td></tr>
      @endforelse
    </table></div>
    <a class="btn btn-ghost btn-sm btn-block mt" href="{{ route('admin.orders') }}">Manage Orders</a>
  </div>
</div>

<div class="grid-2 mt">
  <div class="card">
    <div class="card-title"><i class="fa-solid fa-fire"></i>Top APIs (30 days)</div>
    @forelse($topSvc as $s)
    <div class="flex between center" style="padding:10px 0;border-bottom:1px solid #f1f5f9"><b>{{ $s->name }}</b><span class="mini-tag blue">{{ number_format($s->logs_count) }} hits</span></div>
    @empty
    <div class="empty"><i class="fa-solid fa-chart-simple"></i><b>No data yet</b></div>
    @endforelse
  </div>
  <div class="card">
    <div class="card-title"><i class="fa-solid fa-crown"></i>Top Keys by Usage</div>
    @forelse($topKeys as $t)
    <div class="flex between center" style="padding:10px 0;border-bottom:1px solid #f1f5f9"><div><b>{{ $t->service->name ?? $t->label }}</b><br><small class="text-gray">{{ $t->user->name ?? '' }}</small></div><span class="mini-tag blue">{{ number_format($t->used_request) }} used</span></div>
    @empty
    <div class="empty"><i class="fa-solid fa-chart-simple"></i><b>No data yet</b></div>
    @endforelse
  </div>
</div>
@endsection
