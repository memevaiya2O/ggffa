@extends('layouts.dash')
@section('title', $key->exists ? 'Edit Key' : 'Create Key')
@section('content')
<div class="page-head">
  <div><h1>{{ $key->exists ? 'Edit Key' : 'Create Key' }}</h1><p>{{ $key->exists ? 'Full control of this key.' : 'Issue a key to any user instantly.' }}</p></div>
  <a class="btn btn-outline btn-sm" href="{{ route('admin.keys') }}"><i class="fa-solid fa-arrow-left"></i>Back</a>
</div>
<div class="card" style="max-width:640px">
  <form method="POST" action="{{ $key->exists ? route('admin.keys.update', $key) : route('admin.keys.store') }}">
    @csrf
    @if($key->exists) @method('PATCH') @endif
    @if(!$key->exists)
    <div class="form-group"><label>User Email <span class="req">*</span></label><input type="email" name="email" class="form-control" placeholder="user@example.com" required value="{{ old('email') }}"></div>
    <div class="form-group"><label>API <span class="req">*</span></label><select name="service_id" class="form-control">@foreach($services as $s)<option value="{{ $s->id }}" {{ old('service_id') == $s->id ? 'selected' : '' }}>{{ $s->name }}</option>@endforeach</select></div>
    @else
    <div class="alert alert-info"><i class="fa-solid fa-user"></i><div>Owner: <b>{{ $key->user->name ?? '' }}</b> ({{ $key->user->email ?? '' }}) • API: <b>{{ $key->service->name ?? '' }}</b><br><span class="mono">{{ $key->api_key }}</span></div></div>
    @endif
    <div class="form-row">
      <div class="form-group"><label>Label <span class="req">*</span></label><input type="text" name="label" class="form-control" required value="{{ old('label', $key->label ?? 'My API Key') }}"></div>
      <div class="form-group"><label>Expiry Date</label><input type="date" name="exp_date" class="form-control" value="{{ old('exp_date', $key->exists && $key->exp_date ? $key->exp_date->format('Y-m-d') : date('Y-m-d', strtotime('+30 days'))) }}"></div>
    </div>
    @if(!$key->exists)
    <div class="form-row">
      <div class="form-group"><label>Credits (quota)</label><input type="number" name="quota" class="form-control" min="0" value="{{ old('quota', 1000) }}"></div>
      <div class="form-group"><label>Custom Key (optional)</label><input type="text" name="custom" class="form-control mono" placeholder="Auto-generate" value="{{ old('custom') }}"></div>
    </div>
    @else
    <div class="form-row">
      <div class="form-group"><label>Total Requests</label><input type="number" name="total_request" class="form-control" min="0" value="{{ old('total_request', $key->total_request) }}"></div>
      <div class="form-group"><label>Used Requests</label><input type="number" name="used_request" class="form-control" min="0" value="{{ old('used_request', $key->used_request) }}"></div>
    </div>
    <div class="form-group"><label>Status</label><select name="status" class="form-control"><option value="active" {{ $key->status === 'active' ? 'selected' : '' }}>Active</option><option value="inactive" {{ $key->status === 'inactive' ? 'selected' : '' }}>Inactive</option><option value="expired" {{ $key->status === 'expired' ? 'selected' : '' }}>Expired</option></select></div>
    @endif
    <div class="flex gap">
      <button class="btn btn-primary" style="flex:1" type="submit"><i class="fa-solid fa-check"></i>{{ $key->exists ? 'Save Changes' : 'Create Key' }}</button>
      @if($key->exists)
  </form>
  <form action="{{ route('admin.keys.regenerate', $key) }}" method="POST" onsubmit="return confirm('Regenerate? Old key stops working.')">@csrf<button class="btn btn-warning" type="submit"><i class="fa-solid fa-rotate"></i>Regenerate</button></form>
      @else
  </form>
      @endif
    </div>
  </div>
</div>
@endsection
