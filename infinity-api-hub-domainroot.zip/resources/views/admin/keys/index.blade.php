@extends('layouts.dash')
@section('title', 'All Keys')
@section('content')
<div class="page-head">
  <div><h1>All Keys ({{ $keys->total() }})</h1><p>Every API key across all users.</p></div>
  <a class="btn btn-primary btn-sm" href="{{ route('admin.keys.create') }}"><i class="fa-solid fa-plus"></i>Create Key</a>
</div>
<div class="card">
  <form method="GET" class="filter-bar">
    <input type="text" name="q" class="form-control" placeholder="🔍 Search key, label, user…" value="{{ request('q') }}">
    <select name="status" class="form-control"><option value="">All Status</option><option value="active" {{ request('status') === 'active' ? 'selected' : '' }}>Active</option><option value="inactive" {{ request('status') === 'inactive' ? 'selected' : '' }}>Inactive</option><option value="expired" {{ request('status') === 'expired' ? 'selected' : '' }}>Expired</option></select>
    <select name="svc" class="form-control"><option value="0">All APIs</option>@foreach($services as $s)<option value="{{ $s->id }}" {{ (int) request('svc') === $s->id ? 'selected' : '' }}>{{ $s->name }}</option>@endforeach</select>
    <button class="btn btn-primary" type="submit">Filter</button>
  </form>
  <div class="table-wrap"><table class="tbl">
    <tr><th>API / Key</th><th>User</th><th>Usage</th><th>Expiry</th><th>Status</th><th>Action</th></tr>
    @foreach($keys as $k)
    @php $pct = $k->usagePercent(); @endphp
    <tr>
      <td><b>{{ $k->service->name ?? '—' }}</b> <small class="text-gray">({{ $k->label }})</small><br><small class="mono text-gray">{{ \Illuminate\Support\Str::limit($k->api_key, 26) }}</small></td>
      <td class="text-sm">{{ $k->user->name ?? '—' }}<br><small class="text-gray">{{ $k->user->email ?? '' }}</small></td>
      <td style="min-width:170px"><small><b>{{ number_format($k->used_request) }}</b> / {{ number_format($k->total_request) }}</small><div class="progress{{ $pct >= 90 ? ' low' : '' }}"><div style="width:{{ $pct }}%"></div></div></td>
      <td class="text-sm">{{ fmt_date($k->exp_date) }}</td>
      <td>{!! badge($k->status) !!}</td>
      <td><div class="flex gap"><a class="btn btn-ghost btn-xs" href="{{ route('admin.keys.edit', $k) }}"><i class="fa-solid fa-pen"></i></a><form action="{{ route('admin.keys.destroy', $k) }}" method="POST" onsubmit="return confirm('Delete key?')">@csrf @method('DELETE')<button class="btn btn-danger btn-xs"><i class="fa-solid fa-trash"></i></button></form></div></td>
    </tr>
    @endforeach
  </table></div>
  @if($keys->isEmpty())<div class="empty"><i class="fa-solid fa-key"></i><b>No keys found</b></div>@endif
  {{ $keys->links() }}
</div>
@endsection
