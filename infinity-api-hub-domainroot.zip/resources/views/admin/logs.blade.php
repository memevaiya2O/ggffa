@extends('layouts.dash')
@section('title', 'API Logs')
@section('content')
<div class="page-head">
  <div><h1>API Logs ({{ $logs->total() }})</h1><p>Every gateway & panel request, live.</p></div>
  <div class="flex gap wrap-x">
    <a class="btn btn-outline btn-sm" href="{{ route('admin.logs.export', request()->query()) }}"><i class="fa-solid fa-download"></i>Export CSV</a>
    <button class="btn btn-danger btn-sm" onclick="openModal('clearModal')"><i class="fa-solid fa-trash"></i>Clear Old</button>
  </div>
</div>
<div class="card">
  <form method="GET" class="filter-bar">
    <input type="text" name="q" class="form-control" placeholder="🔍 Search param, IP, key, user…" value="{{ request('q') }}">
    <select name="status" class="form-control"><option value="">All Status</option><option value="success" {{ request('status') === 'success' ? 'selected' : '' }}>Success</option><option value="error" {{ request('status') === 'error' ? 'selected' : '' }}>Error</option></select>
    <select name="svc" class="form-control"><option value="0">All APIs</option>@foreach($services as $s)<option value="{{ $s->id }}" {{ (int) request('svc') === $s->id ? 'selected' : '' }}>{{ $s->name }}</option>@endforeach</select>
    <button class="btn btn-primary" type="submit">Filter</button>
  </form>
  <div class="table-wrap"><table class="tbl">
    <tr><th>#</th><th>Time</th><th>User / Key</th><th>API</th><th>Params</th><th>Status</th><th>MS</th><th>Src</th></tr>
    @foreach($logs as $l)
    <tr>
      <td><b>{{ $l->id }}</b></td>
      <td class="text-sm text-gray">{{ fmt_date($l->created_at, true) }}</td>
      <td class="text-sm"><b>{{ $l->user->name ?? 'Guest' }}</b><br><small class="mono text-gray">{{ $l->key ? \Illuminate\Support\Str::limit($l->key->api_key, 18) : '—' }}</small></td>
      <td class="text-sm">{{ $l->service->name ?? '—' }}</td>
      <td class="mono text-sm" title="{{ $l->param_summary }}">{{ \Illuminate\Support\Str::limit($l->param_summary ?? '', 30) }}</td>
      <td>{!! badge($l->status) !!}<br><small class="text-gray">HTTP {{ (int) $l->response_code }}</small></td>
      <td class="text-sm">{{ (int) $l->latency_ms }}ms</td>
      <td><span class="mini-tag">{{ $l->source }}</span><br><small class="text-gray">{{ $l->ip }}</small></td>
    </tr>
    @endforeach
  </table></div>
  @if($logs->isEmpty())<div class="empty"><i class="fa-solid fa-list-ul"></i><b>No logs found</b></div>@endif
  {{ $logs->links() }}
</div>

<div class="modal-bg" id="clearModal">
  <div class="modal">
    <h3><i class="fa-solid fa-trash text-primary"></i> Clear Old Logs</h3>
    <p class="sub">Delete logs older than the selected days.</p>
    <form method="POST" action="{{ route('admin.logs.clear') }}">
      @csrf
      <div class="form-group"><label>Older than</label><select name="days" class="form-control"><option value="7">7 days</option><option value="30" selected>30 days</option><option value="90">90 days</option><option value="180">180 days</option></select></div>
      <div class="flex gap">
        <button type="button" class="btn btn-outline" style="flex:1" onclick="closeModal('clearModal')">Cancel</button>
        <button class="btn btn-danger" style="flex:1" type="submit">Delete Logs</button>
      </div>
    </form>
  </div>
</div>
@endsection
