@extends('layouts.dash')
@section('title', 'NagorikPay Logs')
@section('content')
<div class="page-head">
  <div><h1>NagorikPay API Logs {!! \App\Services\NagorikPayGateway::testModeBadge() !!}</h1><p>Every create / verify / webhook call — request/response without leaking keys.</p></div>
  <a class="btn btn-outline btn-sm" href="{{ route('admin.settings', ['tab'=>'payment']) }}"><i class="fa-solid fa-gear"></i>Settings</a>
</div>
<div class="card">
  <form method="GET" class="filter-bar">
    <select name="type" class="form-control" onchange="this.form.submit()">
      <option value="">All Types</option>
      <option value="create" {{ request('type')==='create'?'selected':'' }}>create</option>
      <option value="verify" {{ request('type')==='verify'?'selected':'' }}>verify</option>
      <option value="webhook" {{ request('type')==='webhook'?'selected':'' }}>webhook</option>
    </select>
    <input type="text" name="q" class="form-control" placeholder="🔍 txn / url…" value="{{ request('q') }}">
    <button class="btn btn-primary" type="submit">Search</button>
  </form>
  <div class="table-wrap"><table class="tbl">
    <tr><th>#</th><th>Type</th><th>Order</th><th>Txn</th><th>URL</th><th>Status</th><th>Key Masked</th><th>Date</th></tr>
    @foreach($logs as $l)
    <tr>
      <td><b>{{ $l->id }}</b></td>
      <td>{!! badge($l->type) !!}</td>
      <td>{{ $l->order_id ?: '—' }}</td>
      <td class="mono text-sm">{{ \Illuminate\Support\Str::limit($l->transaction_id ?: '—', 18) }}</td>
      <td class="text-sm" style="max-width:240px;white-space:normal;word-break:break-all">{{ $l->url }}</td>
      <td><b>{{ $l->http_status }}</b></td>
      <td class="mono text-sm">{{ $l->api_key_masked }}</td>
      <td class="text-sm text-gray">{{ \Carbon\Carbon::parse($l->created_at)->format('d M H:i') }}</td>
    </tr>
    <tr><td colspan="8" style="background:var(--bg)">
      <details style="font-size:13px"><summary style="cursor:pointer;font-weight:700"><i class="fa-solid fa-code"></i> Request / Response</summary>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:10px">
          <div><b>Request</b><pre style="background:#fff;border:1px solid var(--border);padding:10px;border-radius:8px;overflow:auto;max-height:240px;white-space:pre-wrap;word-break:break-all">{{ $l->request_payload ?: '—' }}</pre></div>
          <div><b>Response</b><pre style="background:#fff;border:1px solid var(--border);padding:10px;border-radius:8px;overflow:auto;max-height:240px;white-space:pre-wrap;word-break:break-all">{{ $l->response_payload ?: '—' }}</pre></div>
        </div>
      </details>
    </td></tr>
    @endforeach
  </table></div>
  @if($logs->isEmpty())<div class="empty"><i class="fa-solid fa-list"></i><b>No logs yet</b><span class="text-sm">Trigger a payment to see logs here.</span></div>@endif
  {{ $logs->links() }}
</div>
@endsection
