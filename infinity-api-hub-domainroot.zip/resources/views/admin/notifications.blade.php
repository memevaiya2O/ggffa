@extends('layouts.dash')
@section('title', 'Notifications')
@section('content')
<div class="page-head"><div><h1>Notifications</h1><p>Broadcast notices to users (dashboard + homepage).</p></div></div>
<div class="grid-2" style="grid-template-columns:1fr 1.3fr;align-items:start">
  <div class="card">
    <div class="card-title"><i class="fa-solid fa-{{ $n->exists ? 'pen' : 'plus' }}"></i>{{ $n->exists ? 'Edit' : 'New' }} Notice</div>
    <form method="POST" class="mt" action="{{ $n->exists ? route('admin.notifications.update', $n) : route('admin.notifications.store') }}">
      @csrf
      @if($n->exists) @method('PATCH') @endif
      <div class="form-group"><label>Title <span class="req">*</span></label><input type="text" name="title" class="form-control" required value="{{ old('title', $n->title) }}"></div>
      <div class="form-group"><label>Message <span class="req">*</span></label><textarea name="message" class="form-control" required>{{ old('message', $n->message) }}</textarea></div>
      <div class="form-row">
        <div class="form-group"><label>Type</label><select name="type" class="form-control"><option value="info" {{ $n->type === 'info' ? 'selected' : '' }}>ℹ️ Info</option><option value="success" {{ $n->type === 'success' ? 'selected' : '' }}>✅ Success</option><option value="warning" {{ $n->type === 'warning' ? 'selected' : '' }}>⚠️ Warning</option><option value="error" {{ $n->type === 'error' ? 'selected' : '' }}>❌ Alert</option></select></div>
        <div class="form-group"><label>Show To</label><select name="target" class="form-control"><option value="all" {{ $n->target === 'all' ? 'selected' : '' }}>Homepage + Users</option><option value="users" {{ $n->target === 'users' ? 'selected' : '' }}>Logged-in Users Only</option></select></div>
      </div>
      @if($n->exists)<div class="form-group"><label>Status</label><select name="status" class="form-control"><option value="active" {{ $n->status === 'active' ? 'selected' : '' }}>Active</option><option value="inactive" {{ $n->status !== 'active' ? 'selected' : '' }}>Hidden</option></select></div>@endif
      <div class="flex gap">
        @if($n->exists)<a class="btn btn-outline" href="{{ route('admin.notifications') }}">Cancel</a>@endif
        <button class="btn btn-primary" style="flex:1" type="submit"><i class="fa-solid fa-paper-plane"></i>{{ $n->exists ? 'Save' : 'Publish' }}</button>
      </div>
    </form>
  </div>
  <div class="card">
    <div class="card-title"><i class="fa-solid fa-bell"></i>All Notices ({{ $list->count() }})</div>
    @forelse($list as $x)
    @php $bg = ['success' => 'bg-green', 'warning' => 'bg-amber', 'error' => 'bg-red'][$x->type] ?? 'bg-sky'; @endphp
    <div class="notice-item">
      <div class="notice-ic {{ $bg }}"><i class="fa-solid fa-bullhorn"></i></div>
      <div style="flex:1">
        <div class="flex between wrap-x"><b>{{ $x->title }}</b><small class="text-gray">{{ $x->created_at->diffForHumans() }}</small></div>
        <div class="text-gray text-sm">{{ \Illuminate\Support\Str::limit($x->message, 160) }}</div>
        <div class="flex gap wrap-x mt">{!! badge($x->type, 'info') !!} {!! badge($x->status) !!}<span class="mini-tag">{{ $x->target }}</span>
          <a class="btn btn-ghost btn-xs" href="{{ route('admin.notifications.edit', $x) }}"><i class="fa-solid fa-pen"></i>Edit</a>
          <form action="{{ route('admin.notifications.destroy', $x) }}" method="POST" style="display:inline" onsubmit="return confirm('Delete?')">@csrf @method('DELETE')<button class="btn btn-danger btn-xs"><i class="fa-solid fa-trash"></i></button></form>
        </div>
      </div>
    </div>
    @empty
    <div class="empty"><i class="fa-solid fa-bell-slash"></i><b>No notices yet</b></div>
    @endforelse
  </div>
</div>
@endsection
