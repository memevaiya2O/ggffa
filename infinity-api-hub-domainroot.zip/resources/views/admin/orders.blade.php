@extends('layouts.dash')
@section('title', 'Orders')
@section('content')
<div class="page-head">
  <div><h1>Orders ({{ $orders->total() }}) {!! \App\Services\NagorikPayGateway::testModeBadge() !!}</h1><p>Revenue: <b class="text-primary">{{ taka($revenue) }}</b> total • <b>{{ taka($revenueToday) }}</b> today • Auto-expire: {{ (int) setting('nagorikpay_expire_minutes',30) }} min • Auto-recheck every 5 min</p></div>
  <div class="flex gap wrap-x">
    <a class="btn btn-outline btn-sm" href="{{ route('admin.logs.nagorikpay') }}"><i class="fa-solid fa-list"></i>NagorikPay Logs</a>
  </div>
</div>
<div class="card">
  <form method="GET" class="filter-bar">
    <select name="status" class="form-control" onchange="this.form.submit()">
      <option value="">All Status</option>
      <option value="pending" {{ request('status') === 'pending' ? 'selected' : '' }}>⏳ Pending</option>
      <option value="approved" {{ request('status') === 'approved' ? 'selected' : '' }}>✅ Approved</option>
      <option value="rejected" {{ request('status') === 'rejected' ? 'selected' : '' }}>❌ Rejected</option>
      <option value="expired" {{ request('status') === 'expired' ? 'selected' : '' }}>⌛ Expired</option>
      <option value="cancelled" {{ request('status') === 'cancelled' ? 'selected' : '' }}>🚫 Cancelled</option>
    </select>
    <input type="text" name="q" class="form-control" placeholder="🔍 Search user / txn id…" value="{{ request('q') }}">
    <button class="btn btn-primary" type="submit">Search</button>
  </form>
  <div class="table-wrap"><table class="tbl">
    <tr><th>#</th><th>User</th><th>API / Package</th><th>Amount</th><th>Payment</th><th>Status</th><th>Action</th></tr>
    @foreach($orders as $o)
    <tr>
      <td><b>{{ $o->id }}</b><br><small class="text-gray">{{ fmt_date($o->created_at, true) }}</small>
        @if($o->expires_at && $o->status === 'pending')<br><small class="text-warning">Exp {{ $o->expires_at->diffForHumans() }}</small>@endif
      </td>
      <td class="text-sm"><b>{{ $o->user->name }}</b><br><small class="text-gray">{{ $o->user->email }}</small></td>
      <td class="text-sm"><b>{{ $o->order_kind === 'wallet_topup' ? 'Wallet top-up' : ($o->service?->name ?? '—') }}</b><br><small class="text-gray">{{ $o->order_kind === 'wallet_topup' ? taka($o->amount) : (($o->package?->name ?? 'Custom credits').' • '.number_format((int) ($o->credit_quantity ?: ($o->package?->requests ?? 0))).' credits') }}</small></td>
      <td><b>{{ $o->amount > 0 ? taka($o->amount) : 'FREE' }}</b></td>
      <td class="text-sm">{{ $o->payment_method }}<br><small>{{ $o->sender_number }}</small><br><small class="mono"><b>{{ \Illuminate\Support\Str::limit($o->txn_id,18) }}</b></small>
        @if($o->nagorikpay_txn && $o->nagorikpay_txn !== $o->txn_id)<br><small class="mono text-success">{{ \Illuminate\Support\Str::limit($o->nagorikpay_txn,18) }}</small>@endif
        @if($o->attempts > 0)<br><small class="text-gray">Attempts: {{ $o->attempts }}</small>@endif
      </td>
      <td>{!! badge($o->status) !!}
        @if($o->admin_note)<br><small class="text-gray" style="max-width:180px;display:block;white-space:normal">{{ $o->admin_note }}</small>@endif
      </td>
      <td>
        @if($o->status === 'pending')
        <div class="flex gap wrap-x" style="flex-wrap:wrap;min-width:180px">
          <button class="btn btn-success btn-xs" onclick="reviewOrder({{ $o->id }}, 'approve', '{{ route('admin.orders.approve', $o) }}')"><i class="fa-solid fa-check"></i>Approve</button>
          <button class="btn btn-danger btn-xs" onclick="reviewOrder({{ $o->id }}, 'reject', '{{ route('admin.orders.reject', $o) }}')"><i class="fa-solid fa-xmark"></i> Reject</button>
          @if($o->payment_method==='nagorikpay')
            <form method="POST" action="{{ route('admin.orders.recheck', $o) }}">@csrf<button class="btn btn-primary btn-xs"><i class="fa-solid fa-rotate"></i> Recheck</button></form>
          @endif
          <form method="POST" action="{{ route('admin.orders.expire', $o) }}" onsubmit="return confirm('Expire this order?')">@csrf<button class="btn btn-outline btn-xs">Expire</button></form>
        </div>
        @else
          @if($o->payment_method==='nagorikpay' && $o->txn_id && $o->status!=='approved')
            <form method="POST" action="{{ route('admin.orders.recheck', $o) }}">@csrf<button class="btn btn-primary btn-xs"><i class="fa-solid fa-rotate"></i> Recheck</button></form>
          @else
            <span class="text-gray text-sm">—</span>
          @endif
        @endif
      </td>
    </tr>
    @endforeach
  </table></div>
  @if($orders->isEmpty())<div class="empty"><i class="fa-solid fa-receipt"></i><b>No orders found</b></div>@endif
  {{ $orders->links() }}
</div>

<div class="modal-bg" id="reviewModal">
  <div class="modal">
    <h3 id="reviewTitle">Review Order</h3>
    <p class="sub" id="reviewSub"></p>
    <form method="POST" id="reviewForm">@csrf
      <div class="form-group"><label>Admin Note (optional)</label><input type="text" name="note" class="form-control" placeholder="e.g. Payment verified ✔"></div>
      <div class="flex gap">
        <button type="button" class="btn btn-outline" style="flex:1" onclick="closeModal('reviewModal')">Cancel</button>
        <button class="btn btn-primary" style="flex:1" type="submit" id="reviewBtn">Confirm</button>
      </div>
    </form>
  </div>
</div>
@push('scripts')
<script>
function reviewOrder(id, action, url) {
  document.getElementById('reviewForm').action = url;
  document.getElementById('reviewTitle').textContent = (action === 'approve' ? 'Approve Order #' : 'Reject Order #') + id;
  document.getElementById('reviewSub').textContent = action === 'approve' ? 'Credits will be added to the key instantly (idempotent – safe even if webhook already credited).' : 'The user will see your note.';
  document.getElementById('reviewBtn').textContent = action === 'approve' ? 'Approve & Add Credits' : 'Reject Order';
  openModal('reviewModal');
}
</script>
@endpush
@endsection
