@extends('layouts.dash')
@section('title', 'Packages')
@section('content')
<div class="page-head">
  <div><h1>Packages ({{ $packages->count() }})</h1><p>Credit plans per API — ৳0 = free instant-claim.</p></div>
  <a class="btn btn-primary btn-sm" href="{{ route('admin.packages.create') }}"><i class="fa-solid fa-plus"></i>New Package</a>
</div>
<div class="card mb">
  <form method="GET" class="filter-bar" style="margin:0">
    <select name="svc" class="form-control" style="max-width:300px" onchange="this.form.submit()"><option value="0">All APIs</option>@foreach($services as $s)<option value="{{ $s->id }}" {{ (int) request('svc') === $s->id ? 'selected' : '' }}>{{ $s->name }}</option>@endforeach</select>
  </form>
</div>
<div class="pricing-grid">
  @foreach($packages as $p)
  @php $perCredit = $p->requests > 0 && $p->price > 0 ? ((float) $p->price / (int) $p->requests) : 0; @endphp
  <div class="price-card{{ $p->highlight ? ' popular' : '' }}" style="{{ $p->status !== 'active' ? 'opacity:.6' : '' }}">
    @if($p->highlight)<span class="pop-tag">Popular</span>@endif
    <h3>{{ $p->name }}</h3>
    <div class="text-sm text-gray">{{ $p->service->name ?? '' }}</div>
    <div class="amount">{{ $p->price > 0 ? taka($p->price) : 'FREE' }}</div>
    @if($perCredit > 0)<div class="text-sm text-gray" style="margin-top:-3px">{{ taka($perCredit) }} / credit</div>@else<div class="text-sm text-gray" style="margin-top:-3px">Instant free claim</div>@endif
    <div class="req">{{ number_format((int) $p->requests) }} credits • {{ (int) $p->validity_days }} days {!! badge($p->status) !!}</div>
    <ul>@foreach($p->featureList() as $f)<li><i class="fa-solid fa-circle-check"></i><span>{{ $f }}</span></li>@endforeach</ul>
    <div class="flex gap">
      <a class="btn btn-outline btn-sm" style="flex:1" href="{{ route('admin.packages.edit', $p) }}"><i class="fa-solid fa-pen"></i>Edit</a>
      <form action="{{ route('admin.packages.destroy', $p) }}" method="POST" onsubmit="return confirm('Delete package?')">@csrf @method('DELETE')<button class="btn btn-danger btn-sm"><i class="fa-solid fa-trash"></i></button></form>
    </div>
  </div>
  @endforeach
</div>
@if($packages->isEmpty())<div class="card mt"><div class="empty"><i class="fa-solid fa-box-open"></i><b>No packages yet</b></div></div>@endif
@endsection
