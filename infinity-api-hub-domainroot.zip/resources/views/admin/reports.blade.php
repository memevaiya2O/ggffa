@extends('layouts.dash')
@section('title', 'Reports')
@section('content')
<div class="page-head"><div><h1>Sales & Usage Reports 📈</h1><p>Per-API revenue and traffic analytics.</p></div></div>

@php $max = max(1, max(array_column($chart, 'total') ?: [1])); @endphp
<div class="card mb">
  <div class="card-title"><i class="fa-solid fa-bangladeshi-taka-sign"></i>Revenue — Last 14 Days</div>
  <div class="chart-bars">
    @foreach($chart as $c)
    <div class="chart-col">
      <div class="chart-bar" style="height:{{ max(3, round(($c['total'] / $max) * 100)) }}%"><span class="tip">{{ $c['label'] }}: ৳{{ number_format($c['total']) }}</span></div>
      <span class="d">{{ \Carbon\Carbon::parse($c['label'])->format('d') }}</span>
    </div>
    @endforeach
  </div>
</div>

<div class="card">
  <div class="card-title"><i class="fa-solid fa-layer-group"></i>Per-API Performance</div>
  <div class="table-wrap mt"><table class="tbl">
    <tr><th>API</th><th>Keys</th><th>Total Calls</th><th>Hits (30d)</th><th>Avg MS</th><th>Orders</th><th>Revenue</th></tr>
    @foreach($services as $s)
    <tr>
      <td><b>{{ $s->name }}</b><br><small class="mono text-gray">/api/{{ $s->slug }}</small></td>
      <td><b>{{ number_format($s->keys_count) }}</b></td>
      <td>{{ number_format($s->logs_count) }}</td>
      <td>{{ number_format($hits30[$s->id]->hits ?? 0) }}</td>
      <td>{{ isset($hits30[$s->id]) ? round($hits30[$s->id]->ms).'ms' : '—' }}</td>
      <td>{{ number_format($sales[$s->id]->orders ?? 0) }}</td>
      <td><b class="text-primary">{{ taka($sales[$s->id]->revenue ?? 0) }}</b></td>
    </tr>
    @endforeach
  </table></div>
  @if($services->isEmpty())<div class="empty"><i class="fa-solid fa-chart-line"></i><b>No APIs yet</b></div>@endif
</div>
@endsection
