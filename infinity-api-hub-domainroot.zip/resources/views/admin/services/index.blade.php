@extends('layouts.dash')
@section('title', 'APIs / Services')
@section('content')
<div class="page-head">
  <div><h1>APIs / Services ({{ $services->count() }})</h1><p>Add unlimited APIs — each gets its own keys, credits & packages.</p></div>
  <a class="btn btn-primary btn-sm" href="{{ route('admin.services.create') }}"><i class="fa-solid fa-plus"></i>Add API</a>
</div>
@if($services->isEmpty())
<div class="card"><div class="empty"><i class="fa-solid fa-layer-group"></i><b>No APIs yet</b>Add your first provider API now.<br><br><a class="btn btn-primary" href="{{ route('admin.services.create') }}">Add API</a></div></div>
@endif
<div class="grid-2 admin-services-grid">
@foreach($services as $s)
  <div class="card hoverable admin-service-card">
    <div class="flex between center">
      <div class="flex center gap"><div class="svc-ic" style="width:46px;height:46px"><i class="fa-solid {{ $s->icon ?: 'fa-plug' }}"></i></div><div><b style="font-size:16.5px">{{ $s->name }}</b><br><small class="mono text-gray">/api/{{ $s->slug }}</small></div></div>
      {!! badge($s->status) !!}
    </div>
    <p class="text-gray text-sm mt">{{ $s->description ?: 'No description.' }}</p>
    <div class="flex wrap-x gap mt">
      <span class="mini-tag blue">{{ (int) $s->credits_per_hit }} credit/hit</span>
      <span class="mini-tag"><i class="fa-solid fa-coins"></i> {{ taka($s->credit_price ?: setting('credit_price_default', 1)) }} / credit</span>
      <span class="mini-tag">{{ $s->method }}</span>
      <span class="mini-tag"><i class="fa-solid fa-{{ $s->provider_source === 'file_manager' ? 'folder-open' : ($s->provider_source === 'subdomain' ? 'globe' : 'link') }}"></i> {{ $s->provider_source === 'file_manager' ? 'File Manager' : ($s->provider_source === 'subdomain' ? 'Subdomain' : 'External API') }}</span>
      <span class="mini-tag">{{ count($s->paramList()) }} params</span>
      @if($s->useCaseList())<span class="mini-tag"><i class="fa-solid fa-list-check"></i> {{ count($s->useCaseList()) }} use cases</span>@endif
      <span class="mini-tag"><i class="fa-solid fa-key"></i> {{ $s->keys_count }} keys</span>
      @if($s->show_on_home)<span class="mini-tag"><i class="fa-solid fa-house"></i> Home</span>@endif
    </div>
    <div class="mono text-sm mt" style="background:var(--bg);border:1px solid var(--border);border-radius:10px;padding:10px 12px;overflow-x:auto;white-space:nowrap">{{ \Illuminate\Support\Str::limit($s->provider_url, 90) }}</div>
    <div class="flex gap wrap-x mt">
      <a class="btn btn-primary btn-xs" href="{{ route('admin.services.pricing', $s) }}"><i class="fa-solid fa-tags"></i>Price Management</a>
      <a class="btn btn-ghost btn-xs" href="{{ route('admin.services.test', $s) }}"><i class="fa-solid fa-flask-vial"></i>Test</a>
      <a class="btn btn-outline btn-xs" href="{{ route('admin.services.edit', $s) }}"><i class="fa-solid fa-pen"></i>Edit</a>
      <a class="btn btn-outline btn-xs" href="{{ route('service.show', $s->slug) }}" target="_blank"><i class="fa-solid fa-eye"></i>View</a>
      <form action="{{ route('admin.services.toggle', $s) }}" method="POST" style="display:inline">@csrf<button class="btn btn-warning btn-xs">{{ $s->status === 'active' ? 'Disable' : 'Enable' }}</button></form>
      <form action="{{ route('admin.services.issueAll', $s) }}" method="POST" style="display:inline" onsubmit="return confirm('Issue keys to ALL users missing this API?')">@csrf<button class="btn btn-outline btn-xs"><i class="fa-solid fa-users"></i>Issue All</button></form>
      <form action="{{ route('admin.services.destroy', $s) }}" method="POST" style="display:inline" onsubmit="return confirm('Delete API + its keys, packages & logs?')">@csrf @method('DELETE')<button class="btn btn-danger btn-xs"><i class="fa-solid fa-trash"></i></button></form>
    </div>
  </div>
@endforeach
</div>
@endsection
