@extends('layouts.dash')
@section('title', 'Price Management — '.$service->name)
@section('content')
<div class="page-head">
  <div>
    <div class="text-sm text-gray" style="margin-bottom:6px"><a href="{{ route('admin.services') }}" style="color:var(--primary);font-weight:800"><i class="fa-solid fa-arrow-left"></i> API Management</a> <span style="opacity:.45">/</span> Price Management</div>
    <h1><i class="fa-solid fa-tags" style="color:var(--primary)"></i> Price Management</h1>
    <p>Build product cards for <b>{{ $service->name }}</b>. Each card controls credits, total price, validity, status, and checkout visibility.</p>
  </div>
  <div class="flex gap wrap-x">
    <a class="btn btn-outline btn-sm" href="{{ route('admin.services.edit', $service) }}"><i class="fa-solid fa-pen"></i>Edit API</a>
    <a class="btn btn-primary btn-sm" href="{{ route('admin.services.pricing.create', $service) }}"><i class="fa-solid fa-plus"></i>New Product Card</a>
  </div>
</div>

<div class="card price-management-summary mb">
  <div class="price-management-summary-icon"><i class="fa-solid {{ $service->icon ?: 'fa-plug' }}"></i></div>
  <div class="price-management-summary-main">
    <div class="flex between center wrap-x gap"><div><b>{{ $service->name }}</b><span class="mono text-gray" style="margin-left:8px">/api/{{ $service->slug }}</span></div>{!! badge($service->status) !!}</div>
    <div class="flex wrap-x gap mt">
      <span class="mini-tag blue"><i class="fa-solid fa-bolt"></i>{{ (int) $service->credits_per_hit }} credit/hit</span>
      <span class="mini-tag"><i class="fa-solid fa-coins"></i>{{ taka($service->credit_price ?: setting('credit_price_default', 1)) }} custom / credit</span>
      <span class="mini-tag"><i class="fa-solid fa-box-open"></i>{{ $packages->count() }} product cards</span>
    </div>
  </div>
</div>

@if($packages->isEmpty())
  <div class="card"><div class="empty price-management-empty"><i class="fa-solid fa-tags"></i><b>No product cards yet</b><span class="text-sm text-gray">Add your first plan to let users buy credits for this API.</span><a class="btn btn-primary mt" href="{{ route('admin.services.pricing.create', $service) }}"><i class="fa-solid fa-plus"></i>Create Product Card</a></div></div>
@else
  <div class="pricing-grid price-management-grid">
    @foreach($packages as $p)
      @php $perCredit = $p->requests > 0 && $p->price > 0 ? (float) $p->price / (int) $p->requests : 0; @endphp
      <div class="price-card price-management-card{{ $p->highlight ? ' popular' : '' }}" style="{{ $p->status !== 'active' ? 'opacity:.68' : '' }}">
        @if($p->highlight)<span class="pop-tag"><i class="fa-solid fa-crown"></i> Most Popular</span>@endif
        <div class="price-card-status">{!! badge($p->status) !!}</div>
        <h3>{{ $p->name }}</h3>
        <div class="price-card-price">{{ $p->price > 0 ? taka($p->price) : 'FREE' }}</div>
        <div class="price-card-unit">{{ $perCredit > 0 ? taka($perCredit).' per credit' : 'Instant free claim' }}</div>
        <div class="price-card-metrics">
          <span><i class="fa-solid fa-bolt"></i>{{ number_format((int) $p->requests) }} credits</span>
          <span><i class="fa-solid fa-calendar-days"></i>{{ (int) $p->validity_days }} days</span>
        </div>
        <ul>@forelse($p->featureList() as $f)<li><i class="fa-solid fa-circle-check"></i><span>{{ $f }}</span></li>@empty<li><i class="fa-solid fa-circle-check"></i><span>Instant activation</span></li>@endforelse</ul>
        <div class="flex gap price-management-actions">
          <a class="btn btn-outline btn-sm" href="{{ route('admin.services.pricing.edit', [$service, $p]) }}"><i class="fa-solid fa-pen"></i>Edit</a>
          <form method="POST" action="{{ route('admin.services.pricing.destroy', [$service, $p]) }}" onsubmit="return confirm('Delete this product card? Existing orders will remain safe.')">@csrf @method('DELETE')<button class="btn btn-danger btn-sm" type="submit"><i class="fa-solid fa-trash"></i></button></form>
        </div>
      </div>
    @endforeach
  </div>
@endif

<div class="card mt price-management-note"><i class="fa-solid fa-circle-info"></i><div><b>Pricing rule</b><span>Package price is the total checkout amount. The effective per-credit rate is calculated as total price ÷ credits. Custom credit purchases use the API’s {{ taka($service->credit_price ?: setting('credit_price_default', 1)) }} per-credit rate.</span></div></div>
@endsection
