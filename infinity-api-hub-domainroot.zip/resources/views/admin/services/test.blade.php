@extends('layouts.dash')
@section('title', 'Test '.$service->name)
@section('content')
<div class="page-head">
  <div><h1>Test: {{ $service->name }}</h1><p>Direct {{ $service->provider_source === 'file_manager' ? 'file-manager API' : ($service->provider_source === 'subdomain' ? 'subdomain API' : 'external provider') }} check (no user credits used).</p></div>
  <a class="btn btn-outline btn-sm" href="{{ route('admin.services') }}"><i class="fa-solid fa-arrow-left"></i>All APIs</a>
</div>
<div class="grid-2" style="grid-template-columns:1fr 1.2fr">
  <div class="card">
    <div class="alert alert-info"><i class="fa-solid fa-link"></i><div><b>Connected endpoint</b><br><span class="mono" style="word-break:break-all">{{ $service->provider_url }}</span><br><small>Method: {{ strtoupper($service->method) }} • Source: {{ $service->provider_source === 'file_manager' ? 'File Manager API file' : ($service->provider_source === 'subdomain' ? 'Subdomain API' : 'External API') }}</small></div></div>
    <div class="card-title"><i class="fa-solid fa-sliders"></i>Parameters</div>
    <form method="POST" action="{{ route('admin.services.test.run', $service) }}">
      @csrf
      @foreach($service->paramList() as $p)
      <div class="form-group"><label>{{ $p['label'] ?? $p['name'] }}@if(!empty($p['required'])) <span class="req">*</span>@endif</label><input type="text" name="p[{{ $p['name'] }}]" class="form-control mono" placeholder="{{ $p['placeholder'] ?? $p['name'] }}" value="{{ old('p.'.$p['name']) }}" @if(!empty($p['required']))required @endif></div>
      @endforeach
      @if(!count($service->paramList()))<div class="alert alert-info"><i class="fa-solid fa-circle-info"></i><div>No parameters needed.</div></div>@endif
      <button class="btn btn-primary btn-block" type="submit"><i class="fa-solid fa-play"></i>Run Test</button>
    </form>
  </div>
  <div class="card">
    <div class="card-title"><i class="fa-solid fa-terminal"></i>Provider Response</div>
    @if(!$result)
      <div class="empty"><i class="fa-solid fa-paper-plane"></i><b>Not tested yet</b></div>
    @else
      <div class="flex wrap-x gap mb">{!! badge($result['ok'] ? 'success' : 'error') !!}<span class="mini-tag">HTTP {{ (int) $result['code'] }}</span><span class="mini-tag">{{ (int) $result['ms'] }} ms</span></div>
      <div class="code-box"><div class="code-head"><span>Response</span></div><pre>{{ $result['body'] ?: ($result['err'] ?: '(empty)') }}</pre></div>
      <div class="alert alert-info"><i class="fa-solid fa-lightbulb"></i><div>Happy with this? Paste it into <b>Sample Response</b> on the edit page — it shows in docs.</div></div>
    @endif
  </div>
</div>
@endsection
