@extends('layouts.dash')
@section('title', 'Settings')
@section('content')
<div class="page-head" style="flex-wrap:wrap;gap:16px">
  <div>
    <h1 style="font-size:26px;font-weight:900;letter-spacing:-.5px;display:flex;gap:10px;align-items:center"><i class="fa-solid fa-gear" style="color:var(--primary)"></i> Settings & Customization</h1>
    <p style="color:var(--gray);margin-top:4px">লোগো থেকে ফুটার পর্যন্ত — সবকিছু এখান থেকে কাস্টমাইজ করুন। Live preview সহ।</p>
  </div>
  <div class="flex gap">
    <a href="{{ route('home') }}" target="_blank" class="btn btn-outline btn-sm"><i class="fa-solid fa-eye"></i> Preview Site</a>
    <span class="badge badge-primary" style="align-self:center"><i class="fa-solid fa-wand-magic-sparkles"></i> Fresh UI • {{ ucfirst($tab) }}</span>
  </div>
</div>

@php
function s_field($key, $label, $hint = '', $type = 'text', $def = '') {
    $isEncrypted = is_encrypted_setting($key);
    $rawVal = setting($key, $def);
    $v = old('s.'.$key, $rawVal);
    $isSecret = $isEncrypted;
    $masked = $isSecret && $rawVal !== '' ? mask_secret($rawVal) : '';
    $h = '<div class="form-group"><label style="font-weight:700;font-size:13px">'.e($label);
    if ($isSecret && $rawVal !== '') $h .= ' <span class="badge badge-success" style="font-size:9px;vertical-align:middle"><i class="fa-solid fa-lock"></i> encrypted</span>';
    if ($isSecret && $rawVal !== '' && $masked) $h .= ' <small class="text-gray" style="font-size:11px">Current: '.$masked.'</small>';
    $h .= '</label>';
    if ($type === 'textarea') {
      $rows = str_contains($key,'footer_col') ? 5 : 3;
      $h .= '<textarea name="s['.e($key).']" class="form-control" rows="'.$rows.'" placeholder="'.e($masked ?: $hint).'">'.e($isSecret ? '' : $v).'</textarea>';
      if($hint) $h .= '<div class="form-hint">'.e($hint).'</div>';
    } elseif ($type === 'color') {
      $h .= '<input type="color" name="s['.e($key).']" class="form-control" value="'.e($v ?: $def).'" style="height:42px;padding:4px">';
      if($hint) $h .= '<div class="form-hint">'.e($hint).'</div>';
    } else {
        $inputType = $isSecret ? 'password' : $type;
        $placeholder = $masked ?: $hint;
        $val = $isSecret ? '' : $v;
        $h .= '<input type="'.e($inputType).'" name="s['.e($key).']" class="form-control" value="'.e($val).'" placeholder="'.e($placeholder).'">';
        if ($hint) $h .= '<div class="form-hint">'.e($hint).'</div>';
        if ($isSecret && $rawVal !== '') $h .= '<div class="form-hint">খালি রাখলে আগের মান বহাল থাকবে। <a href="#" onclick="event.preventDefault(); document.getElementById(\'clear_'.$key.'\').submit();" style="color:var(--danger);font-weight:700">Clear</a></div>';
    }
    return $h.'</div>';
}
function s_select($key, $label, $options, $hint = '', $def = '') {
    $v = old('s.'.$key, setting($key, $def));
    $h = '<div class="form-group"><label style="font-weight:700;font-size:13px">'.e($label).'</label><select name="s['.e($key).']" class="form-control">';
    foreach ($options as $optVal => $optLabel) {
        $h .= '<option value="'.e($optVal).'"'.($v == $optVal ? ' selected' : '').'>'.e($optLabel).'</option>';
    }
    $h .= '</select>';
    if ($hint) $h .= '<div class="form-hint">'.e($hint).'</div>';
    return $h.'</div>';
}
@endphp

<!-- Fresh Tab Bar -->
<div style="background:#fff;border:1px solid var(--border);border-radius:16px;padding:8px;display:flex;gap:6px;overflow-x:auto;white-space:nowrap;box-shadow:var(--shadow);margin-bottom:18px;-webkit-overflow-scrolling:touch">
  @php $tabs = ['general'=>'General','branding'=>'Branding','theme'=>'Theme','hero'=>'Hero','footer'=>'Footer','payment'=>'Payments','api'=>'API & Limits','social'=>'Social','seo'=>'SEO','security'=>'Security','system'=>'System']; @endphp
  @foreach($tabs as $k=>$label)
    <a href="{{ route('admin.settings', ['tab'=>$k]) }}" class="btn {{ $tab===$k ? 'btn-primary' : 'btn-ghost' }} btn-sm" style="border-radius:12px;white-space:nowrap;font-size:13px">
      @if($k==='general')<i class="fa-solid fa-globe"></i>
      @elseif($k==='branding')<i class="fa-solid fa-image"></i>
      @elseif($k==='theme')<i class="fa-solid fa-palette"></i>
      @elseif($k==='hero')<i class="fa-solid fa-rocket"></i>
      @elseif($k==='footer')<i class="fa-solid fa-shoe-prints"></i>
      @elseif($k==='payment')<i class="fa-solid fa-money-bill"></i>
      @elseif($k==='api')<i class="fa-solid fa-plug"></i>
      @elseif($k==='social')<i class="fa-solid fa-share-nodes"></i>
      @elseif($k==='seo')<i class="fa-solid fa-magnifying-glass-chart"></i>
      @elseif($k==='security')<i class="fa-solid fa-shield-halved"></i>
      @else<i class="fa-solid fa-server"></i>
      @endif {{ $label }} @if($k==='payment'){!! \App\Services\NagorikPayGateway::testModeBadge() !!}@endif
    </a>
  @endforeach
</div>

@if($tab === 'general')
<div class="grid-2" style="align-items:start">
  <div class="card" style="border-radius:20px">
    <div class="card-title" style="font-size:16px"><i class="fa-solid fa-globe" style="color:var(--primary)"></i> Site Identity — নাম ও পরিচয়</div>
    <p class="card-sub">এই নাম, ট্যাগলাইন সব জায়গায় দেখাবে — হেডার, ফুটার, টাইটেল, SEO।</p>
    <form method="POST" action="{{ route('admin.settings.update', ['tab'=>'general']) }}">
      @csrf @method('PATCH')
      {!! s_field('site_name', 'Website Name', 'যেমন: INFINITY API HUB', 'text', 'INFINITY API HUB') !!}
      {!! s_field('site_tagline', 'Tagline', 'ছোট বর্ণনা — হিরোর নিচে', 'text', 'Premium API Platform') !!}
      {!! s_field('announcement', 'Top Announcement Bar', 'খালি রাখলে হাইড হবে — যেমন: ঈদ অফার চলছে!', 'text') !!}
      <input type="hidden" name="cb_registration_open" value="1">
      <label class="checkbox-row" style="background:var(--bg);padding:10px 12px;border-radius:12px;border:1px solid var(--border);margin:12px 0"><input type="checkbox" name="s[registration_open]" value="1" {{ setting('registration_open','1')==='1' ? 'checked' : '' }}> নতুন ইউজার রেজিস্ট্রেশন চালু রাখুন</label>
      <button class="btn btn-primary btn-block" type="submit"><i class="fa-solid fa-check"></i> Save General</button>
    </form>
  </div>
  <div class="card" style="border-radius:20px">
    <div class="card-title"><i class="fa-solid fa-sliders" style="color:var(--primary)"></i> Quick Customize</div>
    <p class="card-sub">প্রায়ই পরিবর্তন করেন? এখান থেকে ১ ক্লিকে।</p>
    <div class="grid-2" style="gap:12px">
      <a href="{{ route('admin.settings',['tab'=>'branding']) }}" class="card" style="padding:14px;text-align:center;border-radius:14px;background:linear-gradient(135deg,#eff6ff,#dbeafe)"><i class="fa-solid fa-image" style="font-size:22px;color:var(--primary)"></i><div style="font-weight:800;margin-top:6px">Logo & Header</div><small class="text-gray">লোগো বদলান</small></a>
      <a href="{{ route('admin.settings',['tab'=>'footer']) }}" class="card" style="padding:14px;text-align:center;border-radius:14px;background:linear-gradient(135deg,#f0fdf4,#dcfce7)"><i class="fa-solid fa-shoe-prints" style="font-size:22px;color:var(--success)"></i><div style="font-weight:800;margin-top:6px">Footer</div><small class="text-gray">ফুটার সাজান</small></a>
      <a href="{{ route('admin.settings',['tab'=>'theme']) }}" class="card" style="padding:14px;text-align:center;border-radius:14px;background:linear-gradient(135deg,#fef3c7,#fde68a)"><i class="fa-solid fa-palette" style="font-size:22px;color:#d97706"></i><div style="font-weight:800;margin-top:6px">Theme</div><small class="text-gray">রঙ ও স্টাইল</small></a>
      <a href="{{ route('admin.settings',['tab'=>'hero']) }}" class="card" style="padding:14px;text-align:center;border-radius:14px;background:linear-gradient(135deg,#fce7f3,#fbcfe8)"><i class="fa-solid fa-rocket" style="font-size:22px;color:#db2777"></i><div style="font-weight:800;margin-top:6px">Hero</div><small class="text-gray">হোম ব্যানার</small></a>
    </div>
    <div class="alert alert-info mt" style="margin-top:14px"><i class="fa-solid fa-lightbulb"></i><div><b>Pro tip:</b> যেকোনো ট্যাবে Save করলে পুরো সাইটে instantly আপডেট হয় — কোনো কোড লাগে না।</div></div>
  </div>
</div>

<div class="card mt" style="border-radius:20px">
  <div class="card-title" style="font-size:16px"><i class="fa-solid fa-swatchbook" style="color:var(--primary)"></i> Brand Kit — Logo, Icon & Name</div>
  <p class="card-sub">এই তিনটি এক জায়গা থেকে পরিবর্তন করলে header, browser tab, footer, dashboard, invoice, email ও page title-এ নতুন branding ব্যবহার হবে।</p>
  <div class="grid-3" style="align-items:start">
    <div class="brand-asset-box"><div class="brand-asset-preview">@if(setting('logo',''))<img src="{{ asset('uploads/'.setting('logo')) }}" alt="Logo" style="max-height:58px;max-width:100%;object-fit:contain">@else<span class="brand-icon">∞</span>@endif</div><b>Logo</b><small class="text-gray">Header ও site branding</small><form method="POST" action="{{ route('admin.settings.logo') }}" enctype="multipart/form-data" class="mt">@csrf<input type="file" name="logo" accept="image/png,image/jpeg,image/webp,image/gif" required class="form-control"><button class="btn btn-primary btn-sm btn-block mt" type="submit"><i class="fa-solid fa-upload"></i> Upload Logo</button></form></div>
    <div class="brand-asset-box"><div class="brand-asset-preview">@if(setting('site_icon',''))<img src="{{ asset('uploads/'.setting('site_icon')) }}" alt="Icon" style="height:52px;width:52px;object-fit:contain;border-radius:12px">@else<i class="fa-solid fa-globe" style="font-size:34px;color:var(--primary)"></i>@endif</div><b>Icon / Favicon</b><small class="text-gray">Browser tab ও link icon</small><form method="POST" action="{{ route('admin.settings.icon') }}" enctype="multipart/form-data" class="mt">@csrf<input type="file" name="icon" accept="image/png,image/jpeg,image/webp,image/gif,image/x-icon" required class="form-control"><button class="btn btn-primary btn-sm btn-block mt" type="submit"><i class="fa-solid fa-upload"></i> Upload Icon</button></form></div>
    <div class="brand-asset-box"><div class="brand-name-preview">{{ setting('site_name','INFINITY API HUB') }}</div><b>Brand Name</b><small class="text-gray">সব title, footer ও system text</small><form method="POST" action="{{ route('admin.settings.update', ['tab'=>'general']) }}" class="mt">@csrf @method('PATCH')<input type="text" name="s[site_name]" class="form-control" value="{{ setting('site_name','INFINITY API HUB') }}" required maxlength="120"><button class="btn btn-primary btn-sm btn-block mt" type="submit"><i class="fa-solid fa-check"></i> Save Name</button></form></div>
  </div>
  <div class="alert alert-info mt"><i class="fa-solid fa-circle-info"></i><div><b>File guidance:</b> Logo PNG/WebP/JPG max 2MB; Icon PNG/WebP/ICO/JPG max 1MB. Uploading a new file automatically replaces the previous one.</div></div>
</div>

@elseif($tab === 'branding')
<div class="grid-2" style="align-items:start">
  <div class="card" style="border-radius:20px">
    <div class="card-title"><i class="fa-solid fa-image"></i> Header Logo — হেডার লোগো</div>
    <p class="card-sub">PNG / SVG / WebP — সাদা ব্যাকগ্রাউন্ডে ভালো দেখায় এমন লোগো দিন।</p>
    <div style="text-align:center;padding:14px;background:var(--bg);border:1px dashed var(--border);border-radius:16px;margin-bottom:14px">
      @if(setting('logo',''))
        <img src="{{ asset('uploads/'.setting('logo')) }}" style="max-height:90px;max-width:100%;border-radius:14px;background:#fff;padding:8px;border:1px solid var(--border)" alt="logo">
        <div class="text-sm text-gray mt" style="word-break:break-all">{{ setting('logo') }}</div>
      @else
        <div class="auth-logo-ic" style="margin:0 auto">∞</div>
        <p class="text-sm text-gray mt">ডিফল্ট ∞ আইকন ব্যবহার হচ্ছে</p>
      @endif
    </div>
    <form method="POST" action="{{ route('admin.settings.logo') }}" enctype="multipart/form-data">
      @csrf
      <div class="form-group"><label>নতুন লোগো আপলোড (max 2MB)</label><input type="file" name="logo" class="form-control" accept="image/*" required></div>
      <div class="flex gap"><button class="btn btn-primary" style="flex:1" type="submit"><i class="fa-solid fa-upload"></i> Upload Logo</button>
        @if(setting('logo',''))</form><form method="POST" action="{{ route('admin.settings.logo.remove') }}" style="flex:1">@csrf @method('DELETE')<button class="btn btn-danger btn-block" type="submit">Remove</button></form>@else</form>@endif
      </div>
    </div>
  </div>
  <div class="card" style="border-radius:20px">
    <div class="card-title"><i class="fa-solid fa-font"></i> Brand Text & Header Links</div>
    <form method="POST" action="{{ route('admin.settings.update', ['tab'=>'branding']) }}">
      @csrf @method('PATCH')
      {!! s_field('header_brand_text', 'Header Brand Text (logo এর পাশে)', 'খালি রাখলে site_name দেখাবে', 'text') !!}
      {!! s_field('header_tagline_small', 'Header এর ছোট ট্যাগলাইন', 'যেমন: Premium API Platform', 'text') !!}
      <div class="alert alert-info"><i class="fa-solid fa-circle-info"></i><div style="font-size:13px"><b>Header Links:</b> Docs, Status ইত্যাদি অটো — কাস্টম লিংক ফুটারে যোগ করুন। হেডার সব পেজে একই থাকে।</div></div>
      <div class="form-row">
        {!! s_field('header_cta_text', 'Header CTA Text', 'যেমন: Get Started', 'text', 'Get Started') !!}
        {!! s_field('header_cta_link', 'Header CTA Link', 'যেমন: /register', 'text', '/register') !!}
      </div>
      <button class="btn btn-primary btn-block" type="submit"><i class="fa-solid fa-check"></i> Save Branding</button>
    </form>
    <div class="card mt" style="background:var(--bg);border:1px dashed var(--border)">
      <div style="font-weight:800"><i class="fa-solid fa-eye"></i> Live Header Preview</div>
      <div style="margin-top:10px;background:#fff;border:1px solid var(--border);border-radius:12px;padding:10px;display:flex;justify-content:space-between;align-items:center">
        <span style="display:flex;gap:8px;align-items:center;font-weight:900">@if(setting('logo',''))<img src="{{ asset('uploads/'.setting('logo')) }}" style="height:28px;border-radius:8px">@else<span class="brand-icon" style="width:28px;height:28px;font-size:14px">∞</span>@endif {{ setting('site_name','INFINITY API HUB') }}</span>
        <span class="btn btn-primary btn-xs">Preview</span>
      </div>
    </div>
  </div>
</div>

@elseif($tab === 'theme')
<div class="card" style="border-radius:20px;max-width:900px">
  <div class="card-title"><i class="fa-solid fa-palette"></i> Theme — রঙ, রাউন্ডনেস, স্টাইল</div>
  <p class="card-sub">এক ক্লিকে পুরো সাইটের লুক বদলান — primary রঙ সব বাটন, কার্ড, হেডারে প্রভাব ফেলে।</p>
  <form method="POST" action="{{ route('admin.settings.update', ['tab'=>'theme']) }}">
    @csrf @method('PATCH')
    <div class="form-row">
      {!! s_field('primary_color', 'Primary Color', 'মূল রঙ — বাটন, লিংক', 'color', '#2563eb') !!}
      {!! s_field('secondary_color', 'Secondary Color', 'হোভার, ডার্ক শেড', 'color', '#1d4ed8') !!}
      {!! s_field('accent_color', 'Accent Color', 'হাইলাইট', 'color', '#38bdf8') !!}
      {!! s_field('ui_radius', 'Corner Radius (px)', 'কার্ড ও বাটনের গোল', 'number', '16') !!}
    </div>
    <div class="form-row">
      {!! s_field('footer_bg', 'Footer Background', 'ফুটারের ব্যাকগ্রাউন্ড — ডার্ক সুন্দর', 'color', '#0b1526') !!}
      {!! s_field('footer_text', 'Footer Text Color', 'ফুটারের লেখার রঙ', 'color', '#cbd5e1') !!}
    </div>
    {!! s_field('custom_css', 'Custom CSS (advanced)', 'যেকোনো CSS — পুরো সাইটে যোগ হবে', 'textarea') !!}
    <div class="flex gap"><button class="btn btn-primary" type="submit"><i class="fa-solid fa-check"></i> Save Theme</button><a class="btn btn-outline" href="{{ route('home') }}" target="_blank"><i class="fa-solid fa-eye"></i> Preview Home</a></div>
  </form>
  <div class="alert alert-success mt"><i class="fa-solid fa-wand-magic-sparkles"></i><div><b>Fresh & Cleantip:</b> Primary #2563eb + Radius 16 + Footer #0b1526 = সবচেয়ে প্রিমিয়াম লুক।</div></div>
</div>

@elseif($tab === 'hero')
<div class="card" style="border-radius:20px;max-width:900px">
  <div class="card-title"><i class="fa-solid fa-rocket"></i> Hero — হোমপেজের ব্যানার</div>
  <form method="POST" action="{{ route('admin.settings.update', ['tab'=>'hero']) }}">
    @csrf @method('PATCH')
    {!! s_field('hero_badge', 'Hero Badge Text', 'ছোট pill — যেমন: Trusted API Platform', 'text') !!}
    {!! s_field('hero_title', 'Hero Title', '{hl}...{/hl} দিলে গ্রেডিয়েন্ট হবে', 'text') !!}
    {!! s_field('hero_subtitle', 'Hero Subtitle', '', 'textarea') !!}
    <div class="grid-2">
      <div>{!! s_field('feat1_title', 'Feature 1 Title') !!}{!! s_field('feat1_desc', 'Feature 1 Text') !!}</div>
      <div>{!! s_field('feat2_title', 'Feature 2 Title') !!}{!! s_field('feat2_desc', 'Feature 2 Text') !!}</div>
      <div>{!! s_field('feat3_title', 'Feature 3 Title') !!}{!! s_field('feat3_desc', 'Feature 3 Text') !!}</div>
      <div>{!! s_field('feat4_title', 'Feature 4 Title') !!}{!! s_field('feat4_desc', 'Feature 4 Text') !!}</div>
    </div>
    <button class="btn btn-primary" type="submit"><i class="fa-solid fa-check"></i> Save Hero</button>
  </form>
</div>

@elseif($tab === 'footer')
<div class="grid-2" style="align-items:start">
  <div class="card" style="border-radius:20px">
    <div class="card-title"><i class="fa-solid fa-shoe-prints"></i> Footer Brand — লোগো ও পরিচয়</div>
    <p class="card-sub">ফুটারের বাম পাশে image-only branding, বর্ণনা ও সোশ্যাল লিংক। Footer-এ আর আলাদা text brand দেখানো হবে না।</p>
    <div style="text-align:center;padding:12px;background:var(--bg);border:1px dashed var(--border);border-radius:12px;margin-bottom:12px">
      @if(setting('footer_logo',''))
        <img src="{{ asset('uploads/'.setting('footer_logo')) }}" style="max-height:80px;border-radius:12px;background:#fff;padding:6px;border:1px solid var(--border)">
      @elseif(setting('logo',''))
        <img src="{{ asset('uploads/'.setting('logo')) }}" style="max-height:60px;opacity:.7;border-radius:10px">
        <div class="text-sm text-gray">Header লোগো ব্যবহার হচ্ছে (footer logo আলাদা দিতে পারেন)</div>
      @else
        <span class="brand-icon" style="width:42px;height:42px">∞</span><div class="text-sm text-gray">Default ∞</div>
      @endif
    </div>
    <form method="POST" action="{{ route('admin.settings.footerLogo') }}" enctype="multipart/form-data" style="margin-bottom:14px">
      @csrf
      <div class="form-group"><label>Footer Logo (ঐচ্ছিক, আলাদা)</label><input type="file" name="footer_logo" class="form-control" accept="image/*" required></div>
      <div class="flex gap"><button class="btn btn-primary btn-sm" type="submit"><i class="fa-solid fa-upload"></i> Upload Footer Logo</button>
        @if(setting('footer_logo',''))</form><form method="POST" action="{{ route('admin.settings.footerLogo.remove') }}">@csrf @method('DELETE')<button class="btn btn-danger btn-sm" type="submit">Remove</button></form>@else</form>@endif
      </div>
    </div>
    <form method="POST" action="{{ route('admin.settings.update', ['tab'=>'footer']) }}">
      @csrf @method('PATCH')
      {!! s_field('footer_brand_text', 'Footer Image Alt Text', 'ছবির accessibility label — footer-এ দৃশ্যমান text নয়', 'text') !!}
      {!! s_field('footer_about', 'Footer About Text', '১-২ লাইন — কোম্পানি সম্পর্কে', 'textarea', 'Fast, reliable & developer-friendly APIs.') !!}
      {!! s_field('footer_text', 'Footer Short Note (legacy)', 'পুরনো ফিল্ড — footer_about প্রাধান্য পাবে', 'text') !!}
      <button class="btn btn-primary btn-block" type="submit"><i class="fa-solid fa-check"></i> Save Footer Brand</button>
    </form>
  </div>

  <div class="card" style="border-radius:20px">
    <div class="card-title"><i class="fa-solid fa-link"></i> Footer Links — ৩ কলাম কাস্টম</div>
    <p class="card-sub">প্রতি লাইনে <span class="mono">Label|URL</span> — যেমন: <span class="mono">Home|/</span> । খালি রাখলে ডিফল্ট দেখাবে।</p>
    <form method="POST" action="{{ route('admin.settings.update', ['tab'=>'footer']) }}">
      @csrf @method('PATCH')
      <div style="background:var(--bg);border:1px solid var(--border);border-radius:12px;padding:12px;margin-bottom:12px">
        <div style="font-weight:800;font-size:13px"><i class="fa-solid fa-list"></i> Column 1 — Quick Links</div>
        {!! s_field('footer_col1_title', 'Title', '', 'text', 'Quick Links') !!}
        {!! s_field('footer_col1_links', 'Links ( Label|URL per line )', "Home|/\nPricing|/#pricing\nAPI Documentation|/docs\nCheck Key|/check-key\nSystem Status|/status", 'textarea') !!}
      </div>
      <div style="background:var(--bg);border:1px solid var(--border);border-radius:12px;padding:12px;margin-bottom:12px">
        <div style="font-weight:800;font-size:13px"><i class="fa-solid fa-layer-group"></i> Column 2 — APIs</div>
        {!! s_field('footer_col2_title', 'Title', '', 'text', 'APIs') !!}
        <div class="alert alert-info" style="margin:8px 0"><i class="fa-solid fa-circle-info"></i><div style="font-size:12px">APIs কলাম অটো — আপনার Active APIs থেকে ৫টা দেখায়। কাস্টম করতে নিচে লিখুন (খালি রাখলে অটো)।</div></div>
        {!! s_field('footer_col2_links', 'Custom Links (optional, Label|URL)', 'খালি = অটো APIs', 'textarea') !!}
      </div>
      <div style="background:var(--bg);border:1px solid var(--border);border-radius:12px;padding:12px;margin-bottom:12px">
        <div style="font-weight:800;font-size:13px"><i class="fa-solid fa-headset"></i> Column 3 — Support</div>
        {!! s_field('footer_col3_title', 'Title', '', 'text', 'Support') !!}
        {!! s_field('footer_col3_links', 'Links ( Label|URL )', "Integration Help|/docs\nFAQ|/#faq\nClient Login|/login", 'textarea') !!}
      </div>
      <button class="btn btn-primary btn-block" type="submit"><i class="fa-solid fa-check"></i> Save Footer Links</button>
    </form>
  </div>
</div>

<div class="card mt" style="border-radius:20px">
  <div class="card-title"><i class="fa-solid fa-copyright"></i> Footer Bottom — কপিরাইট ও ডেভেলপার</div>
  <p class="card-sub">নিচের বার — কপিরাইট + Developed by।</p>
  <form method="POST" action="{{ route('admin.settings.update', ['tab'=>'footer']) }}" style="max-width:700px">
    @csrf @method('PATCH')
    <div class="form-row">
      {!! s_field('footer_copyright', 'Copyright Text', 'যেমন: © 2025 INFINITY API HUB. All rights reserved.', 'text') !!}
      {!! s_field('footer_developer_name', 'Developer Name', 'যেমন: Infinity Codex', 'text', 'Infinity Codex') !!}
    </div>
    {!! s_field('footer_developer_link', 'Developer Link', 'https://t.me/...', 'url', 'https://t.me/INFINITY_codex') !!}
    <div class="form-row">
      {!! s_field('footer_bg', 'Footer Background', '', 'color', '#0b1526') !!}
      {!! s_field('footer_extra_class', 'Extra Footer Class (optional)', 'যেমন: dark', 'text') !!}
    </div>
    <button class="btn btn-primary" type="submit"><i class="fa-solid fa-check"></i> Save Footer Bottom</button>
    <a href="{{ route('home') }}#footer" target="_blank" class="btn btn-outline"><i class="fa-solid fa-eye"></i> View Footer</a>
  </form>
  <div class="alert alert-success mt"><i class="fa-solid fa-wand-magic-sparkles"></i><div><b>Fresh tip:</b> Footer BG #0b1526 + প্রাইমারি #2563eb = সবচেয়ে প্রিমিয়াম ফুটার।</div></div>
</div>

@elseif($tab === 'payment')
@php $isSandbox = \App\Services\NagorikPayGateway::isSandbox(); $enabled = \App\Services\NagorikPayGateway::enabled(); @endphp
@if($isSandbox && $enabled)
<div class="alert alert-warning"><i class="fa-solid fa-flask"></i><div><b>TEST MODE ACTIVE — Sandbox</b> — No real money moves. Use sandbox API key (sk_test_…).</div></div>
@elseif(!$isSandbox && $enabled)
<div class="alert alert-success"><i class="fa-solid fa-shield-halved"></i><div><b>LIVE MODE</b> — Real payments processing.</div></div>
@endif
<div class="card" style="max-width:820px;border-radius:20px">
  <div class="card-title"><i class="fa-solid fa-money-bill-transfer"></i> Automatic Payment — NagorikPay {!! \App\Services\NagorikPayGateway::testModeBadge() !!}</div>
  <p class="card-sub">Sandbox ও Live আলাদা কী — টেস্টের পর Live অন করুন। Hosted checkout বা Direct Payment (payment number + TrxID) flow admin থেকেই বেছে নিন।</p>
  <form method="POST" action="{{ route('admin.settings.update', ['tab'=>'payment']) }}">
    @csrf @method('PATCH')
    <div class="form-row">
      {!! s_select('nagorikpay_enabled', 'Enable NagorikPay', ['0'=>'Disabled — Manual (bKash/Nagad)', '1'=>'Enabled — Auto-verify'], '', '0') !!}
      {!! s_select('nagorikpay_mode', 'Mode', ['sandbox'=>'🧪 Sandbox (Test)', 'live'=>'✅ Live (Production)'], '', 'sandbox') !!}
    </div>
    <div class="form-row">
      {!! s_select('nagorikpay_payment_flow', 'Payment Flow', ['hosted'=>'Hosted checkout page', 'direct'=>'Direct Payment — number + TrxID'], 'Choose how customers pay', 'hosted') !!}
      {!! s_select('nagorikpay_payment_method', 'Direct Payment Method', ['auto'=>'Auto / gateway choice', 'bkash'=>'bKash', 'nagad'=>'Nagad', 'rocket'=>'Rocket', 'upay'=>'Upay', 'card'=>'Card', 'bank'=>'Bank / QR'], 'Used in Direct Payment mode', 'auto') !!}
    </div>
    <div class="form-row">
      {!! s_select('nagorikpay_account_type', 'Account Type', ['personal'=>'Personal', 'agent'=>'Agent', 'merchant'=>'Merchant'], 'Used by Direct Payment request', 'personal') !!}
      <div class="alert alert-info" style="margin:0;display:flex;align-items:center"><i class="fa-solid fa-circle-info"></i><div>Direct mode shows the gateway’s exact <b>pay_amount</b>, not only the requested amount.</div></div>
    </div>
    <div class="form-row">
      {!! s_field('nagorikpay_base_url', 'Gateway Base URL', 'Auto per mode — override if docs differ', 'url', $isSandbox ? \App\Services\NagorikPayGateway::SANDBOX_BASE : \App\Services\NagorikPayGateway::LIVE_BASE) !!}
      {!! s_field('nagorikpay_brand_id', 'Brand ID', 'Optional from Brands page', 'text') !!}
    </div>
    <div class="form-row">
      {!! s_field('nagorikpay_create_path', 'Create Path', 'Default: api/payment/create', 'text', 'api/payment/create') !!}
      {!! s_field('nagorikpay_verify_path', 'Verify Path', 'Default: api/payment/verify', 'text', 'api/payment/verify') !!}
    </div>
    <div class="form-row">
      {!! s_field('nagorikpay_create_request_path', 'Direct Create Path', 'Default: api/payment/create-request', 'text', 'api/payment/create-request') !!}
      {!! s_field('nagorikpay_submit_transaction_path', 'Direct TrxID Submit Path', 'Default: api/payment-submit-transaction', 'text', 'api/payment-submit-transaction') !!}
    </div>
    {!! s_field('nagorikpay_callback_base_url', 'Public Callback / Subdomain URL', 'Optional. Example: https://pay.example.com — leave empty to use this site URL.', 'url') !!}
    <hr style="border:none;border-top:1px solid var(--border);margin:16px 0">
    <h4 style="font-weight:900;margin-bottom:8px"><i class="fa-solid fa-flask"></i> Sandbox Credentials <span class="badge badge-warning" style="font-size:10px">TEST</span></h4>
    {!! s_field('nagorikpay_api_key_sandbox', 'Sandbox API Key', 'sk_test_…', 'password') !!}
    {!! s_field('nagorikpay_webhook_secret_sandbox', 'Sandbox Webhook Secret', '', 'password') !!}
    <hr style="border:none;border-top:1px solid var(--border);margin:16px 0">
    <h4 style="font-weight:900;margin-bottom:8px"><i class="fa-solid fa-shield-halved"></i> Live Credentials <span class="badge badge-success" style="font-size:10px">PROD</span></h4>
    {!! s_field('nagorikpay_api_key_live', 'Live API Key', '', 'password') !!}
    {!! s_field('nagorikpay_webhook_secret_live', 'Live Webhook Secret', '', 'password') !!}
    <hr style="border:none;border-top:1px solid var(--border);margin:16px 0">
    <h4 style="font-weight:800">Legacy Fallback</h4>
    {!! s_field('nagorikpay_api_key', 'Fallback API Key', '', 'password') !!}
    {!! s_field('nagorikpay_webhook_secret', 'Fallback Webhook Secret', '', 'password') !!}
    <div class="form-row">
      {!! s_field('nagorikpay_expire_minutes', 'Auto-Expire (min)', '', 'number', '30') !!}
      {!! s_field('nagorikpay_recheck_minutes', 'Auto-Recheck (min)', '', 'number', '5') !!}
    </div>
    <hr style="border:none;border-top:1px solid var(--border);margin:16px 0">
    <h4 style="font-weight:900;margin-bottom:8px"><i class="fa-solid fa-wallet"></i> Wallet & Custom Credits</h4>
    <div class="form-row">
      {!! s_field('wallet_min_topup', 'Minimum wallet top-up', 'Users cannot add less than this amount.', 'number', '10') !!}
      {!! s_field('wallet_max_topup', 'Maximum wallet top-up', 'Maximum amount per top-up.', 'number', '100000') !!}
    </div>
    {!! s_field('credit_price_default', 'Default price per credit', 'Used when an API does not have its own price. Per-API price is managed from Services.', 'number', '1') !!}
    <button class="btn btn-primary btn-block btn-lg" type="submit"><i class="fa-solid fa-bolt"></i> Save NagorikPay</button>
  </form>
  <div class="flex gap wrap-x mt">
    <a class="btn btn-outline btn-sm" href="{{ route('admin.logs.nagorikpay') }}"><i class="fa-solid fa-list"></i> NagorikPay Logs</a>
    <a class="btn btn-outline btn-sm" href="https://nagorikpay.com/developers" target="_blank"><i class="fa-solid fa-book"></i> Docs</a>
  </div>
  @foreach(['nagorikpay_api_key_sandbox','nagorikpay_webhook_secret_sandbox','nagorikpay_api_key_live','nagorikpay_webhook_secret_live','nagorikpay_api_key','nagorikpay_webhook_secret'] as $k)
    <form id="clear_{{ $k }}" method="POST" action="{{ route('admin.settings.nagorikpay.clear') }}" style="display:none">@csrf<input type="hidden" name="key" value="{{ $k }}"></form>
  @endforeach
</div>
<div class="card mt" style="max-width:820px;border-radius:20px">
  <div class="card-title"><i class="fa-solid fa-money-bill-transfer"></i> Manual Fallback</div>
  <form method="POST" action="{{ route('admin.settings.update', ['tab'=>'payment']) }}">
    @csrf @method('PATCH')
    <div class="form-row">{!! s_field('pay_bkash', 'bKash Number') !!}{!! s_field('pay_nagad', 'Nagad Number') !!}</div>
    {!! s_field('pay_rocket', 'Rocket Number') !!}
    {!! s_field('pay_instruction', 'Instruction', '', 'textarea') !!}
    <button class="btn btn-primary" type="submit"><i class="fa-solid fa-check"></i> Save Manual</button>
  </form>
</div>

@elseif($tab === 'api')
<div class="card" style="max-width:700px;border-radius:20px">
  <div class="card-title"><i class="fa-solid fa-plug"></i> API Defaults & Limits</div>
  <form method="POST" action="{{ route('admin.settings.update', ['tab'=>'api']) }}">
    @csrf @method('PATCH')
    {!! s_field('global_provider_key', 'Global Provider Key') !!}
    <div class="form-row">{!! s_field('key_prefix', 'Key Prefix', '', 'text', 'INF-') !!}{!! s_field('api_rate_limit', 'Rate Limit /min per key', '', 'number', '60') !!}</div>
    <div class="form-row">{!! s_field('api_ip_rate_limit', 'IP Rate Limit /min', '', 'number', '120') !!}{!! s_field('signup_bonus', 'Signup Bonus', '', 'number', '50') !!}</div>
    <div class="form-row">{!! s_field('signup_validity', 'Key Validity days', '', 'number', '30') !!}{!! s_field('service_free_quota', 'Free Quota', '', 'number', '25') !!}</div>
    {!! s_field('status_threshold', 'Status Operational %', '', 'number', '50') !!}
    <button class="btn btn-primary" type="submit"><i class="fa-solid fa-check"></i> Save API</button>
  </form>
</div>

@elseif($tab === 'social')
<div class="card" style="max-width:680px;border-radius:20px">
  <div class="card-title"><i class="fa-solid fa-headset"></i> Support & Social — ফুটার + হেডার</div>
  <form method="POST" action="{{ route('admin.settings.update', ['tab'=>'social']) }}">
    @csrf @method('PATCH')
    {!! s_field('support_telegram', 'Telegram URL', 'https://t.me/...') !!}
    {!! s_field('support_whatsapp', 'WhatsApp URL', 'https://wa.me/...') !!}
    {!! s_field('support_facebook', 'Facebook Page URL') !!}
    {!! s_field('support_youtube', 'YouTube Channel URL') !!}
    <button class="btn btn-primary" type="submit"><i class="fa-solid fa-check"></i> Save Links</button>
  </form>
  <div class="alert alert-info mt"><i class="fa-solid fa-circle-info"></i><div style="font-size:13px">এই লিংকগুলো ফুটারের সোশ্যাল আইকন + Support কলামে অটো দেখায়। খালি রাখলে আইকন হাইড।</div></div>
</div>

@elseif($tab === 'seo')
<div class="card" style="max-width:820px;border-radius:20px">
  <div class="card-title"><i class="fa-solid fa-magnifying-glass-chart"></i> SEO & Analytics</div>
  <form method="POST" action="{{ route('admin.settings.update', ['tab'=>'seo']) }}">
    @csrf @method('PATCH')
    {!! s_field('seo_title', 'SEO Title') !!}
    {!! s_field('seo_description', 'Meta Description', '120–160 chars', 'textarea') !!}
    {!! s_field('seo_keywords', 'Keywords', 'comma separated') !!}
    <div class="form-row">{!! s_field('seo_robots', 'Robots', 'index,follow', 'text', 'index,follow') !!}{!! s_field('seo_canonical_url', 'Canonical URL', '', 'url') !!}</div>
    {!! s_field('analytics_id', 'Google Analytics ID', 'G-XXXXXXXXXX') !!}
    <button class="btn btn-primary" type="submit"><i class="fa-solid fa-check"></i> Save SEO</button>
  </form>
</div>

@elseif($tab === 'security')
<div class="card" style="max-width:820px;border-radius:20px">
  <div class="card-title"><i class="fa-brands fa-google"></i> Google Login</div>
  <form method="POST" action="{{ route('admin.settings.update', ['tab'=>'security']) }}">
    @csrf @method('PATCH')
    {!! s_field('google_oauth_enabled', 'Enable Google Login', '1 = on', 'number', '0') !!}
    <div class="form-row">{!! s_field('google_client_id', 'Google Client ID') !!}{!! s_field('google_client_secret', 'Google Client Secret', 'encrypted', 'password') !!}</div>
    {!! s_field('google_redirect_url', 'Callback URL', 'Must match Google Cloud', 'url') !!}
    <div class="form-hint">Default: {{ route('google.callback') }}</div>
    <div class="card mt" style="background:#f8fbff;border:1px solid #dbeafe;border-radius:14px;padding:14px">
      <div class="card-title" style="font-size:14px"><i class="fa-solid fa-shield-halved"></i> API Provider Security</div>
      {!! s_select('api_allow_http', 'Allow insecure HTTP provider URLs', ['0'=>'Disabled — HTTPS only (recommended)','1'=>'Allow HTTP — only for trusted legacy providers'], 'Private/reserved hosts remain blocked.') !!}
    </div>
    <button class="btn btn-primary mt" type="submit"><i class="fa-solid fa-check"></i> Save Google</button>
  </form>
</div>
<div class="card mt" style="max-width:820px;border-radius:20px">
  <div class="card-title"><i class="fa-solid fa-shield-halved"></i> Password Security</div>
  <p class="card-sub">ডিফল্ট <span class="mono">admin123</span> বদলাতে হবে — না বদলালে প্রোফাইলে redirect হবে।</p>
  <form method="POST" action="{{ route('admin.admins.mypass') }}" style="max-width:480px">@csrf @method('PATCH')
    <div class="form-group"><label>Change My Admin Password</label><input type="password" name="password" class="form-control" placeholder="New password (min 8)"></div>
    <div class="form-group"><input type="password" name="password_confirmation" class="form-control" placeholder="Confirm"></div>
    <button class="btn btn-primary btn-block" type="submit">Update Password</button>
  </form>
</div>

@elseif($tab === 'system')
<div class="grid-2" style="align-items:start">
  <div class="card" style="border-radius:20px">
    <div class="card-title"><i class="fa-solid fa-screwdriver-wrench"></i> Maintenance Mode</div>
    <form method="POST" action="{{ route('admin.settings.update', ['tab'=>'system']) }}">
      @csrf @method('PATCH')
      <input type="hidden" name="cb_maintenance_mode" value="1">
      <label class="checkbox-row mb" style="background:var(--bg);padding:12px;border-radius:12px;border:1px solid var(--border)"><input type="checkbox" name="s[maintenance_mode]" value="1" {{ setting('maintenance_mode','0')==='1' ? 'checked' : '' }}> Enable maintenance (admins can still browse)</label>
      {!! s_field('maintenance_msg', 'Message', '', 'textarea') !!}
      <button class="btn btn-warning" type="submit"><i class="fa-solid fa-check"></i> Save</button>
    </form>
  </div>
  <div class="card" style="border-radius:20px">
    <div class="card-title"><i class="fa-solid fa-database"></i> Backup & Cron</div>
    <a class="btn btn-primary btn-block" href="{{ route('admin.settings.backup') }}"><i class="fa-solid fa-download"></i> Download Backup (.sql)</a>
    <hr style="border:none;border-top:1px solid var(--border);margin:16px 0">
    <div class="card-title" style="font-size:14px"><i class="fa-solid fa-terminal"></i> Scheduler</div>
    <div class="endpoint-line" style="font-size:11px;overflow:auto"><span>* * * * * cd /path/to/project && php artisan schedule:run >> /dev/null 2>&1</span></div>
  </div>
</div>
@endif
@endsection
