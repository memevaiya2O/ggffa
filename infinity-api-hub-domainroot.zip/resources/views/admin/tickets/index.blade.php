@extends('layouts.dash')
@section('title', 'Support Tickets')
@section('content')
<div class="page-head"><div><h1>Support Tickets ({{ $tickets->total() }})</h1><p>Help your customers fast.</p></div></div>
<div class="card">
  <form method="GET" class="filter-bar">
    <select name="status" class="form-control" style="max-width:260px" onchange="this.form.submit()">
      <option value="">All Status</option>
      <option value="open" {{ request('status') === 'open' ? 'selected' : '' }}>Open</option>
      <option value="answered" {{ request('status') === 'answered' ? 'selected' : '' }}>Answered</option>
      <option value="closed" {{ request('status') === 'closed' ? 'selected' : '' }}>Closed</option>
    </select>
  </form>
  <div class="table-wrap"><table class="tbl">
    <tr><th>#</th><th>User</th><th>Subject</th><th>API</th><th>Priority</th><th>Status</th><th>Updated</th><th></th></tr>
    @foreach($tickets as $t)
    <tr>
      <td><b>{{ $t->id }}</b></td>
      <td class="text-sm"><b>{{ $t->user->name ?? '—' }}</b><br><small class="text-gray">{{ $t->user->email ?? '' }}</small></td>
      <td><b>{{ $t->subject }}</b></td>
      <td class="text-sm">{{ $t->service->name ?? 'General' }}</td>
      <td>{!! badge($t->priority) !!}</td>
      <td>{!! badge($t->status) !!}</td>
      <td class="text-sm text-gray">{{ $t->updated_at->diffForHumans() }}</td>
      <td><a class="btn btn-ghost btn-xs" href="{{ route('admin.tickets.show', $t) }}"><i class="fa-solid fa-eye"></i> Open</a></td>
    </tr>
    @endforeach
  </table></div>
  @if($tickets->isEmpty())<div class="empty"><i class="fa-solid fa-headset"></i><b>No tickets</b></div>@endif
  {{ $tickets->links() }}
</div>
@endsection
