@extends('layouts.dash')
@section('title', 'Ticket #'.$ticket->id)
@section('content')
<div class="page-head">
  <div><h1>#{{ $ticket->id }} — {{ $ticket->subject }}</h1><p>{{ $ticket->user->name ?? '' }} ({{ $ticket->user->email ?? '' }}) • {{ $ticket->service->name ?? 'General' }}</p></div>
  <a class="btn btn-outline btn-sm" href="{{ route('admin.tickets') }}"><i class="fa-solid fa-arrow-left"></i>All Tickets</a>
</div>
<div class="flex gap wrap-x mb">
  {!! badge($ticket->status) !!} {!! badge($ticket->priority) !!}
  <form action="{{ route('admin.tickets.status', $ticket) }}" method="POST" class="flex gap">@csrf
    <select name="status" class="form-control" style="width:auto;padding:7px 12px"><option value="open" {{ $ticket->status === 'open' ? 'selected' : '' }}>Open</option><option value="answered" {{ $ticket->status === 'answered' ? 'selected' : '' }}>Answered</option><option value="closed" {{ $ticket->status === 'closed' ? 'selected' : '' }}>Closed</option></select>
    <button class="btn btn-outline btn-sm">Update</button>
  </form>
</div>
<div class="card">
  @foreach($ticket->replies as $r)
  <div class="ticket-msg {{ $r->is_admin ? 'admin' : 'user' }}">
    <div class="ticket-head"><b>{{ $r->is_admin ? '🛡️ '.e($r->user->name ?? 'Support') : e($r->user->name ?? 'User') }}</b><small>{{ $r->created_at->diffForHumans() }}</small></div>
    <div class="ticket-body">{!! nl2br(e($r->message)) !!}</div>
  </div>
  @endforeach
  <form method="POST" action="{{ route('admin.tickets.reply', $ticket) }}" class="mt">
    @csrf
    <div class="form-group"><label>Write a reply</label><textarea name="message" class="form-control" required placeholder="Type your reply…"></textarea></div>
    <button class="btn btn-primary" type="submit"><i class="fa-solid fa-paper-plane"></i>Send Reply</button>
  </form>
</div>
@endsection
