@extends('layouts.dash')
@section('title', 'User Management')
@section('content')
<div class="page-head">
  <div><h1><i class="fa-solid fa-users-gear" style="color:var(--primary)"></i> User Management <span class="badge badge-primary" style="font-size:11px">{{ $users->total() }} total</span></h1><p>Manage accounts, access status, roles, API usage, and user support from one place.</p></div>
</div>
<div class="card user-management-toolbar">
  <form method="GET" class="filter-bar">
    <input type="text" name="q" class="form-control" placeholder="Search name, email, or phone…" value="{{ request('q') }}">
    <select name="status" class="form-control"><option value="">All statuses</option><option value="active" {{ request('status') === 'active' ? 'selected' : '' }}>Active</option><option value="suspended" {{ request('status') === 'suspended' ? 'selected' : '' }}>Banned / Suspended</option></select>
    <select name="role" class="form-control"><option value="">All roles</option><option value="user" {{ request('role') === 'user' ? 'selected' : '' }}>Users</option><option value="admin" {{ request('role') === 'admin' ? 'selected' : '' }}>Admins</option></select>
    <button class="btn btn-primary" type="submit"><i class="fa-solid fa-filter"></i>Filter</button>
    @if(request()->hasAny(['q','status','role']))<a class="btn btn-outline" href="{{ route('admin.users') }}">Reset</a>@endif
  </form>
</div>
<div class="card">
  <div class="flex between center wrap-x mb"><div class="card-title" style="margin:0"><i class="fa-solid fa-table-list"></i> Accounts</div><span class="mini-tag blue">Ban, notify, reset, and manage APIs from user details</span></div>
  <div class="table-wrap"><table class="tbl user-management-table">
    <tr><th>User</th><th>Contact</th><th>API usage</th><th>Role</th><th>Status</th><th>Joined</th><th>Action</th></tr>
    @foreach($users as $u)
    @php $left = max(0, (int) ($u->quota_total ?? 0) - (int) ($u->quota_used ?? 0)); @endphp
    <tr>
      <td><div class="user-row-main"><div class="avatar user-list-avatar">{{ strtoupper(substr($u->name ?: 'U', 0, 1)) }}</div><div><b>{{ $u->name }}</b><br><small class="text-gray">{{ $u->email }}</small></div></div></td>
      <td class="text-sm">{{ $u->phone ?: '—' }}</td>
      <td style="min-width:150px"><b>{{ number_format($left) }}</b> left<br><small class="text-gray">{{ number_format((int) ($u->quota_used ?? 0)) }} used</small><div class="progress"><div style="width:{{ ($u->quota_total ?? 0) > 0 ? min(100, (($u->quota_used ?? 0) / $u->quota_total) * 100) : 0 }}%"></div></div></td>
      <td>{!! badge($u->role, 'primary') !!}</td>
      <td>{!! badge($u->status) !!}</td>
      <td class="text-sm text-gray">{{ fmt_date($u->created_at) }}</td>
      <td><a class="btn btn-primary btn-xs" href="{{ route('admin.users.show', $u) }}"><i class="fa-solid fa-sliders"></i>Manage</a></td>
    </tr>
    @endforeach
  </table></div>
  @if($users->isEmpty())<div class="empty"><i class="fa-solid fa-users-slash"></i><b>No users found</b><span class="text-sm text-gray">Try changing your search or filters.</span></div>@endif
  {{ $users->links() }}
</div>
@endsection
