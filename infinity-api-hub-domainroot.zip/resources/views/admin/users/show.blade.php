@extends('layouts.dash')
@section('title', 'Manage '.$u->name)
@section('content')
<div class="page-head">
  <div><div class="text-sm text-gray" style="margin-bottom:5px"><a href="{{ route('admin.users') }}" style="color:var(--primary);font-weight:800"><i class="fa-solid fa-arrow-left"></i> User Management</a></div><h1><i class="fa-solid fa-user-gear" style="color:var(--primary)"></i> {{ $u->name }}</h1><p>{{ $u->email }} @if($u->phone) • {{ $u->phone }} @endif • Joined {{ fmt_date($u->created_at) }}</p></div>
  <div class="flex gap wrap-x">{!! badge($u->role, 'primary') !!} {!! badge($u->status) !!}<a class="btn btn-outline btn-sm" href="{{ route('admin.users') }}">All Users</a></div>
</div>
<div class="stat-grid">
  <div class="stat-card"><div class="top"><div class="sic bg-blue"><i class="fa-solid fa-key"></i></div><span class="trend bg-blue">{{ $stats['keys'] }} active</span></div><h3>{{ $stats['keys'] }}</h3><p>API Keys</p></div>
  <div class="stat-card"><div class="top"><div class="sic bg-green"><i class="fa-solid fa-coins"></i></div></div><h3>{{ number_format($stats['left']) }}</h3><p>Credits Left</p></div>
  <div class="stat-card"><div class="top"><div class="sic bg-sky"><i class="fa-solid fa-bolt"></i></div></div><h3>{{ number_format($stats['today']) }}</h3><p>Hits Today</p></div>
  <div class="stat-card"><div class="top"><div class="sic bg-amber"><i class="fa-solid fa-wallet"></i></div></div><h3>{{ $wallet ? taka($wallet->balance) : taka(0) }}</h3><p>Wallet Balance</p></div>
</div>
<div class="grid-2 user-detail-grid">
  <div>
    <div class="card">
      <div class="card-title"><i class="fa-solid fa-shield-halved"></i> Account Access</div>
      <p class="card-sub">Ban or unban the user, change account role, reset password, or permanently remove the account.</p>
      <div class="flex wrap-x gap mt">
        <form action="{{ route('admin.users.status', $u) }}" method="POST">@csrf<button class="btn {{ $u->status === 'active' ? 'btn-warning' : 'btn-success' }} btn-sm" type="submit"><i class="fa-solid fa-{{ $u->status === 'active' ? 'ban' : 'check' }}"></i>{{ $u->status === 'active' ? 'Ban User' : 'Unban User' }}</button></form>
        <form action="{{ route('admin.users.role', $u) }}" method="POST" onsubmit="return confirm('Change this user role?')">@csrf<button class="btn btn-outline btn-sm" type="submit"><i class="fa-solid fa-user-shield"></i>Make {{ $u->role === 'admin' ? 'User' : 'Admin' }}</button></form>
        <form action="{{ route('admin.users.destroy', $u) }}" method="POST" onsubmit="return confirm('Delete this user and all related keys/orders? This cannot be undone.')">@csrf @method('DELETE')<button class="btn btn-danger btn-sm" type="submit"><i class="fa-solid fa-trash"></i>Delete</button></form>
      </div>
      <hr class="user-detail-rule">
      <div class="user-management-two-col">
        <form action="{{ route('admin.users.resetpass', $u) }}" method="POST"><b><i class="fa-solid fa-lock text-primary"></i> Reset Password</b>@csrf<div class="flex gap mt"><input type="text" name="newpass" class="form-control" placeholder="New password (min 6)" required><button class="btn btn-outline" type="submit">Reset</button></div></form>
        <div><b><i class="fa-solid fa-circle-info text-primary"></i> Account flags</b><div class="flex wrap-x gap mt"><span class="mini-tag">{{ $u->must_change_password ? 'Must change password' : 'Password set' }}</span><span class="mini-tag">{{ $u->google_id ? 'Google linked' : 'Email login' }}</span></div></div>
      </div>
    </div>
    <div class="card mt">
      <div class="card-title"><i class="fa-solid fa-paper-plane"></i> Send Direct Notification</div>
      <p class="card-sub">This message appears in the user's dashboard and Notifications page. It is not a public broadcast.</p>
      <form action="{{ route('admin.users.notify', $u) }}" method="POST">@csrf
        <div class="form-group"><label>Title</label><input name="title" class="form-control" maxlength="200" required placeholder="e.g. Your API key was updated"></div>
        <div class="form-group"><label>Message</label><textarea name="message" class="form-control" maxlength="5000" required placeholder="Write a clear message for this user…"></textarea></div>
        <div class="form-row"><div class="form-group"><label>Type</label><select name="type" class="form-control"><option value="info">Info</option><option value="success">Success</option><option value="warning">Warning</option><option value="error">Alert</option></select></div><div class="form-group" style="display:flex;align-items:end"><button class="btn btn-primary btn-block" type="submit"><i class="fa-solid fa-paper-plane"></i>Send Notification</button></div></div>
      </form>
    </div>
    <div class="card mt">
      <div class="card-title"><i class="fa-solid fa-gift text-primary"></i> Add Bonus Credits</div>
      <form action="{{ route('admin.users.bonus', $u) }}" method="POST" class="mt">@csrf
        <div class="form-group"><label>API key</label><select name="key_id" class="form-control" required>@forelse($keys as $k)<option value="{{ $k->id }}">{{ $k->service->name ?? $k->label }} — {{ number_format($k->remaining()) }} left</option>@empty<option disabled>No API keys available</option>@endforelse</select></div>
        <div class="form-row"><div class="form-group"><label>Credits</label><input type="number" name="qty" class="form-control" min="1" value="100" required></div><div class="form-group"><label>Extra validity days</label><input type="number" name="days" class="form-control" min="0" value="0"></div></div>
        <button class="btn btn-success btn-block" type="submit" {{ $keys->isEmpty() ? 'disabled' : '' }}><i class="fa-solid fa-gift"></i>Add Bonus Credits</button>
      </form>
    </div>
  </div>
  <div>
    <div class="card">
      <div class="flex between center wrap-x"><div class="card-title" style="margin:0"><i class="fa-solid fa-key"></i> API Keys ({{ $keys->count() }})</div><a class="btn btn-outline btn-xs" href="{{ route('admin.keys.create') }}"><i class="fa-solid fa-plus"></i>Create Key</a></div>
      <div class="user-key-stack mt">
      @forelse($keys as $k)
        <div class="user-key-card">
          <div class="flex between center gap"><div><b>{{ $k->service->name ?? $k->label }}</b><br><small class="mono text-gray">{{ \Illuminate\Support\Str::limit($k->api_key, 28) }}</small></div>{!! badge($k->status) !!}</div>
          <div class="flex between center mt"><span class="text-sm text-gray">{{ number_format($k->remaining()) }} left • {{ number_format($k->used_request) }} used</span><span class="mini-tag">{{ fmt_date($k->exp_date) }}</span></div>
          <div class="flex gap wrap-x mt"><a class="btn btn-ghost btn-xs" href="{{ route('admin.keys.edit', $k) }}"><i class="fa-solid fa-pen"></i>Edit</a><form method="POST" action="{{ route('admin.users.keys.toggle', [$u, $k]) }}">@csrf<button class="btn btn-warning btn-xs" type="submit">{{ $k->status === 'active' ? 'Disable' : 'Enable' }}</button></form><form method="POST" action="{{ route('admin.users.keys.regenerate', [$u, $k]) }}" onsubmit="return confirm('Regenerate this key? The old key will stop working.')">@csrf<button class="btn btn-outline btn-xs" type="submit"><i class="fa-solid fa-rotate"></i>Regenerate</button></form></div>
        </div>
      @empty<div class="empty"><i class="fa-solid fa-key"></i><b>No API keys</b></div>@endforelse
      </div>
    </div>
    <div class="card mt"><div class="card-title"><i class="fa-solid fa-receipt"></i>Recent Orders</div>@forelse($orders as $o)<div class="flex between center gap user-order-row"><div><b>{{ $o->order_kind === 'wallet_topup' ? 'Wallet top-up' : ($o->package?->name ?? 'Custom credits') }}</b><br><small class="text-gray">{{ fmt_date($o->created_at) }}</small></div><span>{!! badge($o->status) !!} <b>{{ $o->amount > 0 ? taka($o->amount) : 'FREE' }}</b></span></div>@empty<div class="empty"><i class="fa-solid fa-receipt"></i><b>No orders</b></div>@endforelse</div>
    <div class="card mt"><div class="card-title"><i class="fa-solid fa-bell"></i>Direct Notifications</div>@forelse($notifications as $n)<div class="user-order-row"><div class="flex between gap"><b>{{ $n->title }}</b>{!! badge($n->type, 'info') !!}</div><div class="text-sm text-gray">{{ \Illuminate\Support\Str::limit($n->message, 120) }}</div></div>@empty<div class="empty"><i class="fa-solid fa-bell-slash"></i><b>No direct messages</b></div>@endforelse</div>
  </div>
</div>
@endsection
