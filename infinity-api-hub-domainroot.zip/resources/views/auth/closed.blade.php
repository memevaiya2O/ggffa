@extends('layouts.app')
@section('title', 'Register')
@section('content')
<div class="auth-wrap">
  <div class="auth-card">
    <div class="auth-logo-ic">∞</div>
    <h2>Registration Closed</h2>
    <div class="alert alert-warning"><i class="fa-solid fa-lock"></i><div>New registrations are temporarily closed. Please try again later.</div></div>
    <a class="btn btn-outline btn-block mt" href="{{ route('home') }}">Back to Home</a>
  </div>
</div>
@endsection
