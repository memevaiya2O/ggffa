@extends('layouts.app')
@section('title', 'Login')
@section('content')
<div class="auth-wrap">
  <div class="auth-card">
    <div class="auth-logo-ic">∞</div>
    <h2>Welcome Back</h2>
    <p>Login to manage your API keys & credits.</p>
    <form method="POST" action="{{ route('login.post') }}" autocomplete="off">
      @csrf
      <div class="form-group">
        <label>Email Address</label>
        <div class="input-icon"><i class="fa-solid fa-envelope"></i><input type="email" name="email" class="form-control" placeholder="you@example.com" required value="{{ old('email') }}"></div>
      </div>
      <div class="form-group">
        <label>Password</label>
        <div class="input-icon"><i class="fa-solid fa-lock"></i><input type="password" name="password" class="form-control" placeholder="••••••••" required></div>
      </div>
      <label class="checkbox-row mb"><input type="checkbox" name="remember" value="1"> Remember me</label>
      <button class="btn btn-primary btn-block btn-lg" type="submit"><i class="fa-solid fa-right-to-bracket"></i>Login</button>
    </form>
    @if(setting('google_oauth_enabled', '0') === '1' && setting('google_client_id', ''))
    <div class="auth-divider"><span>or</span></div>
    <a class="btn btn-outline btn-block btn-lg google-login" href="{{ route('google.redirect') }}"><i class="fa-brands fa-google"></i>Continue with Google</a>
    @endif
    <div class="auth-alt">Don't have an account? <a href="{{ route('register') }}">Create free account</a></div>
  </div>
</div>
@endsection
