@extends('layouts.app')
@section('title', 'Create Account')
@section('content')
<div class="auth-wrap">
  <div class="auth-card">
    <div class="auth-logo-ic">∞</div>
    <h2>Create Free Account</h2>
    <p>Instantly get an API key for <b class="text-primary">every service</b> with <b class="text-primary">{{ (int) setting('signup_bonus', 50) }} free credits each</b>.</p>
    <form method="POST" action="{{ route('register.post') }}" autocomplete="off">
      @csrf
      <div class="form-group">
        <label>Full Name <span class="req">*</span></label>
        <div class="input-icon"><i class="fa-solid fa-user"></i><input type="text" name="name" class="form-control" placeholder="Your name" required value="{{ old('name') }}"></div>
      </div>
      <div class="form-group">
        <label>Email Address <span class="req">*</span></label>
        <div class="input-icon"><i class="fa-solid fa-envelope"></i><input type="email" name="email" class="form-control" placeholder="you@example.com" required value="{{ old('email') }}"></div>
      </div>
      <div class="form-group">
        <label>Phone / WhatsApp</label>
        <div class="input-icon"><i class="fa-solid fa-phone"></i><input type="text" name="phone" class="form-control" placeholder="01XXXXXXXXX" value="{{ old('phone') }}"></div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Password <span class="req">*</span></label>
          <div class="input-icon"><i class="fa-solid fa-lock"></i><input type="password" name="password" class="form-control" placeholder="Min 6 chars" required></div>
        </div>
        <div class="form-group">
          <label>Confirm <span class="req">*</span></label>
          <div class="input-icon"><i class="fa-solid fa-lock"></i><input type="password" name="password_confirmation" class="form-control" placeholder="Repeat" required></div>
        </div>
      </div>
      <button class="btn btn-primary btn-block btn-lg" type="submit"><i class="fa-solid fa-user-plus"></i>Create Account</button>
    </form>
    @if(setting('google_oauth_enabled', '0') === '1' && setting('google_client_id', ''))
    <div class="auth-divider"><span>or</span></div>
    <a class="btn btn-outline btn-block btn-lg google-login" href="{{ route('google.redirect') }}"><i class="fa-brands fa-google"></i>Sign up with Google</a>
    @endif
    <div class="auth-alt">Already have an account? <a href="{{ route('login') }}">Login here</a></div>
  </div>
</div>
@endsection
