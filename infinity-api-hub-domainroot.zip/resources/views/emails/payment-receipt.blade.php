<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>Payment Receipt</title></head>
<body style="font-family:Inter,Outfit,sans-serif;background:#f1f5f9;padding:24px;color:#0f172a">
  <div style="max-width:640px;margin:0 auto;background:#fff;border-radius:16px;overflow:hidden;box-shadow:0 6px 24px rgba(0,0,0,.07)">
    <div style="background:linear-gradient(135deg,#1e3a8a,#2563eb);color:#fff;padding:22px 26px">
      <h1 style="margin:0;font-size:22px">∞ {{ setting('site_name','INFINITY API HUB') }}</h1>
      <p style="margin:4px 0 0;opacity:.9">Payment Receipt — Invoice {{ $invoice->invoice_number ?? '#'.$order->id }}</p>
    </div>
    <div style="padding:24px 26px">
      <p>Hi <b>{{ $order->user->name }}</b>,</p>
      <p>Your payment was <b style="color:#22c55e">verified successfully</b> and credits have been added.</p>
      <table style="width:100%;border-collapse:collapse;margin:14px 0">
        <tr><td style="padding:10px;border-bottom:1px solid #f1f5f9;color:#64748b">Order</td><td style="padding:10px;border-bottom:1px solid #f1f5f9;text-align:right"><b>#{{ $order->id }}</b></td></tr>
        <tr><td style="padding:10px;border-bottom:1px solid #f1f5f9;color:#64748b">Purchase</td><td style="padding:10px;border-bottom:1px solid #f1f5f9;text-align:right"><b>{{ $order->order_kind === 'wallet_topup' ? 'Wallet top-up' : (($order->service?->name ?? '—').' — '.($order->package?->name ?? 'Custom credits')) }}</b></td></tr>
        <tr><td style="padding:10px;border-bottom:1px solid #f1f5f9;color:#64748b">Credits / Wallet</td><td style="padding:10px;border-bottom:1px solid #f1f5f9;text-align:right"><b>{{ $order->order_kind === 'wallet_topup' ? taka($order->amount) : number_format((int)($order->credit_quantity ?: ($order->package?->requests ?? 0))) }}</b></td></tr>
        <tr><td style="padding:10px;border-bottom:1px solid #f1f5f9;color:#64748b">Amount Paid</td><td style="padding:10px;border-bottom:1px solid #f1f5f9;text-align:right"><b>{{ taka($order->amount) }}</b></td></tr>
        <tr><td style="padding:10px;border-bottom:1px solid #f1f5f9;color:#64748b">Transaction ID</td><td style="padding:10px;border-bottom:1px solid #f1f5f9;text-align:right;font-family:monospace">{{ $order->txn_id }}</td></tr>
        <tr><td style="padding:10px;color:#64748b">Date</td><td style="padding:10px;text-align:right">{{ fmt_date($order->reviewed_at ?: now(), true) }}</td></tr>
      </table>
      <p style="background:#f0fdf4;border:1px solid #dcfce7;padding:12px;border-radius:10px;color:#15803d;font-size:13px">Credits are now available on your API key: <span style="font-family:monospace">{{ $order->key->api_key ?? '' }}</span></p>
      <p style="text-align:center;margin:20px 0">
        <a href="{{ route('user.orders.invoice', $order) }}" style="display:inline-block;background:#2563eb;color:#fff;padding:12px 24px;border-radius:50px;text-decoration:none;font-weight:700">View Invoice</a>
        <a href="{{ route('user.keys') }}" style="display:inline-block;background:#fff;color:#2563eb;border:2px solid #e2e8f0;padding:10px 22px;border-radius:50px;text-decoration:none;font-weight:700;margin-left:8px">My API Keys</a>
      </p>
      <p style="font-size:13px;color:#64748b">Invoice PDF is attached to this email (if generated). Keep Transaction ID <span style="font-family:monospace">{{ $order->txn_id }}</span> for support.</p>
      <hr style="border:none;border-top:1px solid #e2e8f0;margin:18px 0">
      <p style="font-size:12px;color:#94a3b8;text-align:center">© {{ date('Y') }} {{ setting('site_name','INFINITY API HUB') }} • Need help? Reply to this email or open a ticket in your dashboard.</p>
    </div>
  </div>
</body>
</html>
