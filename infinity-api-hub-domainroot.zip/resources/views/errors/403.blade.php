<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>403 — Forbidden — {{ setting('site_name','INFINITY API HUB') }}</title>
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
*{margin:0;box-sizing:border-box;font-family:'Outfit',system-ui,sans-serif}body{background:#f6f8fc;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;color:#0f172a}
.box{background:#fff;border:1px solid #e2e8f0;border-radius:22px;max-width:520px;width:100%;padding:42px 30px;text-align:center;box-shadow:0 18px 50px rgba(37,99,235,.08)}
.ic{width:74px;height:74px;border-radius:18px;background:#fef2f2;color:#ef4444;display:flex;align-items:center;justify-content:center;font-size:30px;margin:0 auto 18px}
.code{font-size:54px;font-weight:900;letter-spacing:-1.5px;line-height:1}
.code span{color:#ef4444}
h1{font-size:20px;margin:10px 0 8px}
p{color:#64748b;font-size:14.5px;line-height:1.7}
.btns{display:flex;gap:10px;justify-content:center;margin-top:22px;flex-wrap:wrap}
.btn{display:inline-flex;align-items:center;gap:8px;padding:12px 22px;border-radius:50px;font-weight:700;font-size:14px;border:1px solid #e2e8f0;text-decoration:none;transition:.2s;color:#0f172a}
.btn-primary{background:linear-gradient(135deg,#2563eb,#1d4ed8);color:#fff;border-color:transparent;box-shadow:0 6px 18px rgba(37,99,235,.25)}
.btn:hover{transform:translateY(-2px)}
</style>
</head>
<body>
<div class="box">
  <div class="ic"><i class="fa-solid fa-shield-halved"></i></div>
  <div class="code">4<span>0</span>3</div>
  <h1>Access denied</h1>
  <p>You don’t have permission to view this page. If you’re logged in with the wrong account, try switching or contact an administrator.</p>
  <div class="btns">
    <a class="btn btn-primary" href="{{ url('/') }}"><i class="fa-solid fa-house"></i> Home</a>
    @auth<a class="btn" href="{{ auth()->user()->role==='admin'?route('admin.dashboard'):route('user.dashboard') }}"><i class="fa-solid fa-gauge-high"></i> Dashboard</a>@else<a class="btn" href="{{ route('login') }}"><i class="fa-solid fa-right-to-bracket"></i> Login</a>@endauth
  </div>
</div>
</body>
</html>
