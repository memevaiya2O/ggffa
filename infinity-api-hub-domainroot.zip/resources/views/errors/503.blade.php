<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Maintenance — {{ setting('site_name','INFINITY API HUB') }}</title>
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
*{margin:0;box-sizing:border-box;font-family:'Outfit',system-ui,sans-serif}body{background:#f6f8fc;display:flex;align-items:center;justify-content:center;min-height:100vh;padding:20px;color:#0f172a}
.box{background:#fff;padding:42px 30px;border-radius:22px;text-align:center;box-shadow:0 18px 50px rgba(37,99,235,.08);max-width:520px;width:100%;border:1px solid #e2e8f0}
.ic{width:74px;height:74px;border-radius:18px;background:#eff6ff;color:#2563eb;font-size:30px;display:flex;align-items:center;justify-content:center;margin:0 auto 18px}
h1{font-size:22px;font-weight:900;margin-bottom:8px}
p{color:#64748b;line-height:1.7;font-size:14.5px}
.btn{display:inline-flex;align-items:center;gap:8px;margin-top:22px;padding:12px 22px;border-radius:50px;background:linear-gradient(135deg,#2563eb,#1d4ed8);color:#fff;text-decoration:none;font-weight:700;font-size:14px;box-shadow:0 6px 18px rgba(37,99,235,.25)}
.small{margin-top:16px;font-size:12px;color:#94a3b8}
</style>
</head>
<body>
<div class="box"><div class="ic"><i class="fa-solid fa-screwdriver-wrench"></i></div><h1>Under Maintenance</h1><p>{{ setting('maintenance_msg','We are upgrading our systems to serve you better. Please come back soon — all your credits and keys are safe.') }}</p><a class="btn" href="{{ url('/') }}"><i class="fa-solid fa-rotate"></i> Check Again</a><div class="small">{{ setting('site_name','INFINITY API HUB') }} — {{ setting('site_tagline','Premium API Platform') }}</div></div>
</body>
</html>
