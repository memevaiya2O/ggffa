@include('partials.head')
@yield('content')
@include('partials.foot')
