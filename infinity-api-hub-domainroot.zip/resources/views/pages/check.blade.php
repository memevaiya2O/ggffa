@extends('layouts.app')
@section('title', 'Check API Key')
@section('content')
<div class="wrap page" style="max-width:640px">
  <div style="text-align:center;margin-bottom:24px">
    <div class="auth-logo-ic"><i class="fa-solid fa-key" style="font-size:26px"></i></div>
    <h1 style="font-size:30px;font-weight:900;margin-top:14px">Check API Key</h1>
    <p class="text-gray">Enter any key to see its API, status & credits.</p>
  </div>
  <div class="card">
    <form method="POST" action="{{ route('check.key.post') }}">
      @csrf
      <div class="form-group">
        <label>API Key</label>
        <div class="input-icon"><i class="fa-solid fa-key"></i><input type="text" name="api_key" class="form-control mono" placeholder="INF-XXXX-XXXX-XXXX-XXXX" required value="{{ $input ?? old('api_key', request('key')) }}"></div>
      </div>
      <button class="btn btn-primary btn-block" type="submit"><i class="fa-solid fa-magnifying-glass"></i>Check Now</button>
    </form>
  </div>

  @if(!empty($searched) && !empty($result))
  @php $pct = $result->usagePercent(); @endphp
  <div class="card mt">
    <div class="card-title"><i class="fa-solid fa-circle-info"></i>Key Details</div>
    <div style="display:grid;gap:12px;margin-top:14px">
      <div class="flex between wrap-x gap"><span class="text-gray">API</span><b>{{ $result->service->name ?? '—' }}</b></div>
      <div class="flex between wrap-x gap"><span class="text-gray">Label</span><b>{{ $result->label }}</b></div>
      <div class="flex between wrap-x gap"><span class="text-gray">Status</span><span>{!! badge($result->isExpired() ? 'expired' : $result->status) !!}</span></div>
      <div class="flex between wrap-x gap"><span class="text-gray">Expiry</span><b>{{ fmt_date($result->exp_date) }}</b></div>
      <div class="flex between wrap-x gap"><span class="text-gray">Last Used</span><b>{{ $result->last_used_at ? $result->last_used_at->diffForHumans() : 'Never' }}</b></div>
      <div>
        <div class="flex between"><span class="text-gray">Credits</span><b>{{ number_format($result->used_request) }} / {{ number_format($result->total_request) }} <span class="text-gray">({{ number_format($result->remaining()) }} left)</span></b></div>
        <div class="progress{{ $pct >= 90 ? ' low' : '' }}" style="margin-top:8px"><div style="width:{{ $pct }}%"></div></div>
      </div>
    </div>
  </div>
  @endif
</div>
@endsection
