@php
$flashes = [];
foreach (['success' => 'fa-circle-check', 'error' => 'fa-circle-exclamation', 'warning' => 'fa-triangle-exclamation', 'info' => 'fa-circle-info'] as $k => $icon) {
    if (session()->has($k)) $flashes[] = ['type' => $k, 'icon' => $icon, 'msg' => session($k)];
}
foreach ($errors->all() as $err) { $flashes[] = ['type' => 'error', 'icon' => 'fa-circle-exclamation', 'msg' => $err]; }
@endphp
@if(count($flashes))
<div class="toast-wrap">
  @foreach($flashes as $f)
  <div class="toast toast-{{ $f['type'] }}"><i class="fa-solid {{ $f['icon'] }}"></i><span>{{ $f['msg'] }}</span><button type="button" class="toast-x" onclick="this.parentElement.remove()"><i class="fa-solid fa-xmark"></i></button></div>
  @endforeach
</div>
@endif
