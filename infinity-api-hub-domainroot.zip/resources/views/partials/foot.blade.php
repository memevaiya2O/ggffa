@php
$siteName = setting('site_name', 'INFINITY API HUB');
$footerBrand = setting('footer_brand_text', '') ?: $siteName;
$footerAbout = setting('footer_about', '') ?: setting('footer_text', 'Fast, reliable & developer-friendly APIs. Built for developers, trusted by thousands.');
$footerLogo = setting('footer_logo', '');
$headerLogo = setting('logo', '');
$footLogoPath = $footerLogo ? asset('uploads/'.$footerLogo) : ($headerLogo ? asset('uploads/'.$headerLogo) : '/assets/footer-logo.png');
$tg = setting('support_telegram', ''); $wa = setting('support_whatsapp', '');
$fb = setting('support_facebook', ''); $yt = setting('support_youtube', '');
$footerBg = setting('footer_bg', '#0b1526');
$footerCopyright = setting('footer_copyright', '') ?: '© '.date('Y').' '.$siteName.'. All rights reserved.';
$devName = setting('footer_developer_name', 'Infinity Codex');
$devLink = setting('footer_developer_link', 'https://t.me/INFINITY_codex');

if(!function_exists('parseFooterLinks')){ function parseFooterLinks($raw, $fallback = []) {
  $raw = trim((string)$raw);
  if($raw === '') return $fallback;
  $out = [];
  foreach(explode("\n", $raw) as $line){
    $line = trim($line);
    if($line==='') continue;
    $parts = explode('|', $line, 2);
    $label = trim($parts[0] ?? '');
    $url = trim($parts[1] ?? '#');
    if($label==='') continue;
    $out[] = ['label'=>$label, 'url'=>$url];
  }
  return $out ?: $fallback;
}}
$col1Title = setting('footer_col1_title', 'Quick Links');
$col1Raw = setting('footer_col1_links', '');
$col1Fallback = [
  ['label'=>'Home','url'=>route('home')],
  ['label'=>'Pricing','url'=>route('home').'#pricing'],
  ['label'=>'API Documentation','url'=>route('docs')],
  ['label'=>'Check Key','url'=>route('check.key')],
  ['label'=>'System Status','url'=>route('status')],
];
$col1Links = parseFooterLinks($col1Raw, $col1Fallback);

$col2Title = setting('footer_col2_title', 'APIs');
$col2Raw = setting('footer_col2_links', '');
try { $footServices = \App\Models\ApiService::active()->onHome()->orderBy('sort_order')->take(5)->get(); } catch (\Throwable $e) { $footServices = collect(); }
$col2Custom = parseFooterLinks($col2Raw, []);
$useCustomCol2 = !empty($col2Custom);

$col3Title = setting('footer_col3_title', 'Support');
$col3Raw = setting('footer_col3_links', '');
$col3Fallback = [
  ['label'=>'Integration Help','url'=>route('docs')],
  ['label'=>'FAQ','url'=>route('home').'#faq'],
  ['label'=>'Client Login','url'=>route('login')],
];
if($tg) $col3Fallback[] = ['label'=>'Telegram Support','url'=>$tg];
if($wa) $col3Fallback[] = ['label'=>'WhatsApp Support','url'=>$wa];
$col3Links = parseFooterLinks($col3Raw, $col3Fallback);
@endphp
<footer class="site-footer" id="footer" style="background:{{ $footerBg }};margin-top:40px;border-top:1px solid rgba(255,255,255,.06)">
  <div class="wrap">
    <div class="foot-grid" style="padding:38px 0 28px;gap:28px">
      <!-- Brand -->
      <div>
        <div class="foot-brand" style="display:flex;align-items:center;max-width:260px">
          <img src="{{ $footLogoPath }}" alt="{{ $footerBrand }} footer logo" style="display:block;max-height:48px;max-width:100%;width:auto;border:0;background:transparent;padding:0;object-fit:contain">
        </div>
        <p style="color:#94a3b8;font-size:13.5px;line-height:1.7;margin-top:10px">{{ $footerAbout }}</p>
        <div class="socials" style="margin-top:14px;display:flex;gap:8px">
          @if($tg)<a href="{{ $tg }}" target="_blank" rel="noopener" title="Telegram" style="width:38px;height:38px;border-radius:10px;background:rgba(255,255,255,.08);display:flex;align-items:center;justify-content:center;color:#fff;transition:.2s"><i class="fa-brands fa-telegram"></i></a>@endif
          @if($wa)<a href="{{ $wa }}" target="_blank" rel="noopener" title="WhatsApp" style="width:38px;height:38px;border-radius:10px;background:rgba(255,255,255,.08);display:flex;align-items:center;justify-content:center;color:#fff"><i class="fa-brands fa-whatsapp"></i></a>@endif
          @if($fb)<a href="{{ $fb }}" target="_blank" rel="noopener" title="Facebook" style="width:38px;height:38px;border-radius:10px;background:rgba(255,255,255,.08);display:flex;align-items:center;justify-content:center;color:#fff"><i class="fa-brands fa-facebook"></i></a>@endif
          @if($yt)<a href="{{ $yt }}" target="_blank" rel="noopener" title="YouTube" style="width:38px;height:38px;border-radius:10px;background:rgba(255,255,255,.08);display:flex;align-items:center;justify-content:center;color:#fff"><i class="fa-brands fa-youtube"></i></a>@endif
        </div>
        <div style="margin-top:14px;display:flex;gap:8px;flex-wrap:wrap">
          <span class="mini-tag" style="background:rgba(255,255,255,.08);color:#cbd5e1;border-color:rgba(255,255,255,.12);font-size:11px"><i class="fa-solid fa-shield-halved" style="color:#22c55e"></i> SSL Secure</span>
          <span class="mini-tag" style="background:rgba(255,255,255,.08);color:#cbd5e1;border-color:rgba(255,255,255,.12);font-size:11px"><i class="fa-solid fa-bolt" style="color:#38bdf8"></i> 99.9% Uptime</span>
        </div>
      </div>
      <!-- Col1 -->
      <div>
        <h5 style="color:#fff;font-size:13px;letter-spacing:.6px;text-transform:uppercase;margin-bottom:12px;display:flex;gap:8px;align-items:center"><i class="fa-solid fa-link" style="color:var(--primary-light)"></i> {{ $col1Title }}</h5>
        <ul style="list-style:none;padding:0;margin:0;display:grid;gap:8px">
          @foreach($col1Links as $l)
            <li><a href="{{ $l['url'] }}" style="color:#94a3b8;font-size:13.5px;display:flex;gap:8px;align-items:center;transition:.2s"><i class="fa-solid fa-chevron-right" style="font-size:9px;opacity:.5"></i> {{ $l['label'] }}</a></li>
          @endforeach
        </ul>
      </div>
      <!-- Col2 -->
      <div>
        <h5 style="color:#fff;font-size:13px;letter-spacing:.6px;text-transform:uppercase;margin-bottom:12px;display:flex;gap:8px;align-items:center"><i class="fa-solid fa-layer-group" style="color:var(--primary-light)"></i> {{ $col2Title }}</h5>
        <ul style="list-style:none;padding:0;margin:0;display:grid;gap:8px">
          @if($useCustomCol2)
            @foreach($col2Custom as $l)
              <li><a href="{{ $l['url'] }}" style="color:#94a3b8;font-size:13.5px;display:flex;gap:8px;align-items:center"><i class="fa-solid fa-chevron-right" style="font-size:9px;opacity:.5"></i> {{ $l['label'] }}</a></li>
            @endforeach
          @else
            @forelse($footServices as $s)
              <li><a href="{{ route('service.show', $s->slug) }}" style="color:#94a3b8;font-size:13.5px;display:flex;gap:8px;align-items:center"><i class="fa-solid fa-chevron-right" style="font-size:9px;opacity:.5"></i> {{ $s->name }}</a></li>
            @empty
              <li><a href="{{ route('docs') }}" style="color:#94a3b8;font-size:13.5px">All APIs</a></li>
            @endforelse
          @endif
        </ul>
      </div>
      <!-- Col3 -->
      <div>
        <h5 style="color:#fff;font-size:13px;letter-spacing:.6px;text-transform:uppercase;margin-bottom:12px;display:flex;gap:8px;align-items:center"><i class="fa-solid fa-headset" style="color:var(--primary-light)"></i> {{ $col3Title }}</h5>
        <ul style="list-style:none;padding:0;margin:0;display:grid;gap:8px">
          @foreach($col3Links as $l)
            <li><a href="{{ $l['url'] }}" @if(str_starts_with($l['url'],'http')) target="_blank" rel="noopener" @endif style="color:#94a3b8;font-size:13.5px;display:flex;gap:8px;align-items:center"><i class="fa-solid fa-chevron-right" style="font-size:9px;opacity:.5"></i> {{ $l['label'] }}</a></li>
          @endforeach
        </ul>
      </div>
    </div>
    <div class="foot-bottom compact-footer-bottom" style="border-top:1px solid rgba(255,255,255,.08);padding:12px 0 8px;display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:center;color:#64748b;font-size:12.5px">
      <span style="display:flex;gap:8px;align-items:center;flex-wrap:wrap"><i class="fa-solid fa-copyright"></i> {{ $footerCopyright }}</span>
      <a class="developer-credit" href="{{ $devLink }}" target="_blank" rel="noopener noreferrer" style="color:var(--primary-light);font-weight:800;display:flex;gap:6px;align-items:center"><i class="fa-solid fa-code"></i> Developed by {{ $devName }}</a>
    </div>
  </div>
</footer>
<script src="/assets/js/app.js?v=6.3"></script>
@stack('scripts')
</body>
</html>
