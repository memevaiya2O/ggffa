@php
$siteName = setting('site_name', config('app.name', 'INFINITY API HUB'));
$headerBrand = setting('header_brand_text', '') ?: $siteName;
$headerCtaText = setting('header_cta_text', 'Get Started');
$headerCtaLink = setting('header_cta_link', '/register');
$tagline = setting('site_tagline', 'Premium API Platform');
$logo = setting('logo', '');
$logoPath = $logo ? asset('uploads/'.$logo) : '/assets/brand-logo.svg';
$headerLogoPath = $logoPath;
$siteIcon = setting('site_icon', '');
$siteIconPath = $siteIcon ? asset('uploads/'.$siteIcon) : '/assets/brand-mark.svg';
$primary = setting('primary_color', '#2563eb');
$announce = setting('announcement', '');
$customCss = setting('custom_css', '');
$seoTitle = setting('seo_title', $siteName);
$seoDescription = setting('seo_description', $tagline);
$seoKeywords = setting('seo_keywords', 'API, developer API, gaming API, Free Fire API');
$seoRobots = setting('seo_robots', 'index,follow');
$canonical = setting('seo_canonical_url', url()->current());
$parts = preg_split('/\s+/', trim($siteName), 2);
$brandA = $parts[0] ?? 'INFINITY';
$brandB = $parts[1] ?? '';
$title = trim($__env->yieldContent('title')) ?: ($title ?? $siteName);
$active = trim($__env->yieldContent('active')) ?: ($active ?? '');
@endphp
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{{ $title }} — {{ $siteName }}</title>
<meta name="description" content="{{ $seoDescription }}">
<meta name="keywords" content="{{ $seoKeywords }}">
<meta name="robots" content="{{ $seoRobots }}">
<link rel="canonical" href="{{ $canonical }}">
<meta property="og:title" content="{{ $seoTitle }}">
<meta property="og:description" content="{{ $seoDescription }}">
<meta property="og:type" content="website">
<meta property="og:url" content="{{ $canonical }}">
<meta property="og:image" content="{{ $logoPath }}">
<link rel="icon" href="{{ $siteIconPath }}">
<link rel="shortcut icon" href="{{ $siteIconPath }}">
<link rel="apple-touch-icon" href="{{ $siteIconPath }}">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<meta name="csrf-token" content="{{ csrf_token() }}">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://cdnjs.cloudflare.com" crossorigin>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer">
<link rel="stylesheet" href="/assets/css/style.css?v=6.6">
<style>
:root { --primary: {{ $primary }}; --primary-dark: {{ setting('secondary_color', '#1d4ed8') }}; --accent: {{ setting('accent_color', '#38bdf8') }}; --radius: {{ (int) setting('ui_radius', 16) }}px; }
{!! $customCss !!}
</style>
@if(setting('analytics_id', ''))<script async src="https://www.googletagmanager.com/gtag/js?id={{ urlencode(setting('analytics_id')) }}"></script><script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments)}gtag('js',new Date());gtag('config','{{ addslashes(setting('analytics_id')) }}');</script>@endif
</head>
<body>
<div class="ambient-glow"></div>
@if($announce)
<div class="announce-bar"><i class="fa-solid fa-bullhorn"></i>{{ $announce }}</div>
@endif
<header class="app-header">
  <a href="{{ route('home') }}" class="brand brand-wordmark-logo" aria-label="{{ $headerBrand }} home">
    <img src="{{ $headerLogoPath }}" alt="{{ $headerBrand }} logo" class="logo-img">
  </a>
  <nav class="nav-links" id="navLinks">
    <a href="{{ route('home') }}" class="{{ $active === 'home' ? 'active' : '' }}"><i class="fa-solid fa-house"></i> Home</a>
    <a href="{{ route('home') }}#services" class="{{ $active === 'services' ? 'active' : '' }}"><i class="fa-solid fa-layer-group"></i> APIs</a>
    <a href="{{ route('home') }}#pricing" class="{{ $active === 'pricing' ? 'active' : '' }}"><i class="fa-solid fa-tags"></i> Pricing</a>
    <a href="{{ route('docs') }}" class="{{ $active === 'docs' ? 'active' : '' }}"><i class="fa-solid fa-book"></i> Docs</a>
    <a href="{{ route('status') }}" class="{{ $active === 'status' ? 'active' : '' }}"><i class="fa-solid fa-signal"></i> Status</a>
  </nav>
  <div class="header-actions">
    @auth
      <a class="btn btn-primary btn-sm header-cta" href="{{ auth()->user()->role === 'admin' ? route('admin.dashboard') : route('user.dashboard') }}"><i class="fa-solid fa-gauge-high"></i> <span class="txt">Dashboard</span></a>
      <form action="{{ route('logout') }}" method="POST" style="display:inline">@csrf<button class="btn btn-outline btn-sm" title="Logout"><i class="fa-solid fa-right-from-bracket"></i></button></form>
    @else
      <a class="btn btn-outline btn-sm" href="{{ route('login') }}"><i class="fa-solid fa-right-to-bracket"></i> <span class="txt">Login</span></a>
      <a class="btn btn-primary btn-sm header-cta" href="{{ $headerCtaLink }}"><i class="fa-solid fa-rocket"></i> <span class="txt">{{ $headerCtaText }}</span></a>
    @endauth
    <button class="hamburger" id="burger" type="button" aria-label="Open menu" aria-expanded="false" aria-controls="navLinks"><i class="fa-solid fa-bars"></i></button>
  </div>
</header>
@include('partials.flash')
