@php
use Illuminate\Support\Str;
$isAdmin = request()->is('admin/*');
$route = request()->route()?->getName() ?? '';
$me = auth()->user();
if ($isAdmin) {
    try { $pendingOrders = \App\Models\Order::where('status', 'pending')->count(); } catch (\Throwable $e) { $pendingOrders = 0; }
    try { $openTickets = \App\Models\Ticket::where('status', 'open')->count(); } catch (\Throwable $e) { $openTickets = 0; }
    $menu = [
        ['match' => 'admin.dashboard', 'icon' => 'fa-gauge-high', 'label' => 'Dashboard', 'url' => route('admin.dashboard'), 'group' => 'Overview'],
        ['match' => 'admin.users', 'icon' => 'fa-users', 'label' => 'Users', 'url' => route('admin.users'), 'group' => 'Manage'],
        ['match' => 'admin.services', 'icon' => 'fa-layer-group', 'label' => 'APIs / Services', 'url' => route('admin.services'), 'group' => 'Manage'],
        ['match' => 'admin.keys', 'icon' => 'fa-key', 'label' => 'All Keys', 'url' => route('admin.keys'), 'group' => 'Manage'],
        ['match' => 'admin.packages', 'icon' => 'fa-box-open', 'label' => 'Packages', 'url' => route('admin.packages'), 'group' => 'Billing'],
        ['match' => 'admin.orders', 'icon' => 'fa-receipt', 'label' => 'Orders', 'url' => route('admin.orders'), 'group' => 'Billing', 'badge' => $pendingOrders ?: ''],
        ['match' => 'admin.tickets', 'icon' => 'fa-headset', 'label' => 'Tickets', 'url' => route('admin.tickets'), 'group' => 'Billing', 'badge' => $openTickets ?: ''],
        ['match' => 'admin.logs', 'icon' => 'fa-list-ul', 'label' => 'API Logs', 'url' => route('admin.logs'), 'group' => 'Monitor'],
        ['match' => 'admin.reports', 'icon' => 'fa-chart-line', 'label' => 'Reports', 'url' => route('admin.reports'), 'group' => 'Monitor'],
        ['match' => 'admin.notifications', 'icon' => 'fa-bell', 'label' => 'Notifications', 'url' => route('admin.notifications'), 'group' => 'System'],
        ['match' => 'admin.admins', 'icon' => 'fa-user-shield', 'label' => 'Admins', 'url' => route('admin.admins'), 'group' => 'System'],
        ['match' => 'admin.settings', 'icon' => 'fa-gear', 'label' => 'Settings', 'url' => route('admin.settings'), 'group' => 'System'],
    ];
} else {
    $menu = [
        ['match' => 'user.dashboard', 'icon' => 'fa-gauge-high', 'label' => 'Dashboard', 'url' => route('user.dashboard'), 'group' => 'Main'],
        ['match' => 'user.keys', 'icon' => 'fa-key', 'label' => 'My API Keys', 'url' => route('user.keys'), 'group' => 'Main'],
        ['match' => 'user.test', 'icon' => 'fa-flask-vial', 'label' => 'Test API', 'url' => route('user.test'), 'group' => 'Main'],
        ['match' => 'user.tickets', 'icon' => 'fa-headset', 'label' => 'Support Tickets', 'url' => route('user.tickets'), 'group' => 'Main'],
        ['match' => 'user.buy', 'icon' => 'fa-cart-shopping', 'label' => 'Buy Credits', 'url' => route('user.buy'), 'group' => 'Billing'],
        ['match' => 'user.wallet', 'icon' => 'fa-wallet', 'label' => 'My Wallet', 'url' => route('user.wallet'), 'group' => 'Billing'],
        ['match' => 'user.orders', 'icon' => 'fa-receipt', 'label' => 'My Orders', 'url' => route('user.orders'), 'group' => 'Billing'],
        ['match' => 'user.notifications', 'icon' => 'fa-bell', 'label' => 'Notifications', 'url' => route('user.notifications'), 'group' => 'Help'],
        ['match' => 'user.profile', 'icon' => 'fa-user-gear', 'label' => 'My Profile', 'url' => route('user.profile'), 'group' => 'Help'],
    ];
}
$lastGroup = null;
$siteName = setting('site_name','INFINITY API HUB');
$logo = setting('logo','');
$miniLogo = $logo ? asset('uploads/'.$logo) : null;
@endphp
<div class="dash {{ $isAdmin ? 'admin-panel' : 'user-panel' }}" style="background:transparent">
  <div class="side-overlay" id="sideOverlay" style="backdrop-filter:blur(8px)"></div>
  <aside class="sidebar" id="sidebar" aria-label="{{ $isAdmin ? 'Admin' : 'Client' }} navigation" style="background:rgba(255,255,255,.96);backdrop-filter:blur(16px);border-right:1px solid #e8eef7;box-shadow:4px 0 24px rgba(15,23,42,.04)">
    <div class="drawer-mobile-head">
      <span>{{ $isAdmin ? 'Admin menu' : 'Client menu' }}</span>
      <button type="button" class="drawer-close" data-menu-close aria-label="Close menu"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <!-- Brand mini is shown only in the admin drawer. -->
    @if($isAdmin)<div class="sidebar-brand" style="display:flex;align-items:center;gap:10px;padding:6px 6px 14px;border-bottom:1px solid var(--border);margin-bottom:12px">
      @if($miniLogo)
        <img src="{{ $miniLogo }}" style="height:36px;width:auto;border-radius:10px;background:#fff;padding:4px;border:1px solid var(--border);object-fit:contain">
      @else
        <span class="brand-icon" style="width:36px;height:36px;font-size:16px;border-radius:10px">∞</span>
      @endif
      <div style="min-width:0"><div style="font-weight:900;font-size:13px;letter-spacing:-.3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">{{ $siteName }}</div><div style="font-size:11px;color:var(--gray);font-weight:700;letter-spacing:.5px">{{ $isAdmin ? 'ADMIN PANEL' : 'CLIENT PANEL' }}</div></div>
      <span class="badge badge-success" style="margin-left:auto;font-size:10px;padding:3px 8px"><i class="fa-solid fa-circle" style="font-size:6px"></i> Live</span>
    </div>@endif

    <div class="side-user" style="background:linear-gradient(135deg,#f8fbff,#eef4ff);border:1px solid #dbeafe;border-radius:14px;padding:12px">
      <div class="avatar" style="width:40px;height:40px;border-radius:12px;font-size:16px;box-shadow:0 4px 10px rgba(37,99,235,.2)">{{ strtoupper(substr($me->name ?? 'U', 0, 1)) }}</div>
      <div style="min-width:0;flex:1">
        <b style="font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:block">{{ $me->name }}</b>
        <span style="font-size:11px;color:var(--gray);display:flex;gap:6px;align-items:center"><i class="fa-solid fa-circle" style="font-size:6px;color:var(--success)"></i> {{ $isAdmin ? 'Administrator' : 'Client' }} • {{ $me->email }}</span>
      </div>
    </div>

    <div style="margin-top:14px">
    @foreach($menu as $m)
      @if(!$isAdmin && $m['group'] === 'Help' && $lastGroup !== 'Help')
        <div class="sidebar-help-card" style="margin-top:16px;background:linear-gradient(135deg,var(--primary),var(--primary-dark));color:#fff;border-radius:14px;padding:14px;text-align:center">
          <div style="font-weight:900;font-size:13px"><i class="fa-solid fa-wand-magic-sparkles"></i> Need help?</div><div style="font-size:12px;opacity:.9;margin:4px 0 10px">Admin guide &amp; support</div>
          <a href="{{ route('user.tickets') }}" class="btn btn-sm" style="background:#fff;color:var(--primary);border-radius:10px;font-weight:800;width:100%"><i class="fa-solid fa-headset"></i> Open Ticket</a>
        </div>
      @endif
      @if(!empty($m['group']) && $m['group'] !== $lastGroup)
        @php $lastGroup = $m['group']; @endphp
        <div class="side-label" style="font-size:10px;letter-spacing:.8px;color:#94a3b8;margin-top:14px;margin-bottom:6px;font-weight:800;display:flex;align-items:center;gap:8px"><span style="height:1px;flex:1;background:var(--border)"></span> {{ $lastGroup }} <span style="height:1px;flex:1;background:var(--border)"></span></div>
      @endif
      <a class="side-link{{ Str::startsWith($route, $m['match']) ? ' active' : '' }}" href="{{ $m['url'] }}" style="border-radius:12px;margin-bottom:4px;font-size:13.5px;font-weight:700;min-height:42px">
        <i class="fa-solid {{ $m['icon'] }}" style="width:20px;text-align:center"></i>{{ $m['label'] }}
        @if(!empty($m['badge']))<span class="count" style="background:var(--danger);color:#fff;font-size:11px;min-width:20px;height:20px;border-radius:50px;padding:0 6px">{{ $m['badge'] }}</span>@endif
      </a>
    @endforeach
    </div>

    @if($isAdmin)<div style="margin-top:16px;background:linear-gradient(135deg,var(--primary),var(--primary-dark));color:#fff;border-radius:14px;padding:14px;text-align:center">
      <div style="font-weight:900;font-size:13px"><i class="fa-solid fa-wand-magic-sparkles"></i> Need help?</div><div style="font-size:12px;opacity:.9;margin:4px 0 10px">Admin guide & support</div>
      <a href="{{ $isAdmin ? route('admin.tickets') : route('user.tickets') }}" class="btn btn-sm" style="background:#fff;color:var(--primary);border-radius:10px;font-weight:800;width:100%"><i class="fa-solid fa-headset"></i> Open Ticket</a>
    </div>@endif

    <div class="side-label" style="margin-top:16px">Account</div>
    <a class="side-link" href="{{ route('docs') }}" style="border-radius:12px"><i class="fa-solid fa-book"></i> API Docs</a>
    <a class="side-link" href="{{ route('home') }}" style="border-radius:12px"><i class="fa-solid fa-globe"></i> View Website</a>
    <form action="{{ route('logout') }}" method="POST" style="margin-top:4px">@csrf<button class="side-link sidebar-logout" style="width:100%;background:none;border:none;cursor:pointer;text-align:left;font-size:13.5px;border-radius:12px;color:var(--gray)"><i class="fa-solid fa-right-from-bracket"></i> Logout</button></form>
    <div style="text-align:center;font-size:11px;color:var(--gray-light);margin-top:12px">© {{ date('Y') }} {{ $siteName }}</div>
  </aside>
  <main class="dash-main" style="background:transparent">
    @yield('content')
  </main>
</div>
@php
  $mobileMenu = $isAdmin ? [
    ['match' => 'admin.dashboard', 'icon' => 'fa-house', 'label' => 'Home', 'url' => route('admin.dashboard')],
    ['match' => 'admin.services', 'icon' => 'fa-layer-group', 'label' => 'APIs', 'url' => route('admin.services')],
    ['match' => 'admin.users', 'icon' => 'fa-users', 'label' => 'Users', 'url' => route('admin.users')],
    ['match' => 'admin.orders', 'icon' => 'fa-receipt', 'label' => 'Orders', 'url' => route('admin.orders')],
    ['match' => 'admin.settings', 'icon' => 'fa-gear', 'label' => 'Settings', 'url' => route('admin.settings')],
  ] : [
    ['match' => 'user.dashboard', 'icon' => 'fa-house', 'label' => 'Home', 'url' => route('user.dashboard')],
    ['match' => 'user.keys', 'icon' => 'fa-key', 'label' => 'Keys', 'url' => route('user.keys')],
    ['match' => 'user.test', 'icon' => 'fa-flask-vial', 'label' => 'Test', 'url' => route('user.test')],
    ['match' => 'user.buy', 'icon' => 'fa-cart-shopping', 'label' => 'Buy', 'url' => route('user.buy')],
    ['match' => 'user.wallet', 'icon' => 'fa-wallet', 'label' => 'Wallet', 'url' => route('user.wallet')],
    ['match' => 'user.profile', 'icon' => 'fa-user', 'label' => 'Profile', 'url' => route('user.profile')],
  ];
@endphp
<nav class="mobile-app-nav" aria-label="Mobile navigation" style="backdrop-filter:blur(16px);background:rgba(255,255,255,.94);border:1px solid #e2e8f0;box-shadow:0 12px 32px rgba(15,23,42,.12)">
  @foreach($mobileMenu as $m)
    <a class="{{ Str::startsWith($route, $m['match']) ? 'active' : '' }}" href="{{ $m['url'] }}" style="border-radius:12px"><i class="fa-solid {{ $m['icon'] }}"></i><span>{{ $m['label'] }}</span></a>
  @endforeach
</nav>
<script src="/assets/js/app.js?v=6.4"></script>
@stack('scripts')
</body>
</html>
