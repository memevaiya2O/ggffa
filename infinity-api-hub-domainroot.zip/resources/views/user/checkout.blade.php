@extends('layouts.dash')
@section('title', 'Checkout')
@section('content')
@php
  $isFree = $package->price <= 0;
  $hasAuto = $nagorikpayEnabled;
  $perCredit = $package->requests > 0 ? $package->price / $package->requests : 0;
@endphp
<div class="page-head" style="margin-bottom:18px">
  <div>
    <nav aria-label="Breadcrumb" style="font-size:13px;color:var(--gray);margin-bottom:8px;display:flex;gap:8px;align-items:center;flex-wrap:wrap">
      <a href="{{ route('user.buy') }}" style="color:var(--primary);font-weight:700"><i class="fa-solid fa-arrow-left"></i> Packages</a>
      <span style="opacity:.4">/</span><span>{{ $package->service->name }}</span><span style="opacity:.4">/</span><span style="color:var(--text);font-weight:800">{{ $package->name }}</span>
    </nav>
    <h1 style="display:flex;align-items:center;gap:12px;flex-wrap:wrap">{{ $isFree ? 'Claim Free Package' : 'Secure Checkout' }}
      @if($isFree)<span class="badge badge-success" style="font-size:12px"><i class="fa-solid fa-gift"></i> FREE</span>
      @elseif($hasAuto)<span class="badge badge-primary" style="font-size:12px"><i class="fa-solid fa-shield-halved"></i> Auto Payment</span>
      @endif
    </h1>
    <p style="margin-top:6px;color:var(--gray);font-size:14.5px">You’re one step away — credits go to your <b>{{ $package->service->name }}</b> key instantly after payment.</p>
  </div>
</div>

<!-- Stepper -->
<div class="card" style="padding:14px 18px;margin-bottom:18px;background:linear-gradient(135deg,#f8fbff,#f3f7ff);border-color:#dbeafe">
  <div style="display:flex;align-items:center;gap:10px;font-size:13px;font-weight:700;color:var(--gray);overflow-x:auto;white-space:nowrap;-webkit-overflow-scrolling:touch">
    <span style="display:inline-flex;align-items:center;gap:8px;color:var(--success)"><span style="width:26px;height:26px;border-radius:50%;background:var(--success);color:#fff;display:flex;align-items:center;justify-content:center;font-size:12px"><i class="fa-solid fa-check"></i></span> Choose</span>
    <span style="opacity:.3">→</span>
    <span style="display:inline-flex;align-items:center;gap:8px;color:var(--primary)"><span style="width:26px;height:26px;border-radius:50%;background:var(--primary);color:#fff;display:flex;align-items:center;justify-content:center;font-size:12px">2</span> Payment</span>
    <span style="opacity:.3">→</span>
    <span style="display:inline-flex;align-items:center;gap:8px;opacity:.6"><span style="width:26px;height:26px;border-radius:50%;background:#e2e8f0;color:#64748b;display:flex;align-items:center;justify-content:center;font-size:12px">3</span> Credits Added</span>
    <span style="margin-left:auto;display:none" class="hide-mobile"><span class="mini-tag blue"><i class="fa-solid fa-lock"></i> SSL Secure</span> <span class="mini-tag"><i class="fa-solid fa-bolt"></i> Instant after verify</span></span>
  </div>
</div>

<div class="grid-2" style="align-items:start">
  <!-- Left: Payment -->
  <div class="card" style="padding:22px">
    <div class="flex between center wrap-x" style="margin-bottom:14px">
      <div class="card-title" style="margin:0"><i class="fa-solid fa-wallet"></i> Payment</div>
      @if(!$isFree && $hasAuto)
        <span class="badge badge-success"><i class="fa-solid fa-bolt"></i> Auto verification • 30s</span>
      @endif
    </div>

    @if($key)
      <div style="background:var(--bg);border:1px solid var(--border);border-radius:14px;padding:14px;display:flex;gap:12px;align-items:center;margin-bottom:14px">
        <div class="sic bg-blue" style="width:42px;height:42px;border-radius:12px;display:flex;align-items:center;justify-content:center"><i class="fa-solid fa-key"></i></div>
        <div style="min-width:0;flex:1">
          <div style="font-size:13px;font-weight:800;color:var(--text)">Credits go to this key</div>
          <div class="mono text-sm" style="color:var(--gray);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">{{ $key->api_key }}</div>
          <div class="text-sm" style="color:var(--gray)">{{ $package->service->name }} • <b style="color:var(--success)">{{ number_format($key->remaining()) }} left</b> • +{{ number_format($package->requests) }} after payment</div>
        </div>
        <button type="button" class="copy-btn" onclick="copyText('{{ $key->api_key }}', this)" title="Copy key"><i class="fa-solid fa-copy"></i></button>
      </div>
    @else
      <div class="alert alert-info" style="display:flex;gap:12px"><i class="fa-solid fa-circle-info" style="margin-top:2px"></i><div><b>New key will be created</b><br><span class="text-sm">We’ll auto-create a dedicated <b>{{ $package->service->name }}</b> key with {{ number_format($package->requests) }} credits & {{ $package->validity_days }} days validity.</span></div></div>
    @endif

    <form method="POST" action="{{ route('user.buy.order', $package) }}" id="checkoutForm" novalidate>
      @csrf

      @if($isFree)
        <div class="alert alert-success" style="display:flex;gap:12px"><i class="fa-solid fa-gift"></i><div><b>100% Free — instant activation</b><br><span class="text-sm">Each free package can be claimed once. No payment needed.</span></div></div>
        <button class="btn btn-primary btn-block btn-lg" type="submit" style="margin-top:12px"><i class="fa-solid fa-gift"></i> Activate Free — {{ number_format($package->requests) }} Credits</button>
        <p class="text-sm text-gray" style="text-align:center;margin-top:10px"><i class="fa-solid fa-shield-halved"></i> No card required • Instant</p>

      @elseif(!$isFree)
        <div class="form-group"><label style="font-weight:800">Choose payment method</label>
          <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:12px">
            <label style="cursor:pointer;border:2px solid var(--primary);background:var(--primary-soft);border-radius:16px;padding:15px;display:flex;gap:12px;align-items:flex-start">
              <input type="radio" name="method" value="wallet" checked required style="accent-color:var(--primary);margin-top:4px"><span><b><i class="fa-solid fa-wallet"></i> Wallet balance</b><br><small class="text-gray">Available: <b>{{ taka($wallet->balance) }}</b>. Buy instantly from your balance.</small></span>
            </label>
            @if($hasAuto)<label style="cursor:pointer;border:1px solid var(--border);border-radius:16px;padding:15px;display:flex;gap:12px;align-items:flex-start">
              <input type="radio" name="method" value="nagorikpay" required style="accent-color:var(--primary);margin-top:4px"><span><b><i class="fa-solid fa-credit-card"></i> Auto Payment</b><br><small class="text-gray">Open the secure gateway, complete payment, then get credits after verification.</small></span>
            </label>@endif
          </div>
        </div>
        <div class="alert alert-info mt" style="display:flex;gap:10px;font-size:13px"><i class="fa-solid fa-circle-info"></i><div>Wallet purchases are instant.@if($hasAuto) Auto Payment redirects to the secure gateway and credits are added only after successful verification.@else Add money to your wallet first, then use it here to buy credits.@endif</div></div>
        <button class="btn btn-primary btn-block btn-lg" type="submit" id="payBtn" style="margin-top:14px;min-height:54px;font-size:16px"><i class="fa-solid fa-bolt"></i> Continue — {{ taka($package->price) }}</button>
        <p class="text-sm text-gray" style="text-align:center;margin-top:8px"><i class="fa-solid fa-shield-halved"></i> Duplicate payments are blocked safely.</p>
      @endif
    </form>

    <!-- Help -->
    <details style="margin-top:16px;background:var(--bg);border:1px solid var(--border);border-radius:12px;padding:12px 14px">
      <summary style="font-weight:800;cursor:pointer;list-style:none;display:flex;gap:8px;align-items:center"><i class="fa-solid fa-circle-question text-primary"></i> Need help with this checkout? <span style="margin-left:auto;color:var(--gray);font-size:12px"><i class="fa-solid fa-chevron-down"></i></span></summary>
      <ul style="margin:10px 0 0 18px;color:var(--gray);font-size:13.5px;line-height:1.7">
        @if($hasAuto)<li><b>Stuck on Pending?</b> Go to <a href="{{ route('user.orders') }}" style="color:var(--primary);font-weight:700">My Orders → Recheck</a>, we auto-recheck every 5 min.</li>@endif
        <li>Credits never deduct twice for same transaction (idempotent).</li>
        <li>Need invoice? Auto-emailed as PDF + downloadable from Orders.</li>
        <li>Contact: <a href="{{ route('user.tickets') }}" style="color:var(--primary);font-weight:700">Support ticket</a> — average reply &lt; 15 min.</li>
      </ul>
    </details>
  </div>

  <!-- Right: Sticky summary -->
  <div style="position:sticky;top:88px">
    <div class="card" style="padding:20px;border-color:#dbeafe;background:linear-gradient(180deg,#fff,#f8fbff)">
      <div class="card-title" style="margin-bottom:12px"><i class="fa-solid fa-receipt"></i> Order Summary</div>
      <div style="display:flex;gap:12px;align-items:center;padding:12px;background:var(--bg);border:1px solid var(--border);border-radius:12px;margin-bottom:12px">
        <div class="svc-ic" style="width:48px;height:48px"><i class="fa-solid {{ $package->service->icon ?? 'fa-plug' }}"></i></div>
        <div><div style="font-weight:900">{{ $package->service->name }}</div><div class="text-sm text-gray">{{ $package->name }} • {{ $package->service->slug ? '/api/'.$package->service->slug : '' }}</div></div>
      </div>
      <div style="display:grid;gap:10px;font-size:14px">
        <div class="flex between"><span class="text-gray"><i class="fa-solid fa-bolt text-primary"></i> Credits</span><b>{{ number_format($package->requests) }} <small class="text-gray" style="font-weight:600">({{ $package->credits_per_hit }} / hit)</small></b></div>
        <div class="flex between"><span class="text-gray"><i class="fa-solid fa-calendar text-primary"></i> Validity</span><b>{{ $package->validity_days }} days</b></div>
        @if($package->price>0)
        <div class="flex between"><span class="text-gray"><i class="fa-solid fa-coins text-primary"></i> Per credit</span><b>{{ $perCredit>0 ? taka($perCredit) : '—' }}</b></div>
        @endif
        <hr style="border:none;border-top:1px dashed var(--border);margin:6px 0">
        <div class="flex between" style="font-size:18px"><span style="font-weight:800">Total</span><b class="text-primary" style="font-size:22px">{{ $isFree ? 'FREE' : taka($package->price) }}</b></div>
        @if(!$isFree)<div style="font-size:12px;color:var(--gray);text-align:right">VAT included where applicable</div>@endif
      </div>
      @if($key)
      <div class="alert alert-success mt" style="display:flex;gap:10px"><i class="fa-solid fa-check-circle" style="color:var(--success)"></i><div style="font-size:13px"><b>Will be added to existing key</b><br><span class="text-gray">New total: <b style="color:var(--success)">{{ number_format($key->remaining() + $package->requests) }} credits</b> • Exp extends by {{ $package->validity_days }} days</span></div></div>
      @else
      <div class="alert alert-info mt" style="font-size:13px"><i class="fa-solid fa-wand-magic-sparkles"></i> New key will be created automatically — no extra steps.</div>
      @endif
      <div class="flex gap mt" style="flex-wrap:wrap">
        <span class="mini-tag blue"><i class="fa-solid fa-shield-halved"></i> Secure</span>
        <span class="mini-tag"><i class="fa-solid fa-rotate"></i> Recheckable</span>
        <span class="mini-tag"><i class="fa-solid fa-file-invoice"></i> PDF invoice</span>
      </div>
    </div>

    @if(!$isFree && $hasAuto)
      <div class="card mt" style="padding:16px;background:var(--success-soft);border-color:#bbf7d0">
        <div style="font-weight:900;display:flex;gap:8px;align-items:center"><i class="fa-solid fa-bolt" style="color:var(--success)"></i> Why Auto Payment?</div>
        <ul style="margin:8px 0 0 18px;font-size:13px;color:#15803d;line-height:1.8">
          <li>Seconds, not hours — no manual approval wait</li>
          <li>Works for bKash/Nagad/Rocket/Upay/Cards</li>
          <li>Auto PDF invoice emailed</li>
        </ul>
      </div>
    @elseif(!$isFree)
      <div class="card mt">
        <div class="card-title" style="font-size:15px"><i class="fa-solid fa-wallet"></i> Use your wallet</div>
        <p class="text-sm text-gray" style="line-height:1.7">Add money to your wallet from the <a href="{{ route('user.wallet') }}" style="color:var(--primary);font-weight:800">My Wallet</a> page, then return here. Wallet purchases are settled instantly and your credits go straight to the selected API key.</p>
      </div>
    @else
      <div class="card mt" style="padding:16px;background:var(--success-soft);border-color:#bbf7d0;text-align:center">
        <div style="font-size:20px">🎉</div><div style="font-weight:900">100% Free — no risk</div><div class="text-sm text-gray">Claim once, use instantly, upgrade anytime.</div>
      </div>
    @endif

    <div style="text-align:center;margin-top:12px;font-size:12px;color:var(--gray)"><i class="fa-solid fa-headset"></i> Need help? <a href="{{ route('user.tickets') }}" style="color:var(--primary);font-weight:800">Open ticket</a> • Avg reply &lt; 15 min</div>
  </div>
</div>

@push('scripts')
<script>
(function(){
  const form = document.getElementById('checkoutForm');
  const btn = document.getElementById('payBtn');
  if(form && btn){
    form.addEventListener('submit', function(){
      const label = document.getElementById('payBtnLabel');
      const spin = document.getElementById('payBtnSpin');
      if(label) label.classList.add('hide');
      if(spin) spin.classList.remove('hide');
      btn.disabled = true;
      btn.style.opacity = '.8';
    });
  }
  // radio visual active state
  document.querySelectorAll('input[name="method"][type="radio"]').forEach(r=>{
    r.addEventListener('change', ()=>{
      document.querySelectorAll('input[name="method"]').forEach(x=>{
        const lab = x.closest('label');
        if(!lab) return;
        if(x.checked){ lab.style.borderColor='var(--primary)'; lab.style.background='var(--primary-soft)'; }
        else { lab.style.borderColor='var(--border)'; lab.style.background='#fff'; }
      });
    });
  });
  // uppercase txn
  const txn = document.querySelector('input[name="txn"]');
  if(txn) txn.addEventListener('input', ()=> txn.value = txn.value.toUpperCase());
})();
</script>
@endpush
@endsection
