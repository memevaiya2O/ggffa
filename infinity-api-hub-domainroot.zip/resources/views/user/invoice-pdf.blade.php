<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Invoice {{ $invoice->invoice_number }}</title>
<style>
@page { margin: 28px; }
body { font-family: DejaVu Sans, sans-serif; color:#0f172a; font-size:13px; }
.header { background:#1e3a8a; color:#fff; padding:22px; border-radius:12px; }
.header h1 { margin:0; font-size:22px; }
.meta { margin-top:18px; width:100%; border-collapse:collapse; }
.meta td { padding:8px 10px; border-bottom:1px solid #e2e8f0; }
.meta td:first-child { color:#64748b; width:160px; font-weight:700; }
.total { font-size:18px; font-weight:900; color:#2563eb; text-align:right; padding:14px 10px; border-top:2px solid #1e3a8a; }
.foot { text-align:center; margin-top:22px; color:#94a3b8; font-size:11px; }
.badge { padding:3px 10px; border-radius:50px; font-size:11px; font-weight:800; }
</style>
</head>
<body>
<div class="header">
  <h1>∞ {{ setting('site_name','INFINITY API HUB') }} — INVOICE</h1>
  <div style="opacity:.9; font-size:13px">Invoice {{ $invoice->invoice_number }} • Order #{{ $order->id }} • {{ $order->created_at->format('d M Y, h:i A') }}</div>
</div>
<table class="meta">
  <tr><td>Billed To</td><td><b>{{ $order->user->name }}</b> — {{ $order->user->email }} @if($order->user->phone) • {{ $order->user->phone }} @endif</td></tr>
  <tr><td>API / Service</td><td>{{ $order->service->name ?? '—' }} (/api/{{ $order->service->slug ?? '' }})</td></tr>
  <tr><td>Package</td><td>{{ $order->package->name ?? '' }} — {{ number_format((int)($order->package->requests ?? 0)) }} credits • {{ $order->package->validity_days ?? 0 }} days</td></tr>
  <tr><td>API Key credited</td><td style="font-family:monospace">{{ $order->key->api_key ?? '—' }}</td></tr>
  <tr><td>Payment Method</td><td>{{ $order->payment_method }}</td></tr>
  <tr><td>Transaction ID</td><td style="font-family:monospace">{{ $order->txn_id }}</td></tr>
  <tr><td>Status</td><td><b style="text-transform:uppercase">{{ $order->status }}</b> @if($order->reviewed_at) • {{ $order->reviewed_at->format('d M Y, h:i A') }}@endif</td></tr>
</table>
<div class="total">Total Paid: {{ $order->amount > 0 ? 'BDT '.number_format((float)$order->amount,2) : 'FREE' }}</div>
<div style="margin-top:14px; padding:10px; background:#f0fdf4; border:1px solid #bbf7d0; border-radius:8px; font-size:12px;">
  Payment verified and credits added successfully. This is a computer-generated invoice – no signature required.
</div>
<div class="foot">
  Thank you for your business.<br>
  {{ setting('site_name','INFINITY API HUB') }} • {{ setting('footer_text','') }}<br>
  Generated {{ now()->format('d M Y, h:i:s') }}
</div>
</body>
</html>
