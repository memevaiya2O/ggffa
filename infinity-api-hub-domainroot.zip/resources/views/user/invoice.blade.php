<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Invoice {{ $invoice->invoice_number ?? '#'.$order->id }} — {{ setting('site_name', 'INFINITY API HUB') }}</title>
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<style>*{margin:0;box-sizing:border-box;font-family:'Outfit',sans-serif}body{background:#f1f5f9;padding:30px;color:#0f172a}.inv{max-width:700px;margin:0 auto;background:#fff;border-radius:20px;overflow:hidden;box-shadow:0 10px 40px rgba(0,0,0,.08)}.head{background:linear-gradient(135deg,#1e3a8a,#2563eb);color:#fff;padding:34px;display:flex;justify-content:space-between;align-items:center}.head h1{font-size:26px}.body{padding:34px}.row{display:flex;justify-content:space-between;padding:11px 0;border-bottom:1px solid #f1f5f9;font-size:15px;gap:12px}.row span{color:#64748b;flex:0 0 140px}.row b{flex:1;text-align:right;word-break:break-all}.total{display:flex;justify-content:space-between;padding:16px 0 0;font-size:20px;font-weight:900}.total b{color:#2563eb}.foot{text-align:center;padding:20px;color:#94a3b8;font-size:13px}@media print{body{background:#fff;padding:0}.inv{box-shadow:none}.noprint{display:none!important}}.btn{display:inline-block;background:#2563eb;color:#fff;padding:11px 26px;border-radius:50px;text-decoration:none;font-weight:700;margin-top:20px;border:none;cursor:pointer}.badge{padding:4px 12px;border-radius:50px;font-size:12px;font-weight:800}.badge-success{background:#f0fdf4;color:#22c55e}.badge-warning{background:#fffbeb;color:#f59e0b}.badge-danger{background:#fef2f2;color:#ef4444}</style>
</head>
<body>
<div class="inv">
  <div class="head">
    <div><h1>∞ {{ setting('site_name', 'INFINITY API HUB') }}</h1><div style="opacity:.85;font-size:14px">Payment Invoice • {{ $invoice->invoice_number ?? 'INV-'.$order->id }}</div></div>
    <div style="text-align:right"><div style="font-size:15px;opacity:.9">Order</div><div style="font-size:28px;font-weight:900">#{{ $order->id }}</div><div style="opacity:.85;font-size:13px">{{ fmt_date($order->created_at, true) }}</div><div style="margin-top:6px">{!! badge($order->status) !!}</div></div>
  </div>
  <div class="body">
    <div class="row"><span>Invoice No</span><b>{{ $invoice->invoice_number ?? 'INV-'.$order->id }}</b></div>
    <div class="row"><span>Billed To</span><b>{{ $order->user->name }}<br><small style="color:#64748b">{{ $order->user->email }} @if($order->user->phone) • {{ $order->user->phone }}@endif</small></b></div>
    <div class="row"><span>API / Service</span><b>{{ $order->service?->name ?? ($order->order_kind === 'wallet_topup' ? 'Wallet' : '—') }} <small style="color:#64748b">@if($order->service?->slug)/api/{{ $order->service->slug }}@endif</small></b></div>
    <div class="row"><span>Purchase</span><b>{{ $order->order_kind === 'wallet_topup' ? 'Wallet top-up' : (($order->package?->name ?? 'Custom credits').' — '.number_format((int) ($order->credit_quantity ?: ($order->package?->requests ?? 0))).' credits') }}</b></div>
    <div class="row"><span>Key credited</span><b class="mono" style="font-size:13px">{{ $order->key->api_key ?? $order->user->keys()->first()?->api_key ?? '—' }}</b></div>
    <div class="row"><span>Payment Method</span><b>{{ $order->payment_method === 'wallet' ? 'Wallet balance' : 'Auto Payment' }}</b></div>
    <div class="row"><span>Transaction ID</span><b class="mono">{{ $order->txn_id ?: '—' }}</b></div>
    @if($order->sender_number)<div class="row"><span>Sender Number</span><b>{{ $order->sender_number }}</b></div>@endif
    <div class="row"><span>Payment Date</span><b>{{ fmt_date($order->reviewed_at ?: $order->created_at, true) }}</b></div>
    <div class="total"><span>Total Paid</span><b>{{ $order->amount > 0 ? taka($order->amount) : 'FREE' }}</b></div>
    @if($order->status==='approved')
      <div style="margin-top:14px;padding:12px;background:#f0fdf4;border:1px solid #dcfce7;border-radius:12px;font-size:13px;color:#15803d"><i class="fa-solid fa-circle-check"></i> Payment verified and credits added successfully.</div>
    @endif
    <div class="noprint" style="text-align:center;display:flex;gap:10px;justify-content:center;flex-wrap:wrap">
      <a class="btn" href="#" onclick="window.print();return false"><i class="fa-solid fa-print"></i> Print / Save PDF</a>
      @if(isset($invoice) && $invoice->pdf_path)<a class="btn" style="background:#0f172a" href="{{ route('user.orders.invoice.download', $order) }}"><i class="fa-solid fa-download"></i> Download PDF</a>@endif
      <a class="btn" style="background:#fff;color:#0f172a;border:2px solid #e2e8f0" href="{{ route('user.orders') }}">Back to Orders</a>
    </div>
  </div>
  <div class="foot">Thank you for your business • {{ setting('site_name', 'INFINITY API HUB') }}<br><small>Invoice generated {{ now()->format('d M Y, h:i A') }} • For support: {{ setting('support_telegram','') ?: setting('support_whatsapp','') ?: 'Contact via dashboard tickets' }}</small></div>
</div>
</body>
</html>
