@extends('layouts.dash')
@section('title', 'Notifications')
@section('content')
<div class="page-head"><div><h1>Notifications</h1><p>Announcements & updates from admin.</p></div></div>
<div class="card">
  @forelse($list as $n)
  @php $bg = ['success' => 'bg-green', 'warning' => 'bg-amber', 'error' => 'bg-red'][$n->type] ?? 'bg-sky'; @endphp
  <div class="notice-item">
    <div class="notice-ic {{ $bg }}"><i class="fa-solid fa-bullhorn"></i></div>
    <div style="flex:1">
      <div class="flex between wrap-x"><b>{{ $n->title }}</b><small class="text-gray">{{ $n->created_at->diffForHumans() }}</small></div>
      <div class="text-gray text-sm" style="margin-top:4px">{!! nl2br(e($n->message)) !!}</div>
    </div>
  </div>
  @empty
  <div class="empty"><i class="fa-solid fa-bell-slash"></i><b>No notifications</b>You're all caught up!</div>
  @endforelse
</div>
@endsection
