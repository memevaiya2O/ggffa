@extends('layouts.dash')
@section('title', 'My Orders')
@section('content')
<div class="page-head">
  <div><h1>My Orders</h1><p>Your package purchases & payment status.</p></div>
  <a class="btn btn-primary btn-sm" href="{{ route('user.buy') }}"><i class="fa-solid fa-plus"></i>New Order</a>
</div>

<div class="card">
  @if($orders->isEmpty())
    <div class="empty"><i class="fa-solid fa-receipt"></i><b>No orders yet</b><span class="text-sm text-gray">Buy a package to see it here.</span></div>
  @else
  <div class="table-wrap"><table class="tbl">
    <tr><th>#</th><th>API / Package</th><th>Amount</th><th>Payment</th><th>Status</th><th>Date</th><th>Actions</th></tr>
    @foreach($orders as $o)
    <tr>
      <td><b>{{ $o->id }}</b></td>
      <td><b>{{ $o->order_kind === 'wallet_topup' ? 'Wallet top-up' : ($o->service?->name ?? '—') }}</b><br><small class="text-gray">{{ $o->order_kind === 'wallet_topup' ? taka($o->amount).' wallet balance' : (($o->package?->name ?? 'Custom credits').' • '.number_format((int) ($o->credit_quantity ?: ($o->package?->requests ?? 0))).' credits') }}</small></td>
      <td><b>{{ $o->amount > 0 ? taka($o->amount) : 'FREE' }}</b></td>
      <td class="text-sm">{{ $o->payment_method }}<br><small class="mono text-gray">{{ \Illuminate\Support\Str::limit($o->txn_id, 22) }}</small>@if($o->expires_at && $o->status==='pending')<br><small class="text-warning"><i class="fa-solid fa-clock"></i> Expires {{ $o->expires_at->diffForHumans() }}</small>@endif</td>
      <td>
        {!! badge($o->status) !!}
        @if($o->status==='pending')<br><span class="badge badge-warning" style="font-size:10px;margin-top:4px;display:inline-block"><i class="fa-solid fa-clock"></i> Pending verification</span>@endif
        @if($o->status==='expired')<br><span class="badge badge-danger" style="font-size:10px">Expired — please retry</span>@endif
        @if($o->admin_note)<br><small class="text-gray" style="display:block;max-width:220px;white-space:normal">{{ $o->admin_note }}</small>@endif
      </td>
      <td class="text-sm text-gray">{{ fmt_date($o->created_at, true) }}</td>
      <td>
        <div class="flex gap wrap-x" style="min-width:160px">
          <a class="btn btn-ghost btn-xs" href="{{ route('user.orders.invoice', $o) }}" target="_blank"><i class="fa-solid fa-file-invoice"></i> Invoice</a>
          @if($o->invoice)<a class="btn btn-outline btn-xs" href="{{ route('user.orders.invoice.download', $o) }}"><i class="fa-solid fa-download"></i> PDF</a>@endif
          @if($o->status==='pending' && $o->payment_method==='nagorikpay')
            <form method="POST" action="{{ route('user.orders.recheck', $o) }}">@csrf<button class="btn btn-primary btn-xs"><i class="fa-solid fa-rotate"></i> Recheck</button></form>
          @endif
          @if($o->status==='pending' || $o->status==='expired')
            <a class="btn btn-outline btn-xs" href="{{ route('user.buy', ['service'=>$o->service_id]) }}"><i class="fa-solid fa-credit-card"></i> Retry</a>
          @endif
        </div>
      </td>
    </tr>
    @endforeach
  </table></div>
  @endif
</div>

<div class="card mt">
  <div class="card-title"><i class="fa-solid fa-circle-info"></i>Payment Statuses Explained</div>
  <div class="grid-2 mt">
    <div><span class="badge badge-warning">Pending verification</span> <span class="text-sm">Payment is being verified — usually within seconds. Use <b>Recheck</b> if needed.</span></div>
    <div><span class="badge badge-success">Success — Credits Added</span> <span class="text-sm">Payment verified & invoice emailed.</span></div>
    <div><span class="badge badge-danger">Expired — Please Retry</span> <span class="text-sm">Timed out after {{ (int) setting('nagorikpay_expire_minutes',30) }} min.</span></div>
    <div><span class="badge badge-danger">Failed / Rejected</span> <span class="text-sm">Gateway declined — retry or contact support.</span></div>
  </div>
</div>
@endsection
