@extends('layouts.dash')
@section('title', $title ?? 'Payment Status')
@section('content')
@php
  $iconMap = [
    'success' => ['bg'=>'#f0fdf4','color'=>'#22c55e','icon'=>'fa-circle-check'],
    'pending' => ['bg'=>'#fffbeb','color'=>'#f59e0b','icon'=>'fa-clock'],
    'failed' => ['bg'=>'#fef2f2','color'=>'#ef4444','icon'=>'fa-circle-xmark'],
    'expired' => ['bg'=>'#fef2f2','color'=>'#ef4444','icon'=>'fa-hourglass-end'],
    'cancelled' => ['bg'=>'#f1f5f9','color'=>'#64748b','icon'=>'fa-circle-xmark'],
  ];
  $theme = $iconMap[$status] ?? $iconMap['pending'];
  $orderUrl = route('user.orders');
  $creditQty = (int) ($order->credit_quantity ?: ($order->package?->requests ?? 0));
@endphp
<div class="card" style="max-width:700px;margin:30px auto;padding:28px">
  <div style="width:84px;height:84px;border-radius:50%;background:{{ $theme['bg'] }};color:{{ $theme['color'] }};display:flex;align-items:center;justify-content:center;margin:0 auto 14px;font-size:42px;border:2px solid {{ $theme['color'] }}22">
    <i class="fa-solid {{ $theme['icon'] }}"></i>
  </div>
  <h1 style="text-align:center;font-size:26px;font-weight:900">{{ $title }}</h1>
  <p style="text-align:center;color:var(--gray);margin:8px 0 14px">{!! nl2br(e($message)) !!}</p>

  <div class="card" style="background:var(--bg);margin:16px 0">
    <div class="flex between"><span class="text-gray">Order ID</span><b>#{{ $order->id }}</b></div>
    <div class="flex between mt"><span class="text-gray">Purchase</span><b>{{ $order->order_kind === 'wallet_topup' ? 'Wallet top-up' : (($order->service?->name ?? '—').' — '.($order->package?->name ?? 'Custom credits')) }}</b></div>
    <div class="flex between mt"><span class="text-gray">Amount</span><b>{{ taka($order->amount) }}</b></div>
    <div class="flex between mt"><span class="text-gray">Status</span><span>{!! badge($order->status) !!}</span></div>
    <div class="flex between mt"><span class="text-gray">Transaction ID</span><span class="mono text-sm">{{ $transaction ?: ($order->txn_id ?: '— pending —') }}</span></div>
    @if($order->expires_at)<div class="flex between mt"><span class="text-gray">Expires</span><span class="text-sm">{{ fmt_date($order->expires_at, true) }}</span></div>@endif
    @if($order->admin_note)<div class="alert alert-info mt" style="margin-bottom:0"><i class="fa-solid fa-circle-info"></i><div>{{ $order->admin_note }}</div></div>@endif
  </div>

  @if($status === 'success')
    <div class="alert alert-success"><i class="fa-solid fa-gift"></i><div>@if($order->order_kind === 'wallet_topup')<b>Wallet Updated!</b> {{ taka($order->amount) }} has been added to your wallet. Check <a href="{{ route('user.wallet') }}" style="font-weight:800">My Wallet</a>.@else<b>Credits Added!</b> {{ number_format($creditQty) }} credits are now on <b>{{ $order->service?->name ?? 'your key' }}</b>. Check <a href="{{ route('user.keys') }}" style="font-weight:800">My Keys</a>.@endif Invoice has been emailed.</div></div>
    <div class="flex gap wrap-x mt">
      <a class="btn btn-primary" href="{{ route('user.keys') }}"><i class="fa-solid fa-key"></i>My Keys</a>
      <a class="btn btn-outline" href="{{ route('user.orders.invoice', $order) }}" target="_blank"><i class="fa-solid fa-file-invoice"></i>View Invoice</a>
      @if($order->invoice)<a class="btn btn-ghost" href="{{ route('user.orders.invoice.download', $order) }}"><i class="fa-solid fa-download"></i>Download PDF</a>@endif
      <a class="btn btn-ghost" href="{{ route('user.test') }}"><i class="fa-solid fa-flask-vial"></i>Test API</a>
    </div>
  @elseif($status === 'pending')
    <div class="alert alert-warning"><i class="fa-solid fa-clock"></i><div><b>Verification Pending</b> — Your payment is being verified. This usually finishes in seconds. You can also click <b>Recheck Status</b>. If money was deducted but your balance or credits are not updated within 5 minutes, contact support with Transaction ID.</div></div>
    <div class="flex gap wrap-x mt">
      <form method="POST" action="{{ route('user.orders.recheck', $order) }}">@csrf<button class="btn btn-primary"><i class="fa-solid fa-rotate"></i>Recheck Status</button></form>
      <a class="btn btn-outline" href="{{ route('user.orders') }}"><i class="fa-solid fa-list"></i>My Orders</a>
      <a class="btn btn-ghost" href="{{ route('home') }}#faq"><i class="fa-solid fa-headset"></i>Contact Support</a>
    </div>
    <p class="text-sm text-gray mt" style="text-align:center">Auto-recheck runs every 5 minutes. Page will refresh if status changes.</p>
    <script>setTimeout(()=>location.reload(), 15000);</script>
  @elseif($status === 'expired')
    <div class="alert alert-danger"><i class="fa-solid fa-hourglass-end"></i><div><b>Payment Expired</b> — This session timed out after {{ (int) setting('nagorikpay_expire_minutes',30) }} minutes. No credits were added. Please retry.</div></div>
    <div class="flex gap wrap-x mt">
      <a class="btn btn-primary" href="{{ route('user.buy', ['service' => $order->service_id]) }}"><i class="fa-solid fa-rotate"></i>Retry Payment</a>
      <a class="btn btn-outline" href="{{ route('user.orders') }}"><i class="fa-solid fa-list"></i>My Orders</a>
    </div>
  @elseif($status === 'cancelled')
    <div class="alert alert-info"><i class="fa-solid fa-circle-info"></i><div>You cancelled the payment on the gateway. No money was deducted. You can retry anytime.</div></div>
    <div class="flex gap wrap-x mt">
      <a class="btn btn-primary" href="{{ route('user.buy', ['service' => $order->service_id]) }}"><i class="fa-solid fa-credit-card"></i>Try Again</a>
      <a class="btn btn-outline" href="{{ route('user.orders') }}"><i class="fa-solid fa-list"></i>My Orders</a>
    </div>
  @else {{-- failed --}}
    <div class="alert alert-danger"><i class="fa-solid fa-triangle-exclamation"></i><div><b>Payment Failed</b> — {{ $order->admin_note ?: 'Could not verify payment.' }} If money was deducted, contact support with Transaction ID <span class="mono">{{ $transaction ?: $order->txn_id }}</span>.</div></div>
    <div class="flex gap wrap-x mt">
      <form method="POST" action="{{ route('user.orders.recheck', $order) }}">@csrf<button class="btn btn-primary"><i class="fa-solid fa-rotate"></i>Recheck Status</button></form>
      <a class="btn btn-outline" href="{{ route('user.buy', ['service' => $order->service_id]) }}"><i class="fa-solid fa-rotate"></i>Retry</a>
      <a class="btn btn-ghost" href="{{ route('user.tickets') }}"><i class="fa-solid fa-headset"></i>Open Ticket</a>
    </div>
  @endif

  <hr style="border:none;border-top:1px solid var(--border);margin:22px 0">
  <p class="text-sm text-gray" style="text-align:center">Need help? <a href="{{ route('user.tickets') }}" style="font-weight:700">Open a ticket</a> • Transaction: <span class="mono">{{ $transaction ?: ($order->txn_id ?: '—') }}</span></p>
</div>
@endsection
