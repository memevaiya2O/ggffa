@extends('layouts.dash')
@section('title', 'Ticket #'.$ticket->id)
@section('content')
<div class="page-head">
  <div><h1>#{{ $ticket->id }} — {{ $ticket->subject }}</h1><p>{{ $ticket->service->name ?? 'General' }} • opened {{ $ticket->created_at->diffForHumans() }}</p></div>
  <div class="flex gap">
    @if($ticket->status !== 'closed')
    <form action="{{ route('user.tickets.close', $ticket) }}" method="POST" onsubmit="return confirm('Close this ticket?')">@csrf<button class="btn btn-outline btn-sm">Close Ticket</button></form>
    @endif
    <a class="btn btn-outline btn-sm" href="{{ route('user.tickets') }}"><i class="fa-solid fa-arrow-left"></i>All Tickets</a>
  </div>
</div>
<div class="flex gap wrap-x mb">{!! badge($ticket->status) !!} {!! badge($ticket->priority) !!}</div>
<div class="card">
  @foreach($ticket->replies as $r)
  <div class="ticket-msg {{ $r->is_admin ? 'admin' : 'user' }}">
    <div class="ticket-head"><b>{{ $r->is_admin ? '🛡️ Support Team' : e($r->user->name ?? 'You') }}</b><small>{{ $r->created_at->diffForHumans() }}</small></div>
    <div class="ticket-body">{!! nl2br(e($r->message)) !!}</div>
  </div>
  @endforeach

  @if($ticket->status !== 'closed')
  <form method="POST" action="{{ route('user.tickets.reply', $ticket) }}" class="mt">
    @csrf
    <div class="form-group"><label>Write a reply</label><textarea name="message" class="form-control" required placeholder="Type your message…"></textarea></div>
    <button class="btn btn-primary" type="submit"><i class="fa-solid fa-paper-plane"></i>Send Reply</button>
  </form>
  @else
  <div class="alert alert-info" style="margin:18px 0 0"><i class="fa-solid fa-lock"></i><div>This ticket is closed. Open a new one if you need more help.</div></div>
  @endif
</div>
@endsection
