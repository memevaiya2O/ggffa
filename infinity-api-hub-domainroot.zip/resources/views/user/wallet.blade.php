@extends('layouts.dash')
@section('title', 'My Wallet')
@section('content')
<div class="page-head">
  <div><h1><i class="fa-solid fa-wallet" style="color:var(--primary)"></i> My Wallet</h1><p>Add money securely, see your balance, then use it to buy any API credits instantly.</p></div>
  <a class="btn btn-primary" href="{{ route('user.buy') }}"><i class="fa-solid fa-cart-shopping"></i> Buy Credits</a>
</div>
<div class="grid-2" style="align-items:start">
  <div class="card wallet-balance-card" style="background:linear-gradient(135deg,#1d4ed8,#2563eb);color:#fff;border:0">
    <div class="flex between center"><span style="font-weight:800;opacity:.9"><i class="fa-solid fa-wallet"></i> Available balance</span><span class="badge" style="background:rgba(255,255,255,.18);color:#fff"><i class="fa-solid fa-shield-halved"></i> Secure</span></div>
    <div style="font-size:42px;font-weight:900;letter-spacing:-1px;margin:20px 0 3px">{{ taka($wallet->balance) }}</div>
    <div style="opacity:.82;font-size:13px">Use this balance for any API credit purchase. No separate payment each time.</div>
  </div>
  <div class="card">
    <div class="card-title"><i class="fa-solid fa-circle-plus"></i> Add Money</div>
    <p class="card-sub">Choose an amount and complete payment in the secure payment gateway. Your wallet updates after verification.</p>
    <form method="POST" action="{{ route('user.wallet.purchase') }}">
      @csrf
      <input type="hidden" name="kind" value="wallet_topup"><input type="hidden" name="payment_type" value="gateway">
      <div class="form-group"><label>Amount to add</label><div class="input-icon"><i class="fa-solid fa-bangladeshi-taka-sign"></i><input type="number" class="form-control" name="amount" min="{{ setting('wallet_min_topup',10) }}" max="{{ setting('wallet_max_topup',100000) }}" step="0.01" placeholder="e.g. 500" required></div><div class="form-hint">Minimum {{ taka(setting('wallet_min_topup',10)) }} • Maximum {{ taka(setting('wallet_max_topup',100000)) }}</div></div>
      <button class="btn btn-primary btn-block" type="submit"><i class="fa-solid fa-bolt"></i> Add Money via Auto Payment</button>
    </form>
  </div>
</div>
<div class="card mt">
  <div class="flex between center wrap-x"><div><div class="card-title" style="margin:0"><i class="fa-solid fa-clock-rotate-left"></i> Wallet Activity</div><p class="card-sub" style="margin:4px 0 0">Every top-up and credit purchase is recorded here.</p></div><span class="mini-tag blue">{{ $transactions->total() }} transactions</span></div>
  @if($transactions->isEmpty())<div class="empty mt"><i class="fa-solid fa-receipt"></i><b>No wallet activity yet</b><span class="text-sm text-gray">Add money to start using your wallet.</span></div>
  @else
  <div class="table-wrap mt"><table class="tbl"><tr><th>Type</th><th>Description</th><th>Amount</th><th>Balance after</th><th>Date</th></tr>
    @foreach($transactions as $tx)<tr><td><span class="badge {{ $tx->amount >= 0 ? 'badge-success' : 'badge-warning' }}">{{ $tx->amount >= 0 ? 'Added' : 'Spent' }}</span></td><td><b>{{ $tx->description ?: ucfirst(str_replace('_',' ', $tx->type)) }}</b><br><small class="mono text-gray">{{ $tx->reference ?: '—' }}</small></td><td><b style="color:{{ $tx->amount >= 0 ? 'var(--success)' : 'var(--danger)' }}">{{ $tx->amount >= 0 ? '+' : '' }}{{ taka($tx->amount) }}</b></td><td>{{ taka($tx->balance_after) }}</td><td class="text-sm text-gray">{{ fmt_date($tx->created_at, true) }}</td></tr>@endforeach
  </table></div>{{ $transactions->links() }}
  @endif
</div>
<div class="card mt" style="background:linear-gradient(135deg,#eff6ff,#f8fbff);border-color:#bfdbfe"><div class="flex gap center"><i class="fa-solid fa-lightbulb text-primary"></i><div><b>How it works</b><div class="text-sm text-gray">Add money once → choose an API → set any credit quantity → pay from wallet. The admin controls each API’s per-credit price.</div></div></div></div>
@endsection
