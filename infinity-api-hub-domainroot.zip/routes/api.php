<?php

use App\Http\Controllers\Api\GatewayController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Public API Gateway
| Single endpoint per service:
|   GET|POST /api/{service}?api_key=KEY&param=value...
| Also accepts: X-API-KEY header, ?key=..., ?token=...
|--------------------------------------------------------------------------
*/
Route::match(['get', 'post'], '/{service}', [GatewayController::class, 'handle'])
    ->where('service', '[a-z0-9-]+')
    ->name('api.gateway');
