<?php

use Illuminate\Support\Facades\Schedule;

Schedule::command('keys:expire')->daily();
Schedule::command('logs:prune')->daily();
Schedule::command('orders:expire')->everyFiveMinutes();
Schedule::command('orders:recheck --limit=20')->everyFiveMinutes();
