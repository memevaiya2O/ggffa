<?php

use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\CheckKeyController;
use App\Http\Controllers\DocsController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\ServiceController;
use App\Http\Controllers\StatusController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Public routes
|--------------------------------------------------------------------------
*/
Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/docs', [DocsController::class, 'index'])->name('docs');
Route::post('/docs/try', [DocsController::class, 'try'])->name('docs.try');
Route::get('/service/{slug}', [ServiceController::class, 'show'])->name('service.show');
Route::get('/check-key', [CheckKeyController::class, 'index'])->name('check.key');
Route::post('/check-key', [CheckKeyController::class, 'check'])->name('check.key.post');
Route::get('/status', [StatusController::class, 'index'])->name('status');

Route::middleware('guest')->group(function () {
    Route::get('/login', [LoginController::class, 'show'])->name('login');
    Route::post('/login', [LoginController::class, 'login'])->name('login.post');
    Route::get('/auth/google', [\App\Http\Controllers\Auth\GoogleController::class, 'redirect'])->name('google.redirect');
    Route::get('/auth/google/callback', [\App\Http\Controllers\Auth\GoogleController::class, 'callback'])->name('google.callback');
    Route::get('/register', [RegisterController::class, 'show'])->name('register');
    Route::post('/register', [RegisterController::class, 'register'])->name('register.post');
});
Route::post('/logout', [LoginController::class, 'logout'])->name('logout')->middleware('auth');

Route::get('/payments/nagorikpay/{order}/success', [\App\Http\Controllers\NagorikPayController::class, 'success'])->name('payments.nagorikpay.success');
Route::get('/payments/nagorikpay/{order}/cancel', [\App\Http\Controllers\NagorikPayController::class, 'cancel'])->name('payments.nagorikpay.cancel');
Route::post('/payments/nagorikpay/{order}/webhook', [\App\Http\Controllers\NagorikPayController::class, 'webhook'])->name('payments.nagorikpay.webhook');
Route::post('/payments/nagorikpay/{order}/recheck', [\App\Http\Controllers\NagorikPayController::class, 'recheck'])->name('payments.nagorikpay.recheck')->middleware('auth');
Route::post('/payments/nagorikpay/{order}/submit-transaction', [\App\Http\Controllers\NagorikPayController::class, 'submitTransaction'])->name('payments.nagorikpay.submit')->middleware('auth');

/*
|--------------------------------------------------------------------------
| User (client) panel
|--------------------------------------------------------------------------
*/
Route::prefix('user')->name('user.')->middleware(['auth', 'active'])->group(function () {
    Route::get('/dashboard', [\App\Http\Controllers\User\DashboardController::class, 'index'])->name('dashboard');

    Route::get('/keys', [\App\Http\Controllers\User\KeyController::class, 'index'])->name('keys');
    Route::post('/keys', [\App\Http\Controllers\User\KeyController::class, 'store'])->name('keys.store');
    Route::patch('/keys/{key}', [\App\Http\Controllers\User\KeyController::class, 'update'])->name('keys.update');
    Route::delete('/keys/{key}', [\App\Http\Controllers\User\KeyController::class, 'destroy'])->name('keys.destroy');
    Route::post('/keys/{key}/regenerate', [\App\Http\Controllers\User\KeyController::class, 'regenerate'])->name('keys.regenerate');

    Route::get('/test', [\App\Http\Controllers\User\TesterController::class, 'index'])->name('test');
    Route::post('/test', [\App\Http\Controllers\User\TesterController::class, 'run'])->name('test.run');

    Route::get('/buy', [\App\Http\Controllers\User\BuyController::class, 'index'])->name('buy');
    Route::get('/buy/{package}', [\App\Http\Controllers\User\BuyController::class, 'checkout'])->name('buy.checkout');
    Route::post('/buy/{package}', [\App\Http\Controllers\User\BuyController::class, 'order'])->name('buy.order');
    Route::get('/wallet', [\App\Http\Controllers\User\WalletController::class, 'index'])->name('wallet');
    Route::post('/wallet/purchase', [\App\Http\Controllers\User\WalletController::class, 'purchase'])->name('wallet.purchase');
    Route::get('/orders', [\App\Http\Controllers\User\OrderController::class, 'index'])->name('orders');
    Route::get('/orders/{order}/invoice', [\App\Http\Controllers\User\OrderController::class, 'invoice'])->name('orders.invoice');
    Route::get('/orders/{order}/invoice/download', [\App\Http\Controllers\User\OrderController::class, 'invoiceDownload'])->name('orders.invoice.download');
    Route::post('/orders/{order}/recheck', [\App\Http\Controllers\User\OrderController::class, 'recheck'])->name('orders.recheck');

    Route::get('/notifications', [\App\Http\Controllers\User\NotificationController::class, 'index'])->name('notifications');

    Route::get('/profile', [\App\Http\Controllers\User\ProfileController::class, 'index'])->name('profile');
    Route::patch('/profile', [\App\Http\Controllers\User\ProfileController::class, 'updateInfo'])->name('profile.info');
    Route::patch('/profile/password', [\App\Http\Controllers\User\ProfileController::class, 'updatePassword'])->name('profile.password');

    Route::get('/tickets', [\App\Http\Controllers\User\TicketController::class, 'index'])->name('tickets');
    Route::post('/tickets', [\App\Http\Controllers\User\TicketController::class, 'store'])->name('tickets.store');
    Route::get('/tickets/{ticket}', [\App\Http\Controllers\User\TicketController::class, 'show'])->name('tickets.show');
    Route::post('/tickets/{ticket}/reply', [\App\Http\Controllers\User\TicketController::class, 'reply'])->name('tickets.reply');
    Route::post('/tickets/{ticket}/close', [\App\Http\Controllers\User\TicketController::class, 'close'])->name('tickets.close');
});

/*
|--------------------------------------------------------------------------
| Admin panel
|--------------------------------------------------------------------------
*/
Route::prefix('admin')->name('admin.')->middleware(['auth', 'active', 'admin'])->group(function () {
    Route::get('/dashboard', [\App\Http\Controllers\Admin\DashboardController::class, 'index'])->name('dashboard');

    Route::get('/users', [\App\Http\Controllers\Admin\UserController::class, 'index'])->name('users');
    Route::get('/users/{user}', [\App\Http\Controllers\Admin\UserController::class, 'show'])->name('users.show');
    Route::post('/users/{user}/status', [\App\Http\Controllers\Admin\UserController::class, 'toggleStatus'])->name('users.status');
    Route::post('/users/{user}/role', [\App\Http\Controllers\Admin\UserController::class, 'toggleRole'])->name('users.role');
    Route::delete('/users/{user}', [\App\Http\Controllers\Admin\UserController::class, 'destroy'])->name('users.destroy');
    Route::post('/users/{user}/reset-password', [\App\Http\Controllers\Admin\UserController::class, 'resetPassword'])->name('users.resetpass');
    Route::post('/users/{user}/bonus', [\App\Http\Controllers\Admin\UserController::class, 'bonus'])->name('users.bonus');
    Route::post('/users/{user}/notify', [\App\Http\Controllers\Admin\UserController::class, 'notify'])->name('users.notify');
    Route::post('/users/{user}/keys/{key}/toggle', [\App\Http\Controllers\Admin\UserController::class, 'toggleKey'])->name('users.keys.toggle');
    Route::post('/users/{user}/keys/{key}/regenerate', [\App\Http\Controllers\Admin\UserController::class, 'regenerateKey'])->name('users.keys.regenerate');

    Route::get('/services', [\App\Http\Controllers\Admin\ServiceController::class, 'index'])->name('services');
    Route::get('/services/create', [\App\Http\Controllers\Admin\ServiceController::class, 'create'])->name('services.create');
    Route::post('/services', [\App\Http\Controllers\Admin\ServiceController::class, 'store'])->name('services.store');
    Route::get('/services/{service}/edit', [\App\Http\Controllers\Admin\ServiceController::class, 'edit'])->name('services.edit');
    Route::patch('/services/{service}', [\App\Http\Controllers\Admin\ServiceController::class, 'update'])->name('services.update');
    Route::delete('/services/{service}', [\App\Http\Controllers\Admin\ServiceController::class, 'destroy'])->name('services.destroy');
    Route::post('/services/{service}/toggle', [\App\Http\Controllers\Admin\ServiceController::class, 'toggle'])->name('services.toggle');
    Route::get('/services/{service}/test', [\App\Http\Controllers\Admin\ServiceController::class, 'testForm'])->name('services.test');
    Route::post('/services/{service}/test', [\App\Http\Controllers\Admin\ServiceController::class, 'testRun'])->name('services.test.run');
    Route::post('/services/{service}/issue-all', [\App\Http\Controllers\Admin\ServiceController::class, 'issueAll'])->name('services.issueAll');
    Route::get('/services/{service}/pricing', [\App\Http\Controllers\Admin\PackageController::class, 'pricing'])->name('services.pricing');
    Route::get('/services/{service}/pricing/create', [\App\Http\Controllers\Admin\PackageController::class, 'pricingCreate'])->name('services.pricing.create');
    Route::post('/services/{service}/pricing', [\App\Http\Controllers\Admin\PackageController::class, 'pricingStore'])->name('services.pricing.store');
    Route::get('/services/{service}/pricing/{package}/edit', [\App\Http\Controllers\Admin\PackageController::class, 'pricingEdit'])->name('services.pricing.edit');
    Route::patch('/services/{service}/pricing/{package}', [\App\Http\Controllers\Admin\PackageController::class, 'pricingUpdate'])->name('services.pricing.update');
    Route::delete('/services/{service}/pricing/{package}', [\App\Http\Controllers\Admin\PackageController::class, 'pricingDestroy'])->name('services.pricing.destroy');

    Route::get('/keys', [\App\Http\Controllers\Admin\KeyController::class, 'index'])->name('keys');
    Route::get('/keys/create', [\App\Http\Controllers\Admin\KeyController::class, 'create'])->name('keys.create');
    Route::post('/keys', [\App\Http\Controllers\Admin\KeyController::class, 'store'])->name('keys.store');
    Route::get('/keys/{key}/edit', [\App\Http\Controllers\Admin\KeyController::class, 'edit'])->name('keys.edit');
    Route::patch('/keys/{key}', [\App\Http\Controllers\Admin\KeyController::class, 'update'])->name('keys.update');
    Route::delete('/keys/{key}', [\App\Http\Controllers\Admin\KeyController::class, 'destroy'])->name('keys.destroy');
    Route::post('/keys/{key}/regenerate', [\App\Http\Controllers\Admin\KeyController::class, 'regenerate'])->name('keys.regenerate');

    Route::get('/packages', [\App\Http\Controllers\Admin\PackageController::class, 'index'])->name('packages');
    Route::get('/packages/create', [\App\Http\Controllers\Admin\PackageController::class, 'create'])->name('packages.create');
    Route::post('/packages', [\App\Http\Controllers\Admin\PackageController::class, 'store'])->name('packages.store');
    Route::get('/packages/{package}/edit', [\App\Http\Controllers\Admin\PackageController::class, 'edit'])->name('packages.edit');
    Route::patch('/packages/{package}', [\App\Http\Controllers\Admin\PackageController::class, 'update'])->name('packages.update');
    Route::delete('/packages/{package}', [\App\Http\Controllers\Admin\PackageController::class, 'destroy'])->name('packages.destroy');

    Route::get('/orders', [\App\Http\Controllers\Admin\OrderController::class, 'index'])->name('orders');
    Route::post('/orders/{order}/approve', [\App\Http\Controllers\Admin\OrderController::class, 'approve'])->name('orders.approve');
    Route::post('/orders/{order}/reject', [\App\Http\Controllers\Admin\OrderController::class, 'reject'])->name('orders.reject');
    Route::post('/orders/{order}/recheck', [\App\Http\Controllers\Admin\OrderController::class, 'recheck'])->name('orders.recheck');
    Route::post('/orders/{order}/expire', [\App\Http\Controllers\Admin\OrderController::class, 'expire'])->name('orders.expire');

    Route::get('/logs', [\App\Http\Controllers\Admin\LogController::class, 'index'])->name('logs');
    Route::get('/logs/export', [\App\Http\Controllers\Admin\LogController::class, 'export'])->name('logs.export');
    Route::post('/logs/clear', [\App\Http\Controllers\Admin\LogController::class, 'clear'])->name('logs.clear');
    Route::get('/logs/nagorikpay', [\App\Http\Controllers\Admin\LogController::class, 'nagorikpay'])->name('logs.nagorikpay');

    Route::get('/notifications', [\App\Http\Controllers\Admin\NotificationController::class, 'index'])->name('notifications');
    Route::post('/notifications', [\App\Http\Controllers\Admin\NotificationController::class, 'store'])->name('notifications.store');
    Route::get('/notifications/{notification}/edit', [\App\Http\Controllers\Admin\NotificationController::class, 'edit'])->name('notifications.edit');
    Route::patch('/notifications/{notification}', [\App\Http\Controllers\Admin\NotificationController::class, 'update'])->name('notifications.update');
    Route::delete('/notifications/{notification}', [\App\Http\Controllers\Admin\NotificationController::class, 'destroy'])->name('notifications.destroy');

    Route::get('/admins', [\App\Http\Controllers\Admin\AdminUserController::class, 'index'])->name('admins');
    Route::post('/admins', [\App\Http\Controllers\Admin\AdminUserController::class, 'store'])->name('admins.store');
    Route::post('/admins/{user}/demote', [\App\Http\Controllers\Admin\AdminUserController::class, 'demote'])->name('admins.demote');
    Route::patch('/admins/password', [\App\Http\Controllers\Admin\AdminUserController::class, 'myPassword'])->name('admins.mypass');

    Route::get('/tickets', [\App\Http\Controllers\Admin\TicketController::class, 'index'])->name('tickets');
    Route::get('/tickets/{ticket}', [\App\Http\Controllers\Admin\TicketController::class, 'show'])->name('tickets.show');
    Route::post('/tickets/{ticket}/reply', [\App\Http\Controllers\Admin\TicketController::class, 'reply'])->name('tickets.reply');
    Route::post('/tickets/{ticket}/status', [\App\Http\Controllers\Admin\TicketController::class, 'status'])->name('tickets.status');

    Route::get('/reports', [\App\Http\Controllers\Admin\ReportController::class, 'index'])->name('reports');

    Route::get('/settings', [\App\Http\Controllers\Admin\SettingController::class, 'index'])->name('settings');
    Route::patch('/settings', [\App\Http\Controllers\Admin\SettingController::class, 'update'])->name('settings.update');
    Route::post('/settings/logo', [\App\Http\Controllers\Admin\SettingController::class, 'logo'])->name('settings.logo');
    Route::delete('/settings/logo', [\App\Http\Controllers\Admin\SettingController::class, 'logoRemove'])->name('settings.logo.remove');
    Route::post('/settings/icon', [\App\Http\Controllers\Admin\SettingController::class, 'icon'])->name('settings.icon');
    Route::delete('/settings/icon', [\App\Http\Controllers\Admin\SettingController::class, 'iconRemove'])->name('settings.icon.remove');
    Route::post('/settings/footer-logo', [\App\Http\Controllers\Admin\SettingController::class, 'footerLogo'])->name('settings.footerLogo');
    Route::delete('/settings/footer-logo', [\App\Http\Controllers\Admin\SettingController::class, 'footerLogoRemove'])->name('settings.footerLogo.remove');
    Route::post('/settings/nagorikpay/clear', [\App\Http\Controllers\Admin\SettingController::class, 'clearNagorikPayKey'])->name('settings.nagorikpay.clear');
    Route::get('/settings/backup', [\App\Http\Controllers\Admin\SettingController::class, 'backup'])->name('settings.backup');
});
