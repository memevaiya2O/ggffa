<?php

/**
 * Laravel - A PHP Framework For Web Artisans
 *
 * Development router for PHP's built-in web server:
 *   php -S localhost:8000 server.php
 */

$publicPath = __DIR__.'/public';
$uri = urldecode(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?? '/');

if ($uri !== '/' && file_exists($publicPath.$uri)) {
    return false;
}

require_once $publicPath.'/index.php';
