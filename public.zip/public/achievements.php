<?php
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/includes/settings-loader.php';
$user = requireLogin();
$pdo  = getDB();

$notifCount = getUnreadNotificationCount((int)$user['id']);
$achievements = $pdo->query("SELECT a.*, ua.unlocked_at FROM achievements a LEFT JOIN user_achievements ua ON ua.achievement_id = a.id AND ua.user_id = {$user['id']} ORDER BY ua.unlocked_at DESC NULLS LAST, a.id")->fetchAll();
$unlockedCount = count(array_filter($achievements, fn($a) => $a['unlocked_at']));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?= renderSeoMeta() ?>
<?= renderGoogleFont() ?>
<?= renderCssVars() ?>
<link rel="stylesheet" href="/assets/css/style.css">
<link rel="stylesheet" href="/assets/css/dashboard.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="app-layout">
  <header class="app-header">
    <div class="app-header-left"><div class="user-name">Achievements</div></div>
    <div class="app-header-right">
      <a href="/notifications.php" class="notif-btn"><i class="fa-solid fa-bell"></i><?php if ($notifCount): ?><span class="notif-badge"><?= $notifCount ?></span><?php endif; ?></a>
    </div>
  </header>
  <main class="main-content">
    <div class="card" style="text-align:center;margin-bottom:20px;">
      <div style="font-size:36px;font-weight:900;color:var(--primary)"><?= $unlockedCount ?> / <?= count($achievements) ?></div>
      <div style="color:#888;font-size:14px;margin-top:4px;">Badges Unlocked</div>
      <div class="xp-bar" style="margin-top:12px;"><div class="xp-fill" style="width:<?= count($achievements) ? round($unlockedCount/count($achievements)*100) : 0 ?>%"></div></div>
    </div>
    <div class="achievements-grid">
      <?php foreach ($achievements as $a): ?>
        <?php $unlocked = !empty($a['unlocked_at']); ?>
        <div class="achievement-card <?= $unlocked ? 'unlocked' : 'locked' ?>">
          <div class="ach-icon" style="<?= $unlocked ? "color:var(--primary)" : '' ?>">
            <i class="fa-solid <?= h($a['icon']) ?>" style="font-size:36px;"></i>
          </div>
          <h4><?= h($a['name']) ?></h4>
          <p><?= h($a['description']) ?></p>
          <?php if ($unlocked): ?>
            <div class="ach-check"><i class="fa-solid fa-circle-check"></i> <?= date('M j', strtotime($a['unlocked_at'])) ?></div>
          <?php else: ?>
            <div style="margin-top:8px;font-size:11px;color:#aaa;"><i class="fa-solid fa-lock"></i> Locked</div>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
    </div>
  </main>
  <nav class="bottom-nav">
    <a href="/dashboard.php" class="nav-item"><i class="fa-solid fa-house"></i>Home</a>
    <a href="/tasks.php" class="nav-item"><i class="fa-solid fa-list-check"></i>Tasks</a>
    <a href="/wallet.php" class="nav-item"><i class="fa-solid fa-wallet"></i>Wallet</a>
    <a href="/leaderboard.php" class="nav-item"><i class="fa-solid fa-trophy"></i>Board</a>
    <a href="/profile.php" class="nav-item active"><i class="fa-solid fa-user"></i>Profile</a>
  </nav>
</div>
<script src="/assets/js/main.js"></script>
</body>
</html>
