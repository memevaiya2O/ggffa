<?php
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/includes/settings-loader.php';
requireAdmin();
$pdo = getDB();
$pageTitle = 'Categories';
$adminPage = 'categories';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'reorder') {
        $order = json_decode(file_get_contents('php://input'), true)['order'] ?? [];
        foreach ($order as $item) { $pdo->prepare("UPDATE task_categories SET sort_order=:o WHERE id=:id")->execute([':o'=>$item['order'],':id'=>$item['id']]); }
        header('Content-Type: application/json'); echo json_encode(['success'=>true,'message'=>'Order saved']); exit;
    }
    verifyCsrf();
    if ($action === 'add' || $action === 'edit') {
        $id    = (int)($_POST['cat_id'] ?? 0);
        $name  = trim($_POST['name'] ?? '');
        $icon  = trim($_POST['icon'] ?? 'fa-tag');
        $color = trim($_POST['color'] ?? '#00C896');
        $st    = $_POST['status'] ?? 'active';
        if (!$name) { $_SESSION['flash_err'] = 'Name required.'; redirect('/admin/categories.php'); }
        if ($action === 'add') { $pdo->prepare("INSERT INTO task_categories (name,icon,color,status) VALUES(:n,:i,:c,:s)")->execute([':n'=>$name,':i'=>$icon,':c'=>$color,':s'=>$st]); }
        else { $pdo->prepare("UPDATE task_categories SET name=:n,icon=:i,color=:c,status=:s WHERE id=:id")->execute([':n'=>$name,':i'=>$icon,':c'=>$color,':s'=>$st,':id'=>$id]); }
        $_SESSION['flash'] = 'Category saved.';
    } elseif ($action === 'delete') {
        $pdo->prepare("DELETE FROM task_categories WHERE id=:id")->execute([':id'=>(int)$_POST['cat_id']]);
        $_SESSION['flash'] = 'Category deleted.';
    }
    redirect('/admin/categories.php');
}
$flash = $_SESSION['flash'] ?? ''; unset($_SESSION['flash']);
$flashErr = $_SESSION['flash_err'] ?? ''; unset($_SESSION['flash_err']);
$cats = $pdo->query("SELECT c.*, (SELECT COUNT(*) FROM tasks WHERE category_id=c.id) as task_count FROM task_categories c ORDER BY c.sort_order, c.id")->fetchAll();
require ROOT_PATH . '/admin/includes/header.php';
?>
<?php if ($flash): ?><div class="alert alert-success" style="margin-bottom:20px;"><?= h($flash) ?></div><?php endif; ?>
<?php if ($flashErr): ?><div class="alert alert-error" style="margin-bottom:20px;"><?= h($flashErr) ?></div><?php endif; ?>
<div style="display:grid;grid-template-columns:1fr 340px;gap:24px;">
  <div class="admin-card">
    <div class="admin-card-header"><div class="admin-card-title">Categories</div></div>
    <div class="admin-table-wrap">
      <table class="admin-table">
        <thead><tr><th>☰</th><th>Category</th><th>Tasks</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody id="sortable-cats">
          <?php foreach ($cats as $c): ?>
            <tr data-id="<?= $c['id'] ?>">
              <td><span class="drag-handle"><i class="fa-solid fa-grip-lines"></i></span></td>
              <td>
                <div style="display:flex;align-items:center;gap:10px;">
                  <div style="width:40px;height:40px;border-radius:10px;background:<?= h($c['color']) ?>22;display:flex;align-items:center;justify-content:center;color:<?= h($c['color']) ?>;font-size:18px;">
                    <i class="fa-solid <?= h($c['icon']) ?>"></i>
                  </div>
                  <div style="font-weight:700"><?= h($c['name']) ?></div>
                </div>
              </td>
              <td><?= $c['task_count'] ?></td>
              <td><span class="status-badge status-<?= h($c['status']) ?>"><?= ucfirst($c['status']) ?></span></td>
              <td>
                <div class="action-btns">
                  <button class="action-btn-sm action-btn-edit" onclick="editCat(<?= h(json_encode($c)) ?>)"><i class="fa-solid fa-pen"></i></button>
                  <form method="post" style="display:inline"><?= csrfField() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="cat_id" value="<?= $c['id'] ?>"><button type="submit" class="action-btn-sm action-btn-delete" data-confirm="Delete this category?"><i class="fa-solid fa-trash"></i></button></form>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
  <div class="admin-card" id="cat-form-card">
    <div class="admin-card-title" style="margin-bottom:20px;" id="cat-form-title">Add Category</div>
    <form method="post" id="cat-form">
      <?= csrfField() ?>
      <input type="hidden" name="action" id="cat-action" value="add">
      <input type="hidden" name="cat_id" id="cat-id" value="0">
      <div class="admin-form-group"><label class="admin-label">Name *</label><input type="text" name="name" id="cat-name" class="admin-input" required></div>
      <div class="admin-form-group"><label class="admin-label">Font Awesome Icon Class</label><input type="text" name="icon" id="cat-icon" class="admin-input" placeholder="fa-tag" value="fa-tag"><div style="margin-top:8px;font-size:24px;"><i class="fa-solid fa-tag" id="icon-preview"></i></div></div>
      <div class="admin-form-group">
        <label class="admin-label">Color</label>
        <div class="color-picker-wrap"><input type="color" name="color" id="cat-color" value="#00C896"><input type="text" id="cat-color-text" value="#00C896" style="width:100px;padding:8px;border:2px solid #e8e8e8;border-radius:6px;font-family:monospace;font-size:13px;"></div>
      </div>
      <div class="admin-form-group"><label class="admin-label">Status</label><select name="status" id="cat-status" class="admin-input"><option value="active">Active</option><option value="inactive">Inactive</option></select></div>
      <button type="submit" class="btn btn-primary btn-block">Save Category</button>
      <button type="button" class="btn btn-outline btn-block" style="margin-top:8px;" onclick="resetCatForm()">Reset</button>
    </form>
  </div>
</div>
<script>
function editCat(c) {
  document.getElementById('cat-action').value='edit';
  document.getElementById('cat-id').value=c.id;
  document.getElementById('cat-name').value=c.name;
  document.getElementById('cat-icon').value=c.icon;
  document.getElementById('cat-color').value=c.color;
  document.getElementById('cat-color-text').value=c.color;
  document.getElementById('cat-status').value=c.status;
  document.getElementById('cat-form-title').textContent='Edit: '+c.name;
  document.getElementById('icon-preview').className='fa-solid '+c.icon;
  document.getElementById('cat-form-card').scrollIntoView({behavior:'smooth'});
}
function resetCatForm() {
  document.getElementById('cat-action').value='add';
  document.getElementById('cat-id').value='0';
  document.getElementById('cat-form').reset();
  document.getElementById('cat-form-title').textContent='Add Category';
}
document.getElementById('cat-icon').addEventListener('input', function() {
  document.getElementById('icon-preview').className='fa-solid '+this.value;
});
initSortable('sortable-cats','/admin/categories.php');
</script>
<?php require ROOT_PATH . '/admin/includes/footer.php'; ?>
