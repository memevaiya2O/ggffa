<?php
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/includes/settings-loader.php';
requireAdmin();
$pdo = getDB();
$pageTitle = 'Homepage Editor';
$adminPage = 'homepage-editor';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $fields = [
        'hero_title','hero_subtitle','hero_btn_text','hero_btn_link',
        'stats_show','stat1_number','stat1_label','stat2_number','stat2_label','stat3_number','stat3_label','stat4_number','stat4_label',
        'features_show','features_title',
        'how_show','how_title',
        'testimonials_show','testimonials_title',
        'cta_show','cta_title','cta_subtitle','cta_btn_text','cta_btn_link',
        'hero_bg_color','hero_text_color',
    ];
    foreach ($fields as $k) {
        $v = trim($_POST[$k] ?? '');
        $existing = $pdo->prepare("SELECT id FROM settings WHERE key=:k"); $existing->execute([':k'=>$k]);
        if ($existing->fetchColumn()) {
            $pdo->prepare("UPDATE settings SET value=:v WHERE key=:k")->execute([':v'=>$v,':k'=>$k]);
        } else {
            $pdo->prepare("INSERT INTO settings (key,value,group_name) VALUES(:k,:v,'homepage')")->execute([':k'=>$k,':v'=>$v]);
        }
    }
    // Handle feature blocks (3)
    for ($i=1;$i<=6;$i++) {
        foreach (['feat_icon_','feat_title_','feat_desc_'] as $prefix) {
            $k = $prefix.$i; $v = trim($_POST[$k] ?? '');
            $existing = $pdo->prepare("SELECT id FROM settings WHERE key=:k"); $existing->execute([':k'=>$k]);
            if ($existing->fetchColumn()) { $pdo->prepare("UPDATE settings SET value=:v WHERE key=:k")->execute([':v'=>$v,':k'=>$k]); }
            else { $pdo->prepare("INSERT INTO settings (key,value,group_name) VALUES(:k,:v,'homepage')")->execute([':k'=>$k,':v'=>$v]); }
        }
    }
    $_SESSION['flash'] = 'Homepage updated.';
    redirect('/admin/homepage-editor.php');
}

$flash = $_SESSION['flash'] ?? ''; unset($_SESSION['flash']);
$s = [];
$rows = $pdo->query("SELECT key,value FROM settings WHERE group_name='homepage' OR key LIKE 'hero_%' OR key LIKE 'stat%' OR key LIKE 'feat%' OR key LIKE 'how_%' OR key LIKE 'cta_%' OR key LIKE 'testimonials_%'")->fetchAll();
foreach ($rows as $r) $s[$r['key']] = $r['value'];
$g = fn($k,$d='') => $s[$k] ?? $d;
require ROOT_PATH . '/admin/includes/header.php';
?>
<?php if ($flash): ?><div class="alert alert-success" style="margin-bottom:20px;"><?= h($flash) ?></div><?php endif; ?>

<form method="post">
  <?= csrfField() ?>

  <div class="admin-card" style="margin-bottom:20px;">
    <div class="admin-card-header"><div class="admin-card-title">🏠 Hero Section</div></div>
    <div class="admin-card-body">
      <div class="admin-grid-2" style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
        <div class="form-group"><label>Hero Title</label><input type="text" name="hero_title" class="form-control" value="<?= h($g('hero_title','Earn Real Money Online')) ?>"></div>
        <div class="form-group"><label>Hero Subtitle</label><input type="text" name="hero_subtitle" class="form-control" value="<?= h($g('hero_subtitle','Complete tasks and get paid')) ?>"></div>
        <div class="form-group"><label>Button Text</label><input type="text" name="hero_btn_text" class="form-control" value="<?= h($g('hero_btn_text','Get Started')) ?>"></div>
        <div class="form-group"><label>Button Link</label><input type="text" name="hero_btn_link" class="form-control" value="<?= h($g('hero_btn_link','/register.php')) ?>"></div>
        <div class="form-group"><label>Hero Background Color</label><input type="color" name="hero_bg_color" value="<?= h($g('hero_bg_color','#667eea')) ?>" style="height:40px;width:100%;"></div>
        <div class="form-group"><label>Hero Text Color</label><input type="color" name="hero_text_color" value="<?= h($g('hero_text_color','#ffffff')) ?>" style="height:40px;width:100%;"></div>
      </div>
    </div>
  </div>

  <div class="admin-card" style="margin-bottom:20px;">
    <div class="admin-card-header"><div class="admin-card-title">📊 Stats Bar</div></div>
    <div class="admin-card-body">
      <div class="form-group">
        <label>Show Stats Bar</label>
        <select name="stats_show" class="form-control" style="max-width:200px;">
          <option value="1" <?= $g('stats_show','1')==='1'?'selected':'' ?>>Yes</option>
          <option value="0" <?= $g('stats_show','1')==='0'?'selected':'' ?>>No</option>
        </select>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:16px;">
        <?php for ($i=1;$i<=4;$i++): ?>
        <div>
          <div class="form-group"><label>Stat <?= $i ?> Number</label><input type="text" name="stat<?= $i ?>_number" class="form-control" value="<?= h($g("stat{$i}_number",'0+')) ?>"></div>
          <div class="form-group"><label>Stat <?= $i ?> Label</label><input type="text" name="stat<?= $i ?>_label" class="form-control" value="<?= h($g("stat{$i}_label",'Label')) ?>"></div>
        </div>
        <?php endfor; ?>
      </div>
    </div>
  </div>

  <div class="admin-card" style="margin-bottom:20px;">
    <div class="admin-card-header"><div class="admin-card-title">✨ Features Section</div></div>
    <div class="admin-card-body">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px;">
        <div class="form-group"><label>Show Features</label><select name="features_show" class="form-control"><option value="1" <?= $g('features_show','1')==='1'?'selected':'' ?>>Yes</option><option value="0" <?= $g('features_show','1')==='0'?'selected':'' ?>>No</option></select></div>
        <div class="form-group"><label>Section Title</label><input type="text" name="features_title" class="form-control" value="<?= h($g('features_title','Why Choose Us')) ?>"></div>
      </div>
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px;">
        <?php for ($i=1;$i<=6;$i++): ?>
        <div style="border:1px solid #eee;padding:12px;border-radius:8px;">
          <div class="form-group"><label>Icon <?= $i ?> (FA class)</label><input type="text" name="feat_icon_<?= $i ?>" class="form-control" value="<?= h($g("feat_icon_$i",'fa-star')) ?>"></div>
          <div class="form-group"><label>Title <?= $i ?></label><input type="text" name="feat_title_<?= $i ?>" class="form-control" value="<?= h($g("feat_title_$i","Feature $i")) ?>"></div>
          <div class="form-group"><label>Description <?= $i ?></label><input type="text" name="feat_desc_<?= $i ?>" class="form-control" value="<?= h($g("feat_desc_$i",'')) ?>"></div>
        </div>
        <?php endfor; ?>
      </div>
    </div>
  </div>

  <div class="admin-card" style="margin-bottom:20px;">
    <div class="admin-card-header"><div class="admin-card-title">📢 CTA Section</div></div>
    <div class="admin-card-body">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
        <div class="form-group"><label>Show CTA</label><select name="cta_show" class="form-control"><option value="1" <?= $g('cta_show','1')==='1'?'selected':'' ?>>Yes</option><option value="0" <?= $g('cta_show','1')==='0'?'selected':'' ?>>No</option></select></div>
        <div class="form-group"><label>CTA Title</label><input type="text" name="cta_title" class="form-control" value="<?= h($g('cta_title','Ready to Earn?')) ?>"></div>
        <div class="form-group"><label>CTA Subtitle</label><input type="text" name="cta_subtitle" class="form-control" value="<?= h($g('cta_subtitle','Join thousands of earners today!')) ?>"></div>
        <div class="form-group"><label>Button Text</label><input type="text" name="cta_btn_text" class="form-control" value="<?= h($g('cta_btn_text','Join Now')) ?>"></div>
        <div class="form-group"><label>Button Link</label><input type="text" name="cta_btn_link" class="form-control" value="<?= h($g('cta_btn_link','/register.php')) ?>"></div>
      </div>
    </div>
  </div>

  <button class="btn btn-primary btn-lg">💾 Save Homepage</button>
</form>
<?php require ROOT_PATH . '/admin/includes/footer.php'; ?>
