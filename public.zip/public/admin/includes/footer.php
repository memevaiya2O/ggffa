    </div><!-- /admin-content -->
  </div><!-- /admin-main -->
</div><!-- /admin-layout -->
<div id="toast-container"></div>
<script src="/assets/js/admin.js"></script>
<?php if (!empty($extraJs)) echo $extraJs; ?>
</body>
</html>
