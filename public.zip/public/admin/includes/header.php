<?php
$adminPage = $adminPage ?? 'dashboard';
$pendSubs  = (int)getDB()->query("SELECT COUNT(*) FROM submissions WHERE status='pending'")->fetchColumn();
$pendWith  = (int)getDB()->query("SELECT COUNT(*) FROM withdrawals WHERE status='pending'")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= h($pageTitle ?? 'Admin') ?> — <?= h(getSetting('site_name','EarnBD')) ?> Admin</title>
<?= renderGoogleFont() ?>
<?= renderCssVars() ?>
<link rel="stylesheet" href="/assets/css/style.css">
<link rel="stylesheet" href="/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4/dist/chart.umd.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js"></script>
</head>
<body>
<div class="admin-layout">
  <aside class="admin-sidebar" id="admin-sidebar">
    <div class="sidebar-header">
      <div class="sidebar-logo"><?= h(getSetting('site_name','EarnBD')) ?></div>
      <div class="sidebar-subtitle">Admin Panel</div>
    </div>
    <nav class="sidebar-nav">
      <div class="sidebar-section">Main</div>
      <a href="/admin/" class="sidebar-link <?= $adminPage==='dashboard'?'active':'' ?>"><i class="fa-solid fa-chart-pie"></i> Dashboard</a>
      <a href="/admin/users.php" class="sidebar-link <?= $adminPage==='users'?'active':'' ?>"><i class="fa-solid fa-users"></i> Users</a>

      <div class="sidebar-section">Tasks</div>
      <a href="/admin/tasks.php" class="sidebar-link <?= $adminPage==='tasks'?'active':'' ?>"><i class="fa-solid fa-list-check"></i> All Tasks</a>
      <a href="/admin/task-add.php" class="sidebar-link <?= $adminPage==='task-add'?'active':'' ?>"><i class="fa-solid fa-plus"></i> Add Task</a>
      <a href="/admin/categories.php" class="sidebar-link <?= $adminPage==='categories'?'active':'' ?>"><i class="fa-solid fa-tags"></i> Categories</a>
      <a href="/admin/submissions.php" class="sidebar-link <?= $adminPage==='submissions'?'active':'' ?>">
        <i class="fa-solid fa-inbox"></i> Submissions <?php if ($pendSubs): ?><span class="sidebar-badge"><?= $pendSubs ?></span><?php endif; ?>
      </a>

      <div class="sidebar-section">Finance</div>
      <a href="/admin/withdrawals.php" class="sidebar-link <?= $adminPage==='withdrawals'?'active':'' ?>">
        <i class="fa-solid fa-money-bill-transfer"></i> Withdrawals <?php if ($pendWith): ?><span class="sidebar-badge"><?= $pendWith ?></span><?php endif; ?>
      </a>
      <a href="/admin/withdraw-methods.php" class="sidebar-link <?= $adminPage==='withdraw-methods'?'active':'' ?>"><i class="fa-solid fa-wallet"></i> Methods</a>
      <a href="/admin/withdraw-proof.php" class="sidebar-link <?= $adminPage==='withdraw-proof'?'active':'' ?>"><i class="fa-solid fa-images"></i> Pay Proof</a>
      <a href="/admin/reports.php" class="sidebar-link <?= $adminPage==='reports'?'active':'' ?>"><i class="fa-solid fa-chart-bar"></i> Reports</a>

      <div class="sidebar-section">Gamification</div>
      <a href="/admin/levels.php" class="sidebar-link <?= $adminPage==='levels'?'active':'' ?>"><i class="fa-solid fa-medal"></i> Levels</a>
      <a href="/admin/spin-config.php" class="sidebar-link <?= $adminPage==='spin-config'?'active':'' ?>"><i class="fa-solid fa-circle-notch"></i> Spin Config</a>
      <a href="/admin/referral-config.php" class="sidebar-link <?= $adminPage==='referral-config'?'active':'' ?>"><i class="fa-solid fa-user-plus"></i> Referrals</a>
      <a href="/admin/leaderboard.php" class="sidebar-link <?= $adminPage==='leaderboard'?'active':'' ?>"><i class="fa-solid fa-trophy"></i> Leaderboard</a>

      <div class="sidebar-section">Content</div>
      <a href="/admin/notifications.php" class="sidebar-link <?= $adminPage==='notifications'?'active':'' ?>"><i class="fa-solid fa-bell"></i> Notifications</a>
      <a href="/admin/homepage-editor.php" class="sidebar-link <?= $adminPage==='homepage-editor'?'active':'' ?>"><i class="fa-solid fa-home"></i> Homepage</a>
      <a href="/admin/pages.php" class="sidebar-link <?= $adminPage==='pages'?'active':'' ?>"><i class="fa-solid fa-file-lines"></i> Pages</a>
      <a href="/admin/popup-manager.php" class="sidebar-link <?= $adminPage==='popup-manager'?'active':'' ?>"><i class="fa-solid fa-comment-dots"></i> Popups</a>

      <div class="sidebar-section">System</div>
      <a href="/admin/theme.php" class="sidebar-link <?= $adminPage==='theme'?'active':'' ?>"><i class="fa-solid fa-palette"></i> Theme</a>
      <a href="/admin/seo.php" class="sidebar-link <?= $adminPage==='seo'?'active':'' ?>"><i class="fa-solid fa-magnifying-glass-chart"></i> SEO</a>
      <a href="/admin/settings.php" class="sidebar-link <?= $adminPage==='settings'?'active':'' ?>"><i class="fa-solid fa-gear"></i> Settings</a>
      <a href="/admin/maintenance.php" class="sidebar-link <?= $adminPage==='maintenance'?'active':'' ?>"><i class="fa-solid fa-screwdriver-wrench"></i> Maintenance</a>
      <a href="/admin/logout.php" class="sidebar-link" style="color:var(--danger);margin-top:12px;"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
    </nav>
  </aside>
  <div class="admin-main">
    <header class="admin-topbar">
      <div class="admin-topbar-left">
        <span class="sidebar-toggle" onclick="document.getElementById('admin-sidebar').classList.toggle('open')"><i class="fa-solid fa-bars"></i></span>
        <div class="page-title"><?= h($pageTitle ?? 'Dashboard') ?></div>
      </div>
      <div class="admin-topbar-right">
        <a href="/" target="_blank" style="font-size:13px;color:#888;font-weight:600;"><i class="fa-solid fa-external-link"></i> View Site</a>
        <div class="admin-user">
          <div class="admin-user-avatar"><?= strtoupper(substr($_SESSION['admin_username']??'A',0,1)) ?></div>
          <?= h($_SESSION['admin_username']??'Admin') ?>
        </div>
      </div>
    </header>
    <div class="admin-content">
