<?php
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/includes/settings-loader.php';
requireAdmin();
$pdo = getDB();
$pageTitle = 'Analytics Dashboard';
$adminPage = 'dashboard';

// KPI data
$totalUsers    = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$todayUsers    = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE DATE(created_at)=CURRENT_DATE")->fetchColumn();
$activeUsers   = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE last_login >= NOW()-INTERVAL '7 days'")->fetchColumn();
$bannedUsers   = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE status='banned'")->fetchColumn();
$pendingSubs   = (int)$pdo->query("SELECT COUNT(*) FROM submissions WHERE status='pending'")->fetchColumn();
$todayApproved = (int)$pdo->query("SELECT COUNT(*) FROM submissions WHERE status='approved' AND DATE(reviewed_at)=CURRENT_DATE")->fetchColumn();
$totalTasks    = (int)$pdo->query("SELECT COUNT(*) FROM tasks")->fetchColumn();
$totalCats     = (int)$pdo->query("SELECT COUNT(*) FROM task_categories")->fetchColumn();
$pendingWith   = (int)$pdo->query("SELECT COUNT(*) FROM withdrawals WHERE status='pending'")->fetchColumn();
$todayPaid     = (int)$pdo->query("SELECT COUNT(*) FROM withdrawals WHERE status='paid' AND DATE(paid_at)=CURRENT_DATE")->fetchColumn();
$totalPayout   = (float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM withdrawals WHERE status='paid'")->fetchColumn();
$totalBalance  = (float)$pdo->query("SELECT COALESCE(SUM(balance),0) FROM users")->fetchColumn();

// Charts
$monthlyUsers = $pdo->query("SELECT TO_CHAR(created_at,'Mon') as month, COUNT(*) as cnt FROM users WHERE created_at >= NOW()-INTERVAL '12 months' GROUP BY DATE_TRUNC('month',created_at), TO_CHAR(created_at,'Mon') ORDER BY DATE_TRUNC('month',created_at)")->fetchAll();
$monthlyPayout = $pdo->query("SELECT TO_CHAR(paid_at,'Mon') as month, COALESCE(SUM(amount),0) as total FROM withdrawals WHERE status='paid' AND paid_at >= NOW()-INTERVAL '12 months' GROUP BY DATE_TRUNC('month',paid_at), TO_CHAR(paid_at,'Mon') ORDER BY DATE_TRUNC('month',paid_at)")->fetchAll();

// Recent records
$recentUsers = $pdo->query("SELECT u.*, l.name as level_name, l.color as level_color FROM users u LEFT JOIN levels l ON l.id=u.level_id ORDER BY u.created_at DESC LIMIT 10")->fetchAll();
$recentSubs  = $pdo->query("SELECT s.*, u.name as user_name, t.title as task_title FROM submissions s JOIN users u ON u.id=s.user_id JOIN tasks t ON t.id=s.task_id ORDER BY s.created_at DESC LIMIT 10")->fetchAll();
$recentWith  = $pdo->query("SELECT w.*, u.name as user_name, wm.name as method_name FROM withdrawals w JOIN users u ON u.id=w.user_id JOIN withdraw_methods wm ON wm.id=w.method_id ORDER BY w.created_at DESC LIMIT 10")->fetchAll();
$topMonth    = $pdo->query("SELECT u.name, u.avatar, COALESCE(SUM(t.amount),0) as earned FROM users u LEFT JOIN transactions t ON t.user_id=u.id AND t.amount>0 AND t.created_at>=DATE_TRUNC('month',NOW()) GROUP BY u.id,u.name,u.avatar ORDER BY earned DESC LIMIT 5")->fetchAll();

require ROOT_PATH . '/admin/includes/header.php';
?>
<!-- KPI Row 1 -->
<div class="kpi-grid">
  <div class="kpi-card"><div class="kpi-icon green"><i class="fa-solid fa-users"></i></div><div class="kpi-body"><div class="kpi-label">Total Users</div><div class="kpi-value"><?= number_format($totalUsers) ?></div><div class="kpi-sub">Today: +<?= $todayUsers ?></div></div></div>
  <div class="kpi-card"><div class="kpi-icon blue"><i class="fa-solid fa-user-clock"></i></div><div class="kpi-body"><div class="kpi-label">Active (7d)</div><div class="kpi-value"><?= number_format($activeUsers) ?></div></div></div>
  <div class="kpi-card"><div class="kpi-icon red"><i class="fa-solid fa-user-slash"></i></div><div class="kpi-body"><div class="kpi-label">Banned</div><div class="kpi-value"><?= number_format($bannedUsers) ?></div></div></div>
  <div class="kpi-card"><div class="kpi-icon orange"><i class="fa-solid fa-inbox"></i></div><div class="kpi-body"><div class="kpi-label">Pending Subs</div><div class="kpi-value"><?= number_format($pendingSubs) ?></div><div class="kpi-sub">Today: <?= $todayApproved ?> approved</div></div></div>
  <div class="kpi-card"><div class="kpi-icon green"><i class="fa-solid fa-list-check"></i></div><div class="kpi-body"><div class="kpi-label">Total Tasks</div><div class="kpi-value"><?= number_format($totalTasks) ?></div><div class="kpi-sub"><?= $totalCats ?> categories</div></div></div>
  <div class="kpi-card"><div class="kpi-icon orange"><i class="fa-solid fa-clock"></i></div><div class="kpi-body"><div class="kpi-label">Pending Withdrawals</div><div class="kpi-value"><?= number_format($pendingWith) ?></div><div class="kpi-sub">Today: <?= $todayPaid ?> paid</div></div></div>
  <div class="kpi-card"><div class="kpi-icon green"><i class="fa-solid fa-sack-dollar"></i></div><div class="kpi-body"><div class="kpi-label">Total Payout</div><div class="kpi-value"><?= getSetting('currency_symbol','৳') ?><?= number_format($totalPayout,0) ?></div></div></div>
  <div class="kpi-card"><div class="kpi-icon purple"><i class="fa-solid fa-piggy-bank"></i></div><div class="kpi-body"><div class="kpi-label">Balance in System</div><div class="kpi-value"><?= getSetting('currency_symbol','৳') ?><?= number_format($totalBalance,0) ?></div></div></div>
</div>

<!-- Charts -->
<div class="charts-grid">
  <div class="chart-card"><h3>New Users (12 Months)</h3><div style="height:220px"><canvas id="usersChart"></canvas></div></div>
  <div class="chart-card"><h3>Total Payout (12 Months)</h3><div style="height:220px"><canvas id="payoutChart"></canvas></div></div>
</div>

<!-- Recent Records -->
<div style="display:grid;grid-template-columns:1fr 1fr;gap:24px;margin-bottom:24px;">
  <!-- Top Earners -->
  <div class="admin-card">
    <div class="admin-card-header"><div class="admin-card-title">Top Earners This Month</div></div>
    <div class="admin-table-wrap">
      <table class="admin-table">
        <thead><tr><th>#</th><th>User</th><th>Earned</th></tr></thead>
        <tbody>
          <?php foreach ($topMonth as $i => $u): ?>
            <tr><td><?= $i+1 ?></td><td><?= h($u['name']) ?></td><td style="color:var(--primary);font-weight:700"><?= getSetting('currency_symbol','৳') ?><?= number_format($u['earned'],2) ?></td></tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
  <!-- Recent Registrations -->
  <div class="admin-card">
    <div class="admin-card-header"><div class="admin-card-title">Recent Registrations</div><a href="/admin/users.php" class="btn btn-sm btn-outline">View All</a></div>
    <div class="admin-table-wrap">
      <table class="admin-table">
        <thead><tr><th>User</th><th>Level</th><th>Joined</th></tr></thead>
        <tbody>
          <?php foreach ($recentUsers as $u): ?>
            <tr>
              <td><div class="user-cell"><div class="table-avatar"><?= strtoupper(substr($u['name'],0,1)) ?></div><div class="user-cell-info"><div class="user-cell-name"><?= h($u['name']) ?></div><div class="user-cell-email"><?= h($u['email']) ?></div></div></div></td>
              <td><span class="badge badge-info" style="background:<?= h($u['level_color']??'#CD7F32') ?>22;color:<?= h($u['level_color']??'#CD7F32') ?>"><?= h($u['level_name']??'Bronze') ?></span></td>
              <td style="font-size:12px;color:#888"><?= date('M j',strtotime($u['created_at'])) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Recent Submissions + Withdrawals -->
<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">Recent Submissions</div><a href="/admin/submissions.php" class="btn btn-sm btn-outline">View All</a></div>
  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>User</th><th>Task</th><th>Status</th><th>Time</th></tr></thead>
      <tbody>
        <?php foreach ($recentSubs as $s): ?>
          <tr>
            <td><?= h($s['user_name']) ?></td>
            <td><?= h($s['task_title']) ?></td>
            <td><span class="status-badge status-<?= h($s['status']) ?>"><?= ucfirst($s['status']) ?></span></td>
            <td style="font-size:12px;color:#888"><?= timeAgo($s['created_at']) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">Recent Withdrawals</div><a href="/admin/withdrawals.php" class="btn btn-sm btn-outline">View All</a></div>
  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>User</th><th>Method</th><th>Amount</th><th>Status</th><th>Date</th></tr></thead>
      <tbody>
        <?php foreach ($recentWith as $w): ?>
          <tr>
            <td><?= h($w['user_name']) ?></td>
            <td><?= h($w['method_name']) ?></td>
            <td style="font-weight:700"><?= getSetting('currency_symbol','৳') ?><?= number_format($w['amount'],2) ?></td>
            <td><span class="status-badge status-<?= h($w['status']) ?>"><?= ucfirst($w['status']) ?></span></td>
            <td style="font-size:12px;color:#888"><?= timeAgo($w['created_at']) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php
$extraJs = '<script>
createLineChart("usersChart",' . json_encode(array_column($monthlyUsers,'month')) . ',' . json_encode(array_map(fn($r)=>(int)$r["cnt"],$monthlyUsers)) . ',"New Users");
createBarChart("payoutChart",' . json_encode(array_column($monthlyPayout,'month')) . ',' . json_encode(array_map(fn($r)=>(float)$r["total"],$monthlyPayout)) . ',"Payout");
</script>';
require ROOT_PATH . '/admin/includes/footer.php';
