<?php
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/includes/settings-loader.php';
requireAdmin();
$pdo = getDB();
$pageTitle = 'Leaderboard';
$adminPage = 'leaderboard';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $fields = ['leaderboard_enabled','leaderboard_period','leaderboard_top_n','leaderboard_prize_1','leaderboard_prize_2','leaderboard_prize_3'];
    foreach ($fields as $k) {
        $v = trim($_POST[$k] ?? '');
        $pdo->prepare("UPDATE settings SET value=:v WHERE key=:k")->execute([':v'=>$v,':k'=>$k]);
    }
    $_SESSION['flash'] = 'Settings saved.';
    redirect('/admin/leaderboard.php');
}

$flash = $_SESSION['flash'] ?? ''; unset($_SESSION['flash']);
$s = [];
$rows = $pdo->query("SELECT key,value FROM settings WHERE key LIKE 'leaderboard_%'")->fetchAll();
foreach ($rows as $r) $s[$r['key']] = $r['value'];
$g = fn($k,$d='') => $s[$k] ?? $d;

$period = $_GET['period'] ?? 'alltime';
$periodSQL = match($period) {
    'today'  => "AND created_at >= CURRENT_DATE",
    'week'   => "AND created_at >= DATE_TRUNC('week', NOW())",
    'month'  => "AND created_at >= DATE_TRUNC('month', NOW())",
    default  => ""
};
$leaders = $pdo->query("SELECT u.id,u.name,u.avatar,l.name as level_name,l.color as level_color,
    COALESCE(SUM(t2.amount),0) as earned
    FROM users u
    LEFT JOIN transactions t2 ON t2.user_id=u.id AND t2.amount>0 $periodSQL
    LEFT JOIN levels l ON l.id=u.level_id
    WHERE u.status='active'
    GROUP BY u.id,u.name,u.avatar,l.name,l.color
    ORDER BY earned DESC LIMIT 50")->fetchAll();
require ROOT_PATH . '/admin/includes/header.php';
?>
<?php if ($flash): ?><div class="alert alert-success" style="margin-bottom:20px;"><?= h($flash) ?></div><?php endif; ?>

<div class="admin-grid-2" style="display:grid;grid-template-columns:320px 1fr;gap:24px;">

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">Leaderboard Settings</div></div>
  <div class="admin-card-body">
    <form method="post">
      <?= csrfField() ?>
      <div class="form-group">
        <label>Enabled</label>
        <select name="leaderboard_enabled" class="form-control">
          <option value="1" <?= $g('leaderboard_enabled','1')==='1'?'selected':'' ?>>Yes</option>
          <option value="0" <?= $g('leaderboard_enabled','1')==='0'?'selected':'' ?>>No</option>
        </select>
      </div>
      <div class="form-group">
        <label>Default Period</label>
        <select name="leaderboard_period" class="form-control">
          <?php foreach (['alltime'=>'All Time','month'=>'Monthly','week'=>'Weekly','today'=>'Daily'] as $v=>$l): ?>
          <option value="<?= $v ?>" <?= $g('leaderboard_period','alltime')===$v?'selected':'' ?>><?= $l ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group">
        <label>Display Top N Users</label>
        <input type="number" name="leaderboard_top_n" class="form-control" value="<?= h($g('leaderboard_top_n','10')) ?>" min="5" max="100">
      </div>
      <div class="form-group"><label>🥇 1st Prize (BDT)</label><input type="number" name="leaderboard_prize_1" class="form-control" value="<?= h($g('leaderboard_prize_1','500')) ?>" step="0.01" min="0"></div>
      <div class="form-group"><label>🥈 2nd Prize (BDT)</label><input type="number" name="leaderboard_prize_2" class="form-control" value="<?= h($g('leaderboard_prize_2','250')) ?>" step="0.01" min="0"></div>
      <div class="form-group"><label>🥉 3rd Prize (BDT)</label><input type="number" name="leaderboard_prize_3" class="form-control" value="<?= h($g('leaderboard_prize_3','100')) ?>" step="0.01" min="0"></div>
      <button class="btn btn-primary">Save</button>
    </form>
  </div>
</div>

<div class="admin-card">
  <div class="admin-card-header">
    <div class="admin-card-title">Live Rankings</div>
    <div style="display:flex;gap:8px;">
      <?php foreach (['alltime'=>'All Time','month'=>'Month','week'=>'Week','today'=>'Today'] as $v=>$l): ?>
      <a href="?period=<?= $v ?>" class="btn btn-xs <?= $period===$v?'btn-primary':'btn-secondary' ?>"><?= $l ?></a>
      <?php endforeach; ?>
    </div>
  </div>
  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>Rank</th><th>User</th><th>Level</th><th>Earned (BDT)</th></tr></thead>
      <tbody>
        <?php foreach ($leaders as $i=>$u):
          $medal = $i===0?'🥇':($i===1?'🥈':($i===2?'🥉':''));
        ?>
        <tr>
          <td><strong><?= $medal ?: ($i+1) ?></strong></td>
          <td><a href="/admin/user-detail.php?id=<?= $u['id'] ?>"><?= h($u['name']) ?></a></td>
          <td><?php if ($u['level_name']): ?><span class="badge" style="background:<?= h($u['level_color']) ?>"><?= h($u['level_name']) ?></span><?php endif; ?></td>
          <td>৳<?= number_format($u['earned'],2) ?></td>
        </tr>
        <?php endforeach; ?>
        <?php if (!$leaders): ?><tr><td colspan="4" style="text-align:center;color:#888;">No data.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

</div>
<?php require ROOT_PATH . '/admin/includes/footer.php'; ?>
