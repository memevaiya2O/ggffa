<?php
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/includes/settings-loader.php';
requireAdmin();
$pdo = getDB();
$pageTitle = 'Level System';
$adminPage = 'levels';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $action = $_POST['action'] ?? '';
    if ($action === 'save_all') {
        $ids = $_POST['level_id'] ?? [];
        foreach ($ids as $i => $lid) {
            $pdo->prepare("UPDATE levels SET name=:n,icon=:ic,color=:c,required_points=:rp,levelup_bonus=:lb,daily_withdraw_limit=:dwl,can_access_vip=:vip WHERE id=:id")
                ->execute([':n'=>$_POST['name'][$i],':ic'=>$_POST['icon'][$i],':c'=>$_POST['color'][$i],':rp'=>(int)$_POST['required_points'][$i],':lb'=>(float)$_POST['levelup_bonus'][$i],':dwl'=>(float)$_POST['daily_withdraw_limit'][$i],':vip'=>isset($_POST['can_access_vip'][$i])?1:0,':id'=>(int)$lid]);
        }
        $_SESSION['flash'] = 'Levels saved!';
    } elseif ($action === 'add') {
        $pdo->prepare("INSERT INTO levels (name,icon,color,required_points,levelup_bonus,daily_withdraw_limit,can_access_vip,sort_order) VALUES(:n,:ic,:c,:rp,:lb,:dwl,:vip,(SELECT COALESCE(MAX(sort_order),0)+1 FROM levels l2))")
            ->execute([':n'=>trim($_POST['name'][0]??'New Level'),':ic'=>'fa-medal',':c'=>'#00C896',':rp'=>0,':lb'=>0,':dwl'=>100,':vip'=>0]);
        $_SESSION['flash'] = 'Level added!';
    } elseif ($action === 'delete') {
        $pdo->prepare("DELETE FROM levels WHERE id=:id")->execute([':id'=>(int)$_POST['level_id_del']]);
        $_SESSION['flash'] = 'Level deleted.';
    }
    redirect('/admin/levels.php');
}
$flash = $_SESSION['flash'] ?? ''; unset($_SESSION['flash']);
$levels = $pdo->query("SELECT * FROM levels ORDER BY sort_order,required_points")->fetchAll();
require ROOT_PATH . '/admin/includes/header.php';
?>
<?php if ($flash): ?><div class="alert alert-success" style="margin-bottom:20px;"><?= h($flash) ?></div><?php endif; ?>
<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">Level Configuration</div>
    <form method="post" style="display:inline"><<?= csrfField() ?><input type="hidden" name="action" value="add"><button type="submit" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Add Level</button></form>
  </div>
  <form method="post">
    <?= csrfField() ?>
    <input type="hidden" name="action" value="save_all">
    <div class="admin-table-wrap">
      <table class="admin-table">
        <thead><tr><th>#</th><th>Name</th><th>Icon</th><th>Color</th><th>Req. Points</th><th>Lvl-Up Bonus</th><th>Daily Limit</th><th>VIP Access</th><th></th></tr></thead>
        <tbody>
          <?php foreach ($levels as $i => $l): ?>
            <tr>
              <td><?= $i+1 ?></td>
              <td><input type="hidden" name="level_id[]" value="<?= $l['id'] ?>"><input type="text" name="name[]" class="admin-input" value="<?= h($l['name']) ?>" style="width:100px" required></td>
              <td><input type="text" name="icon[]" class="admin-input" value="<?= h($l['icon']) ?>" style="width:100px" placeholder="fa-medal"></td>
              <td><input type="color" name="color[]" value="<?= h($l['color']) ?>" style="height:36px;border:none;border-radius:6px;cursor:pointer;padding:2px;width:48px;"></td>
              <td><input type="number" name="required_points[]" class="admin-input" value="<?= $l['required_points'] ?>" min="0" style="width:90px"></td>
              <td><input type="number" name="levelup_bonus[]" class="admin-input" value="<?= $l['levelup_bonus'] ?>" step="0.01" min="0" style="width:90px"></td>
              <td><input type="number" name="daily_withdraw_limit[]" class="admin-input" value="<?= $l['daily_withdraw_limit'] ?>" step="0.01" min="0" style="width:90px"></td>
              <td style="text-align:center"><input type="checkbox" name="can_access_vip[<?= $i ?>]" value="1" <?= $l['can_access_vip']?'checked':'' ?> style="width:18px;height:18px;"></td>
              <td>
                <form method="post" style="display:inline"><?= csrfField() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="level_id_del" value="<?= $l['id'] ?>"><button type="submit" class="action-btn-sm action-btn-delete" data-confirm="Delete this level?"><i class="fa-solid fa-trash"></i></button></form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <button type="submit" class="btn btn-primary" style="margin-top:16px;"><i class="fa-solid fa-save"></i> Save All Levels</button>
  </form>
</div>
<?php require ROOT_PATH . '/admin/includes/footer.php'; ?>
