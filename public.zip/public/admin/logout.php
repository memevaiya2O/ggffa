<?php
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/includes/settings-loader.php';
session_destroy();
header('Location: /admin/login.php');
exit;
