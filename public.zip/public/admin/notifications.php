<?php
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/includes/settings-loader.php';
requireAdmin();
$pdo = getDB();
$pageTitle = 'Notifications';
$adminPage = 'notifications';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'broadcast') {
        $title   = trim($_POST['title'] ?? '');
        $message = trim($_POST['message'] ?? '');
        $target  = $_POST['target'] ?? 'all';
        if ($title && $message) {
            if ($target === 'all') {
                $uids = $pdo->query("SELECT id FROM users WHERE status='active'")->fetchAll(\PDO::FETCH_COLUMN);
            } else {
                $uids = [(int)$target];
            }
            foreach ($uids as $uid) {
                createNotification((int)$uid, 'broadcast', $title, $message);
            }
            $_SESSION['flash'] = 'Broadcast sent to ' . count($uids) . ' user(s).';
        }
    } elseif ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        $pdo->prepare("DELETE FROM notifications WHERE id=:id")->execute([':id'=>$id]);
        $_SESSION['flash'] = 'Notification deleted.';
    } elseif ($action === 'delete_all') {
        $pdo->exec("DELETE FROM notifications");
        $_SESSION['flash'] = 'All notifications cleared.';
    } elseif ($action === 'mark_read') {
        $pdo->exec("UPDATE notifications SET is_read=true");
        $_SESSION['flash'] = 'All marked as read.';
    }
    redirect('/admin/notifications.php');
}

$flash = $_SESSION['flash'] ?? ''; unset($_SESSION['flash']);
$page  = max(1,(int)($_GET['page']??1));
$limit = 30; $offset = ($page-1)*$limit;
$total = (int)$pdo->query("SELECT COUNT(*) FROM notifications")->fetchColumn();
$notifs = $pdo->query("SELECT n.*,u.name as user_name FROM notifications n LEFT JOIN users u ON u.id=n.user_id ORDER BY n.created_at DESC LIMIT $limit OFFSET $offset")->fetchAll();
$users = $pdo->query("SELECT id,name FROM users WHERE status='active' ORDER BY name LIMIT 500")->fetchAll();
require ROOT_PATH . '/admin/includes/header.php';
?>
<?php if ($flash): ?><div class="alert alert-success" style="margin-bottom:20px;"><?= h($flash) ?></div><?php endif; ?>

<div class="admin-grid-2" style="gap:24px;display:grid;grid-template-columns:1fr 1.8fr;">

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">Send Broadcast</div></div>
  <div class="admin-card-body">
    <form method="post">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="broadcast">
      <div class="form-group">
        <label>Target</label>
        <select name="target" class="form-control">
          <option value="all">All Active Users</option>
          <?php foreach ($users as $u): ?>
          <option value="<?= $u['id'] ?>"><?= h($u['name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group">
        <label>Title</label>
        <input type="text" name="title" class="form-control" placeholder="Notification title" required>
      </div>
      <div class="form-group">
        <label>Message</label>
        <textarea name="message" class="form-control" rows="4" placeholder="Write your message..." required></textarea>
      </div>
      <button class="btn btn-primary">Send Broadcast</button>
    </form>
  </div>
</div>

<div class="admin-card">
  <div class="admin-card-header">
    <div class="admin-card-title">Recent Notifications (<?= $total ?>)</div>
    <div style="display:flex;gap:8px;">
      <form method="post" style="display:inline" onsubmit="return confirm('Mark all as read?')">
        <?= csrfField() ?><input type="hidden" name="action" value="mark_read">
        <button class="btn btn-secondary btn-sm">Mark All Read</button>
      </form>
      <form method="post" style="display:inline" onsubmit="return confirm('Delete ALL notifications? This is irreversible.')">
        <?= csrfField() ?><input type="hidden" name="action" value="delete_all">
        <button class="btn btn-danger btn-sm">Clear All</button>
      </form>
    </div>
  </div>
  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>User</th><th>Type</th><th>Title</th><th>Time</th><th>Read</th><th>Del</th></tr></thead>
      <tbody>
        <?php foreach ($notifs as $n): ?>
        <tr>
          <td><?= h($n['user_name'] ?? 'N/A') ?></td>
          <td><span class="badge badge-info"><?= h($n['type']) ?></span></td>
          <td title="<?= h($n['message']) ?>"><?= h(mb_strimwidth($n['title'],0,40,'…')) ?></td>
          <td style="font-size:12px;"><?= date('d M H:i',strtotime($n['created_at'])) ?></td>
          <td><?= $n['is_read']?'<span style="color:green">✓</span>':'<span style="color:#aaa">✗</span>' ?></td>
          <td>
            <form method="post" style="display:inline" onsubmit="return confirm('Delete?')">
              <?= csrfField() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $n['id'] ?>">
              <button class="btn btn-danger btn-xs">×</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (!$notifs): ?><tr><td colspan="6" style="text-align:center;color:#888;">No notifications.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php if ($total > $limit): ?>
  <div style="padding:12px;text-align:center;">
    <?php for ($i=1;$i<=ceil($total/$limit);$i++): ?>
    <a href="?page=<?= $i ?>" class="btn btn-xs <?= $page==$i?'btn-primary':'btn-secondary' ?>"><?= $i ?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
</div>

</div>
<?php require ROOT_PATH . '/admin/includes/footer.php'; ?>
