<?php
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/includes/settings-loader.php';
requireAdmin();
$pdo = getDB();
$pageTitle = 'Static Pages';
$adminPage = 'pages';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'save') {
        $id      = (int)($_POST['id'] ?? 0);
        $title   = trim($_POST['title'] ?? '');
        $slug    = trim($_POST['slug'] ?? '');
        $content = $_POST['content'] ?? '';
        $status  = $_POST['status'] ?? 'published';
        $slug    = preg_replace('/[^a-z0-9\-]/', '', strtolower($slug));
        if ($title && $slug) {
            if ($id) {
                $pdo->prepare("UPDATE pages SET title=:t,slug=:s,content=:c,status=:st WHERE id=:id")
                    ->execute([':t'=>$title,':s'=>$slug,':c'=>$content,':st'=>$status,':id'=>$id]);
            } else {
                $pdo->prepare("INSERT INTO pages (title,slug,content,status) VALUES(:t,:s,:c,:st)")
                    ->execute([':t'=>$title,':s'=>$slug,':c'=>$content,':st'=>$status]);
            }
            $_SESSION['flash'] = 'Page saved.';
        }
    } elseif ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        $pdo->prepare("DELETE FROM pages WHERE id=:id")->execute([':id'=>$id]);
        $_SESSION['flash'] = 'Page deleted.';
    } elseif ($action === 'toggle') {
        $id  = (int)($_POST['id'] ?? 0);
        $cur = $pdo->query("SELECT status FROM pages WHERE id=$id")->fetchColumn();
        $pdo->prepare("UPDATE pages SET status=:s WHERE id=:id")->execute([':s'=>$cur==='published'?'draft':'published',':id'=>$id]);
        $_SESSION['flash'] = 'Status toggled.';
    }
    redirect('/admin/pages.php');
}

$flash   = $_SESSION['flash'] ?? ''; unset($_SESSION['flash']);
$editId  = (int)($_GET['edit'] ?? 0);
$editPage = $editId ? $pdo->query("SELECT * FROM pages WHERE id=$editId")->fetch() : null;
$pages   = $pdo->query("SELECT * FROM pages ORDER BY created_at DESC")->fetchAll();
require ROOT_PATH . '/admin/includes/header.php';
?>
<?php if ($flash): ?><div class="alert alert-success" style="margin-bottom:20px;"><?= h($flash) ?></div><?php endif; ?>

<div class="admin-grid-2" style="display:grid;grid-template-columns:1fr 1.5fr;gap:24px;">

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title"><?= $editPage ? 'Edit Page' : 'New Page' ?></div></div>
  <div class="admin-card-body">
    <form method="post">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" value="<?= $editPage ? $editPage['id'] : 0 ?>">
      <div class="form-group">
        <label>Title</label>
        <input type="text" name="title" id="pg-title" class="form-control" value="<?= h($editPage['title'] ?? '') ?>" required oninput="autoSlug(this.value)">
      </div>
      <div class="form-group">
        <label>Slug (URL)</label>
        <div style="display:flex;align-items:center;gap:8px;">
          <span style="color:#888;">/page/</span>
          <input type="text" name="slug" id="pg-slug" class="form-control" value="<?= h($editPage['slug'] ?? '') ?>" required>
        </div>
      </div>
      <div class="form-group">
        <label>Content (HTML allowed)</label>
        <textarea name="content" class="form-control" rows="12" style="font-family:monospace;"><?= h($editPage['content'] ?? '') ?></textarea>
      </div>
      <div class="form-group">
        <label>Status</label>
        <select name="status" class="form-control">
          <option value="published" <?= ($editPage['status']??'published')==='published'?'selected':'' ?>>Published</option>
          <option value="draft" <?= ($editPage['status']??'')==='draft'?'selected':'' ?>>Draft</option>
        </select>
      </div>
      <button class="btn btn-primary">Save Page</button>
      <?php if ($editPage): ?><a href="/admin/pages.php" class="btn btn-secondary">Cancel</a><?php endif; ?>
    </form>
  </div>
</div>

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">All Pages (<?= count($pages) ?>)</div></div>
  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>Title</th><th>Slug</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
        <?php foreach ($pages as $p): ?>
        <tr>
          <td><strong><?= h($p['title']) ?></strong></td>
          <td><a href="/page/<?= h($p['slug']) ?>" target="_blank" style="color:#667eea;">/page/<?= h($p['slug']) ?></a></td>
          <td>
            <form method="post" style="display:inline">
              <?= csrfField() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= $p['id'] ?>">
              <button class="btn btn-xs <?= $p['status']==='published'?'btn-success':'btn-secondary' ?>"><?= $p['status'] ?></button>
            </form>
          </td>
          <td>
            <a href="?edit=<?= $p['id'] ?>" class="btn btn-warning btn-xs">Edit</a>
            <form method="post" style="display:inline" onsubmit="return confirm('Delete this page?')">
              <?= csrfField() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $p['id'] ?>">
              <button class="btn btn-danger btn-xs">Del</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (!$pages): ?><tr><td colspan="4" style="text-align:center;color:#888;">No pages yet.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

</div>
<script>
function autoSlug(val) {
  if (!document.getElementById('pg-slug').dataset.manual) {
    document.getElementById('pg-slug').value = val.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
  }
}
document.getElementById('pg-slug').addEventListener('input', function(){ this.dataset.manual = '1'; });
</script>
<?php require ROOT_PATH . '/admin/includes/footer.php'; ?>
