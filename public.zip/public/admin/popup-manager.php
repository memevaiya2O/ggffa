<?php
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/includes/settings-loader.php';
requireAdmin();
$pdo = getDB();
$pageTitle = 'Popup Manager';
$adminPage = 'popup-manager';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'save') {
        $id       = (int)($_POST['id'] ?? 0);
        $title    = trim($_POST['title'] ?? '');
        $content  = $_POST['content'] ?? '';
        $type     = $_POST['type'] ?? 'info';
        $trigger  = $_POST['trigger'] ?? 'pageload';
        $delay    = (int)($_POST['delay'] ?? 0);
        $pages    = trim($_POST['show_pages'] ?? '');
        $btnText  = trim($_POST['btn_text'] ?? '');
        $btnLink  = trim($_POST['btn_link'] ?? '');
        $status   = $_POST['status'] ?? 'active';
        $startDate = $_POST['start_date'] ?? null;
        $endDate   = $_POST['end_date'] ?? null;

        $data = json_encode([
            'title'=>$title,'content'=>$content,'type'=>$type,'trigger'=>$trigger,
            'delay'=>$delay,'pages'=>$pages,'btn_text'=>$btnText,'btn_link'=>$btnLink,
            'start_date'=>$startDate,'end_date'=>$endDate,
        ]);
        if ($id) {
            $pdo->prepare("UPDATE popups SET title=:t,data=:d,status=:s WHERE id=:id")
                ->execute([':t'=>$title,':d'=>$data,':s'=>$status,':id'=>$id]);
        } else {
            $pdo->prepare("INSERT INTO popups (title,data,status) VALUES(:t,:d,:s)")
                ->execute([':t'=>$title,':d'=>$data,':s'=>$status]);
        }
        $_SESSION['flash'] = 'Popup saved.';
    } elseif ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        $pdo->prepare("DELETE FROM popups WHERE id=:id")->execute([':id'=>$id]);
        $_SESSION['flash'] = 'Popup deleted.';
    } elseif ($action === 'toggle') {
        $id  = (int)($_POST['id'] ?? 0);
        $cur = $pdo->query("SELECT status FROM popups WHERE id=$id")->fetchColumn();
        $pdo->prepare("UPDATE popups SET status=:s WHERE id=:id")->execute([':s'=>$cur==='active'?'inactive':'active',':id'=>$id]);
        $_SESSION['flash'] = 'Status updated.';
    }
    redirect('/admin/popup-manager.php');
}

$flash  = $_SESSION['flash'] ?? ''; unset($_SESSION['flash']);
$editId = (int)($_GET['edit'] ?? 0);
$editPop = null;
if ($editId) {
    $row = $pdo->query("SELECT * FROM popups WHERE id=$editId")->fetch();
    if ($row) { $editPop = $row; $editPop['_data'] = json_decode($row['data'], true) ?? []; }
}
$popups = $pdo->query("SELECT * FROM popups ORDER BY created_at DESC")->fetchAll();
require ROOT_PATH . '/admin/includes/header.php';
$d = $editPop['_data'] ?? [];
?>
<?php if ($flash): ?><div class="alert alert-success" style="margin-bottom:20px;"><?= h($flash) ?></div><?php endif; ?>

<div class="admin-grid-2" style="display:grid;grid-template-columns:1fr 1.5fr;gap:24px;">

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title"><?= $editPop ? 'Edit Popup' : 'New Popup' ?></div></div>
  <div class="admin-card-body">
    <form method="post">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" value="<?= $editPop ? $editPop['id'] : 0 ?>">
      <div class="form-group"><label>Title</label><input type="text" name="title" class="form-control" value="<?= h($editPop['title'] ?? $d['title'] ?? '') ?>" required></div>
      <div class="form-group"><label>Content (HTML)</label><textarea name="content" class="form-control" rows="5"><?= h($d['content'] ?? '') ?></textarea></div>
      <div class="form-group"><label>Type</label>
        <select name="type" class="form-control">
          <?php foreach (['info'=>'Info','success'=>'Success','warning'=>'Warning','promo'=>'Promo','announcement'=>'Announcement'] as $v=>$l): ?>
          <option value="<?= $v ?>" <?= ($d['type']??'info')===$v?'selected':'' ?>><?= $l ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group"><label>Trigger</label>
        <select name="trigger" class="form-control">
          <option value="pageload" <?= ($d['trigger']??'pageload')==='pageload'?'selected':'' ?>>Page Load</option>
          <option value="exit_intent" <?= ($d['trigger']??'')==='exit_intent'?'selected':'' ?>>Exit Intent</option>
          <option value="scroll" <?= ($d['trigger']??'')==='scroll'?'selected':'' ?>>On Scroll</option>
        </select>
      </div>
      <div class="form-group"><label>Delay (seconds)</label><input type="number" name="delay" class="form-control" value="<?= h($d['delay'] ?? 0) ?>" min="0"></div>
      <div class="form-group"><label>Show on Pages (comma-separated paths, empty = all)</label><input type="text" name="show_pages" class="form-control" value="<?= h($d['pages'] ?? '') ?>" placeholder="/,/tasks.php,/register.php"></div>
      <div class="form-group"><label>Button Text</label><input type="text" name="btn_text" class="form-control" value="<?= h($d['btn_text'] ?? '') ?>" placeholder="Get Started"></div>
      <div class="form-group"><label>Button Link</label><input type="text" name="btn_link" class="form-control" value="<?= h($d['btn_link'] ?? '') ?>" placeholder="/register.php"></div>
      <div class="form-group"><label>Start Date (optional)</label><input type="datetime-local" name="start_date" class="form-control" value="<?= h($d['start_date'] ?? '') ?>"></div>
      <div class="form-group"><label>End Date (optional)</label><input type="datetime-local" name="end_date" class="form-control" value="<?= h($d['end_date'] ?? '') ?>"></div>
      <div class="form-group"><label>Status</label>
        <select name="status" class="form-control">
          <option value="active" <?= ($editPop['status']??'active')==='active'?'selected':'' ?>>Active</option>
          <option value="inactive" <?= ($editPop['status']??'')==='inactive'?'selected':'' ?>>Inactive</option>
        </select>
      </div>
      <button class="btn btn-primary">Save Popup</button>
      <?php if ($editPop): ?><a href="/admin/popup-manager.php" class="btn btn-secondary">Cancel</a><?php endif; ?>
    </form>
  </div>
</div>

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">All Popups (<?= count($popups) ?>)</div></div>
  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>Title</th><th>Type</th><th>Trigger</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
        <?php foreach ($popups as $p):
          $pd = json_decode($p['data'], true) ?? [];
        ?>
        <tr>
          <td><strong><?= h($p['title']) ?></strong></td>
          <td><span class="badge badge-info"><?= h($pd['type'] ?? '-') ?></span></td>
          <td><?= h($pd['trigger'] ?? '-') ?></td>
          <td>
            <form method="post" style="display:inline">
              <?= csrfField() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= $p['id'] ?>">
              <button class="btn btn-xs <?= $p['status']==='active'?'btn-success':'btn-secondary' ?>"><?= $p['status'] ?></button>
            </form>
          </td>
          <td>
            <a href="?edit=<?= $p['id'] ?>" class="btn btn-warning btn-xs">Edit</a>
            <form method="post" style="display:inline" onsubmit="return confirm('Delete?')">
              <?= csrfField() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $p['id'] ?>">
              <button class="btn btn-danger btn-xs">Del</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (!$popups): ?><tr><td colspan="5" style="text-align:center;color:#888;">No popups yet.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

</div>
<?php require ROOT_PATH . '/admin/includes/footer.php'; ?>
