<?php
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/includes/settings-loader.php';
requireAdmin();
$pdo = getDB();
$pageTitle = 'Referral Config';
$adminPage = 'referral-config';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $fields = [
        'referral_enabled','referral_bonus_referrer','referral_bonus_referee',
        'referral_min_withdraw','referral_max_per_user','referral_bonus_on',
    ];
    foreach ($fields as $k) {
        $v = trim($_POST[$k] ?? '');
        $pdo->prepare("UPDATE settings SET value=:v WHERE key=:k")->execute([':v'=>$v,':k'=>$k]);
    }
    $_SESSION['flash'] = 'Referral settings saved.';
    redirect('/admin/referral-config.php');
}

$flash = $_SESSION['flash'] ?? ''; unset($_SESSION['flash']);
$s = [];
$rows = $pdo->query("SELECT key,value FROM settings WHERE key LIKE 'referral_%'")->fetchAll();
foreach ($rows as $r) $s[$r['key']] = $r['value'];
$g = fn($k,$d='') => $s[$k] ?? $d;

// Stats
$totalReferrals = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE referred_by IS NOT NULL")->fetchColumn();
$topReferrers   = $pdo->query("SELECT u.name, COUNT(r.id) as cnt FROM users r JOIN users u ON u.id=r.referred_by GROUP BY u.id,u.name ORDER BY cnt DESC LIMIT 10")->fetchAll();
require ROOT_PATH . '/admin/includes/header.php';
?>
<?php if ($flash): ?><div class="alert alert-success" style="margin-bottom:20px;"><?= h($flash) ?></div><?php endif; ?>

<div class="admin-grid-2" style="display:grid;grid-template-columns:1fr 1.5fr;gap:24px;">

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">Referral Settings</div></div>
  <div class="admin-card-body">
    <form method="post">
      <?= csrfField() ?>
      <div class="form-group">
        <label>Referral System Enabled</label>
        <select name="referral_enabled" class="form-control">
          <option value="1" <?= $g('referral_enabled','1')==='1'?'selected':'' ?>>Yes</option>
          <option value="0" <?= $g('referral_enabled','1')==='0'?'selected':'' ?>>No</option>
        </select>
      </div>
      <div class="form-group">
        <label>Bonus for Referrer (BDT)</label>
        <input type="number" name="referral_bonus_referrer" class="form-control" value="<?= h($g('referral_bonus_referrer','10')) ?>" step="0.01" min="0">
      </div>
      <div class="form-group">
        <label>Bonus for Referee (BDT)</label>
        <input type="number" name="referral_bonus_referee" class="form-control" value="<?= h($g('referral_bonus_referee','5')) ?>" step="0.01" min="0">
      </div>
      <div class="form-group">
        <label>Max Referrals per User (0 = unlimited)</label>
        <input type="number" name="referral_max_per_user" class="form-control" value="<?= h($g('referral_max_per_user','0')) ?>" min="0">
      </div>
      <div class="form-group">
        <label>Bonus Triggered On</label>
        <select name="referral_bonus_on" class="form-control">
          <option value="register" <?= $g('referral_bonus_on','register')==='register'?'selected':'' ?>>Registration</option>
          <option value="first_task" <?= $g('referral_bonus_on','register')==='first_task'?'selected':'' ?>>First Task Approved</option>
        </select>
      </div>
      <div class="form-group">
        <label>Min Withdraw to Unlock Referral Bonus (0 = no min)</label>
        <input type="number" name="referral_min_withdraw" class="form-control" value="<?= h($g('referral_min_withdraw','0')) ?>" step="0.01" min="0">
      </div>
      <button class="btn btn-primary">Save Settings</button>
    </form>
  </div>
</div>

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">Top Referrers — Total Referred: <?= $totalReferrals ?></div></div>
  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>#</th><th>User</th><th>Referrals</th></tr></thead>
      <tbody>
        <?php foreach ($topReferrers as $i=>$r): ?>
        <tr><td><?= $i+1 ?></td><td><?= h($r['name']) ?></td><td><?= $r['cnt'] ?></td></tr>
        <?php endforeach; ?>
        <?php if (!$topReferrers): ?><tr><td colspan="3" style="text-align:center;color:#888;">No referrals yet.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

</div>
<?php require ROOT_PATH . '/admin/includes/footer.php'; ?>
