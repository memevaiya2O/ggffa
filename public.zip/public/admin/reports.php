<?php
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/includes/settings-loader.php';
requireAdmin();
$pdo = getDB();
$pageTitle = 'Reports & Analytics';
$adminPage = 'reports';

$range = $_GET['range'] ?? '30';
$days  = in_array($range,['7','30','90','365']) ? (int)$range : 30;

// Summary stats
$totalUsers      = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$newUsers        = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE created_at >= NOW() - INTERVAL '$days days'")->fetchColumn();
$totalTasks      = (int)$pdo->query("SELECT COUNT(*) FROM tasks WHERE status='active'")->fetchColumn();
$totalSubs       = (int)$pdo->query("SELECT COUNT(*) FROM submissions")->fetchColumn();
$pendingSubs     = (int)$pdo->query("SELECT COUNT(*) FROM submissions WHERE status='pending'")->fetchColumn();
$approvedSubs    = (int)$pdo->query("SELECT COUNT(*) FROM submissions WHERE status='approved'")->fetchColumn();
$totalWithdrawn  = (float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM withdrawals WHERE status='approved'")->fetchColumn();
$pendingWithdraw = (float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM withdrawals WHERE status='pending'")->fetchColumn();
$totalEarned     = (float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE type IN ('task_reward','referral_bonus','spin_reward') AND amount > 0")->fetchColumn();
$totalSpins      = (int)$pdo->query("SELECT COUNT(*) FROM spin_history WHERE created_at >= NOW() - INTERVAL '$days days'")->fetchColumn();

// Daily registrations
$dailyRegs = $pdo->query("SELECT DATE(created_at) as d, COUNT(*) as cnt FROM users WHERE created_at >= NOW() - INTERVAL '$days days' GROUP BY DATE(created_at) ORDER BY d")->fetchAll();
// Daily submissions
$dailySubs = $pdo->query("SELECT DATE(created_at) as d, COUNT(*) as cnt FROM submissions WHERE created_at >= NOW() - INTERVAL '$days days' GROUP BY DATE(created_at) ORDER BY d")->fetchAll();
// Top tasks
$topTasks = $pdo->query("SELECT t.title, COUNT(s.id) as cnt FROM submissions s JOIN tasks t ON t.id=s.task_id WHERE s.status='approved' GROUP BY t.id,t.title ORDER BY cnt DESC LIMIT 10")->fetchAll();
// Top earners
$topEarners = $pdo->query("SELECT u.name,u.email,u.balance FROM users u ORDER BY u.balance DESC LIMIT 10")->fetchAll();
// Withdrawal by method
$wByMethod = $pdo->query("SELECT method, COUNT(*) as cnt, SUM(amount) as total FROM withdrawals WHERE status='approved' GROUP BY method ORDER BY total DESC")->fetchAll();

require ROOT_PATH . '/admin/includes/header.php';
?>
<div style="display:flex;gap:12px;align-items:center;margin-bottom:20px;flex-wrap:wrap;">
  <strong>Date Range:</strong>
  <?php foreach (['7'=>'7 Days','30'=>'30 Days','90'=>'90 Days','365'=>'1 Year'] as $v=>$l): ?>
  <a href="?range=<?= $v ?>" class="btn btn-sm <?= $range==$v?'btn-primary':'btn-secondary' ?>"><?= $l ?></a>
  <?php endforeach; ?>
</div>

<div class="admin-stats-grid" style="grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:16px;display:grid;margin-bottom:24px;">
  <div class="stat-card"><div class="stat-value"><?= number_format($totalUsers) ?></div><div class="stat-label">Total Users</div></div>
  <div class="stat-card"><div class="stat-value"><?= number_format($newUsers) ?></div><div class="stat-label">New Users (<?= $days ?>d)</div></div>
  <div class="stat-card"><div class="stat-value"><?= number_format($totalTasks) ?></div><div class="stat-label">Active Tasks</div></div>
  <div class="stat-card"><div class="stat-value"><?= number_format($totalSubs) ?></div><div class="stat-label">Total Submissions</div></div>
  <div class="stat-card"><div class="stat-value"><?= number_format($pendingSubs) ?></div><div class="stat-label">Pending Review</div></div>
  <div class="stat-card"><div class="stat-value"><?= number_format($approvedSubs) ?></div><div class="stat-label">Approved</div></div>
  <div class="stat-card"><div class="stat-value">৳<?= number_format($totalEarned,2) ?></div><div class="stat-label">Total Earned</div></div>
  <div class="stat-card"><div class="stat-value">৳<?= number_format($totalWithdrawn,2) ?></div><div class="stat-label">Total Withdrawn</div></div>
  <div class="stat-card"><div class="stat-value">৳<?= number_format($pendingWithdraw,2) ?></div><div class="stat-label">Pending Withdraw</div></div>
  <div class="stat-card"><div class="stat-value"><?= number_format($totalSpins) ?></div><div class="stat-label">Spins (<?= $days ?>d)</div></div>
</div>

<div class="admin-grid-2" style="display:grid;grid-template-columns:1fr 1fr;gap:24px;margin-bottom:24px;">
  <div class="admin-card">
    <div class="admin-card-header"><div class="admin-card-title">Registrations (<?= $days ?> days)</div></div>
    <div class="admin-card-body">
      <canvas id="reg-chart" height="200"></canvas>
    </div>
  </div>
  <div class="admin-card">
    <div class="admin-card-header"><div class="admin-card-title">Submissions (<?= $days ?> days)</div></div>
    <div class="admin-card-body">
      <canvas id="sub-chart" height="200"></canvas>
    </div>
  </div>
</div>

<div class="admin-grid-2" style="display:grid;grid-template-columns:1fr 1fr;gap:24px;">
  <div class="admin-card">
    <div class="admin-card-header"><div class="admin-card-title">Top 10 Tasks</div></div>
    <div class="admin-table-wrap">
      <table class="admin-table">
        <thead><tr><th>#</th><th>Task</th><th>Completions</th></tr></thead>
        <tbody>
          <?php foreach ($topTasks as $i=>$t): ?>
          <tr><td><?= $i+1 ?></td><td><?= h($t['title']) ?></td><td><?= $t['cnt'] ?></td></tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
  <div class="admin-card">
    <div class="admin-card-header"><div class="admin-card-title">Top Earners</div></div>
    <div class="admin-table-wrap">
      <table class="admin-table">
        <thead><tr><th>#</th><th>User</th><th>Balance</th></tr></thead>
        <tbody>
          <?php foreach ($topEarners as $i=>$u): ?>
          <tr><td><?= $i+1 ?></td><td><?= h($u['name']) ?></td><td>৳<?= number_format($u['balance'],2) ?></td></tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<div class="admin-card" style="margin-top:24px;">
  <div class="admin-card-header"><div class="admin-card-title">Withdrawals by Method</div></div>
  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>Method</th><th>Count</th><th>Total (BDT)</th></tr></thead>
      <tbody>
        <?php foreach ($wByMethod as $w): ?>
        <tr><td><?= h($w['method']) ?></td><td><?= $w['cnt'] ?></td><td>৳<?= number_format($w['total'],2) ?></td></tr>
        <?php endforeach; ?>
        <?php if (!$wByMethod): ?><tr><td colspan="3" style="text-align:center;color:#888;">No data.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4/dist/chart.umd.min.js"></script>
<script>
const regLabels = <?= json_encode(array_column($dailyRegs,'d')) ?>;
const regData   = <?= json_encode(array_column($dailyRegs,'cnt')) ?>;
const subLabels = <?= json_encode(array_column($dailySubs,'d')) ?>;
const subData   = <?= json_encode(array_column($dailySubs,'cnt')) ?>;

new Chart(document.getElementById('reg-chart'), {
  type:'line',
  data:{ labels:regLabels, datasets:[{ label:'Registrations', data:regData, borderColor:'#667eea', backgroundColor:'rgba(102,126,234,0.1)', fill:true, tension:0.3 }] },
  options:{ responsive:true, plugins:{legend:{display:false}}, scales:{ y:{beginAtZero:true, ticks:{precision:0}} } }
});
new Chart(document.getElementById('sub-chart'), {
  type:'bar',
  data:{ labels:subLabels, datasets:[{ label:'Submissions', data:subData, backgroundColor:'#4CAF50' }] },
  options:{ responsive:true, plugins:{legend:{display:false}}, scales:{ y:{beginAtZero:true, ticks:{precision:0}} } }
});
</script>
<?php require ROOT_PATH . '/admin/includes/footer.php'; ?>
