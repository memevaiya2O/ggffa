<?php
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/includes/settings-loader.php';
requireAdmin();
$pdo = getDB();
$pageTitle = 'General Settings';
$adminPage = 'settings';
require_once ROOT_PATH . '/includes/upload.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $fields = ['site_name','site_tagline','admin_email','contact_email','currency_symbol','currency_name','daily_bonus_amount','welcome_bonus','min_withdraw','registration_open','maintenance_mode','maintenance_message'];
    $stmt = $pdo->prepare("INSERT INTO settings (key,value,updated_at) VALUES(:k,:v,NOW()) ON CONFLICT (key) DO UPDATE SET value=:v2, updated_at=NOW()");
    foreach ($fields as $f) {
        $val = trim($_POST[$f] ?? '');
        $stmt->execute([':k'=>$f,':v'=>$val,':v2'=>$val]);
    }
    // Logo upload
    if (!empty($_FILES['logo']['name'])) {
        $up = handleUpload('logo','uploads/logos');
        if ($up['success']) { $stmt->execute([':k'=>'site_logo',':v'=>$up['path'],':v2'=>$up['path']]); }
    }
    if (!empty($_FILES['favicon']['name'])) {
        $up = handleUpload('favicon','uploads/logos');
        if ($up['success']) { $stmt->execute([':k'=>'favicon',':v'=>$up['path'],':v2'=>$up['path']]); }
    }
    $_SESSION['flash'] = 'Settings saved!';
    redirect('/admin/settings.php');
}
$flash = $_SESSION['flash'] ?? ''; unset($_SESSION['flash']);
require ROOT_PATH . '/admin/includes/header.php';
?>
<?php if ($flash): ?><div class="alert alert-success" style="margin-bottom:20px;"><?= h($flash) ?></div><?php endif; ?>
<div class="admin-card">
  <form method="post" enctype="multipart/form-data">
    <?= csrfField() ?>
    <div class="admin-form-grid">
      <div class="admin-form-group"><label class="admin-label">Site Name</label><input type="text" name="site_name" class="admin-input" value="<?= h(getSetting('site_name','EarnBD')) ?>" required></div>
      <div class="admin-form-group"><label class="admin-label">Site Tagline</label><input type="text" name="site_tagline" class="admin-input" value="<?= h(getSetting('site_tagline')) ?>"></div>
      <div class="admin-form-group"><label class="admin-label">Admin Email</label><input type="email" name="admin_email" class="admin-input" value="<?= h(getSetting('admin_email')) ?>"></div>
      <div class="admin-form-group"><label class="admin-label">Contact Email</label><input type="email" name="contact_email" class="admin-input" value="<?= h(getSetting('contact_email')) ?>"></div>
      <div class="admin-form-group"><label class="admin-label">Currency Symbol</label><input type="text" name="currency_symbol" class="admin-input" value="<?= h(getSetting('currency_symbol','৳')) ?>" maxlength="5"></div>
      <div class="admin-form-group"><label class="admin-label">Currency Name</label><input type="text" name="currency_name" class="admin-input" value="<?= h(getSetting('currency_name','BDT')) ?>"></div>
      <div class="admin-form-group"><label class="admin-label">Daily Bonus Amount</label><input type="number" name="daily_bonus_amount" class="admin-input" step="0.01" value="<?= h(getSetting('daily_bonus_amount','5')) ?>"></div>
      <div class="admin-form-group"><label class="admin-label">Welcome Bonus</label><input type="number" name="welcome_bonus" class="admin-input" step="0.01" value="<?= h(getSetting('welcome_bonus','10')) ?>"></div>
      <div class="admin-form-group"><label class="admin-label">Min Withdraw Amount (global)</label><input type="number" name="min_withdraw" class="admin-input" step="0.01" value="<?= h(getSetting('min_withdraw','50')) ?>"></div>
      <div class="admin-form-group"><label class="admin-label">Site Logo</label><?php if ($l=getSetting('site_logo')): ?><img src="<?= h($l) ?>" style="height:40px;margin-bottom:8px;display:block;border-radius:6px;"><?php endif; ?><input type="file" name="logo" class="admin-input" accept="image/*"></div>
      <div class="admin-form-group"><label class="admin-label">Favicon</label><?php if ($f=getSetting('favicon')): ?><img src="<?= h($f) ?>" style="height:32px;margin-bottom:8px;display:block;"><?php endif; ?><input type="file" name="favicon" class="admin-input" accept="image/*"></div>
    </div>
    <hr style="margin:20px 0;border-color:#f0f0f0;">
    <div class="admin-form-grid">
      <div class="admin-form-group">
        <label class="toggle-label"><span class="toggle-switch"><input type="checkbox" name="registration_open" value="1" <?= getSetting('registration_open','1')==='1'?'checked':'' ?>><span class="toggle-slider"></span></span> Open Registration</label>
      </div>
      <div class="admin-form-group">
        <label class="toggle-label"><span class="toggle-switch"><input type="checkbox" name="maintenance_mode" value="1" <?= getSetting('maintenance_mode')==='1'?'checked':'' ?>><span class="toggle-slider"></span></span> Maintenance Mode</label>
      </div>
    </div>
    <div class="admin-form-group"><label class="admin-label">Maintenance Message</label><textarea name="maintenance_message" class="admin-input admin-textarea" rows="3"><?= h(getSetting('maintenance_message')) ?></textarea></div>
    <button type="submit" class="btn btn-primary"><i class="fa-solid fa-save"></i> Save Settings</button>
  </form>
</div>
<?php require ROOT_PATH . '/admin/includes/footer.php'; ?>
