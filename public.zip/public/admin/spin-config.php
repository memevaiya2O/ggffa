<?php
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/includes/settings-loader.php';
requireAdmin();
$pdo = getDB();
$pageTitle = 'Spin Wheel Config';
$adminPage = 'spin-config';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'save_segment') {
        $id     = (int)($_POST['id'] ?? 0);
        $label  = trim($_POST['label'] ?? '');
        $type   = $_POST['prize_type'] ?? 'coins';
        $value  = (float)($_POST['prize_value'] ?? 0);
        $weight = max(1,(int)($_POST['weight'] ?? 1));
        $color  = trim($_POST['color'] ?? '#4CAF50');
        if ($label) {
            if ($id) {
                $pdo->prepare("UPDATE spin_segments SET label=:l,prize_type=:pt,prize_value=:pv,weight=:w,color=:c WHERE id=:id")
                    ->execute([':l'=>$label,':pt'=>$type,':pv'=>$value,':w'=>$weight,':c'=>$color,':id'=>$id]);
            } else {
                $pdo->prepare("INSERT INTO spin_segments (label,prize_type,prize_value,weight,color) VALUES(:l,:pt,:pv,:w,:c)")
                    ->execute([':l'=>$label,':pt'=>$type,':pv'=>$value,':w'=>$weight,':c'=>$color]);
            }
            $_SESSION['flash'] = 'Segment saved.';
        }
    } elseif ($action === 'delete_segment') {
        $id = (int)($_POST['id'] ?? 0);
        $pdo->prepare("DELETE FROM spin_segments WHERE id=:id")->execute([':id'=>$id]);
        $_SESSION['flash'] = 'Segment deleted.';
    } elseif ($action === 'save_settings') {
        $keys = ['spin_enabled','spin_daily_limit','spin_cooldown_hours'];
        foreach ($keys as $k) {
            $v = trim($_POST[$k] ?? '');
            $pdo->prepare("UPDATE settings SET value=:v WHERE key=:k")->execute([':v'=>$v,':k'=>$k]);
        }
        $_SESSION['flash'] = 'Settings saved.';
    }
    redirect('/admin/spin-config.php');
}

$flash    = $_SESSION['flash'] ?? ''; unset($_SESSION['flash']);
$segments = $pdo->query("SELECT * FROM spin_segments ORDER BY id")->fetchAll();
$settings = [];
$rows = $pdo->query("SELECT key,value FROM settings WHERE key IN ('spin_enabled','spin_daily_limit','spin_cooldown_hours')")->fetchAll();
foreach ($rows as $r) $settings[$r['key']] = $r['value'];
require ROOT_PATH . '/admin/includes/header.php';
?>
<?php if ($flash): ?><div class="alert alert-success" style="margin-bottom:20px;"><?= h($flash) ?></div><?php endif; ?>

<div class="admin-grid-2" style="gap:24px;display:grid;grid-template-columns:1fr 1fr;">

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">Spin Settings</div></div>
  <div class="admin-card-body">
    <form method="post">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="save_settings">
      <div class="form-group">
        <label>Spin Wheel Enabled</label>
        <select name="spin_enabled" class="form-control">
          <option value="1" <?= ($settings['spin_enabled']??'1')==='1'?'selected':'' ?>>Yes</option>
          <option value="0" <?= ($settings['spin_enabled']??'1')==='0'?'selected':'' ?>>No</option>
        </select>
      </div>
      <div class="form-group">
        <label>Daily Spin Limit</label>
        <input type="number" name="spin_daily_limit" class="form-control" value="<?= h($settings['spin_daily_limit']??'1') ?>" min="1">
      </div>
      <div class="form-group">
        <label>Cooldown Hours</label>
        <input type="number" name="spin_cooldown_hours" class="form-control" value="<?= h($settings['spin_cooldown_hours']??'24') ?>" min="0">
      </div>
      <button class="btn btn-primary">Save Settings</button>
    </form>
  </div>
</div>

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">Add / Edit Segment</div></div>
  <div class="admin-card-body">
    <form method="post" id="seg-form">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="save_segment">
      <input type="hidden" name="id" id="seg-id" value="0">
      <div class="form-group">
        <label>Label</label>
        <input type="text" name="label" id="seg-label" class="form-control" placeholder="e.g. 50 Coins" required>
      </div>
      <div class="form-group">
        <label>Prize Type</label>
        <select name="prize_type" id="seg-type" class="form-control">
          <option value="coins">Coins</option>
          <option value="bonus">Bonus BDT</option>
          <option value="nothing">No Prize</option>
        </select>
      </div>
      <div class="form-group">
        <label>Prize Value</label>
        <input type="number" name="prize_value" id="seg-value" class="form-control" value="0" step="0.01" min="0">
      </div>
      <div class="form-group">
        <label>Weight (higher = more likely)</label>
        <input type="number" name="weight" id="seg-weight" class="form-control" value="1" min="1">
      </div>
      <div class="form-group">
        <label>Color</label>
        <input type="color" name="color" id="seg-color" value="#4CAF50" style="height:40px;width:100%;">
      </div>
      <button class="btn btn-primary" type="submit">Save Segment</button>
      <button class="btn btn-secondary" type="button" onclick="resetSegForm()">Clear</button>
    </form>
  </div>
</div>

</div>

<div class="admin-card" style="margin-top:24px;">
  <div class="admin-card-header"><div class="admin-card-title">Wheel Segments (<?= count($segments) ?>)</div></div>
  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>Label</th><th>Type</th><th>Value</th><th>Weight</th><th>Color</th><th>Actions</th></tr></thead>
      <tbody>
        <?php foreach ($segments as $s): ?>
        <tr>
          <td><?= h($s['label']) ?></td>
          <td><span class="badge badge-info"><?= h($s['prize_type']) ?></span></td>
          <td><?= h($s['prize_value']) ?></td>
          <td><?= $s['weight'] ?></td>
          <td><span style="display:inline-block;width:24px;height:24px;border-radius:4px;background:<?= h($s['color']) ?>;border:1px solid #ccc;"></span></td>
          <td>
            <button class="btn btn-warning btn-xs" onclick="editSeg(<?= htmlspecialchars(json_encode($s)) ?>)">Edit</button>
            <form method="post" style="display:inline" onsubmit="return confirm('Delete?')">
              <?= csrfField() ?><input type="hidden" name="action" value="delete_segment"><input type="hidden" name="id" value="<?= $s['id'] ?>">
              <button class="btn btn-danger btn-xs">Del</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<script>
function editSeg(s) {
  document.getElementById('seg-id').value = s.id;
  document.getElementById('seg-label').value = s.label;
  document.getElementById('seg-type').value = s.prize_type;
  document.getElementById('seg-value').value = s.prize_value;
  document.getElementById('seg-weight').value = s.weight;
  document.getElementById('seg-color').value = s.color;
  document.getElementById('seg-form').scrollIntoView({behavior:'smooth'});
}
function resetSegForm() {
  document.getElementById('seg-id').value = '0';
  document.getElementById('seg-form').reset();
}
</script>
<?php require ROOT_PATH . '/admin/includes/footer.php'; ?>
