<?php
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/includes/settings-loader.php';
requireAdmin();
$pdo = getDB();
$pageTitle = 'Submission Review';
$adminPage = 'submissions';

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $sid    = (int)($_POST['sub_id'] ?? 0);
    $msg    = '';

    if ($action === 'approve' && $sid) {
        $sub = $pdo->prepare("SELECT * FROM submissions WHERE id=:id AND status='pending'");
        $sub->execute([':id'=>$sid]);
        $sub = $sub->fetch();
        if ($sub) {
            $task = $pdo->prepare("SELECT * FROM tasks WHERE id=:id");
            $task->execute([':id'=>$sub['task_id']]);
            $task = $task->fetch();
            $pdo->prepare("UPDATE submissions SET status='approved', reviewed_at=NOW() WHERE id=:id")->execute([':id'=>$sid]);
            creditUser((int)$sub['user_id'], (float)$task['reward'], 'task_reward', 'Task approved: '.$task['title'], $task['id']);
            addPoints((int)$sub['user_id'], 50);
            createNotification((int)$sub['user_id'], 'task_approved', 'Task Approved! ✅', 'Your submission for "'.$task['title'].'" was approved. Reward: '.formatAmount((float)$task['reward']));
            $msg = 'Submission approved.';
        }
    } elseif ($action === 'reject' && $sid) {
        $reason = trim($_POST['reason'] ?? 'Submission rejected.');
        $pdo->prepare("UPDATE submissions SET status='rejected', reject_reason=:r, reviewed_at=NOW() WHERE id=:id")->execute([':r'=>$reason,':id'=>$sid]);
        $sub = $pdo->prepare("SELECT * FROM submissions WHERE id=:id")->execute([':id'=>$sid]) ? $pdo->query("SELECT * FROM submissions WHERE id=$sid")->fetch() : null;
        if ($sub) {
            $task = $pdo->prepare("SELECT title FROM tasks WHERE id=:id")->execute([':id'=>$sub['task_id']]) ? $pdo->query("SELECT title FROM tasks WHERE id={$sub['task_id']}")->fetch() : null;
            createNotification((int)$sub['user_id'], 'task_rejected', 'Task Rejected ❌', 'Your submission for "'.($task['title']??'task').'" was rejected. Reason: '.$reason);
        }
        $msg = 'Submission rejected.';
    } elseif ($action === 'bulk_approve') {
        $ids = array_map('intval', $_POST['ids'] ?? []);
        foreach ($ids as $id) {
            $sub = $pdo->query("SELECT s.*,t.reward,t.title FROM submissions s JOIN tasks t ON t.id=s.task_id WHERE s.id=$id AND s.status='pending'")->fetch();
            if ($sub) {
                $pdo->prepare("UPDATE submissions SET status='approved',reviewed_at=NOW() WHERE id=:id")->execute([':id'=>$id]);
                creditUser((int)$sub['user_id'],(float)$sub['reward'],'task_reward','Task approved: '.$sub['title'],$sub['task_id']);
                addPoints((int)$sub['user_id'],50);
                createNotification((int)$sub['user_id'],'task_approved','Task Approved!','Reward: '.formatAmount((float)$sub['reward']));
            }
        }
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH'])) { echo json_encode(['success'=>true,'message'=>count($ids).' submissions approved.']); exit; }
        $msg = count($ids).' submissions approved.';
    } elseif ($action === 'bulk_reject') {
        $ids = array_map('intval', $_POST['ids'] ?? []);
        $reason = trim($_POST['reason'] ?? 'Rejected');
        foreach ($ids as $id) {
            $pdo->prepare("UPDATE submissions SET status='rejected',reject_reason=:r,reviewed_at=NOW() WHERE id=:id")->execute([':r'=>$reason,':id'=>$id]);
        }
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH'])) { echo json_encode(['success'=>true,'message'=>count($ids).' submissions rejected.']); exit; }
        $msg = count($ids).' submissions rejected.';
    }
    if ($msg) { $_SESSION['flash'] = $msg; redirect('/admin/submissions.php'); }
}

$flash = $_SESSION['flash'] ?? ''; unset($_SESSION['flash']);
$status  = in_array($_GET['status']??'',['pending','approved','rejected','all']) ? $_GET['status'] : 'pending';
$taskId  = (int)($_GET['task'] ?? 0);
$page    = max(1,(int)($_GET['page']??1));
$limit   = 20; $offset = ($page-1)*$limit;

$where = ['1=1'];
$params = [];
if ($status !== 'all') { $where[] = "s.status=:st"; $params[':st'] = $status; }
if ($taskId) { $where[] = "s.task_id=:tid"; $params[':tid'] = $taskId; }
$whereStr = implode(' AND ',$where);

$params2 = $params;
$totalStmt = $pdo->prepare("SELECT COUNT(*) FROM submissions s WHERE $whereStr");
$totalStmt->execute($params2);
$total = (int)$totalStmt->fetchColumn();

$params[':limit'] = $limit; $params[':offset'] = $offset;
$stmt = $pdo->prepare("SELECT s.*, u.name as user_name, u.avatar, t.title as task_title, t.reward FROM submissions s JOIN users u ON u.id=s.user_id JOIN tasks t ON t.id=s.task_id WHERE $whereStr ORDER BY s.created_at DESC LIMIT :limit OFFSET :offset");
$stmt->execute($params);
$submissions = $stmt->fetchAll();

$templates = $pdo->query("SELECT * FROM reject_templates")->fetchAll();
require ROOT_PATH . '/admin/includes/header.php';
?>
<?php if ($flash): ?><div class="alert alert-success" style="margin-bottom:20px;"><?= h($flash) ?></div><?php endif; ?>

<div class="admin-card">
  <div class="admin-card-header">
    <div class="admin-card-title">Submissions (<?= number_format($total) ?>)</div>
  </div>
  <div class="admin-filters">
    <?php foreach (['pending'=>'⏳ Pending','approved'=>'✅ Approved','rejected'=>'❌ Rejected','all'=>'All'] as $k=>$v): ?>
      <a href="?status=<?= $k ?>" class="filter-btn <?= $status===$k?'filter-btn-primary':'filter-btn-outline' ?>"><?= $v ?></a>
    <?php endforeach; ?>
  </div>

  <!-- Bulk action bar -->
  <div id="bulk-action-bar" style="display:none;background:rgba(0,200,150,.1);padding:12px 16px;border-radius:8px;margin-bottom:16px;align-items:center;gap:12px;">
    <span class="bulk-count" style="font-weight:700;"></span>
    <?php if ($status === 'pending'): ?>
      <button id="bulk-approve-btn" class="action-btn-sm action-btn-approve"><i class="fa-solid fa-check"></i> Approve All</button>
      <button id="bulk-reject-btn" class="action-btn-sm action-btn-reject"><i class="fa-solid fa-times"></i> Reject All</button>
    <?php endif; ?>
  </div>
  <?= csrfField() ?>

  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr>
        <?php if ($status === 'pending'): ?><th><input type="checkbox" id="select-all"></th><?php endif; ?>
        <th>User</th><th>Task</th><th>Screenshot</th><th>Notes</th><th>Submitted</th><th>Status</th><th>Actions</th>
      </tr></thead>
      <tbody>
        <?php foreach ($submissions as $s): ?>
          <tr>
            <?php if ($status === 'pending'): ?><td><input type="checkbox" class="row-checkbox" value="<?= $s['id'] ?>"></td><?php endif; ?>
            <td>
              <div class="user-cell">
                <div class="table-avatar"><?= strtoupper(substr($s['user_name'],0,1)) ?></div>
                <div><?= h($s['user_name']) ?></div>
              </div>
            </td>
            <td style="font-size:13px;"><?= h($s['task_title']) ?><br><span style="color:var(--primary);font-weight:700"><?= formatAmount((float)$s['reward']) ?></span></td>
            <td>
              <?php if ($s['screenshot']): ?>
                <img src="<?= h($s['screenshot']) ?>" class="sub-screenshot" data-lightbox="<?= h($s['screenshot']) ?>" alt="" style="max-height:60px;border-radius:6px;cursor:pointer;">
              <?php else: ?><span style="color:#aaa;font-size:12px;">None</span><?php endif; ?>
            </td>
            <td style="font-size:13px;max-width:160px;overflow:hidden;text-overflow:ellipsis;"><?= $s['notes'] ? h(substr($s['notes'],0,60)) : '<span style="color:#aaa">—</span>' ?></td>
            <td style="font-size:12px;color:#888"><?= timeAgo($s['created_at']) ?></td>
            <td><span class="status-badge status-<?= h($s['status']) ?>"><?= ucfirst($s['status']) ?></span><?php if ($s['reject_reason']): ?><div style="font-size:11px;color:#888;margin-top:4px;"><?= h(substr($s['reject_reason'],0,40)) ?></div><?php endif; ?></td>
            <td>
              <?php if ($s['status'] === 'pending'): ?>
                <div class="action-btns">
                  <form method="post" style="display:inline"><?= csrfField() ?><input type="hidden" name="action" value="approve"><input type="hidden" name="sub_id" value="<?= $s['id'] ?>"><button type="submit" class="action-btn-sm action-btn-approve" data-confirm="Approve this submission?"><i class="fa-solid fa-check"></i> Approve</button></form>
                  <button class="action-btn-sm action-btn-reject" onclick="openRejectModal(<?= $s['id'] ?>)"><i class="fa-solid fa-times"></i> Reject</button>
                </div>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?= paginationLinks($total,$page,$limit,'/admin/submissions.php?status='.$status) ?>
</div>

<!-- Reject Modal -->
<div class="modal-overlay" id="reject-modal">
  <div class="modal-box">
    <div class="modal-header"><h3>Reject Submission</h3><span class="modal-close"><i class="fa-solid fa-xmark"></i></span></div>
    <form method="post" action="/admin/submissions.php">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="reject">
      <input type="hidden" name="sub_id" id="reject-sid">
      <div class="form-group">
        <label class="form-label">Quick Templates</label>
        <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:10px;">
          <?php foreach ($templates as $t): ?>
            <button type="button" class="filter-btn filter-btn-outline" style="font-size:12px;" onclick="document.getElementById('reject-reason').value='<?= h(addslashes($t['reason'])) ?>'"><?= h($t['reason']) ?></button>
          <?php endforeach; ?>
        </div>
      </div>
      <div class="form-group"><label class="form-label">Reason <span style="color:var(--danger)">*</span></label><textarea name="reason" id="reject-reason" class="form-control" rows="3" required placeholder="Enter rejection reason..."></textarea></div>
      <button type="submit" class="btn btn-danger btn-block">Reject Submission</button>
    </form>
  </div>
</div>
<script>function openRejectModal(sid){document.getElementById('reject-sid').value=sid;document.getElementById('reject-modal').classList.add('active');}</script>
<?php require ROOT_PATH . '/admin/includes/footer.php'; ?>
