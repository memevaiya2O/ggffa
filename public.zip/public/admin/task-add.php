<?php
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/includes/settings-loader.php';
requireAdmin();
$pdo = getDB();
$pageTitle = 'Add Task';
$adminPage = 'task-add';
require_once ROOT_PATH . '/includes/upload.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $title    = trim($_POST['title'] ?? '');
    $catId    = (int)($_POST['category_id'] ?? 0);
    $type     = trim($_POST['type'] ?? 'standard');
    $reward   = (float)($_POST['reward'] ?? 0);
    $instruc  = trim($_POST['instructions'] ?? '');
    $rules    = trim($_POST['rules'] ?? '');
    $ssReq    = isset($_POST['screenshot_required']) ? 1 : 0;
    $maxPer   = max(1,(int)($_POST['max_per_user']??1));
    $maxTotal = max(1,(int)($_POST['max_total']??1000));
    $isVip    = isset($_POST['is_vip']) ? 1 : 0;
    $isFeat   = isset($_POST['is_featured']) ? 1 : 0;
    $isHot    = isset($_POST['is_hot']) ? 1 : 0;
    $isNew    = isset($_POST['is_new']) ? 1 : 0;
    $status   = $_POST['status'] ?? 'active';
    $thumbnail = null;

    if (!$title) $error = 'Task title is required.';
    elseif ($reward <= 0) $error = 'Reward must be greater than 0.';
    else {
        if (!empty($_FILES['thumbnail']['name'])) {
            $up = handleUpload('thumbnail','uploads/tasks');
            if ($up['success']) $thumbnail = $up['path'];
        }
        $pdo->prepare("INSERT INTO tasks (category_id,title,type,reward,thumbnail,instructions,rules,screenshot_required,max_per_user,max_total,is_vip,is_featured,is_hot,is_new,status) VALUES (:cat,:title,:type,:reward,:thumb,:instr,:rules,:ss,:mp,:mt,:vip,:feat,:hot,:new,:status)")
            ->execute([':cat'=>$catId?:null,':title'=>$title,':type'=>$type,':reward'=>$reward,':thumb'=>$thumbnail,':instr'=>$instruc,':rules'=>$rules,':ss'=>$ssReq,':mp'=>$maxPer,':mt'=>$maxTotal,':vip'=>$isVip,':feat'=>$isFeat,':hot'=>$isHot,':new'=>$isNew,':status'=>$status]);
        $_SESSION['flash'] = 'Task added!';
        redirect('/admin/tasks.php');
    }
}
$cats = $pdo->query("SELECT * FROM task_categories WHERE status='active' ORDER BY sort_order")->fetchAll();
require ROOT_PATH . '/admin/includes/header.php';
?>
<?php if ($error): ?><div class="alert alert-error" style="margin-bottom:20px;"><?= h($error) ?></div><?php endif; ?>
<div class="admin-card">
  <form method="post" enctype="multipart/form-data">
    <?= csrfField() ?>
    <div class="admin-form-grid">
      <div class="admin-form-group"><label class="admin-label">Task Title *</label><input type="text" name="title" class="admin-input" value="<?= h($_POST['title']??'') ?>" required></div>
      <div class="admin-form-group"><label class="admin-label">Category</label><select name="category_id" class="admin-input"><option value="">No Category</option><?php foreach ($cats as $c): ?><option value="<?= $c['id'] ?>"><?= h($c['name']) ?></option><?php endforeach; ?></select></div>
      <div class="admin-form-group"><label class="admin-label">Type</label><select name="type" class="admin-input"><option value="standard">Standard</option><option value="social">Social Media</option><option value="app">App Install</option><option value="survey">Survey</option><option value="video">Video Watch</option></select></div>
      <div class="admin-form-group"><label class="admin-label">Reward Amount *</label><input type="number" name="reward" class="admin-input" step="0.01" min="0.01" value="<?= h($_POST['reward']??'') ?>" required></div>
      <div class="admin-form-group"><label class="admin-label">Max per User</label><input type="number" name="max_per_user" class="admin-input" min="1" value="<?= h($_POST['max_per_user']??'1') ?>"></div>
      <div class="admin-form-group"><label class="admin-label">Max Total Completions</label><input type="number" name="max_total" class="admin-input" min="1" value="<?= h($_POST['max_total']??'1000') ?>"></div>
      <div class="admin-form-group"><label class="admin-label">Thumbnail Image</label><input type="file" name="thumbnail" class="admin-input" accept="image/*"></div>
      <div class="admin-form-group"><label class="admin-label">Status</label><select name="status" class="admin-input"><option value="active">Active</option><option value="inactive">Inactive</option></select></div>
    </div>
    <div class="admin-form-group"><label class="admin-label">Instructions (one step per line)</label><textarea name="instructions" class="admin-input admin-textarea" rows="6" placeholder="Step 1: Do this&#10;Step 2: Do that"><?= h($_POST['instructions']??'') ?></textarea></div>
    <div class="admin-form-group"><label class="admin-label">Rules (one per line)</label><textarea name="rules" class="admin-input admin-textarea" rows="4" placeholder="Rule 1&#10;Rule 2"><?= h($_POST['rules']??'') ?></textarea></div>
    <div style="display:flex;flex-wrap:wrap;gap:20px;margin-bottom:20px;">
      <label class="toggle-label"><span class="toggle-switch"><input type="checkbox" name="screenshot_required" value="1" checked><span class="toggle-slider"></span></span> Require Screenshot</label>
      <label class="toggle-label"><span class="toggle-switch"><input type="checkbox" name="is_featured" value="1"><span class="toggle-slider"></span></span> Featured</label>
      <label class="toggle-label"><span class="toggle-switch"><input type="checkbox" name="is_hot" value="1"><span class="toggle-slider"></span></span> 🔥 Hot</label>
      <label class="toggle-label"><span class="toggle-switch"><input type="checkbox" name="is_new" value="1" checked><span class="toggle-slider"></span></span> ✨ New</label>
      <label class="toggle-label"><span class="toggle-switch"><input type="checkbox" name="is_vip" value="1"><span class="toggle-slider"></span></span> 👑 VIP Only</label>
    </div>
    <button type="submit" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Add Task</button>
    <a href="/admin/tasks.php" class="btn btn-outline" style="margin-left:10px;">Cancel</a>
  </form>
</div>
<?php require ROOT_PATH . '/admin/includes/footer.php'; ?>
