<?php
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/includes/settings-loader.php';
requireAdmin();
$pdo = getDB();
$pageTitle = 'Edit Task';
$adminPage = 'tasks';
require_once ROOT_PATH . '/includes/upload.php';

$taskId = (int)($_GET['id'] ?? 0);
if (!$taskId) redirect('/admin/tasks.php');
$task = $pdo->query("SELECT * FROM tasks WHERE id=$taskId")->fetch();
if (!$task) redirect('/admin/tasks.php');

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $title    = trim($_POST['title'] ?? '');
    $catId    = (int)($_POST['category_id'] ?? 0);
    $type     = trim($_POST['type'] ?? 'standard');
    $reward   = (float)($_POST['reward'] ?? 0);
    $instruc  = trim($_POST['instructions'] ?? '');
    $rules    = trim($_POST['rules'] ?? '');
    $ssReq    = isset($_POST['screenshot_required']) ? 1 : 0;
    $maxPer   = max(1,(int)($_POST['max_per_user']??1));
    $maxTotal = max(1,(int)($_POST['max_total']??1000));
    $isVip    = isset($_POST['is_vip']) ? 1 : 0;
    $isFeat   = isset($_POST['is_featured']) ? 1 : 0;
    $isHot    = isset($_POST['is_hot']) ? 1 : 0;
    $isNew    = isset($_POST['is_new']) ? 1 : 0;
    $status   = $_POST['status'] ?? 'active';
    $thumbnail = $task['thumbnail'];

    if (!$title) $error = 'Task title is required.';
    elseif ($reward <= 0) $error = 'Reward must be greater than 0.';
    else {
        if (!empty($_FILES['thumbnail']['name'])) {
            $up = handleUpload('thumbnail','uploads/tasks');
            if ($up['success']) $thumbnail = $up['path'];
        }
        $pdo->prepare("UPDATE tasks SET category_id=:cat,title=:title,type=:type,reward=:reward,thumbnail=:thumb,instructions=:instr,rules=:rules,screenshot_required=:ss,max_per_user=:mp,max_total=:mt,is_vip=:vip,is_featured=:feat,is_hot=:hot,is_new=:new,status=:status WHERE id=:id")
            ->execute([':cat'=>$catId?:null,':title'=>$title,':type'=>$type,':reward'=>$reward,':thumb'=>$thumbnail,':instr'=>$instruc,':rules'=>$rules,':ss'=>$ssReq,':mp'=>$maxPer,':mt'=>$maxTotal,':vip'=>$isVip,':feat'=>$isFeat,':hot'=>$isHot,':new'=>$isNew,':status'=>$status,':id'=>$taskId]);
        $_SESSION['flash'] = 'Task updated!';
        redirect('/admin/tasks.php');
    }
}
$cats = $pdo->query("SELECT * FROM task_categories WHERE status='active' ORDER BY sort_order")->fetchAll();
require ROOT_PATH . '/admin/includes/header.php';
?>
<?php if ($error): ?><div class="alert alert-error" style="margin-bottom:20px;"><?= h($error) ?></div><?php endif; ?>
<div class="admin-card">
  <form method="post" enctype="multipart/form-data">
    <?= csrfField() ?>
    <div class="admin-form-grid">
      <div class="admin-form-group"><label class="admin-label">Task Title *</label><input type="text" name="title" class="admin-input" value="<?= h($task['title']) ?>" required></div>
      <div class="admin-form-group"><label class="admin-label">Category</label><select name="category_id" class="admin-input"><option value="">No Category</option><?php foreach ($cats as $c): ?><option value="<?= $c['id'] ?>" <?= $task['category_id']==$c['id']?'selected':'' ?>><?= h($c['name']) ?></option><?php endforeach; ?></select></div>
      <div class="admin-form-group"><label class="admin-label">Type</label><select name="type" class="admin-input"><?php foreach (['standard','social','app','survey','video'] as $t): ?><option value="<?= $t ?>" <?= $task['type']===$t?'selected':'' ?>><?= ucfirst($t) ?></option><?php endforeach; ?></select></div>
      <div class="admin-form-group"><label class="admin-label">Reward Amount *</label><input type="number" name="reward" class="admin-input" step="0.01" min="0.01" value="<?= h($task['reward']) ?>" required></div>
      <div class="admin-form-group"><label class="admin-label">Max per User</label><input type="number" name="max_per_user" class="admin-input" min="1" value="<?= h($task['max_per_user']) ?>"></div>
      <div class="admin-form-group"><label class="admin-label">Max Total Completions</label><input type="number" name="max_total" class="admin-input" min="1" value="<?= h($task['max_total']) ?>"></div>
      <div class="admin-form-group"><label class="admin-label">Thumbnail<?php if ($task['thumbnail']): ?> <a href="<?= h($task['thumbnail']) ?>" target="_blank" style="font-size:11px">(current)</a><?php endif; ?></label><input type="file" name="thumbnail" class="admin-input" accept="image/*"></div>
      <div class="admin-form-group"><label class="admin-label">Status</label><select name="status" class="admin-input"><option value="active" <?= $task['status']==='active'?'selected':'' ?>>Active</option><option value="inactive" <?= $task['status']==='inactive'?'selected':'' ?>>Inactive</option></select></div>
    </div>
    <div class="admin-form-group"><label class="admin-label">Instructions</label><textarea name="instructions" class="admin-input admin-textarea" rows="6"><?= h($task['instructions']) ?></textarea></div>
    <div class="admin-form-group"><label class="admin-label">Rules</label><textarea name="rules" class="admin-input admin-textarea" rows="4"><?= h($task['rules']) ?></textarea></div>
    <div style="display:flex;flex-wrap:wrap;gap:20px;margin-bottom:20px;">
      <label class="toggle-label"><span class="toggle-switch"><input type="checkbox" name="screenshot_required" value="1" <?= $task['screenshot_required']?'checked':'' ?>><span class="toggle-slider"></span></span> Require Screenshot</label>
      <label class="toggle-label"><span class="toggle-switch"><input type="checkbox" name="is_featured" value="1" <?= $task['is_featured']?'checked':'' ?>><span class="toggle-slider"></span></span> Featured</label>
      <label class="toggle-label"><span class="toggle-switch"><input type="checkbox" name="is_hot" value="1" <?= $task['is_hot']?'checked':'' ?>><span class="toggle-slider"></span></span> 🔥 Hot</label>
      <label class="toggle-label"><span class="toggle-switch"><input type="checkbox" name="is_new" value="1" <?= $task['is_new']?'checked':'' ?>><span class="toggle-slider"></span></span> ✨ New</label>
      <label class="toggle-label"><span class="toggle-switch"><input type="checkbox" name="is_vip" value="1" <?= $task['is_vip']?'checked':'' ?>><span class="toggle-slider"></span></span> 👑 VIP Only</label>
    </div>
    <button type="submit" class="btn btn-primary"><i class="fa-solid fa-save"></i> Save Changes</button>
    <a href="/admin/tasks.php" class="btn btn-outline" style="margin-left:10px;">Cancel</a>
  </form>
</div>
<?php require ROOT_PATH . '/admin/includes/footer.php'; ?>
