<?php
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/includes/settings-loader.php';
requireAdmin();
$pdo = getDB();
$pageTitle = 'Task Management';
$adminPage = 'tasks';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $action = $_POST['action'] ?? '';
    $tid    = (int)($_POST['task_id'] ?? 0);
    if ($action === 'delete' && $tid) {
        $pdo->prepare("DELETE FROM tasks WHERE id=:id")->execute([':id'=>$tid]);
        $_SESSION['flash'] = 'Task deleted.';
    } elseif (in_array($action,['toggle_featured','toggle_hot','toggle_new','toggle_status']) && $tid) {
        $col = str_replace('toggle_','',$action);
        if ($col === 'status') { $cur = $pdo->query("SELECT status FROM tasks WHERE id=$tid")->fetchColumn(); $pdo->prepare("UPDATE tasks SET status=:s WHERE id=:id")->execute([':s'=>$cur==='active'?'inactive':'active',':id'=>$tid]); }
        else { $cur = (int)$pdo->query("SELECT is_$col FROM tasks WHERE id=$tid")->fetchColumn(); $pdo->prepare("UPDATE tasks SET is_$col=:v WHERE id=:id")->execute([':v'=>$cur?0:1,':id'=>$tid]); }
        $_SESSION['flash'] = 'Task updated.';
    } elseif ($action === 'reorder') {
        $order = json_decode(file_get_contents('php://input'), true)['order'] ?? [];
        foreach ($order as $item) { $pdo->prepare("UPDATE tasks SET sort_order=:o WHERE id=:id")->execute([':o'=>$item['order'],':id'=>$item['id']]); }
        header('Content-Type: application/json'); echo json_encode(['success'=>true,'message'=>'Order saved']); exit;
    }
    redirect('/admin/tasks.php');
}
$flash = $_SESSION['flash'] ?? ''; unset($_SESSION['flash']);
$cat   = (int)($_GET['cat']??0);
$status= $_GET['status']??'active';
$page  = max(1,(int)($_GET['page']??1));
$limit = 20; $offset = ($page-1)*$limit;
$where = ['1=1']; $params = [];
if ($cat) { $where[] = "t.category_id=:cat"; $params[':cat']=$cat; }
if ($status !== 'all') { $where[] = "t.status=:st"; $params[':st']=$status; }
$whereStr = implode(' AND ',$where);
$tStmt = $pdo->prepare("SELECT COUNT(*) FROM tasks t WHERE $whereStr"); $tStmt->execute($params); $total = (int)$tStmt->fetchColumn();
$params[':limit']=$limit; $params[':offset']=$offset;
$stmt = $pdo->prepare("SELECT t.*, tc.name as cat_name, (SELECT COUNT(*) FROM submissions WHERE task_id=t.id AND status='approved') as approved_count, (SELECT COUNT(*) FROM submissions WHERE task_id=t.id AND status='pending') as pending_count FROM tasks t LEFT JOIN task_categories tc ON tc.id=t.category_id WHERE $whereStr ORDER BY t.sort_order, t.created_at DESC LIMIT :limit OFFSET :offset");
$stmt->execute($params);
$tasks = $stmt->fetchAll();
$cats = $pdo->query("SELECT * FROM task_categories ORDER BY sort_order")->fetchAll();
require ROOT_PATH . '/admin/includes/header.php';
?>
<?php if ($flash): ?><div class="alert alert-success" style="margin-bottom:20px;"><?= h($flash) ?></div><?php endif; ?>
<div class="admin-card">
  <div class="admin-card-header">
    <div class="admin-card-title">Tasks (<?= $total ?>)</div>
    <a href="/admin/task-add.php" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Add Task</a>
  </div>
  <form method="get" class="admin-filters">
    <select name="cat" class="filter-select" onchange="this.form.submit()"><option value="">All Categories</option><?php foreach ($cats as $c): ?><option value="<?= $c['id'] ?>" <?= $cat==$c['id']?'selected':'' ?>><?= h($c['name']) ?></option><?php endforeach; ?></select>
    <select name="status" class="filter-select" onchange="this.form.submit()"><option value="all">All Status</option><option value="active" <?= $status==='active'?'selected':'' ?>>Active</option><option value="inactive" <?= $status==='inactive'?'selected':'' ?>>Inactive</option></select>
  </form>
  <div class="admin-table-wrap">
    <table class="admin-table" id="tasks-table">
      <thead><tr><th>☰</th><th>Task</th><th>Category</th><th>Reward</th><th>Stats</th><th>Flags</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody id="sortable-tasks">
        <?php foreach ($tasks as $t): ?>
          <tr data-id="<?= $t['id'] ?>">
            <td><span class="drag-handle"><i class="fa-solid fa-grip-lines"></i></span></td>
            <td>
              <div style="display:flex;align-items:center;gap:10px;">
                <?php if ($t['thumbnail']): ?><img src="<?= h($t['thumbnail']) ?>" style="width:40px;height:40px;border-radius:8px;object-fit:cover;"><?php endif; ?>
                <div><div style="font-weight:700;font-size:14px;"><?= h($t['title']) ?></div><div style="font-size:11px;color:#888"><?= ucfirst($t['type']) ?></div></div>
              </div>
            </td>
            <td><?= h($t['cat_name']??'—') ?></td>
            <td style="font-weight:700;color:var(--primary)"><?= formatAmount((float)$t['reward']) ?></td>
            <td style="font-size:12px"><span style="color:var(--primary)"><?= $t['approved_count'] ?> done</span> · <span style="color:var(--warning)"><?= $t['pending_count'] ?> pending</span></td>
            <td>
              <?php $flags = []; if ($t['is_featured']) $flags[]='<span class="badge badge-info">Featured</span>'; if ($t['is_hot']) $flags[]='<span class="badge badge-hot">🔥</span>'; if ($t['is_new']) $flags[]='<span class="badge badge-new">✨</span>'; if ($t['is_vip']) $flags[]='<span class="badge badge-vip">👑</span>'; echo implode(' ',$flags); ?>
            </td>
            <td>
              <form method="post" style="display:inline"><?= csrfField() ?><input type="hidden" name="action" value="toggle_status"><input type="hidden" name="task_id" value="<?= $t['id'] ?>"><button type="submit" class="status-badge status-<?= $t['status'] === 'active'?'active':'rejected' ?>" style="cursor:pointer;border:none;"><?= $t['status'] === 'active' ? 'Active' : 'Inactive' ?></button></form>
            </td>
            <td>
              <div class="action-btns">
                <a href="/admin/task-edit.php?id=<?= $t['id'] ?>" class="action-btn-sm action-btn-edit"><i class="fa-solid fa-pen"></i></a>
                <form method="post" style="display:inline"><?= csrfField() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="task_id" value="<?= $t['id'] ?>"><button type="submit" class="action-btn-sm action-btn-delete" data-confirm="Delete this task and all submissions?"><i class="fa-solid fa-trash"></i></button></form>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?= paginationLinks($total,$page,$limit,'/admin/tasks.php?cat='.$cat.'&status='.$status) ?>
</div>
<?php $extraJs='<script>initSortable("sortable-tasks","/admin/tasks.php");</script>'; require ROOT_PATH . '/admin/includes/footer.php'; ?>
