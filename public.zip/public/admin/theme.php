<?php
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/includes/settings-loader.php';
requireAdmin();
$pdo = getDB();
$pageTitle = 'Theme Customizer';
$adminPage = 'theme';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $fields = ['color_primary','color_secondary','color_bg','color_card','color_text','color_accent','color_danger','color_warning','font_family','border_radius','button_style'];
    $stmt = $pdo->prepare("INSERT INTO settings (key,value,updated_at) VALUES(:k,:v,NOW()) ON CONFLICT (key) DO UPDATE SET value=:v2,updated_at=NOW()");
    foreach ($fields as $f) { $val = trim($_POST[$f] ?? ''); $stmt->execute([':k'=>$f,':v'=>$val,':v2'=>$val]); }
    $_SESSION['flash'] = 'Theme saved!';
    redirect('/admin/theme.php');
}
$flash = $_SESSION['flash'] ?? ''; unset($_SESSION['flash']);
$fonts = ['Nunito','Poppins','Roboto','Inter','Lato','Open Sans','Montserrat','Raleway','Source Sans Pro','Ubuntu'];
require ROOT_PATH . '/admin/includes/header.php';
?>
<?php if ($flash): ?><div class="alert alert-success" style="margin-bottom:20px;"><?= h($flash) ?></div><?php endif; ?>
<div class="admin-card">
  <form method="post">
    <?= csrfField() ?>
    <h3 style="margin-bottom:20px;">Colors</h3>
    <div class="color-row" style="margin-bottom:28px;">
      <?php
        $colorFields = ['color_primary'=>'Primary','color_secondary'=>'Secondary','color_bg'=>'Background','color_card'=>'Card BG','color_text'=>'Text','color_accent'=>'Accent','color_danger'=>'Danger','color_warning'=>'Warning'];
        foreach ($colorFields as $k=>$label):
          $val = getSetting($k,'#00C896');
      ?>
        <div class="color-item">
          <label><?= $label ?></label>
          <div class="color-picker-wrap">
            <input type="color" name="<?= $k ?>" value="<?= h($val) ?>">
            <input type="text" value="<?= h($val) ?>" onchange="this.previousElementSibling.value=this.value" style="width:90px;padding:8px;border:2px solid #e8e8e8;border-radius:6px;font-family:monospace;font-size:13px;">
          </div>
        </div>
      <?php endforeach; ?>
    </div>
    <h3 style="margin-bottom:20px;">Typography & Style</h3>
    <div class="admin-form-grid">
      <div class="admin-form-group">
        <label class="admin-label">Font Family</label>
        <select name="font_family" class="admin-input">
          <?php foreach ($fonts as $f): ?>
            <option value="<?= $f ?>" <?= getSetting('font_family','Nunito')===$f?'selected':'' ?>><?= $f ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="admin-form-group">
        <label class="admin-label">Border Radius (px): <strong id="radius-val"><?= getSetting('border_radius','12') ?></strong>px</label>
        <input type="range" name="border_radius" min="0" max="32" step="2" value="<?= getSetting('border_radius','12') ?>" oninput="document.getElementById('radius-val').textContent=this.value" style="width:100%;margin-top:8px;">
      </div>
      <div class="admin-form-group">
        <label class="admin-label">Button Style</label>
        <select name="button_style" class="admin-input">
          <option value="filled" <?= getSetting('button_style','filled')==='filled'?'selected':'' ?>>Filled</option>
          <option value="outlined" <?= getSetting('button_style')==='outlined'?'selected':'' ?>>Outlined</option>
          <option value="gradient" <?= getSetting('button_style')==='gradient'?'selected':'' ?>>Gradient</option>
        </select>
      </div>
    </div>
    <div style="display:flex;gap:12px;">
      <button type="submit" class="btn btn-primary"><i class="fa-solid fa-save"></i> Save Theme</button>
      <button type="button" class="btn btn-outline" onclick="if(confirm('Reset all colors to default?')){resetDefaults()}">Reset to Default</button>
    </div>
  </form>
</div>
<script>
function resetDefaults() {
  const d = {color_primary:'#00C896',color_secondary:'#009688',color_bg:'#FFFFFF',color_card:'#F4FBF9',color_text:'#1A1A2E',color_accent:'#00E5B0',color_danger:'#FF4757',color_warning:'#FFA502'};
  Object.entries(d).forEach(([k,v])=>{const inp=document.querySelector('[name='+k+']');if(inp){inp.value=v;inp.nextElementSibling&&(inp.nextElementSibling.value=v);}});
}
</script>
<?php require ROOT_PATH . '/admin/includes/footer.php'; ?>
