<?php
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/includes/settings-loader.php';
requireAdmin();
$pdo = getDB();
$pageTitle = 'User Management';
$adminPage = 'users';

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $action = $_POST['action'] ?? '';
    $uid    = (int)($_POST['user_id'] ?? 0);
    $msg    = '';
    if ($action === 'ban')       { $pdo->prepare("UPDATE users SET status='banned' WHERE id=:id")->execute([':id'=>$uid]); $msg = 'User banned.'; }
    elseif ($action === 'unban') { $pdo->prepare("UPDATE users SET status='active' WHERE id=:id")->execute([':id'=>$uid]); $msg = 'User unbanned.'; }
    elseif ($action === 'delete') { $pdo->prepare("DELETE FROM users WHERE id=:id")->execute([':id'=>$uid]); $msg = 'User deleted.'; }
    elseif ($action === 'credit') {
        $amount = (float)($_POST['amount'] ?? 0);
        if ($amount != 0) { creditUser($uid, $amount, 'admin_credit', 'Admin credit'); $msg = 'Balance updated.'; }
    } elseif ($action === 'change_level') {
        $lvl = (int)($_POST['level_id'] ?? 1);
        $pdo->prepare("UPDATE users SET level_id=:l WHERE id=:id")->execute([':l'=>$lvl,':id'=>$uid]); $msg = 'Level changed.';
    } elseif ($action === 'notify') {
        $title = trim($_POST['notif_title'] ?? '');
        $notifMsg = trim($_POST['notif_msg'] ?? '');
        if ($title && $notifMsg) { createNotification($uid, 'broadcast', $title, $notifMsg); $msg = 'Notification sent.'; }
    }
    if ($msg) { $_SESSION['flash'] = $msg; redirect('/admin/users.php'); }
}

$flash = $_SESSION['flash'] ?? ''; unset($_SESSION['flash']);

// Filters
$search  = trim($_GET['search'] ?? '');
$level   = (int)($_GET['level'] ?? 0);
$status  = $_GET['status'] ?? '';
$page    = max(1,(int)($_GET['page']??1));
$limit   = 20;
$offset  = ($page-1)*$limit;
$where   = ['1=1'];
$params  = [];
if ($search) { $where[] = "(u.name ILIKE :s OR u.email ILIKE :s2)"; $params[':s'] = "%$search%"; $params[':s2'] = "%$search%"; }
if ($level)  { $where[] = "u.level_id = :lvl"; $params[':lvl'] = $level; }
if ($status) { $where[] = "u.status = :st"; $params[':st'] = $status; }
$whereStr = implode(' AND ',$where);

$total = (int)$pdo->prepare("SELECT COUNT(*) FROM users u WHERE $whereStr")->execute($params) ? $pdo->query("SELECT COUNT(*) FROM users u WHERE " . ($search ? "(u.name ILIKE '$search%' OR u.email ILIKE '$search%')" : '1=1') . ($level ? " AND u.level_id=$level" : '') . ($status ? " AND u.status='$status'" : ''))->fetchColumn() : 0;

$stmt = $pdo->prepare("SELECT u.*, l.name as level_name, l.color as level_color FROM users u LEFT JOIN levels l ON l.id=u.level_id WHERE $whereStr ORDER BY u.created_at DESC LIMIT :limit OFFSET :offset");
$params[':limit'] = $limit; $params[':offset'] = $offset;
$stmt->execute($params);
$users = $stmt->fetchAll();

$levels = $pdo->query("SELECT * FROM levels ORDER BY sort_order")->fetchAll();
require ROOT_PATH . '/admin/includes/header.php';
?>
<?php if ($flash): ?><div class="alert alert-success" style="margin-bottom:20px;"><?= h($flash) ?></div><?php endif; ?>
<?= csrfField() ?>

<div class="admin-card">
  <div class="admin-card-header">
    <div class="admin-card-title">Users (<?= number_format($total) ?>)</div>
    <a href="?export=csv" class="btn btn-sm btn-outline"><i class="fa-solid fa-download"></i> Export CSV</a>
  </div>

  <form method="get" class="admin-filters">
    <input type="text" name="search" class="filter-input" placeholder="Search name or email..." value="<?= h($search) ?>">
    <select name="level" class="filter-select">
      <option value="">All Levels</option>
      <?php foreach ($levels as $l): ?>
        <option value="<?= $l['id'] ?>" <?= $level==$l['id']?'selected':'' ?>><?= h($l['name']) ?></option>
      <?php endforeach; ?>
    </select>
    <select name="status" class="filter-select">
      <option value="">All Status</option>
      <option value="active" <?= $status==='active'?'selected':'' ?>>Active</option>
      <option value="banned" <?= $status==='banned'?'selected':'' ?>>Banned</option>
    </select>
    <button type="submit" class="filter-btn filter-btn-primary"><i class="fa-solid fa-magnifying-glass"></i> Search</button>
    <a href="/admin/users.php" class="filter-btn filter-btn-outline">Reset</a>
  </form>

  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>User</th><th>Level</th><th>Balance</th><th>Points</th><th>Status</th><th>Joined</th><th>Actions</th></tr></thead>
      <tbody>
        <?php foreach ($users as $u): ?>
          <tr>
            <td>
              <div class="user-cell">
                <div class="table-avatar"><?php if ($u['avatar']): ?><img src="<?= h($u['avatar']) ?>" alt=""><?php else: ?><?= strtoupper(substr($u['name'],0,1)) ?><?php endif; ?></div>
                <div class="user-cell-info"><div class="user-cell-name"><?= h($u['name']) ?></div><div class="user-cell-email"><?= h($u['email']) ?></div></div>
              </div>
            </td>
            <td><span class="badge" style="background:<?= h($u['level_color']??'#CD7F32') ?>22;color:<?= h($u['level_color']??'#CD7F32') ?>"><?= h($u['level_name']??'Bronze') ?></span></td>
            <td style="font-weight:700;color:var(--primary)"><?= formatAmount((float)$u['balance']) ?></td>
            <td><?= number_format($u['points']) ?></td>
            <td><span class="status-badge status-<?= h($u['status']) ?>"><?= ucfirst($u['status']) ?></span></td>
            <td style="font-size:12px;color:#888"><?= date('M j, Y',strtotime($u['created_at'])) ?></td>
            <td>
              <div class="action-btns">
                <a href="/admin/user-detail.php?id=<?= $u['id'] ?>" class="action-btn-sm action-btn-view"><i class="fa-solid fa-eye"></i></a>
                <button class="action-btn-sm action-btn-edit" onclick="openCreditModal(<?= $u['id'] ?>, '<?= h(addslashes($u['name'])) ?>', <?= $u['balance'] ?>)"><i class="fa-solid fa-coins"></i></button>
                <?php if ($u['status'] === 'active'): ?>
                  <form method="post" style="display:inline"><?= csrfField() ?><input type="hidden" name="action" value="ban"><input type="hidden" name="user_id" value="<?= $u['id'] ?>"><button type="submit" class="action-btn-sm action-btn-reject" data-confirm="Ban this user?"><i class="fa-solid fa-ban"></i></button></form>
                <?php else: ?>
                  <form method="post" style="display:inline"><?= csrfField() ?><input type="hidden" name="action" value="unban"><input type="hidden" name="user_id" value="<?= $u['id'] ?>"><button type="submit" class="action-btn-sm action-btn-approve"><i class="fa-solid fa-check"></i></button></form>
                <?php endif; ?>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?= paginationLinks($total, $page, $limit, '/admin/users.php?' . http_build_query(['search'=>$search,'level'=>$level,'status'=>$status])) ?>
</div>

<!-- Credit Modal -->
<div class="modal-overlay" id="credit-modal">
  <div class="modal-box">
    <div class="modal-header"><h3 id="credit-modal-title">Balance</h3><span class="modal-close"><i class="fa-solid fa-xmark"></i></span></div>
    <form method="post" action="/admin/users.php">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="credit">
      <input type="hidden" name="user_id" id="credit-uid">
      <div class="form-group"><label class="form-label">Amount (positive = credit, negative = deduct)</label><input type="number" name="amount" class="form-control" step="0.01" required placeholder="e.g. 100 or -50"></div>
      <button type="submit" class="btn btn-primary btn-block">Apply</button>
    </form>
  </div>
</div>
<script>function openCreditModal(uid,name,bal){document.getElementById('credit-uid').value=uid;document.getElementById('credit-modal-title').textContent='Balance: '+name+' (Current: '+bal+')';document.getElementById('credit-modal').classList.add('active');}</script>
<?php require ROOT_PATH . '/admin/includes/footer.php'; ?>
