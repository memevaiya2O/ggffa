<?php
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/includes/settings-loader.php';
requireAdmin();
$pdo = getDB();
$pageTitle = 'Withdraw Methods';
$adminPage = 'withdraw-methods';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'save') {
        $id       = (int)($_POST['id'] ?? 0);
        $name     = trim($_POST['name'] ?? '');
        $minAmt   = (float)($_POST['min_amount'] ?? 0);
        $maxAmt   = (float)($_POST['max_amount'] ?? 0);
        $charge   = (float)($_POST['charge_pct'] ?? 0);
        $instruc  = trim($_POST['instructions'] ?? '');
        $fields   = trim($_POST['required_fields'] ?? '');
        $status   = $_POST['status'] ?? 'active';
        if ($name) {
            if ($id) {
                $pdo->prepare("UPDATE withdrawal_methods SET name=:n,min_amount=:mn,max_amount=:mx,charge_pct=:c,instructions=:i,required_fields=:f,status=:s WHERE id=:id")
                    ->execute([':n'=>$name,':mn'=>$minAmt,':mx'=>$maxAmt,':c'=>$charge,':i'=>$instruc,':f'=>$fields,':s'=>$status,':id'=>$id]);
            } else {
                $pdo->prepare("INSERT INTO withdrawal_methods (name,min_amount,max_amount,charge_pct,instructions,required_fields,status) VALUES(:n,:mn,:mx,:c,:i,:f,:s)")
                    ->execute([':n'=>$name,':mn'=>$minAmt,':mx'=>$maxAmt,':c'=>$charge,':i'=>$instruc,':f'=>$fields,':s'=>$status]);
            }
            $_SESSION['flash'] = 'Method saved.';
        }
    } elseif ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        $pdo->prepare("DELETE FROM withdrawal_methods WHERE id=:id")->execute([':id'=>$id]);
        $_SESSION['flash'] = 'Method deleted.';
    } elseif ($action === 'toggle') {
        $id = (int)($_POST['id'] ?? 0);
        $cur = $pdo->query("SELECT status FROM withdrawal_methods WHERE id=$id")->fetchColumn();
        $pdo->prepare("UPDATE withdrawal_methods SET status=:s WHERE id=:id")->execute([':s'=>$cur==='active'?'inactive':'active',':id'=>$id]);
        $_SESSION['flash'] = 'Status updated.';
    }
    redirect('/admin/withdraw-methods.php');
}

$flash   = $_SESSION['flash'] ?? ''; unset($_SESSION['flash']);
$methods = $pdo->query("SELECT * FROM withdrawal_methods ORDER BY id")->fetchAll();
require ROOT_PATH . '/admin/includes/header.php';
?>
<?php if ($flash): ?><div class="alert alert-success" style="margin-bottom:20px;"><?= h($flash) ?></div><?php endif; ?>

<div class="admin-grid-2" style="gap:24px;display:grid;grid-template-columns:1fr 1.5fr;">

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">Add / Edit Method</div></div>
  <div class="admin-card-body">
    <form method="post" id="mth-form">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" id="mth-id" value="0">
      <div class="form-group">
        <label>Method Name</label>
        <input type="text" name="name" id="mth-name" class="form-control" placeholder="e.g. bKash" required>
      </div>
      <div class="form-group">
        <label>Min Amount (BDT)</label>
        <input type="number" name="min_amount" id="mth-min" class="form-control" value="200" step="0.01" min="0">
      </div>
      <div class="form-group">
        <label>Max Amount (BDT)</label>
        <input type="number" name="max_amount" id="mth-max" class="form-control" value="10000" step="0.01" min="0">
      </div>
      <div class="form-group">
        <label>Charge % (0 = no charge)</label>
        <input type="number" name="charge_pct" id="mth-charge" class="form-control" value="0" step="0.01" min="0" max="100">
      </div>
      <div class="form-group">
        <label>Required Fields (comma-separated)</label>
        <input type="text" name="required_fields" id="mth-fields" class="form-control" placeholder="Account Number,Account Name">
      </div>
      <div class="form-group">
        <label>Instructions</label>
        <textarea name="instructions" id="mth-instruc" class="form-control" rows="3" placeholder="e.g. Send to our bKash number..."></textarea>
      </div>
      <div class="form-group">
        <label>Status</label>
        <select name="status" id="mth-status" class="form-control">
          <option value="active">Active</option>
          <option value="inactive">Inactive</option>
        </select>
      </div>
      <button class="btn btn-primary" type="submit">Save Method</button>
      <button class="btn btn-secondary" type="button" onclick="resetMth()">Clear</button>
    </form>
  </div>
</div>

<div class="admin-card">
  <div class="admin-card-header"><div class="admin-card-title">All Methods</div></div>
  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>Name</th><th>Min</th><th>Max</th><th>Charge%</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
        <?php foreach ($methods as $m): ?>
        <tr>
          <td><strong><?= h($m['name']) ?></strong></td>
          <td><?= h($m['min_amount']) ?></td>
          <td><?= h($m['max_amount']) ?></td>
          <td><?= h($m['charge_pct']) ?>%</td>
          <td>
            <form method="post" style="display:inline">
              <?= csrfField() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= $m['id'] ?>">
              <button class="btn btn-xs <?= $m['status']==='active'?'btn-success':'btn-secondary' ?>"><?= $m['status']==='active'?'Active':'Inactive' ?></button>
            </form>
          </td>
          <td>
            <button class="btn btn-warning btn-xs" onclick="editMth(<?= htmlspecialchars(json_encode($m)) ?>)">Edit</button>
            <form method="post" style="display:inline" onsubmit="return confirm('Delete this method?')">
              <?= csrfField() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $m['id'] ?>">
              <button class="btn btn-danger btn-xs">Del</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (!$methods): ?><tr><td colspan="6" style="text-align:center;color:#888;">No methods yet.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

</div>
<script>
function editMth(m) {
  document.getElementById('mth-id').value = m.id;
  document.getElementById('mth-name').value = m.name;
  document.getElementById('mth-min').value = m.min_amount;
  document.getElementById('mth-max').value = m.max_amount;
  document.getElementById('mth-charge').value = m.charge_pct;
  document.getElementById('mth-fields').value = m.required_fields || '';
  document.getElementById('mth-instruc').value = m.instructions || '';
  document.getElementById('mth-status').value = m.status;
  document.getElementById('mth-form').scrollIntoView({behavior:'smooth'});
}
function resetMth() {
  document.getElementById('mth-id').value = '0';
  document.getElementById('mth-form').reset();
}
</script>
<?php require ROOT_PATH . '/admin/includes/footer.php'; ?>
