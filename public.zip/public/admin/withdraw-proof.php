<?php
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/includes/settings-loader.php';
requireAdmin();
$pdo = getDB();
$pageTitle = 'Withdrawal Proofs';
$adminPage = 'withdraw-proof';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $action = $_POST['action'] ?? '';
    $wid    = (int)($_POST['withdrawal_id'] ?? 0);

    if ($action === 'approve' && $wid) {
        $w = $pdo->query("SELECT * FROM withdrawals WHERE id=$wid AND status='pending'")->fetch();
        if ($w) {
            $txRef = trim($_POST['tx_ref'] ?? '');
            $note  = trim($_POST['note'] ?? '');
            $pdo->prepare("UPDATE withdrawals SET status='approved',admin_note=:n,tx_reference=:t,processed_at=NOW() WHERE id=:id")
                ->execute([':n'=>$note,':t'=>$txRef,':id'=>$wid]);
            createNotification($w['user_id'],'withdrawal','Withdrawal Approved','Your withdrawal of ৳'.number_format($w['amount'],2).' has been approved. Transaction ref: '.($txRef ?: 'N/A'));
            $_SESSION['flash'] = 'Withdrawal approved.';
        }
    } elseif ($action === 'reject' && $wid) {
        $w = $pdo->query("SELECT * FROM withdrawals WHERE id=$wid AND status='pending'")->fetch();
        if ($w) {
            $reason = trim($_POST['reject_reason'] ?? 'Rejected by admin');
            // Refund
            creditUser($w['user_id'], $w['amount'], 'refund', 'Withdrawal rejected — refunded');
            $pdo->prepare("UPDATE withdrawals SET status='rejected',admin_note=:n,processed_at=NOW() WHERE id=:id")
                ->execute([':n'=>$reason,':id'=>$wid]);
            createNotification($w['user_id'],'withdrawal','Withdrawal Rejected','Your withdrawal of ৳'.number_format($w['amount'],2).' was rejected. Reason: '.$reason.'. Amount has been refunded.');
            $_SESSION['flash'] = 'Withdrawal rejected and amount refunded.';
        }
    }
    redirect('/admin/withdraw-proof.php');
}

$flash  = $_SESSION['flash'] ?? ''; unset($_SESSION['flash']);
$filter = $_GET['status'] ?? 'pending';
$page   = max(1,(int)($_GET['page']??1));
$limit  = 15; $offset = ($page-1)*$limit;
$where  = $filter !== 'all' ? "AND w.status='$filter'" : '';
$total  = (int)$pdo->query("SELECT COUNT(*) FROM withdrawals w WHERE 1=1 $where")->fetchColumn();
$withdrawals = $pdo->query("SELECT w.*,u.name as user_name,u.email as user_email FROM withdrawals w JOIN users u ON u.id=w.user_id WHERE 1=1 $where ORDER BY w.created_at DESC LIMIT $limit OFFSET $offset")->fetchAll();
require ROOT_PATH . '/admin/includes/header.php';
?>
<?php if ($flash): ?><div class="alert alert-success" style="margin-bottom:20px;"><?= h($flash) ?></div><?php endif; ?>

<div class="admin-card">
  <div class="admin-card-header">
    <div class="admin-card-title">Withdrawal Proofs (<?= $total ?>)</div>
    <div style="display:flex;gap:8px;">
      <?php foreach (['pending'=>'Pending','approved'=>'Approved','rejected'=>'Rejected','all'=>'All'] as $v=>$l): ?>
      <a href="?status=<?= $v ?>" class="btn btn-sm <?= $filter===$v?'btn-primary':'btn-secondary' ?>"><?= $l ?></a>
      <?php endforeach; ?>
    </div>
  </div>

  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>User</th><th>Method</th><th>Account</th><th>Amount</th><th>Requested</th><th>Status</th><th>Proof / Action</th></tr></thead>
      <tbody>
        <?php foreach ($withdrawals as $w):
          $details = json_decode($w['details'] ?? '{}', true) ?? [];
        ?>
        <tr>
          <td>
            <a href="/admin/user-detail.php?id=<?= $w['user_id'] ?>"><strong><?= h($w['user_name']) ?></strong></a><br>
            <small style="color:#888;"><?= h($w['user_email']) ?></small>
          </td>
          <td><span class="badge badge-info"><?= h($w['method']) ?></span></td>
          <td style="font-size:13px;">
            <?php foreach ($details as $k=>$v): ?>
            <div><strong><?= h($k) ?>:</strong> <?= h($v) ?></div>
            <?php endforeach; ?>
          </td>
          <td><strong style="color:#22c55e;">৳<?= number_format($w['amount'],2) ?></strong></td>
          <td style="font-size:12px;"><?= date('d M Y H:i',strtotime($w['created_at'])) ?></td>
          <td>
            <span class="badge <?= $w['status']==='approved'?'badge-success':($w['status']==='rejected'?'badge-danger':'badge-warning') ?>">
              <?= ucfirst($w['status']) ?>
            </span>
            <?php if ($w['admin_note']): ?>
            <div style="font-size:11px;color:#888;margin-top:4px;"><?= h($w['admin_note']) ?></div>
            <?php endif; ?>
            <?php if ($w['tx_reference']): ?>
            <div style="font-size:11px;color:#667eea;">Ref: <?= h($w['tx_reference']) ?></div>
            <?php endif; ?>
          </td>
          <td>
            <?php if ($w['status']==='pending'): ?>
            <button class="btn btn-success btn-xs" onclick="approveW(<?= $w['id'] ?>)">✓ Approve</button>
            <button class="btn btn-danger btn-xs" onclick="rejectW(<?= $w['id'] ?>)">✗ Reject</button>
            <?php else: ?>
            <span style="color:#aaa;font-size:12px;">Processed</span>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (!$withdrawals): ?><tr><td colspan="7" style="text-align:center;color:#888;padding:30px;">No <?= $filter === 'all' ? '' : $filter ?> withdrawals found.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>

  <?php if ($total > $limit): ?>
  <div style="padding:12px;text-align:center;">
    <?php for ($i=1;$i<=ceil($total/$limit);$i++): ?>
    <a href="?status=<?= $filter ?>&page=<?= $i ?>" class="btn btn-xs <?= $page==$i?'btn-primary':'btn-secondary' ?>"><?= $i ?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
</div>

<!-- Approve Modal -->
<div id="approve-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9999;align-items:center;justify-content:center;">
  <div style="background:#fff;border-radius:12px;padding:28px;min-width:360px;max-width:500px;width:90%;">
    <h3 style="margin:0 0 16px;">✓ Approve Withdrawal</h3>
    <form method="post">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="approve">
      <input type="hidden" name="withdrawal_id" id="approve-wid">
      <div class="form-group"><label>Transaction Reference (optional)</label><input type="text" name="tx_ref" class="form-control" placeholder="bKash TrxID / Nagad Ref"></div>
      <div class="form-group"><label>Note (optional)</label><input type="text" name="note" class="form-control" placeholder="Payment sent via bKash"></div>
      <div style="display:flex;gap:8px;margin-top:16px;">
        <button class="btn btn-success">Confirm Approve</button>
        <button type="button" class="btn btn-secondary" onclick="closeModals()">Cancel</button>
      </div>
    </form>
  </div>
</div>

<!-- Reject Modal -->
<div id="reject-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9999;align-items:center;justify-content:center;">
  <div style="background:#fff;border-radius:12px;padding:28px;min-width:360px;max-width:500px;width:90%;">
    <h3 style="margin:0 0 16px;">✗ Reject Withdrawal</h3>
    <form method="post">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="reject">
      <input type="hidden" name="withdrawal_id" id="reject-wid">
      <div class="form-group"><label>Rejection Reason</label><input type="text" name="reject_reason" class="form-control" value="Invalid account details" required></div>
      <small style="color:#e74c3c;">Amount will be automatically refunded to user's wallet.</small>
      <div style="display:flex;gap:8px;margin-top:16px;">
        <button class="btn btn-danger">Confirm Reject</button>
        <button type="button" class="btn btn-secondary" onclick="closeModals()">Cancel</button>
      </div>
    </form>
  </div>
</div>

<script>
function approveW(id) {
  document.getElementById('approve-wid').value = id;
  document.getElementById('approve-modal').style.display = 'flex';
}
function rejectW(id) {
  document.getElementById('reject-wid').value = id;
  document.getElementById('reject-modal').style.display = 'flex';
}
function closeModals() {
  document.getElementById('approve-modal').style.display = 'none';
  document.getElementById('reject-modal').style.display = 'none';
}
document.querySelectorAll('#approve-modal,#reject-modal').forEach(m => m.addEventListener('click', e => { if(e.target===m) closeModals(); }));
</script>
<?php require ROOT_PATH . '/admin/includes/footer.php'; ?>
