<?php
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/includes/settings-loader.php';
requireAdmin();
$pdo = getDB();
$pageTitle = 'Withdrawal Management';
$adminPage = 'withdrawals';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $action = $_POST['action'] ?? '';
    $wid    = (int)($_POST['wid'] ?? 0);
    if ($action === 'pay' && $wid) {
        $note = trim($_POST['note'] ?? '');
        $w = $pdo->query("SELECT * FROM withdrawals WHERE id=$wid AND status='pending'")->fetch();
        if ($w) {
            $pdo->prepare("UPDATE withdrawals SET status='paid', admin_note=:n, paid_at=NOW() WHERE id=:id")->execute([':n'=>$note,':id'=>$wid]);
            $pdo->prepare("UPDATE users SET total_withdrawn=total_withdrawn+:a WHERE id=:uid")->execute([':a'=>$w['amount'],':uid'=>$w['user_id']]);
            createNotification((int)$w['user_id'],'withdraw','Withdrawal Paid! 💰','Your withdrawal of '.formatAmount((float)$w['amount']).' has been paid. '.$note);
            checkAchievements((int)$w['user_id']);
        }
        $_SESSION['flash'] = 'Withdrawal marked as paid.'; redirect('/admin/withdrawals.php');
    } elseif ($action === 'reject' && $wid) {
        $reason = trim($_POST['reason'] ?? 'Rejected');
        $w = $pdo->query("SELECT * FROM withdrawals WHERE id=$wid AND status='pending'")->fetch();
        if ($w) {
            $pdo->prepare("UPDATE withdrawals SET status='rejected', admin_note=:r WHERE id=:id")->execute([':r'=>$reason,':id'=>$wid]);
            $pdo->prepare("UPDATE users SET balance=balance+:a WHERE id=:uid")->execute([':a'=>$w['amount'],':uid'=>$w['user_id']]);
            addTransaction((int)$w['user_id'],'admin_credit',(float)$w['amount'],'Withdrawal refunded: '.$reason);
            createNotification((int)$w['user_id'],'withdraw','Withdrawal Rejected','Your withdrawal was rejected. Reason: '.$reason.'. Amount refunded to your balance.');
        }
        $_SESSION['flash'] = 'Withdrawal rejected and amount refunded.'; redirect('/admin/withdrawals.php');
    }
}

$flash = $_SESSION['flash'] ?? ''; unset($_SESSION['flash']);
$status = in_array($_GET['status']??'',['pending','paid','rejected','all'])?$_GET['status']:'pending';
$method = (int)($_GET['method']??0);
$page   = max(1,(int)($_GET['page']??1));
$limit  = 20; $offset = ($page-1)*$limit;

$where = ['1=1']; $params = [];
if ($status !== 'all') { $where[] = "w.status=:st"; $params[':st']=$status; }
if ($method) { $where[] = "w.method_id=:mid"; $params[':mid']=$method; }
$whereStr = implode(' AND ',$where);

$t2 = $params;
$total = (int)$pdo->prepare("SELECT COUNT(*) FROM withdrawals w WHERE $whereStr")->execute($t2) ? (clone $pdo->prepare("SELECT COUNT(*) FROM withdrawals w WHERE $whereStr"))->execute($t2) && false ?: 0 : 0;
// Safe total
$tStmt = $pdo->prepare("SELECT COUNT(*) FROM withdrawals w WHERE $whereStr");
$tStmt->execute($params);
$total = (int)$tStmt->fetchColumn();

$params[':limit']=$limit; $params[':offset']=$offset;
$stmt = $pdo->prepare("SELECT w.*, u.name as user_name, u.email as user_email, wm.name as method_name, wm.icon as method_icon FROM withdrawals w JOIN users u ON u.id=w.user_id JOIN withdraw_methods wm ON wm.id=w.method_id WHERE $whereStr ORDER BY w.created_at DESC LIMIT :limit OFFSET :offset");
$stmt->execute($params);
$withdrawals = $stmt->fetchAll();

$methods = $pdo->query("SELECT * FROM withdraw_methods ORDER BY id")->fetchAll();
$pendingSum = (float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM withdrawals WHERE status='pending'")->fetchColumn();

require ROOT_PATH . '/admin/includes/header.php';
?>
<?php if ($flash): ?><div class="alert alert-success" style="margin-bottom:20px;"><?= h($flash) ?></div><?php endif; ?>

<div class="kpi-grid" style="margin-bottom:20px;">
  <div class="kpi-card"><div class="kpi-icon orange"><i class="fa-solid fa-clock"></i></div><div class="kpi-body"><div class="kpi-label">Pending Payout</div><div class="kpi-value"><?= getSetting('currency_symbol','৳') ?><?= number_format($pendingSum,2) ?></div></div></div>
</div>

<div class="admin-card">
  <div class="admin-card-header">
    <div class="admin-card-title">Withdrawals (<?= $total ?>)</div>
    <a href="?export=csv&status=<?= $status ?>" class="btn btn-sm btn-outline"><i class="fa-solid fa-download"></i> Export CSV</a>
  </div>
  <div class="admin-filters">
    <?php foreach (['pending'=>'⏳ Pending','paid'=>'✅ Paid','rejected'=>'❌ Rejected','all'=>'All'] as $k=>$v): ?>
      <a href="?status=<?= $k ?>" class="filter-btn <?= $status===$k?'filter-btn-primary':'filter-btn-outline' ?>"><?= $v ?></a>
    <?php endforeach; ?>
    <form method="get" style="display:flex;gap:8px;">
      <input type="hidden" name="status" value="<?= h($status) ?>">
      <select name="method" class="filter-select" onchange="this.form.submit()">
        <option value="">All Methods</option>
        <?php foreach ($methods as $m): ?><option value="<?= $m['id'] ?>" <?= $method==$m['id']?'selected':'' ?>><?= h($m['name']) ?></option><?php endforeach; ?>
      </select>
    </form>
  </div>
  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead><tr><th>User</th><th>Method</th><th>Address</th><th>Amount</th><th>Status</th><th>Requested</th><th>Actions</th></tr></thead>
      <tbody>
        <?php foreach ($withdrawals as $w): ?>
          <tr>
            <td><div class="user-cell"><div class="table-avatar"><?= strtoupper(substr($w['user_name'],0,1)) ?></div><div><div class="user-cell-name"><?= h($w['user_name']) ?></div><div class="user-cell-email"><?= h($w['user_email']) ?></div></div></div></td>
            <td><div style="display:flex;align-items:center;gap:6px;"><i class="fa-solid <?= h($w['method_icon']??'fa-wallet') ?>" style="color:var(--primary)"></i><?= h($w['method_name']) ?></div></td>
            <td style="font-size:13px;font-family:monospace;"><?= h($w['address']) ?></td>
            <td style="font-weight:900;font-size:18px;"><?= formatAmount((float)$w['amount']) ?></td>
            <td><span class="status-badge status-<?= h($w['status']) ?>"><?= ucfirst($w['status']) ?></span><?php if ($w['admin_note']): ?><div style="font-size:11px;color:#888;margin-top:4px;"><?= h(substr($w['admin_note'],0,40)) ?></div><?php endif; ?></td>
            <td style="font-size:12px;color:#888"><?= date('M j, Y',strtotime($w['created_at'])) ?></td>
            <td>
              <?php if ($w['status'] === 'pending'): ?>
                <div class="action-btns">
                  <button class="action-btn-sm action-btn-pay" onclick="openPayModal(<?= $w['id'] ?>,<?= $w['amount'] ?>)"><i class="fa-solid fa-check"></i> Pay</button>
                  <button class="action-btn-sm action-btn-reject" onclick="openRejectWModal(<?= $w['id'] ?>)"><i class="fa-solid fa-times"></i> Reject</button>
                </div>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?= paginationLinks($total,$page,$limit,'/admin/withdrawals.php?status='.$status) ?>
</div>

<!-- Pay Modal -->
<div class="modal-overlay" id="pay-modal">
  <div class="modal-box">
    <div class="modal-header"><h3 id="pay-modal-title">Mark as Paid</h3><span class="modal-close"><i class="fa-solid fa-xmark"></i></span></div>
    <form method="post"><<?= csrfField() ?><input type="hidden" name="action" value="pay"><input type="hidden" name="wid" id="pay-wid">
    <div class="form-group"><label class="form-label">Admin Note (optional)</label><input type="text" name="note" class="form-control" placeholder="Transaction ID or note..."></div>
    <button type="submit" class="btn btn-primary btn-block"><i class="fa-solid fa-check"></i> Mark as Paid</button>
    </form>
  </div>
</div>
<!-- Reject Modal -->
<div class="modal-overlay" id="reject-w-modal">
  <div class="modal-box">
    <div class="modal-header"><h3>Reject Withdrawal</h3><span class="modal-close"><i class="fa-solid fa-xmark"></i></span></div>
    <form method="post"><?= csrfField() ?><input type="hidden" name="action" value="reject"><input type="hidden" name="wid" id="reject-wid">
    <div class="form-group"><label class="form-label">Reason <span style="color:var(--danger)">*</span></label><textarea name="reason" class="form-control" rows="3" required placeholder="Rejection reason..."></textarea></div>
    <button type="submit" class="btn btn-danger btn-block">Reject & Refund</button>
    </form>
  </div>
</div>
<script>
function openPayModal(id,amt){document.getElementById('pay-wid').value=id;document.getElementById('pay-modal-title').textContent='Mark as Paid — <?= getSetting('currency_symbol','৳') ?>'+amt;document.getElementById('pay-modal').classList.add('active');}
function openRejectWModal(id){document.getElementById('reject-wid').value=id;document.getElementById('reject-w-modal').classList.add('active');}
</script>
<?php require ROOT_PATH . '/admin/includes/footer.php'; ?>
