// ── Admin Sidebar Toggle ──────────────────────────────────────────────────────
const sidebarToggle = document.querySelector('.sidebar-toggle');
const adminSidebar  = document.querySelector('.admin-sidebar');
let overlay = null;

if (sidebarToggle && adminSidebar) {
  sidebarToggle.addEventListener('click', () => {
    adminSidebar.classList.toggle('open');
    if (adminSidebar.classList.contains('open')) {
      overlay = document.createElement('div');
      overlay.className = 'sidebar-overlay';
      document.body.appendChild(overlay);
      overlay.addEventListener('click', closeSidebar);
    } else {
      closeSidebar();
    }
  });
}

function closeSidebar() {
  adminSidebar?.classList.remove('open');
  overlay?.remove();
  overlay = null;
}

// ── Color Picker Sync ─────────────────────────────────────────────────────────
document.querySelectorAll('.color-picker-wrap input[type=color]').forEach(picker => {
  const textInput = picker.nextElementSibling;
  if (!textInput) return;
  textInput.value = picker.value;
  picker.addEventListener('input', () => { textInput.value = picker.value; });
  textInput.addEventListener('input', () => {
    if (/^#[0-9A-Fa-f]{6}$/.test(textInput.value)) picker.value = textInput.value;
  });
});

// ── Admin Toast ───────────────────────────────────────────────────────────────
function adminToast(msg, type = 'success') {
  const colors = { success: '#00C896', error: '#FF4757', info: '#FFA502' };
  const toast = document.createElement('div');
  toast.style.cssText = `position:fixed;top:20px;right:20px;z-index:9999;background:#fff;padding:14px 20px;border-radius:10px;box-shadow:0 8px 32px rgba(0,0,0,0.15);border-left:4px solid ${colors[type]};font-weight:600;font-size:14px;animation:slideInRight 0.3s ease;max-width:340px;`;
  toast.textContent = msg;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 3000);
}
window.adminToast = adminToast;

// ── Confirm Delete ────────────────────────────────────────────────────────────
document.addEventListener('click', e => {
  const btn = e.target.closest('[data-confirm]');
  if (!btn) return;
  if (!confirm(btn.dataset.confirm || 'Are you sure?')) e.preventDefault();
});

// ── Image Lightbox ────────────────────────────────────────────────────────────
document.addEventListener('click', e => {
  const img = e.target.closest('.sub-screenshot, [data-lightbox]');
  if (!img) return;
  const src = img.dataset.lightbox || img.src;
  let lb = document.getElementById('admin-lightbox');
  if (!lb) {
    lb = document.createElement('div');
    lb.id = 'admin-lightbox';
    lb.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.92);z-index:2000;display:flex;align-items:center;justify-content:center;';
    lb.innerHTML = '<div style="position:relative;max-width:90vw;"><img style="max-width:90vw;max-height:90vh;border-radius:8px;" src=""><span style="position:absolute;top:-40px;right:0;color:#fff;font-size:28px;cursor:pointer;" onclick="this.closest(\'#admin-lightbox\').remove()">✕</span></div>';
    document.body.appendChild(lb);
    lb.addEventListener('click', ev => { if (ev.target === lb) lb.remove(); });
  }
  lb.querySelector('img').src = src;
  document.body.appendChild(lb);
});

// ── Bulk Select ───────────────────────────────────────────────────────────────
const selectAll = document.getElementById('select-all');
if (selectAll) {
  selectAll.addEventListener('change', function() {
    document.querySelectorAll('.row-checkbox').forEach(cb => { cb.checked = this.checked; });
    updateBulkBar();
  });
  document.querySelectorAll('.row-checkbox').forEach(cb => {
    cb.addEventListener('change', updateBulkBar);
  });
}

function getCheckedIds() {
  return [...document.querySelectorAll('.row-checkbox:checked')].map(cb => cb.value);
}

function updateBulkBar() {
  const bar = document.getElementById('bulk-action-bar');
  if (!bar) return;
  const count = getCheckedIds().length;
  bar.style.display = count > 0 ? 'flex' : 'none';
  const countEl = bar.querySelector('.bulk-count');
  if (countEl) countEl.textContent = count + ' selected';
}

document.getElementById('bulk-approve-btn')?.addEventListener('click', () => {
  const ids = getCheckedIds();
  if (!ids.length) return;
  if (!confirm(`Approve ${ids.length} submissions?`)) return;
  bulkAction('bulk_approve', ids);
});

document.getElementById('bulk-reject-btn')?.addEventListener('click', () => {
  const ids = getCheckedIds();
  if (!ids.length) return;
  const reason = prompt('Enter rejection reason:');
  if (!reason) return;
  bulkAction('bulk_reject', ids, reason);
});

function bulkAction(action, ids, reason = '') {
  const fd = new FormData();
  fd.append('action', action);
  fd.append('csrf_token', document.querySelector('[name=csrf_token]')?.value || '');
  ids.forEach(id => fd.append('ids[]', id));
  if (reason) fd.append('reason', reason);

  fetch(window.location.href, { method: 'POST', body: fd })
    .then(r => r.json())
    .then(d => { adminToast(d.message, d.success ? 'success' : 'error'); if (d.success) setTimeout(() => window.location.reload(), 800); })
    .catch(() => adminToast('Error occurred', 'error'));
}

// ── SortableJS drag & drop ────────────────────────────────────────────────────
function initSortable(listId, saveUrl) {
  const el = document.getElementById(listId);
  if (!el || typeof Sortable === 'undefined') return;
  Sortable.create(el, {
    animation: 200,
    handle: '.drag-handle',
    ghostClass: 'sortable-ghost',
    chosenClass: 'sortable-chosen',
    onEnd() {
      const order = [...el.querySelectorAll('[data-id]')].map((el, i) => ({ id: el.dataset.id, order: i }));
      fetch(saveUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ order, csrf_token: document.querySelector('[name=csrf_token]')?.value })
      }).then(() => adminToast('Order saved', 'success'));
    }
  });
}
window.initSortable = initSortable;

// ── Prize row management ──────────────────────────────────────────────────────
window.addPrizeRow = function() {
  const tbody = document.getElementById('prize-tbody');
  if (!tbody) return;
  const tr = document.createElement('tr');
  tr.innerHTML = `
    <td><input class="admin-input" name="label[]" placeholder="Label" required></td>
    <td><input class="admin-input" type="number" name="amount[]" placeholder="Amount" step="0.01" min="0" required></td>
    <td><input class="admin-input" type="number" name="probability[]" placeholder="%" step="0.01" min="0.01" max="100" required></td>
    <td><input type="color" name="color[]" value="#00C896" class="prize-color-inp"></td>
    <td><button type="button" class="action-btn-sm action-btn-reject" onclick="this.closest('tr').remove()"><i class="fa-solid fa-trash"></i></button></td>`;
  tbody.appendChild(tr);
};

// ── Charts helper (Chart.js) ──────────────────────────────────────────────────
window.createLineChart = function(canvasId, labels, data, label, color = '#00C896') {
  const ctx = document.getElementById(canvasId)?.getContext('2d');
  if (!ctx) return;
  new Chart(ctx, {
    type: 'line',
    data: {
      labels,
      datasets: [{ label, data, borderColor: color, backgroundColor: color + '22', fill: true, tension: 0.4, pointRadius: 4, pointBackgroundColor: color }]
    },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.05)' } }, x: { grid: { display: false } } } }
  });
};

window.createBarChart = function(canvasId, labels, data, label, color = '#00C896') {
  const ctx = document.getElementById(canvasId)?.getContext('2d');
  if (!ctx) return;
  new Chart(ctx, {
    type: 'bar',
    data: { labels, datasets: [{ label, data, backgroundColor: color + 'cc', borderRadius: 6 }] },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.05)' } }, x: { grid: { display: false } } } }
  });
};

window.createPieChart = function(canvasId, labels, data, colors) {
  const ctx = document.getElementById(canvasId)?.getContext('2d');
  if (!ctx) return;
  new Chart(ctx, {
    type: 'doughnut',
    data: { labels, datasets: [{ data, backgroundColor: colors, borderWidth: 0 }] },
    options: { responsive: true, maintainAspectRatio: false, cutout: '60%', plugins: { legend: { position: 'bottom' } } }
  });
};

// ── AJAX admin form ───────────────────────────────────────────────────────────
document.querySelectorAll('form[data-admin-ajax]').forEach(form => {
  form.addEventListener('submit', async function(e) {
    e.preventDefault();
    const btn = form.querySelector('[type=submit]');
    if (btn) { btn.disabled = true; btn.dataset.orig = btn.textContent; btn.textContent = 'Saving...'; }
    try {
      const res = await fetch(form.action || window.location.href, { method: 'POST', body: new FormData(form), headers: { 'X-Requested-With': 'XMLHttpRequest' } });
      const data = await res.json();
      adminToast(data.message, data.success ? 'success' : 'error');
      if (data.success && data.redirect) setTimeout(() => window.location.href = data.redirect, 800);
    } catch { adminToast('Error occurred', 'error'); }
    if (btn) { btn.disabled = false; btn.textContent = btn.dataset.orig || 'Save'; }
  });
});
