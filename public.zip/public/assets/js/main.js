// ── Toast Notifications ──────────────────────────────────────────────────────
function showToast(msg, type = 'success') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }
  const icons = { success: 'fa-circle-check', error: 'fa-circle-xmark', info: 'fa-circle-info' };
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `<i class="fa-solid ${icons[type] || icons.success}"></i><span>${msg}</span>`;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), 3200);
}
window.showToast = showToast;

// ── Skeleton → Content ───────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  setTimeout(() => {
    document.querySelectorAll('.skeleton-loader').forEach(el => {
      el.style.display = 'none';
    });
    document.querySelectorAll('.content-loader').forEach(el => {
      el.style.display = '';
    });
  }, 600);
});

// ── FAQ Accordion ────────────────────────────────────────────────────────────
document.addEventListener('click', e => {
  const q = e.target.closest('.faq-q');
  if (!q) return;
  const item = q.closest('.faq-item');
  item.classList.toggle('open');
});

// ── Count-up Animation ───────────────────────────────────────────────────────
function animateCount(el) {
  const target = parseFloat(el.dataset.target || el.textContent.replace(/[^0-9.]/g, ''));
  const decimals = el.dataset.decimals ? parseInt(el.dataset.decimals) : 0;
  const prefix = el.dataset.prefix || '';
  const suffix = el.dataset.suffix || '';
  const duration = 1800;
  const start = performance.now();
  function step(now) {
    const p = Math.min((now - start) / duration, 1);
    const ease = 1 - Math.pow(1 - p, 3);
    el.textContent = prefix + (target * ease).toFixed(decimals) + suffix;
    if (p < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}

const observer = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      animateCount(e.target);
      observer.unobserve(e.target);
    }
  });
}, { threshold: 0.5 });

document.querySelectorAll('.count-up').forEach(el => observer.observe(el));

// ── Mobile Nav Toggle ────────────────────────────────────────────────────────
const navToggle = document.querySelector('.nav-toggle');
const headerNav = document.querySelector('.header-nav');
if (navToggle && headerNav) {
  navToggle.addEventListener('click', () => {
    headerNav.classList.toggle('nav-open');
  });
}

// ── Modal ─────────────────────────────────────────────────────────────────────
document.addEventListener('click', e => {
  if (e.target.matches('.modal-overlay')) e.target.classList.remove('active');
  if (e.target.closest('.modal-close')) e.target.closest('.modal-overlay').classList.remove('active');
  const openBtn = e.target.closest('[data-modal]');
  if (openBtn) {
    const modal = document.getElementById(openBtn.dataset.modal);
    if (modal) modal.classList.add('active');
  }
});

// ── Lightbox ──────────────────────────────────────────────────────────────────
function openLightbox(src) {
  let lb = document.getElementById('lightbox');
  if (!lb) {
    lb = document.createElement('div');
    lb.id = 'lightbox';
    lb.className = 'lightbox';
    lb.innerHTML = '<span class="lightbox-close"><i class="fa-solid fa-xmark"></i></span><img id="lb-img" src="" alt="">';
    document.body.appendChild(lb);
    lb.addEventListener('click', e => { if (e.target === lb || e.target.closest('.lightbox-close')) lb.classList.remove('active'); });
  }
  document.getElementById('lb-img').src = src;
  lb.classList.add('active');
}
window.openLightbox = openLightbox;

document.addEventListener('click', e => {
  const img = e.target.closest('[data-lightbox]');
  if (img) openLightbox(img.dataset.lightbox || img.src);
});

// ── Copy to Clipboard ─────────────────────────────────────────────────────────
function copyText(text) {
  navigator.clipboard?.writeText(text).then(() => showToast('Copied to clipboard!', 'success'))
    .catch(() => { const ta = document.createElement('textarea'); ta.value = text; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove(); showToast('Copied!', 'success'); });
}
window.copyText = copyText;

// ── Daily Bonus Countdown ─────────────────────────────────────────────────────
const countdownEl = document.getElementById('bonus-countdown');
if (countdownEl) {
  const nextClaim = new Date(countdownEl.dataset.next);
  function updateCountdown() {
    const now = new Date();
    const diff = nextClaim - now;
    if (diff <= 0) { countdownEl.textContent = 'Ready!'; return; }
    const h = Math.floor(diff / 3600000);
    const m = Math.floor((diff % 3600000) / 60000);
    const s = Math.floor((diff % 60000) / 1000);
    countdownEl.textContent = `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
  }
  updateCountdown();
  setInterval(updateCountdown, 1000);
}

// ── Upload Preview ────────────────────────────────────────────────────────────
const screenshotInput = document.getElementById('screenshot');
if (screenshotInput) {
  screenshotInput.addEventListener('change', function() {
    const file = this.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = e => {
      let preview = document.getElementById('upload-preview');
      if (!preview) {
        preview = document.createElement('img');
        preview.id = 'upload-preview';
        preview.className = 'upload-preview';
        this.closest('.upload-area').appendChild(preview);
      }
      preview.src = e.target.result;
    };
    reader.readAsDataURL(file);
  });
}

// ── Drag & drop upload ────────────────────────────────────────────────────────
const uploadArea = document.querySelector('.upload-area');
if (uploadArea) {
  ['dragenter','dragover'].forEach(ev => uploadArea.addEventListener(ev, e => { e.preventDefault(); uploadArea.classList.add('dragover'); }));
  ['dragleave','drop'].forEach(ev => uploadArea.addEventListener(ev, () => uploadArea.classList.remove('dragover')));
  uploadArea.addEventListener('drop', e => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file && screenshotInput) { const dt = new DataTransfer(); dt.items.add(file); screenshotInput.files = dt.files; screenshotInput.dispatchEvent(new Event('change')); }
  });
  uploadArea.addEventListener('click', () => screenshotInput?.click());
}

// ── Withdraw Method Selection ─────────────────────────────────────────────────
document.querySelectorAll('.method-card').forEach(card => {
  card.addEventListener('click', function() {
    document.querySelectorAll('.method-card').forEach(c => c.classList.remove('selected'));
    this.classList.add('selected');
    const form = document.getElementById('withdraw-form');
    const methodId = document.getElementById('method_id');
    const minLabel = document.getElementById('min-amount-label');
    if (form) form.style.display = 'block';
    if (methodId) methodId.value = this.dataset.id;
    if (minLabel) minLabel.textContent = this.dataset.min;
    form?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  });
});

// ── Leaderboard Tabs ──────────────────────────────────────────────────────────
document.querySelectorAll('.lb-tab').forEach(tab => {
  tab.addEventListener('click', function() {
    document.querySelectorAll('.lb-tab').forEach(t => t.classList.remove('active'));
    this.classList.add('active');
    const period = this.dataset.period;
    window.location.href = `?period=${period}`;
  });
});

// ── Filter Tabs ───────────────────────────────────────────────────────────────
document.querySelectorAll('.filter-tab').forEach(tab => {
  tab.addEventListener('click', function() {
    document.querySelectorAll('.filter-tab').forEach(t => t.classList.remove('active'));
    this.classList.add('active');
    const type = this.dataset.type;
    const url = new URL(window.location.href);
    url.searchParams.set('type', type);
    url.searchParams.delete('page');
    window.location.href = url.toString();
  });
});

// ── Spin Wheel ────────────────────────────────────────────────────────────────
const spinBtn = document.getElementById('btn-spin');
const spinCanvas = document.getElementById('spin-wheel');
if (spinBtn && spinCanvas) {
  const ctx = spinCanvas.getContext('2d');
  const prizes = JSON.parse(spinCanvas.dataset.prizes || '[]');
  const size = spinCanvas.width;
  const center = size / 2;
  const radius = center - 10;
  let currentAngle = 0;

  function drawWheel(rotation) {
    ctx.clearRect(0, 0, size, size);
    if (!prizes.length) return;
    const arc = (2 * Math.PI) / prizes.length;
    prizes.forEach((prize, i) => {
      const startAngle = rotation + i * arc;
      const endAngle = startAngle + arc;
      ctx.beginPath();
      ctx.moveTo(center, center);
      ctx.arc(center, center, radius, startAngle, endAngle);
      ctx.closePath();
      ctx.fillStyle = prize.color || '#00C896';
      ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,0.3)';
      ctx.lineWidth = 2;
      ctx.stroke();

      ctx.save();
      ctx.translate(center, center);
      ctx.rotate(startAngle + arc / 2);
      ctx.textAlign = 'right';
      ctx.fillStyle = '#fff';
      ctx.font = 'bold 13px sans-serif';
      ctx.shadowColor = 'rgba(0,0,0,0.4)';
      ctx.shadowBlur = 4;
      ctx.fillText(prize.label, radius - 12, 5);
      ctx.restore();
    });
  }

  drawWheel(currentAngle);

  spinBtn.addEventListener('click', function() {
    if (this.disabled) return;
    this.disabled = true;
    this.textContent = 'Spinning...';

    fetch('?action=spin', { method: 'POST', headers: { 'X-Requested-With': 'XMLHttpRequest', 'Content-Type': 'application/json' }, body: JSON.stringify({ csrf: document.querySelector('[name=csrf_token]')?.value }) })
      .then(r => r.json())
      .then(data => {
        if (!data.success) { showToast(data.message || 'Error', 'error'); spinBtn.disabled = false; spinBtn.textContent = 'SPIN'; return; }

        const prizeIdx = prizes.findIndex(p => p.label === data.prize_label);
        const arc = (2 * Math.PI) / prizes.length;
        const targetAngle = -prizeIdx * arc - arc / 2;
        const totalRotation = Math.PI * 2 * 8 + targetAngle - (currentAngle % (Math.PI * 2));
        const duration = 4000;
        const startTime = performance.now();
        const startAngle = currentAngle;

        function animateSpin(now) {
          const elapsed = now - startTime;
          const progress = Math.min(elapsed / duration, 1);
          const ease = 1 - Math.pow(1 - progress, 4);
          currentAngle = startAngle + totalRotation * ease;
          drawWheel(currentAngle);
          if (progress < 1) { requestAnimationFrame(animateSpin); }
          else {
            setTimeout(() => {
              const overlay = document.querySelector('.spin-result-overlay');
              if (overlay) {
                document.getElementById('spin-prize-label').textContent = data.prize_label;
                document.getElementById('spin-prize-amount').textContent = data.amount_formatted;
                overlay.classList.add('show');
              }
            }, 300);
          }
        }
        requestAnimationFrame(animateSpin);
      })
      .catch(() => { showToast('Spin failed. Try again.', 'error'); spinBtn.disabled = false; spinBtn.textContent = 'SPIN'; });
  });
}

// ── Spin result close ─────────────────────────────────────────────────────────
document.querySelector('.spin-result-close')?.addEventListener('click', () => {
  document.querySelector('.spin-result-overlay')?.classList.remove('show');
  window.location.reload();
});

// ── AJAX form submission ──────────────────────────────────────────────────────
document.querySelectorAll('form[data-ajax]').forEach(form => {
  form.addEventListener('submit', async function(e) {
    e.preventDefault();
    const btn = form.querySelector('[type=submit]');
    if (btn) { btn.disabled = true; btn.dataset.orig = btn.textContent; btn.textContent = 'Processing...'; }
    const fd = new FormData(form);
    try {
      const res = await fetch(form.action || window.location.href, { method: 'POST', body: fd, headers: { 'X-Requested-With': 'XMLHttpRequest' } });
      const data = await res.json();
      showToast(data.message, data.success ? 'success' : 'error');
      if (data.success && data.redirect) setTimeout(() => window.location.href = data.redirect, 800);
      if (data.success && form.dataset.reset) form.reset();
    } catch { showToast('Something went wrong.', 'error'); }
    if (btn) { btn.disabled = false; btn.textContent = btn.dataset.orig || 'Submit'; }
  });
});
