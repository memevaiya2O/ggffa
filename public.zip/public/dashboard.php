<?php
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/includes/settings-loader.php';
$user = requireLogin();
$pdo  = getDB();

$notifCount = getUnreadNotificationCount((int)$user['id']);

// Daily bonus
$today  = date('Y-m-d');
$bonusStmt = $pdo->prepare("SELECT id FROM daily_bonus WHERE user_id = :uid AND claimed_date = :d");
$bonusStmt->execute([':uid' => $user['id'], ':d' => $today]);
$bonusClaimed = (bool)$bonusStmt->fetch();

// Handle daily bonus claim
if (!empty($_POST['claim_bonus']) && !$bonusClaimed) {
    verifyCsrf();
    $amount = (float)getSetting('daily_bonus_amount', '5');
    $pdo->prepare("INSERT INTO daily_bonus (user_id, claimed_date, amount) VALUES (:uid, :d, :a) ON CONFLICT DO NOTHING")
        ->execute([':uid' => $user['id'], ':d' => $today, ':a' => $amount]);
    creditUser((int)$user['id'], $amount, 'daily_bonus', 'Daily bonus claim');
    addPoints((int)$user['id'], 10);
    createNotification((int)$user['id'], 'bonus_credited', 'Daily Bonus!', 'You claimed your daily bonus of ' . formatAmount($amount));
    $bonusClaimed = true;
    $user = getCurrentUser();
    redirect('/dashboard.php?bonus=1');
}

// Recent transactions
$txStmt = $pdo->prepare("SELECT * FROM transactions WHERE user_id = :uid ORDER BY created_at DESC LIMIT 5");
$txStmt->execute([':uid' => $user['id']]);
$transactions = $txStmt->fetchAll();

// Stats
$tasksCompleted = $pdo->prepare("SELECT COUNT(*) FROM submissions WHERE user_id = :uid AND status = 'approved'");
$tasksCompleted->execute([':uid' => $user['id']]);
$tasksCompleted = (int)$tasksCompleted->fetchColumn();

$referralsCount = $pdo->prepare("SELECT COUNT(*) FROM referrals WHERE referrer_id = :uid AND level = 1");
$referralsCount->execute([':uid' => $user['id']]);
$referralsCount = (int)$referralsCount->fetchColumn();

// Achievements
$allAch   = $pdo->query("SELECT a.*, (SELECT id FROM user_achievements WHERE user_id = {$user['id']} AND achievement_id = a.id) as unlocked_id FROM achievements a LIMIT 8")->fetchAll();

// Next level
$nextLvl  = $pdo->prepare("SELECT * FROM levels WHERE required_points > :p ORDER BY required_points ASC LIMIT 1");
$nextLvl->execute([':p' => $user['points']]);
$nextLevel = $nextLvl->fetch();
$curPoints = (int)$user['points'];
$curReq    = (int)($pdo->prepare("SELECT required_points FROM levels WHERE id = :id")->execute([':id' => $user['level_id']]) ? 0 : 0);
$lvlStmt   = $pdo->prepare("SELECT required_points FROM levels WHERE id = :id");
$lvlStmt->execute([':id' => $user['level_id']]);
$curLvlReq = (int)($lvlStmt->fetchColumn() ?: 0);
$xpPct     = $nextLevel ? min(100, round(($curPoints - $curLvlReq) / max(1, ($nextLevel['required_points'] - $curLvlReq)) * 100)) : 100;

// Next claim time
$nextMidnight = new DateTime('tomorrow midnight');
$nextBonus = $nextMidnight->format('c');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?= renderSeoMeta() ?>
<?= renderGoogleFont() ?>
<?= renderCssVars() ?>
<link rel="stylesheet" href="/assets/css/style.css">
<link rel="stylesheet" href="/assets/css/dashboard.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<?= $_SETTINGS['custom_header_script'] ?? '' ?>
</head>
<body>
<div class="app-layout">
  <header class="app-header">
    <div class="app-header-left">
      <div>
        <div class="greeting">Good <?= date('H') < 12 ? 'Morning' : (date('H') < 18 ? 'Afternoon' : 'Evening') ?> 👋</div>
        <div class="user-name"><?= h($user['name']) ?></div>
      </div>
    </div>
    <div class="app-header-right">
      <a href="/notifications.php" class="notif-btn">
        <i class="fa-solid fa-bell"></i>
        <?php if ($notifCount > 0): ?>
          <span class="notif-badge"><?= $notifCount > 99 ? '99+' : $notifCount ?></span>
        <?php endif; ?>
      </a>
      <a href="/profile.php" class="user-avatar-sm">
        <?php if ($user['avatar']): ?><img src="<?= h($user['avatar']) ?>" alt=""><?php else: ?><?= strtoupper(substr($user['name'],0,1)) ?><?php endif; ?>
      </a>
    </div>
  </header>

  <main class="main-content">
    <?php if (!empty($_GET['welcome'])): ?>
      <div class="alert alert-success" style="margin-bottom:16px;">🎉 Welcome to <?= h(getSetting('site_name')) ?>! Your account is ready.</div>
    <?php endif; ?>
    <?php if (!empty($_GET['bonus'])): ?>
      <div class="alert alert-success" style="margin-bottom:16px;">🎁 Daily bonus claimed successfully!</div>
    <?php endif; ?>

    <!-- Balance Card -->
    <div class="balance-card">
      <div class="balance-deco"><i class="fa-solid fa-coins"></i></div>
      <div class="balance-label">Available Balance</div>
      <div class="balance-amount"><?= h(getSetting('currency_symbol','৳')) ?><?= number_format((float)$user['balance'],2) ?></div>
      <div class="balance-stats">
        <div class="balance-stat">
          <div class="label">Total Earned</div>
          <div class="value"><?= h(getSetting('currency_symbol','৳')) ?><?= number_format((float)$user['total_earned'],2) ?></div>
        </div>
        <div class="balance-stat">
          <div class="label">Withdrawn</div>
          <div class="value"><?= h(getSetting('currency_symbol','৳')) ?><?= number_format((float)$user['total_withdrawn'],2) ?></div>
        </div>
      </div>
    </div>

    <!-- Level Card -->
    <div class="level-card">
      <div class="level-header">
        <div class="level-badge" style="background:<?= h($user['level_color'] ?? '#CD7F32') ?>22;color:<?= h($user['level_color'] ?? '#CD7F32') ?>">
          <i class="fa-solid <?= h($user['level_icon'] ?? 'fa-medal') ?>"></i>
        </div>
        <div class="level-info">
          <h4><?= h($user['level_name'] ?? 'Bronze') ?> Level</h4>
          <p><?= $curPoints ?> XP<?= $nextLevel ? ' / ' . $nextLevel['required_points'] . ' to ' . $nextLevel['name'] : ' — Max Level!' ?></p>
        </div>
      </div>
      <div class="xp-bar"><div class="xp-fill" style="width:<?= $xpPct ?>%"></div></div>
      <div class="xp-labels"><span><?= $curPoints ?> XP</span><span><?= $xpPct ?>%</span></div>
    </div>

    <!-- Daily Bonus -->
    <div class="daily-card">
      <div class="daily-info">
        <h4>🎁 Daily Bonus</h4>
        <p><?= formatAmount((float)getSetting('daily_bonus_amount','5')) ?> reward</p>
        <?php if ($bonusClaimed): ?>
          <div class="daily-timer">Next in: <span id="bonus-countdown" data-next="<?= $nextBonus ?>">--:--:--</span></div>
        <?php endif; ?>
      </div>
      <?php if (!$bonusClaimed): ?>
        <form method="post" action="/dashboard.php" style="flex-shrink:0">
          <?= csrfField() ?>
          <button type="submit" name="claim_bonus" value="1" class="btn-daily">CLAIM</button>
        </form>
      <?php else: ?>
        <button class="btn-daily" disabled>CLAIMED ✓</button>
      <?php endif; ?>
    </div>

    <!-- Quick Actions -->
    <div class="quick-actions">
      <a href="/tasks.php" class="action-btn"><i class="fa-solid fa-list-check"></i>Tasks</a>
      <a href="/withdraw.php" class="action-btn"><i class="fa-solid fa-money-bill-transfer"></i>Withdraw</a>
      <a href="/leaderboard.php" class="action-btn"><i class="fa-solid fa-trophy"></i>Board</a>
      <a href="/spin.php" class="action-btn"><i class="fa-solid fa-circle-notch"></i>Spin</a>
    </div>

    <!-- My Stats -->
    <div class="stats-cards">
      <div class="stat-mini"><div class="num"><?= $tasksCompleted ?></div><div class="lbl">Tasks Done</div></div>
      <div class="stat-mini"><div class="num"><?= $referralsCount ?></div><div class="lbl">Referrals</div></div>
      <div class="stat-mini"><div class="num"><?= (int)$user['streak_days'] ?></div><div class="lbl">Day Streak</div></div>
    </div>

    <!-- Recent Activity -->
    <div class="sec-header"><h3>Recent Activity</h3><a href="/wallet.php">See All</a></div>
    <div class="activity-list">
      <?php if (!$transactions): ?>
        <div style="text-align:center;padding:24px;color:#888;font-size:14px;"><i class="fa-solid fa-inbox" style="font-size:32px;display:block;margin-bottom:8px;"></i>No transactions yet</div>
      <?php else: ?>
        <?php foreach ($transactions as $tx): ?>
          <?php $pos = $tx['amount'] > 0; ?>
          <div class="activity-item">
            <div class="activity-icon <?= $pos ? 'credit' : 'debit' ?>">
              <i class="fa-solid <?= getTransactionIcon($tx['type']) ?>"></i>
            </div>
            <div class="activity-info">
              <div class="activity-desc"><?= h($tx['description']) ?></div>
              <div class="activity-time"><?= timeAgo($tx['created_at']) ?></div>
            </div>
            <div class="activity-amount <?= $pos ? 'pos' : 'neg' ?>"><?= $pos ? '+' : '' ?><?= formatAmount(abs($tx['amount'])) ?></div>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>

    <!-- Achievements -->
    <?php if ($allAch): ?>
    <div class="sec-header" style="margin-top:20px"><h3>Badges</h3><a href="/achievements.php">See All</a></div>
    <div class="badges-row">
      <?php foreach ($allAch as $a): ?>
        <div class="badge-item">
          <div class="badge-icon <?= $a['unlocked_id'] ? 'unlocked' : 'locked' ?>">
            <i class="fa-solid <?= h($a['icon']) ?>"></i>
          </div>
          <div class="badge-name"><?= h(strlen($a['name']) > 10 ? substr($a['name'],0,8).'...' : $a['name']) ?></div>
        </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </main>

  <!-- Bottom Nav -->
  <nav class="bottom-nav">
    <a href="/dashboard.php" class="nav-item active"><i class="fa-solid fa-house"></i>Home</a>
    <a href="/tasks.php" class="nav-item"><i class="fa-solid fa-list-check"></i>Tasks</a>
    <a href="/wallet.php" class="nav-item"><i class="fa-solid fa-wallet"></i>Wallet</a>
    <a href="/leaderboard.php" class="nav-item"><i class="fa-solid fa-trophy"></i>Board</a>
    <a href="/profile.php" class="nav-item"><i class="fa-solid fa-user"></i>Profile</a>
  </nav>
</div>
<div id="toast-container"></div>
<script src="/assets/js/main.js"></script>
<?= $_SETTINGS['custom_footer_script'] ?? '' ?>
</body>
</html>
