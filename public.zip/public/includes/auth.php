<?php
if (!defined('ROOT_PATH')) {
    define('ROOT_PATH', dirname(__DIR__));
}
require_once ROOT_PATH . '/includes/db.php';
require_once ROOT_PATH . '/includes/functions.php';

function registerUser(string $name, string $email, string $password, ?string $referralCode = null): array {
    $pdo = getDB();

    $existing = $pdo->prepare("SELECT id FROM users WHERE email = :e");
    $existing->execute([':e' => $email]);
    if ($existing->fetch()) {
        return ['success' => false, 'message' => 'Email already registered.'];
    }

    $hash    = password_hash($password, PASSWORD_BCRYPT);
    $refCode = generateReferralCode();
    while (true) {
        $check = $pdo->prepare("SELECT id FROM users WHERE referral_code = :c");
        $check->execute([':c' => $refCode]);
        if (!$check->fetch()) break;
        $refCode = generateReferralCode();
    }

    $referredById = null;
    if ($referralCode) {
        $ref = $pdo->prepare("SELECT id FROM users WHERE referral_code = :c");
        $ref->execute([':c' => $referralCode]);
        $referrer = $ref->fetch();
        if ($referrer) $referredById = $referrer['id'];
    }

    $pdo->prepare("INSERT INTO users (name, email, password, referral_code, referred_by, level_id) VALUES (:name, :email, :pass, :ref, :rby, 1)")
        ->execute([':name' => $name, ':email' => $email, ':pass' => $hash, ':ref' => $refCode, ':rby' => $referredById]);

    $newUserId = (int)$pdo->lastInsertId();

    // Welcome bonus
    global $_SETTINGS;
    $welcome = (float)($_SETTINGS['welcome_bonus'] ?? 10);
    if ($welcome > 0) {
        creditUser($newUserId, $welcome, 'admin_credit', 'Welcome bonus');
        createNotification($newUserId, 'bonus_credited', 'Welcome Bonus!', "You received a welcome bonus of " . formatAmount($welcome));
    }

    // Referral bonuses
    if ($referredById) {
        $l1 = (float)($_SETTINGS['referral_l1_bonus'] ?? 20);
        if ($l1 > 0) {
            creditUser($referredById, $l1, 'referral_bonus', 'Level 1 referral bonus for ' . $name);
            createNotification($referredById, 'bonus_credited', 'Referral Bonus!', "You earned " . formatAmount($l1) . " for referring " . $name);
            $pdo->prepare("INSERT INTO referrals (referrer_id, referred_id, level, bonus) VALUES (:rid, :nid, 1, :bonus)")
                ->execute([':rid' => $referredById, ':nid' => $newUserId, ':bonus' => $l1]);
        }

        // Level 2
        $referrer2 = $pdo->prepare("SELECT referred_by FROM users WHERE id = :id");
        $referrer2->execute([':id' => $referredById]);
        $r2 = $referrer2->fetch();
        if ($r2 && $r2['referred_by']) {
            $l2 = (float)($_SETTINGS['referral_l2_bonus'] ?? 5);
            if ($l2 > 0) {
                creditUser((int)$r2['referred_by'], $l2, 'referral_bonus', 'Level 2 referral bonus for ' . $name);
                $pdo->prepare("INSERT INTO referrals (referrer_id, referred_id, level, bonus) VALUES (:rid, :nid, 2, :bonus)")
                    ->execute([':rid' => $r2['referred_by'], ':nid' => $newUserId, ':bonus' => $l2]);
            }
        }
    }

    createNotification($newUserId, 'welcome', 'Welcome to EarnBD!', 'Your account has been created. Start completing tasks to earn money!');

    return ['success' => true, 'user_id' => $newUserId];
}

function loginUser(string $email, string $password): array {
    $pdo  = getDB();
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :e");
    $stmt->execute([':e' => $email]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password'])) {
        return ['success' => false, 'message' => 'Invalid email or password.'];
    }
    if ($user['status'] === 'banned') {
        return ['success' => false, 'message' => 'Your account has been suspended.'];
    }

    $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = :id")->execute([':id' => $user['id']]);

    // Update streak
    updateStreak((int)$user['id']);

    $_SESSION['user_id'] = $user['id'];
    return ['success' => true, 'user' => $user];
}

function updateStreak(int $userId): void {
    $pdo  = getDB();
    $user = $pdo->prepare("SELECT streak_days, last_login FROM users WHERE id = :id");
    $user->execute([':id' => $userId]);
    $u = $user->fetch();
    if (!$u) return;

    $today     = new DateTime();
    $lastLogin = $u['last_login'] ? new DateTime($u['last_login']) : null;

    if (!$lastLogin) {
        $pdo->prepare("UPDATE users SET streak_days = 1 WHERE id = :id")->execute([':id' => $userId]);
        return;
    }

    $diff = $today->diff($lastLogin)->days;
    if ($diff === 1) {
        $pdo->prepare("UPDATE users SET streak_days = streak_days + 1 WHERE id = :id")->execute([':id' => $userId]);
    } elseif ($diff > 1) {
        $pdo->prepare("UPDATE users SET streak_days = 1 WHERE id = :id")->execute([':id' => $userId]);
    }
}

function loginAdmin(string $username, string $password): bool {
    $pdo  = getDB();
    $stmt = $pdo->prepare("SELECT * FROM admin_users WHERE username = :u");
    $stmt->execute([':u' => $username]);
    $admin = $stmt->fetch();
    if (!$admin || !password_verify($password, $admin['password'])) return false;
    $_SESSION['admin_id']       = $admin['id'];
    $_SESSION['admin_username'] = $admin['username'];
    return true;
}
