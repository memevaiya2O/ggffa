<?php
if (!defined('ROOT_PATH')) {
    define('ROOT_PATH', dirname(__DIR__));
}

function getDB(): PDO {
    static $pdo = null;
    if ($pdo !== null) return $pdo;

    $url = getenv('DATABASE_URL');
    if (!$url) {
        die('DATABASE_URL not set.');
    }
    $parts = parse_url($url);
    $host = $parts['host'];
    $port = $parts['port'] ?? 5432;
    $db   = ltrim($parts['path'], '/');
    $user = $parts['user'];
    $pass = $parts['pass'];

    $dsn = "pgsql:host={$host};port={$port};dbname={$db};sslmode=prefer";
    try {
        $pdo = new PDO($dsn, $user, $pass, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
    } catch (PDOException $e) {
        die('DB connection failed: ' . $e->getMessage());
    }

    setupSchema($pdo);
    runMigrations($pdo);
    return $pdo;
}

function runMigrations(PDO $pdo): void {
    static $ran = false;
    if ($ran) return;
    $ran = true;

    // group_name on settings
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS group_name TEXT NOT NULL DEFAULT 'general'");

    // phone on users
    $pdo->exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS phone TEXT");

    // spin_segments table (richer version of spin_prizes)
    $pdo->exec("CREATE TABLE IF NOT EXISTS spin_segments (
        id SERIAL PRIMARY KEY,
        label TEXT NOT NULL,
        prize_type TEXT NOT NULL DEFAULT 'coins',
        prize_value NUMERIC(10,2) NOT NULL DEFAULT 0,
        weight INT NOT NULL DEFAULT 1,
        color TEXT NOT NULL DEFAULT '#4CAF50',
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
    )");
    $cnt = (int)$pdo->query("SELECT COUNT(*) FROM spin_segments")->fetchColumn();
    if ($cnt === 0) {
        $pdo->exec("INSERT INTO spin_segments (label,prize_type,prize_value,weight,color) VALUES
            ('Try Again','nothing',0,30,'#e2e8f0'),
            ('৳5','coins',5,25,'#4CAF50'),
            ('৳10','coins',10,20,'#2196F3'),
            ('৳20','coins',20,13,'#FF9800'),
            ('৳50','coins',50,7,'#E91E63'),
            ('৳100','coins',100,3,'#9C27B0'),
            ('৳200','bonus',200,2,'#FFD700')
        ");
    }

    // spin settings defaults
    $spinKeys = ['spin_enabled'=>'1','spin_daily_limit'=>'1','spin_cooldown_hours'=>'24'];
    $stmt = $pdo->prepare("INSERT INTO settings (key,value,group_name) VALUES (:k,:v,'spin') ON CONFLICT (key) DO NOTHING");
    foreach ($spinKeys as $k=>$v) $stmt->execute([':k'=>$k,':v'=>$v]);

    // referral settings defaults
    $refKeys = ['referral_enabled'=>'1','referral_bonus_referrer'=>'10','referral_bonus_referee'=>'5',
                'referral_max_per_user'=>'0','referral_bonus_on'=>'register','referral_min_withdraw'=>'0'];
    $stmt = $pdo->prepare("INSERT INTO settings (key,value,group_name) VALUES (:k,:v,'referral') ON CONFLICT (key) DO NOTHING");
    foreach ($refKeys as $k=>$v) $stmt->execute([':k'=>$k,':v'=>$v]);

    // leaderboard settings defaults
    $lbKeys = ['leaderboard_enabled'=>'1','leaderboard_period'=>'alltime','leaderboard_top_n'=>'10',
               'leaderboard_prize_1'=>'500','leaderboard_prize_2'=>'250','leaderboard_prize_3'=>'100'];
    $stmt = $pdo->prepare("INSERT INTO settings (key,value,group_name) VALUES (:k,:v,'leaderboard') ON CONFLICT (key) DO NOTHING");
    foreach ($lbKeys as $k=>$v) $stmt->execute([':k'=>$k,':v'=>$v]);

    // maintenance settings defaults
    $mKeys = ['maintenance_mode'=>'0','maintenance_title'=>"We'll Be Back Soon!",'maintenance_message'=>'Under maintenance.',
              'maintenance_end_time'=>'','maintenance_allow_admin'=>'1'];
    $stmt = $pdo->prepare("INSERT INTO settings (key,value,group_name) VALUES (:k,:v,'maintenance') ON CONFLICT (key) DO NOTHING");
    foreach ($mKeys as $k=>$v) $stmt->execute([':k'=>$k,':v'=>$v]);

    // pages table (clean alias separate from custom_pages)
    $pdo->exec("CREATE TABLE IF NOT EXISTS pages (
        id SERIAL PRIMARY KEY,
        title TEXT NOT NULL,
        slug TEXT NOT NULL UNIQUE,
        content TEXT,
        status TEXT NOT NULL DEFAULT 'published',
        created_at TIMESTAMP NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMP NOT NULL DEFAULT NOW()
    )");

    // withdrawal_methods table (richer; separate from old withdraw_methods)
    $pdo->exec("CREATE TABLE IF NOT EXISTS withdrawal_methods (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        min_amount NUMERIC(10,2) NOT NULL DEFAULT 200,
        max_amount NUMERIC(10,2) NOT NULL DEFAULT 10000,
        charge_pct NUMERIC(5,2) NOT NULL DEFAULT 0,
        instructions TEXT NOT NULL DEFAULT '',
        required_fields TEXT NOT NULL DEFAULT 'Account Number',
        status TEXT NOT NULL DEFAULT 'active',
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
    )");
    $mCnt = (int)$pdo->query("SELECT COUNT(*) FROM withdrawal_methods")->fetchColumn();
    if ($mCnt === 0) {
        $pdo->exec("INSERT INTO withdrawal_methods (name,min_amount,max_amount,charge_pct,instructions,required_fields) VALUES
            ('bKash',200,10000,0,'Send to our bKash agent number','Account Number,Account Name'),
            ('Nagad',200,10000,0,'Send to our Nagad number','Account Number,Account Name'),
            ('Rocket',200,5000,0,'Send to our Rocket number','Account Number'),
            ('USDT TRC20',1000,50000,1,'Send to our USDT TRC20 wallet address','Wallet Address'),
            ('Bank Transfer',5000,100000,0,'Bank NPSB transfer','Bank Name,Account Number,Account Name,Branch')
        ");
    }

    // withdrawals extra columns
    $pdo->exec("ALTER TABLE withdrawals ADD COLUMN IF NOT EXISTS method TEXT");
    $pdo->exec("ALTER TABLE withdrawals ADD COLUMN IF NOT EXISTS details TEXT");
    $pdo->exec("ALTER TABLE withdrawals ADD COLUMN IF NOT EXISTS tx_reference TEXT");
    $pdo->exec("ALTER TABLE withdrawals ADD COLUMN IF NOT EXISTS processed_at TIMESTAMP");
    // Backfill method name from method_id where null
    $pdo->exec("UPDATE withdrawals w SET method = wm.name FROM withdraw_methods wm WHERE wm.id = w.method_id AND w.method IS NULL");

    // popups: add data column and created_at if missing
    $pdo->exec("ALTER TABLE popups ADD COLUMN IF NOT EXISTS data TEXT");
    $pdo->exec("ALTER TABLE popups ADD COLUMN IF NOT EXISTS created_at TIMESTAMP NOT NULL DEFAULT NOW()");

    // sessions table (for maintenance cleanup)
    $pdo->exec("CREATE TABLE IF NOT EXISTS sessions (
        id TEXT PRIMARY KEY,
        user_id INT,
        last_activity BIGINT NOT NULL DEFAULT EXTRACT(EPOCH FROM NOW())
    )");
}

function setupSchema(PDO $pdo): void {
    $res = $pdo->query("SELECT to_regclass('public.settings')")->fetchColumn();
    if ($res) return;

    $pdo->exec("
    CREATE TABLE IF NOT EXISTS levels (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        icon TEXT NOT NULL DEFAULT 'fa-medal',
        color TEXT NOT NULL DEFAULT '#CD7F32',
        required_points INT NOT NULL DEFAULT 0,
        levelup_bonus NUMERIC(12,2) NOT NULL DEFAULT 0,
        daily_withdraw_limit NUMERIC(12,2) NOT NULL DEFAULT 100,
        can_access_vip BOOLEAN NOT NULL DEFAULT FALSE,
        sort_order INT NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        avatar TEXT,
        referral_code TEXT NOT NULL UNIQUE,
        referred_by INT,
        level_id INT NOT NULL DEFAULT 1 REFERENCES levels(id),
        points INT NOT NULL DEFAULT 0,
        balance NUMERIC(12,2) NOT NULL DEFAULT 0,
        total_earned NUMERIC(12,2) NOT NULL DEFAULT 0,
        total_withdrawn NUMERIC(12,2) NOT NULL DEFAULT 0,
        streak_days INT NOT NULL DEFAULT 0,
        last_login TIMESTAMP,
        status TEXT NOT NULL DEFAULT 'active',
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS task_categories (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        icon TEXT NOT NULL DEFAULT 'fa-tag',
        color TEXT NOT NULL DEFAULT '#00C896',
        sort_order INT NOT NULL DEFAULT 0,
        status TEXT NOT NULL DEFAULT 'active'
    );

    CREATE TABLE IF NOT EXISTS tasks (
        id SERIAL PRIMARY KEY,
        category_id INT REFERENCES task_categories(id),
        title TEXT NOT NULL,
        type TEXT NOT NULL DEFAULT 'standard',
        reward NUMERIC(10,2) NOT NULL DEFAULT 0,
        thumbnail TEXT,
        instructions TEXT,
        rules TEXT,
        screenshot_required BOOLEAN NOT NULL DEFAULT TRUE,
        max_per_user INT NOT NULL DEFAULT 1,
        max_total INT NOT NULL DEFAULT 1000,
        is_vip BOOLEAN NOT NULL DEFAULT FALSE,
        is_featured BOOLEAN NOT NULL DEFAULT FALSE,
        is_hot BOOLEAN NOT NULL DEFAULT FALSE,
        is_new BOOLEAN NOT NULL DEFAULT TRUE,
        sort_order INT NOT NULL DEFAULT 0,
        status TEXT NOT NULL DEFAULT 'active',
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS submissions (
        id SERIAL PRIMARY KEY,
        user_id INT NOT NULL REFERENCES users(id),
        task_id INT NOT NULL REFERENCES tasks(id),
        screenshot TEXT,
        notes TEXT,
        status TEXT NOT NULL DEFAULT 'pending',
        reject_reason TEXT,
        created_at TIMESTAMP NOT NULL DEFAULT NOW(),
        reviewed_at TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS transactions (
        id SERIAL PRIMARY KEY,
        user_id INT NOT NULL REFERENCES users(id),
        type TEXT NOT NULL,
        amount NUMERIC(12,2) NOT NULL,
        description TEXT NOT NULL,
        reference_id INT,
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS withdraw_methods (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        icon TEXT NOT NULL DEFAULT 'fa-wallet',
        min_amount NUMERIC(10,2) NOT NULL DEFAULT 50,
        processing_time TEXT NOT NULL DEFAULT '24 hours',
        instructions TEXT NOT NULL DEFAULT '',
        status TEXT NOT NULL DEFAULT 'active'
    );

    CREATE TABLE IF NOT EXISTS withdrawals (
        id SERIAL PRIMARY KEY,
        user_id INT NOT NULL REFERENCES users(id),
        method_id INT NOT NULL REFERENCES withdraw_methods(id),
        address TEXT NOT NULL,
        amount NUMERIC(12,2) NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending',
        admin_note TEXT,
        created_at TIMESTAMP NOT NULL DEFAULT NOW(),
        paid_at TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS notifications (
        id SERIAL PRIMARY KEY,
        user_id INT NOT NULL REFERENCES users(id),
        type TEXT NOT NULL,
        title TEXT NOT NULL,
        message TEXT NOT NULL,
        is_read BOOLEAN NOT NULL DEFAULT FALSE,
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS daily_bonus (
        id SERIAL PRIMARY KEY,
        user_id INT NOT NULL REFERENCES users(id),
        claimed_date DATE NOT NULL,
        amount NUMERIC(10,2) NOT NULL,
        UNIQUE(user_id, claimed_date)
    );

    CREATE TABLE IF NOT EXISTS spin_prizes (
        id SERIAL PRIMARY KEY,
        label TEXT NOT NULL,
        amount NUMERIC(10,2) NOT NULL DEFAULT 0,
        probability NUMERIC(5,2) NOT NULL DEFAULT 10,
        color TEXT NOT NULL DEFAULT '#00C896',
        status TEXT NOT NULL DEFAULT 'active'
    );

    CREATE TABLE IF NOT EXISTS spin_history (
        id SERIAL PRIMARY KEY,
        user_id INT NOT NULL REFERENCES users(id),
        prize_label TEXT NOT NULL,
        amount NUMERIC(10,2) NOT NULL,
        spin_date DATE NOT NULL DEFAULT CURRENT_DATE
    );

    CREATE TABLE IF NOT EXISTS referrals (
        id SERIAL PRIMARY KEY,
        referrer_id INT NOT NULL REFERENCES users(id),
        referred_id INT NOT NULL REFERENCES users(id),
        level INT NOT NULL DEFAULT 1,
        bonus NUMERIC(10,2) NOT NULL DEFAULT 0,
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS achievements (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        description TEXT NOT NULL,
        icon TEXT NOT NULL DEFAULT 'fa-trophy',
        condition_type TEXT NOT NULL,
        condition_value INT NOT NULL DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS user_achievements (
        id SERIAL PRIMARY KEY,
        user_id INT NOT NULL REFERENCES users(id),
        achievement_id INT NOT NULL REFERENCES achievements(id),
        unlocked_at TIMESTAMP NOT NULL DEFAULT NOW(),
        UNIQUE(user_id, achievement_id)
    );

    CREATE TABLE IF NOT EXISTS settings (
        id SERIAL PRIMARY KEY,
        key TEXT NOT NULL UNIQUE,
        value TEXT,
        updated_at TIMESTAMP NOT NULL DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS withdraw_proof (
        id SERIAL PRIMARY KEY,
        image TEXT NOT NULL,
        caption TEXT,
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS custom_pages (
        id SERIAL PRIMARY KEY,
        slug TEXT NOT NULL UNIQUE,
        title TEXT NOT NULL,
        content TEXT,
        meta_title TEXT,
        meta_desc TEXT,
        status TEXT NOT NULL DEFAULT 'active',
        updated_at TIMESTAMP NOT NULL DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS popups (
        id SERIAL PRIMARY KEY,
        title TEXT NOT NULL,
        content TEXT,
        image TEXT,
        show_on TEXT NOT NULL DEFAULT 'all',
        frequency TEXT NOT NULL DEFAULT 'session',
        status TEXT NOT NULL DEFAULT 'active',
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS announcements (
        id SERIAL PRIMARY KEY,
        text TEXT NOT NULL,
        color TEXT NOT NULL DEFAULT '#00C896',
        link TEXT,
        status TEXT NOT NULL DEFAULT 'active'
    );

    CREATE TABLE IF NOT EXISTS reject_templates (
        id SERIAL PRIMARY KEY,
        reason TEXT NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS admin_users (
        id SERIAL PRIMARY KEY,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
    );
    ");

    seedDefaults($pdo);
}

function seedDefaults(PDO $pdo): void {
    // Levels
    $pdo->exec("INSERT INTO levels (name, icon, color, required_points, levelup_bonus, daily_withdraw_limit, can_access_vip, sort_order) VALUES
        ('Bronze', 'fa-medal', '#CD7F32', 0, 0, 500, FALSE, 1),
        ('Silver', 'fa-medal', '#C0C0C0', 500, 10, 1000, FALSE, 2),
        ('Gold', 'fa-medal', '#FFD700', 2000, 25, 2000, FALSE, 3),
        ('Platinum', 'fa-gem', '#00B4D8', 5000, 50, 5000, TRUE, 4),
        ('Diamond', 'fa-gem', '#B9F2FF', 10000, 100, 10000, TRUE, 5)
    ");

    // Categories
    $pdo->exec("INSERT INTO task_categories (name, icon, color, sort_order) VALUES
        ('Social Media', 'fa-share-nodes', '#4267B2', 1),
        ('App Install', 'fa-mobile-screen', '#00C896', 2),
        ('Survey', 'fa-clipboard-list', '#FFA502', 3),
        ('Video Watch', 'fa-play-circle', '#FF4757', 4),
        ('Referral', 'fa-user-plus', '#9C27B0', 5)
    ");

    // Tasks
    $pdo->exec("INSERT INTO tasks (category_id, title, type, reward, instructions, rules, screenshot_required, max_per_user, max_total, is_featured, is_hot, is_new) VALUES
        (1, 'Follow us on Facebook', 'social', 5.00, '1. Go to our Facebook page\n2. Click Follow\n3. Take a screenshot showing you followed', 'Must use real account\nNo fake accounts', TRUE, 1, 500, TRUE, TRUE, TRUE),
        (2, 'Install & Rate TaskApp', 'app', 15.00, '1. Download TaskApp from Play Store\n2. Install and open it\n3. Give 5-star rating\n4. Screenshot the rating screen', 'Must keep app installed for 7 days\nReal account only', TRUE, 1, 200, TRUE, FALSE, TRUE),
        (3, 'Complete Survey #1', 'survey', 20.00, '1. Click the survey link\n2. Complete all questions honestly\n3. Screenshot completion page', 'Must complete in one session', TRUE, 1, 100, FALSE, TRUE, TRUE),
        (4, 'Watch Promo Video', 'video', 8.00, '1. Watch the full 3-minute video\n2. Do not skip\n3. Screenshot end screen', 'Must watch completely', TRUE, 3, 1000, FALSE, FALSE, TRUE)
    ");

    // Withdraw methods
    $pdo->exec("INSERT INTO withdraw_methods (name, icon, min_amount, processing_time, instructions) VALUES
        ('bKash', 'fa-mobile-screen-button', 50, '1-24 hours', 'Enter your bKash number'),
        ('Nagad', 'fa-wallet', 50, '1-24 hours', 'Enter your Nagad number'),
        ('Rocket', 'fa-rocket', 50, '1-24 hours', 'Enter your Rocket number'),
        ('USDT (TRC20)', 'fa-coins', 100, '1-48 hours', 'Enter your TRC20 wallet address'),
        ('Bitcoin', 'fa-bitcoin-sign', 500, '24-72 hours', 'Enter your BTC wallet address')
    ");

    // Spin prizes
    $pdo->exec("INSERT INTO spin_prizes (label, amount, probability, color) VALUES
        ('BDT 5', 5, 30, '#00C896'),
        ('BDT 10', 10, 25, '#009688'),
        ('BDT 20', 20, 20, '#FFA502'),
        ('BDT 50', 50, 15, '#FF4757'),
        ('BDT 100', 100, 7, '#9C27B0'),
        ('BDT 200', 200, 2.5, '#FFD700'),
        ('BDT 500', 500, 0.5, '#00E5B0')
    ");

    // Achievements
    $pdo->exec("INSERT INTO achievements (name, description, icon, condition_type, condition_value) VALUES
        ('First Task', 'Complete your first task', 'fa-star', 'tasks_completed', 1),
        ('Task Pro', 'Complete 10 tasks', 'fa-star-half-stroke', 'tasks_completed', 10),
        ('Task Master', 'Complete 50 tasks', 'fa-certificate', 'tasks_completed', 50),
        ('Task Legend', 'Complete 100 tasks', 'fa-crown', 'tasks_completed', 100),
        ('First Withdraw', 'Make your first withdrawal', 'fa-hand-holding-dollar', 'withdrawals', 1),
        ('Referral King', 'Refer 10 friends', 'fa-user-group', 'referrals', 10),
        ('Daily Streak 7', 'Login 7 days in a row', 'fa-fire', 'streak_days', 7),
        ('Diamond Member', 'Reach Diamond level', 'fa-gem', 'level_reached', 5)
    ");

    // Reject templates
    $pdo->exec("INSERT INTO reject_templates (reason) VALUES
        ('Screenshot is blurry or unclear'),
        ('Task not completed as per instructions'),
        ('Fake account detected'),
        ('Duplicate submission'),
        ('Screenshot does not match requirements')
    ");

    // Settings
    $settings = [
        'site_name' => 'EarnBD',
        'site_tagline' => 'Earn Real Money Online',
        'site_logo' => '',
        'favicon' => '',
        'admin_email' => 'admin@earnbd.com',
        'contact_email' => 'support@earnbd.com',
        'currency_symbol' => '৳',
        'currency_name' => 'BDT',
        'daily_bonus_amount' => '5',
        'welcome_bonus' => '10',
        'referral_l1_bonus' => '20',
        'referral_l2_bonus' => '5',
        'min_withdraw' => '50',
        'registration_open' => '1',
        'maintenance_mode' => '0',
        'maintenance_message' => 'Site is under maintenance. Please check back soon.',
        'color_primary' => '#00C896',
        'color_secondary' => '#009688',
        'color_bg' => '#FFFFFF',
        'color_card' => '#F4FBF9',
        'color_text' => '#1A1A2E',
        'color_accent' => '#00E5B0',
        'color_danger' => '#FF4757',
        'color_warning' => '#FFA502',
        'font_family' => 'Nunito',
        'border_radius' => '12',
        'button_style' => 'filled',
        'hero_headline' => 'Earn Real Money Completing Simple Tasks',
        'hero_subtext' => 'Join thousands of users earning daily rewards',
        'hero_cta' => 'Start Earning Now',
        'spin_mode' => 'wheel',
        'google_analytics' => '',
        'meta_title' => 'EarnBD - Earn Real Money Online',
        'meta_description' => 'Complete tasks and earn real money in Bangladesh',
        'meta_keywords' => 'earn money online, earnbd, tasks, rewards',
        'footer_description' => 'The #1 earning platform in Bangladesh. Earn real money by completing simple tasks.',
        'footer_copyright' => '© 2024 EarnBD. All rights reserved.',
        'social_facebook' => '#',
        'social_youtube' => '#',
        'social_telegram' => '#',
        'social_twitter' => '#',
        'social_instagram' => '#',
        'howit_1_icon' => 'fa-user-plus',
        'howit_1_title' => 'Register Free',
        'howit_1_desc' => 'Create your free account in seconds',
        'howit_2_icon' => 'fa-list-check',
        'howit_2_title' => 'Complete Tasks',
        'howit_2_desc' => 'Browse and complete available tasks',
        'howit_3_icon' => 'fa-money-bill-transfer',
        'howit_3_title' => 'Get Paid',
        'howit_3_desc' => 'Withdraw earnings to bKash, Nagad & more',
        'custom_header_script' => '',
        'custom_footer_script' => '',
        'og_image' => '',
        'section_stats' => '1',
        'section_howit' => '1',
        'section_tasks' => '1',
        'section_earners' => '1',
        'section_proof' => '1',
        'section_testimonials' => '0',
        'section_faq' => '0',
    ];

    $stmt = $pdo->prepare("INSERT INTO settings (key, value) VALUES (:k, :v) ON CONFLICT (key) DO NOTHING");
    foreach ($settings as $k => $v) {
        $stmt->execute([':k' => $k, ':v' => $v]);
    }

    // Admin user
    $hash = password_hash('admin123', PASSWORD_BCRYPT);
    $pdo->prepare("INSERT INTO admin_users (username, password) VALUES (:u, :p) ON CONFLICT DO NOTHING")
        ->execute([':u' => 'admin', ':p' => $hash]);
}
