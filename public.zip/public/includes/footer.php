<?php
$pages = getDB()->query("SELECT slug, title FROM custom_pages WHERE status='active' ORDER BY id")->fetchAll();
$socials = [
  'facebook'  => ['fa-facebook', getSetting('social_facebook')],
  'youtube'   => ['fa-youtube', getSetting('social_youtube')],
  'telegram'  => ['fa-telegram', getSetting('social_telegram')],
  'twitter'   => ['fa-x-twitter', getSetting('social_twitter')],
  'instagram' => ['fa-instagram', getSetting('social_instagram')],
];
?>
<footer class="public-footer">
  <div class="footer-grid">
    <div class="footer-brand">
      <div class="site-logo" style="margin-bottom:14px;">
        <?php if ($logo = getSetting('site_logo')): ?><img src="<?= h($logo) ?>" alt="" style="height:36px;border-radius:8px;"><?php endif; ?>
        <span style="-webkit-text-fill-color:#fff"><?= h(getSetting('site_name','EarnBD')) ?></span>
      </div>
      <p><?= h(getSetting('footer_description','The #1 earning platform.')) ?></p>
      <div class="social-links">
        <?php foreach ($socials as $key => [$icon, $url]): ?>
          <?php if ($url && $url !== '#'): ?>
            <a href="<?= h($url) ?>" target="_blank" rel="noopener"><i class="fa-brands <?= $icon ?>"></i></a>
          <?php endif; ?>
        <?php endforeach; ?>
      </div>
    </div>
    <div class="footer-col">
      <h4>Quick Links</h4>
      <ul>
        <li><a href="/register.php">Register Free</a></li>
        <li><a href="/login.php">Login</a></li>
        <li><a href="/#how-it-works">How It Works</a></li>
        <li><a href="/#tasks">Featured Tasks</a></li>
      </ul>
    </div>
    <?php if ($pages): ?>
    <div class="footer-col">
      <h4>Information</h4>
      <ul>
        <?php foreach ($pages as $p): ?>
          <li><a href="/page.php?slug=<?= h($p['slug']) ?>"><?= h($p['title']) ?></a></li>
        <?php endforeach; ?>
      </ul>
    </div>
    <?php endif; ?>
  </div>
  <div class="footer-bottom"><?= h(getSetting('footer_copyright','© 2024 EarnBD. All rights reserved.')) ?></div>
</footer>
<?= getSetting('custom_footer_script','') ?>
