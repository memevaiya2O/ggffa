<?php
if (!defined('ROOT_PATH')) {
    define('ROOT_PATH', dirname(__DIR__));
}
require_once ROOT_PATH . '/includes/db.php';

function getSetting(string $key, string $default = ''): string {
    global $_SETTINGS;
    return $_SETTINGS[$key] ?? $default;
}

function loadSettings(): array {
    $pdo = getDB();
    $rows = $pdo->query("SELECT key, value FROM settings")->fetchAll();
    $s = [];
    foreach ($rows as $r) $s[$r['key']] = $r['value'];
    return $s;
}

function h(mixed $s): string {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

function redirect(string $url): void {
    header("Location: $url");
    exit;
}

function generateReferralCode(): string {
    return strtoupper(substr(uniqid(), -8));
}

function getUser(int $id): ?array {
    $pdo = getDB();
    $stmt = $pdo->prepare("SELECT u.*, l.name as level_name, l.icon as level_icon, l.color as level_color, l.required_points, l.daily_withdraw_limit, l.can_access_vip FROM users u LEFT JOIN levels l ON l.id = u.level_id WHERE u.id = :id");
    $stmt->execute([':id' => $id]);
    return $stmt->fetch() ?: null;
}

function getCurrentUser(): ?array {
    if (!isset($_SESSION['user_id'])) return null;
    return getUser((int)$_SESSION['user_id']);
}

function requireLogin(): array {
    if (!isset($_SESSION['user_id'])) {
        redirect('/login.php');
    }
    $user = getCurrentUser();
    if (!$user || $user['status'] === 'banned') {
        session_destroy();
        redirect('/login.php?banned=1');
    }
    return $user;
}

function requireAdmin(): void {
    if (empty($_SESSION['admin_id'])) {
        redirect('/admin/login.php');
    }
}

function createNotification(int $userId, string $type, string $title, string $message): void {
    $pdo = getDB();
    $pdo->prepare("INSERT INTO notifications (user_id, type, title, message) VALUES (:uid, :type, :title, :msg)")
        ->execute([':uid' => $userId, ':type' => $type, ':title' => $title, ':msg' => $message]);
}

function addTransaction(int $userId, string $type, float $amount, string $description, ?int $refId = null): void {
    $pdo = getDB();
    $pdo->prepare("INSERT INTO transactions (user_id, type, amount, description, reference_id) VALUES (:uid, :type, :amount, :desc, :ref)")
        ->execute([':uid' => $userId, ':type' => $type, ':amount' => $amount, ':desc' => $description, ':ref' => $refId]);
}

function creditUser(int $userId, float $amount, string $type, string $description, ?int $refId = null): void {
    $pdo = getDB();
    $pdo->prepare("UPDATE users SET balance = balance + :a, total_earned = total_earned + :a WHERE id = :id")
        ->execute([':a' => $amount, ':id' => $userId]);
    addTransaction($userId, $type, $amount, $description, $refId);
    checkLevelUp($userId);
    checkAchievements($userId);
}

function checkLevelUp(int $userId): void {
    $pdo = getDB();
    $user = getUser($userId);
    if (!$user) return;

    $nextLevel = $pdo->prepare("SELECT * FROM levels WHERE required_points > :points ORDER BY required_points ASC LIMIT 1");
    $nextLevel->execute([':points' => $user['points']]);
    $nl = $nextLevel->fetch();

    $currentLevel = $pdo->prepare("SELECT * FROM levels WHERE required_points <= :points ORDER BY required_points DESC LIMIT 1");
    $currentLevel->execute([':points' => $user['points']]);
    $cl = $currentLevel->fetch();

    if ($cl && $cl['id'] != $user['level_id']) {
        $pdo->prepare("UPDATE users SET level_id = :lid WHERE id = :id")
            ->execute([':lid' => $cl['id'], ':id' => $userId]);
        if ((float)$cl['levelup_bonus'] > 0) {
            creditUser($userId, (float)$cl['levelup_bonus'], 'level_up_bonus', 'Level up bonus: ' . $cl['name']);
        }
        createNotification($userId, 'level_up', 'Level Up!', 'Congratulations! You reached ' . $cl['name'] . ' level!');
    }
}

function addPoints(int $userId, int $points): void {
    $pdo = getDB();
    $pdo->prepare("UPDATE users SET points = points + :p WHERE id = :id")
        ->execute([':p' => $points, ':id' => $userId]);
    checkLevelUp($userId);
}

function checkAchievements(int $userId): void {
    $pdo = getDB();
    $user = getUser($userId);
    if (!$user) return;

    $achievements = $pdo->query("SELECT * FROM achievements")->fetchAll();
    foreach ($achievements as $a) {
        $existing = $pdo->prepare("SELECT id FROM user_achievements WHERE user_id = :uid AND achievement_id = :aid");
        $existing->execute([':uid' => $userId, ':aid' => $a['id']]);
        if ($existing->fetch()) continue;

        $met = false;
        switch ($a['condition_type']) {
            case 'tasks_completed':
                $count = $pdo->prepare("SELECT COUNT(*) FROM submissions WHERE user_id = :uid AND status = 'approved'");
                $count->execute([':uid' => $userId]);
                $met = $count->fetchColumn() >= $a['condition_value'];
                break;
            case 'referrals':
                $count = $pdo->prepare("SELECT COUNT(*) FROM referrals WHERE referrer_id = :uid AND level = 1");
                $count->execute([':uid' => $userId]);
                $met = $count->fetchColumn() >= $a['condition_value'];
                break;
            case 'streak_days':
                $met = $user['streak_days'] >= $a['condition_value'];
                break;
            case 'withdrawals':
                $count = $pdo->prepare("SELECT COUNT(*) FROM withdrawals WHERE user_id = :uid AND status = 'paid'");
                $count->execute([':uid' => $userId]);
                $met = $count->fetchColumn() >= $a['condition_value'];
                break;
            case 'level_reached':
                $met = $user['level_id'] >= $a['condition_value'];
                break;
        }

        if ($met) {
            $pdo->prepare("INSERT INTO user_achievements (user_id, achievement_id) VALUES (:uid, :aid) ON CONFLICT DO NOTHING")
                ->execute([':uid' => $userId, ':aid' => $a['id']]);
            createNotification($userId, 'badge_unlocked', 'Badge Unlocked!', 'You unlocked the "' . $a['name'] . '" badge!');
        }
    }
}

function getUnreadNotificationCount(int $userId): int {
    $pdo = getDB();
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = :uid AND is_read = FALSE");
    $stmt->execute([':uid' => $userId]);
    return (int)$stmt->fetchColumn();
}

function formatAmount(float $amount): string {
    global $_SETTINGS;
    $sym = $_SETTINGS['currency_symbol'] ?? '৳';
    return $sym . number_format($amount, 2);
}

function timeAgo(string $datetime): string {
    $now  = new DateTime();
    $then = new DateTime($datetime);
    $diff = $now->diff($then);
    if ($diff->y > 0) return $diff->y . 'y ago';
    if ($diff->m > 0) return $diff->m . 'mo ago';
    if ($diff->d > 0) return $diff->d . 'd ago';
    if ($diff->h > 0) return $diff->h . 'h ago';
    if ($diff->i > 0) return $diff->i . 'm ago';
    return 'just now';
}

function getTransactionIcon(string $type): string {
    return match($type) {
        'task_reward'     => 'fa-list-check',
        'referral_bonus'  => 'fa-user-plus',
        'daily_bonus'     => 'fa-gift',
        'spin_reward'     => 'fa-circle-notch',
        'withdrawal'      => 'fa-money-bill-transfer',
        'level_up_bonus'  => 'fa-arrow-trend-up',
        'admin_credit'    => 'fa-plus-circle',
        default           => 'fa-circle-dollar-to-slot',
    };
}

function csrfToken(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrfField(): string {
    return '<input type="hidden" name="csrf_token" value="' . h(csrfToken()) . '">';
}

function verifyCsrf(): void {
    if (($_POST['csrf_token'] ?? '') !== ($_SESSION['csrf_token'] ?? '')) {
        http_response_code(403);
        die('CSRF verification failed.');
    }
}

function paginationLinks(int $total, int $page, int $limit, string $baseUrl): string {
    $pages = (int)ceil($total / $limit);
    if ($pages <= 1) return '';
    $html = '<div class="pagination">';
    for ($i = 1; $i <= $pages; $i++) {
        $active = $i === $page ? ' active' : '';
        $sep = str_contains($baseUrl, '?') ? '&' : '?';
        $html .= "<a href=\"{$baseUrl}{$sep}page={$i}\" class=\"page-btn{$active}\">{$i}</a>";
    }
    $html .= '</div>';
    return $html;
}
