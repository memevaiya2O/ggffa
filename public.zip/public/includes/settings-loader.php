<?php
if (!defined('ROOT_PATH')) {
    define('ROOT_PATH', dirname(__DIR__));
}
require_once ROOT_PATH . '/includes/db.php';
require_once ROOT_PATH . '/includes/functions.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$_SETTINGS = loadSettings();

// Check maintenance mode (allow admin through)
if (($_SETTINGS['maintenance_mode'] ?? '0') === '1' && empty($_SESSION['admin_id'])) {
    $currentFile = basename($_SERVER['PHP_SELF']);
    $allowedFiles = ['login.php', 'register.php'];
    if (!in_array($currentFile, $allowedFiles) && !str_starts_with($_SERVER['REQUEST_URI'], '/admin/')) {
        $msg = h($_SETTINGS['maintenance_message'] ?? 'Site under maintenance');
        echo "<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Maintenance</title>
        <style>body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;background:#f4f4f4}
        .box{background:#fff;padding:3rem;border-radius:12px;text-align:center;max-width:400px}
        h1{color:#00C896}p{color:#666}</style></head><body>
        <div class='box'><h1>🔧 Under Maintenance</h1><p>$msg</p></div></body></html>";
        exit;
    }
}

function renderCssVars(): string {
    global $_SETTINGS;
    $vars = [
        '--primary'   => $_SETTINGS['color_primary']   ?? '#00C896',
        '--secondary' => $_SETTINGS['color_secondary'] ?? '#009688',
        '--bg'        => $_SETTINGS['color_bg']        ?? '#FFFFFF',
        '--card-bg'   => $_SETTINGS['color_card']      ?? '#F4FBF9',
        '--text'      => $_SETTINGS['color_text']      ?? '#1A1A2E',
        '--accent'    => $_SETTINGS['color_accent']    ?? '#00E5B0',
        '--danger'    => $_SETTINGS['color_danger']    ?? '#FF4757',
        '--warning'   => $_SETTINGS['color_warning']   ?? '#FFA502',
        '--radius'    => ($_SETTINGS['border_radius'] ?? '12') . 'px',
        '--font'      => "'" . ($_SETTINGS['font_family'] ?? 'Nunito') . "', sans-serif",
    ];
    $css = ':root{';
    foreach ($vars as $k => $v) $css .= "$k:$v;";
    $css .= '}';
    return "<style>$css</style>";
}

function renderGoogleFont(): string {
    global $_SETTINGS;
    $font = urlencode($_SETTINGS['font_family'] ?? 'Nunito');
    return "<link href=\"https://fonts.googleapis.com/css2?family={$font}:wght@400;500;600;700;800;900&display=swap\" rel=\"stylesheet\">";
}

function renderSeoMeta(string $page = 'home'): string {
    global $_SETTINGS;
    $title = h($_SETTINGS['meta_title'] ?? 'EarnBD');
    $desc  = h($_SETTINGS['meta_description'] ?? '');
    $keys  = h($_SETTINGS['meta_keywords'] ?? '');
    $og    = h($_SETTINGS['og_image'] ?? '');
    $ga    = h($_SETTINGS['google_analytics'] ?? '');
    $head  = $_SETTINGS['custom_header_script'] ?? '';
    $html  = "<meta charset='UTF-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
    <title>$title</title>
    <meta name='description' content='$desc'>
    <meta name='keywords' content='$keys'>";
    if ($og) $html .= "<meta property='og:image' content='$og'>";
    if ($ga) $html .= "<script async src='https://www.googletagmanager.com/gtag/js?id=$ga'></script><script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','$ga');</script>";
    $html .= $head;
    return $html;
}
