<?php
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/includes/settings-loader.php';
if (!empty($_SESSION['user_id'])) { redirect('/dashboard.php'); }

$pdo = getDB();

// Stats
$totalUsers    = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$totalTasks    = (int)$pdo->query("SELECT COUNT(*) FROM tasks WHERE status='active'")->fetchColumn();
$totalPayout   = (float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM withdrawals WHERE status='paid'")->fetchColumn();
$totalWithdraws= (int)$pdo->query("SELECT COUNT(*) FROM withdrawals WHERE status='paid'")->fetchColumn();

// Featured tasks
$featTasks = $pdo->query("SELECT t.*, tc.name as cat_name, tc.icon as cat_icon, tc.color as cat_color FROM tasks t LEFT JOIN task_categories tc ON tc.id = t.category_id WHERE t.status='active' AND t.is_featured=TRUE ORDER BY t.sort_order LIMIT 4")->fetchAll();
if (empty($featTasks)) $featTasks = $pdo->query("SELECT t.*, tc.name as cat_name, tc.icon as cat_icon, tc.color as cat_color FROM tasks t LEFT JOIN task_categories tc ON tc.id = t.category_id WHERE t.status='active' ORDER BY t.created_at DESC LIMIT 4")->fetchAll();

// Top earners
$topEarners = $pdo->query("SELECT u.name, u.avatar, u.total_earned, l.name as level_name, l.icon as level_icon, l.color as level_color FROM users u LEFT JOIN levels l ON l.id = u.level_id WHERE u.status='active' ORDER BY u.total_earned DESC LIMIT 5")->fetchAll();

// Withdraw proof
$proofs = $pdo->query("SELECT * FROM withdraw_proof ORDER BY created_at DESC LIMIT 8")->fetchAll();

// Announcements
$ann = $pdo->query("SELECT * FROM announcements WHERE status='active' LIMIT 1")->fetch();

// Popup
$popup = null;
if (!isset($_SESSION['popup_seen'])) {
  $popup = $pdo->query("SELECT * FROM popups WHERE status='active' AND show_on IN ('homepage','all') LIMIT 1")->fetch();
  if ($popup && $popup['frequency'] === 'once') $_SESSION['popup_seen'] = true;
}

// How it works, FAQ
$siteName = getSetting('site_name','EarnBD');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?= renderSeoMeta('home') ?>
<?= renderGoogleFont() ?>
<?= renderCssVars() ?>
<link rel="stylesheet" href="/assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<?= $_SETTINGS['custom_header_script'] ?? '' ?>
</head>
<body>

<?php if ($ann && $ann['status'] === 'active'): ?>
  <div class="announcement-bar" style="background:<?= h($ann['color']) ?>;color:#fff;">
    <?php if ($ann['link']): ?><a href="<?= h($ann['link']) ?>"><?php endif; ?>
    <?= h($ann['text']) ?>
    <?php if ($ann['link']): ?></a><?php endif; ?>
  </div>
<?php endif; ?>

<!-- Header -->
<header class="public-header">
  <div class="site-logo">
    <?php if ($logo = getSetting('site_logo')): ?><img src="<?= h($logo) ?>" alt=""><?php endif; ?>
    <span><?= h($siteName) ?></span>
  </div>
  <div class="header-nav">
    <a href="#how-it-works" style="display:none;"></a>
    <a href="/login.php" class="btn btn-outline btn-sm">Login</a>
    <a href="/register.php" class="btn btn-primary btn-sm"><i class="fa-solid fa-rocket"></i> Join Free</a>
  </div>
  <button class="nav-toggle"><i class="fa-solid fa-bars"></i></button>
</header>

<!-- Hero -->
<?php if (getSetting('section_stats','1') || true): ?>
<section class="hero">
  <div class="floating-coins">
    <?php for ($i=0; $i<12; $i++): ?>
      <div class="coin" style="left:<?= rand(5,95) ?>%;animation-duration:<?= rand(8,18) ?>s;animation-delay:<?= rand(0,10) ?>s;font-size:<?= rand(20,40) ?>px;">💰</div>
    <?php endfor; ?>
  </div>
  <div class="hero-content">
    <h1><?= h(getSetting('hero_headline','Earn Real Money Completing Simple Tasks')) ?></h1>
    <p><?= h(getSetting('hero_subtext','Join thousands of users earning daily rewards')) ?></p>
    <div class="hero-btns">
      <a href="/register.php" class="btn btn-primary btn-lg">
        <i class="fa-solid fa-rocket"></i> <?= h(getSetting('hero_cta','Start Earning Now')) ?>
      </a>
      <a href="#how-it-works" class="btn btn-outline btn-lg" style="color:#fff;border-color:rgba(255,255,255,.4)">
        How It Works
      </a>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- Stats -->
<?php if (getSetting('section_stats','1') === '1'): ?>
<section class="stats-section">
  <div class="stats-grid">
    <div class="stat-card"><div class="stat-icon"><i class="fa-solid fa-users"></i></div><div class="stat-number count-up" data-target="<?= $totalUsers ?>"><?= $totalUsers ?></div><div class="stat-label">Total Users</div></div>
    <div class="stat-card"><div class="stat-icon"><i class="fa-solid fa-coins"></i></div><div class="stat-number count-up" data-target="<?= round($totalPayout,2) ?>" data-decimals="0"><?= number_format($totalPayout,0) ?></div><div class="stat-label">Total Payout <?= h(getSetting('currency_symbol','৳')) ?></div></div>
    <div class="stat-card"><div class="stat-icon"><i class="fa-solid fa-list-check"></i></div><div class="stat-number count-up" data-target="<?= $totalTasks ?>"><?= $totalTasks ?></div><div class="stat-label">Active Tasks</div></div>
    <div class="stat-card"><div class="stat-icon"><i class="fa-solid fa-money-bill-transfer"></i></div><div class="stat-number count-up" data-target="<?= $totalWithdraws ?>"><?= $totalWithdraws ?></div><div class="stat-label">Total Withdrawals</div></div>
  </div>
</section>
<?php endif; ?>

<!-- How It Works -->
<?php if (getSetting('section_howit','1') === '1'): ?>
<section class="section" id="how-it-works">
  <div class="container">
    <div class="section-header"><h2>How It Works</h2><p>Start earning in 3 simple steps</p><div class="underline"></div></div>
    <div class="how-steps">
      <?php for ($s = 1; $s <= 3; $s++): ?>
        <div class="step-card">
          <div class="step-number"><?= $s ?></div>
          <i class="fa-solid <?= h(getSetting("howit_{$s}_icon",'fa-star')) ?>"></i>
          <h3><?= h(getSetting("howit_{$s}_title","Step $s")) ?></h3>
          <p><?= h(getSetting("howit_{$s}_desc","")) ?></p>
        </div>
      <?php endfor; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- Featured Tasks -->
<?php if (getSetting('section_tasks','1') === '1' && $featTasks): ?>
<section class="section" id="tasks" style="background:var(--card-bg);">
  <div class="container">
    <div class="section-header"><h2>Featured Tasks</h2><p>Start earning with these popular tasks</p><div class="underline"></div></div>
    <div class="tasks-grid">
      <?php foreach ($featTasks as $t): ?>
        <div class="task-card-pub">
          <?php if ($t['is_hot']): ?><span class="task-ribbon">🔥 HOT</span><?php elseif ($t['is_new']): ?><span class="task-ribbon new">✨ NEW</span><?php elseif ($t['is_vip']): ?><span class="task-ribbon vip">👑 VIP</span><?php endif; ?>
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;">
            <div style="width:48px;height:48px;border-radius:12px;background:<?= h($t['cat_color']??'var(--primary)') ?>22;display:flex;align-items:center;justify-content:center;font-size:22px;color:<?= h($t['cat_color']??'var(--primary)') ?>;flex-shrink:0;">
              <i class="fa-solid <?= h($t['cat_icon']??'fa-star') ?>"></i>
            </div>
            <div>
              <div style="font-weight:700;font-size:15px;"><?= h($t['title']) ?></div>
              <span class="task-cat-badge" style="margin-top:4px;"><?= h($t['cat_name']??'General') ?></span>
            </div>
          </div>
          <div class="task-reward"><?= formatAmount((float)$t['reward']) ?></div>
          <a href="/register.php" class="btn btn-primary btn-sm btn-block" style="margin-top:8px;">Start Task</a>
        </div>
      <?php endforeach; ?>
    </div>
    <div style="text-align:center;margin-top:28px;">
      <a href="/register.php" class="btn btn-outline btn-lg">View All Tasks <i class="fa-solid fa-arrow-right"></i></a>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- Top Earners -->
<?php if (getSetting('section_earners','1') === '1' && $topEarners): ?>
<section class="section" id="earners">
  <div class="container">
    <div class="section-header"><h2>Top Earners</h2><p>Join our community of top earners</p><div class="underline"></div></div>
    <div class="earners-list">
      <?php foreach ($topEarners as $i => $e): ?>
        <?php $rankClass = $i===0?'top-1':($i===1?'top-2':($i===2?'top-3':'')); ?>
        <div class="earner-card">
          <div class="earner-rank <?= $rankClass ?>"><?= $i===0?'🥇':($i===1?'🥈':($i===2?'🥉':'#'.($i+1))) ?></div>
          <div class="earner-avatar">
            <?php if ($e['avatar']): ?><img src="<?= h($e['avatar']) ?>" alt=""><?php else: ?><?= strtoupper(substr($e['name'],0,1)) ?><?php endif; ?>
          </div>
          <div class="earner-info">
            <div class="earner-name"><?= h($e['name']) ?></div>
            <div class="earner-level"><i class="fa-solid <?= h($e['level_icon']??'fa-medal') ?>" style="color:<?= h($e['level_color']??'#CD7F32') ?>"></i> <?= h($e['level_name']??'Bronze') ?></div>
          </div>
          <div class="earner-amount"><?= formatAmount((float)$e['total_earned']) ?></div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- Withdraw Proof -->
<?php if (getSetting('section_proof','1') === '1' && $proofs): ?>
<section class="section" style="background:var(--card-bg);" id="proof">
  <div class="container">
    <div class="section-header"><h2>Payment Proof</h2><p>Real payments to real users</p><div class="underline"></div></div>
    <div class="proof-grid">
      <?php foreach ($proofs as $p): ?>
        <div class="proof-item" data-lightbox="/<?= ltrim(h($p['image']),'/') ?>" onclick="openLightbox('/<?= ltrim(h($p['image']),'/') ?>')">
          <img src="/<?= ltrim(h($p['image']),'/') ?>" alt="<?= h($p['caption']??'Payment Proof') ?>" loading="lazy">
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- CTA -->
<section style="background:linear-gradient(135deg,#0a2f1f,#003d2b);padding:80px 20px;text-align:center;">
  <div class="container">
    <h2 style="color:#fff;font-size:clamp(24px,4vw,40px);margin-bottom:14px;">Ready to Start Earning?</h2>
    <p style="color:rgba(255,255,255,.7);font-size:17px;margin-bottom:32px;">Join <?= number_format($totalUsers) ?>+ users already earning on <?= h($siteName) ?></p>
    <a href="/register.php" class="btn btn-primary btn-lg">
      <i class="fa-solid fa-user-plus"></i> Create Free Account
    </a>
  </div>
</section>

<!-- Footer -->
<?php require_once ROOT_PATH . '/includes/footer.php'; ?>

<!-- Popup -->
<?php if ($popup): ?>
<div class="modal-overlay active" id="popup-modal">
  <div class="modal-box">
    <div class="modal-header">
      <h3><?= h($popup['title']) ?></h3>
      <span class="modal-close" onclick="document.getElementById('popup-modal').classList.remove('active')"><i class="fa-solid fa-xmark"></i></span>
    </div>
    <?php if ($popup['image']): ?><img src="<?= h($popup['image']) ?>" alt="" style="width:100%;border-radius:10px;margin-bottom:14px;"><?php endif; ?>
    <p><?= nl2br(h($popup['content'] ?? '')) ?></p>
    <button class="btn btn-primary btn-block" style="margin-top:16px;" onclick="document.getElementById('popup-modal').classList.remove('active')">Close</button>
  </div>
</div>
<?php endif; ?>

<div id="toast-container"></div>
<script src="/assets/js/main.js"></script>
</body>
</html>
