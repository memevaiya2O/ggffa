<?php
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/includes/settings-loader.php';
$user = requireLogin();
$pdo  = getDB();

$notifCount = getUnreadNotificationCount((int)$user['id']);
$period = in_array($_GET['period'] ?? '', ['weekly','monthly','alltime']) ? $_GET['period'] : 'alltime';

$dateFilter = '';
if ($period === 'weekly') $dateFilter = "AND t.created_at >= NOW() - INTERVAL '7 days'";
elseif ($period === 'monthly') $dateFilter = "AND t.created_at >= NOW() - INTERVAL '30 days'";

$topStmt = $pdo->query("SELECT u.id, u.name, u.avatar, l.name as level_name, l.icon as level_icon, l.color as level_color,
  COALESCE(SUM(CASE WHEN t.amount > 0 $dateFilter THEN t.amount ELSE 0 END),0) as earned
  FROM users u LEFT JOIN levels l ON l.id = u.level_id LEFT JOIN transactions t ON t.user_id = u.id AND t.type != 'withdrawal'
  WHERE u.status = 'active' GROUP BY u.id, u.name, u.avatar, l.name, l.icon, l.color ORDER BY earned DESC LIMIT 10");
$top = $topStmt->fetchAll();

// My rank
$myRank = null;
foreach ($top as $i => $t) { if ($t['id'] == $user['id']) { $myRank = $i + 1; break; } }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?= renderSeoMeta() ?>
<?= renderGoogleFont() ?>
<?= renderCssVars() ?>
<link rel="stylesheet" href="/assets/css/style.css">
<link rel="stylesheet" href="/assets/css/dashboard.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="app-layout">
  <header class="app-header">
    <div class="app-header-left"><div class="user-name">Leaderboard</div></div>
    <div class="app-header-right">
      <a href="/notifications.php" class="notif-btn"><i class="fa-solid fa-bell"></i><?php if ($notifCount): ?><span class="notif-badge"><?= $notifCount ?></span><?php endif; ?></a>
    </div>
  </header>
  <main class="main-content">
    <div class="leaderboard-tabs">
      <div class="lb-tab <?= $period==='weekly'?'active':'' ?>" data-period="weekly">Weekly</div>
      <div class="lb-tab <?= $period==='monthly'?'active':'' ?>" data-period="monthly">Monthly</div>
      <div class="lb-tab <?= $period==='alltime'?'active':'' ?>" data-period="alltime">All Time</div>
    </div>
    <?php foreach ($top as $i => $u): ?>
      <?php
        $rank = $i + 1;
        $rankClass = $rank === 1 ? 'top-1' : ($rank === 2 ? 'top-2' : ($rank === 3 ? 'top-3' : ''));
        $rankIcon  = $rank === 1 ? '🥇' : ($rank === 2 ? '🥈' : ($rank === 3 ? '🥉' : "#$rank"));
        $isMe = $u['id'] == $user['id'];
      ?>
      <div class="rank-card <?= $isMe ? 'my-rank' : '' ?>">
        <div class="rank-num <?= $rankClass ?>"><?= $rankIcon ?></div>
        <div class="earner-avatar">
          <?php if ($u['avatar']): ?><img src="<?= h($u['avatar']) ?>" alt=""><?php else: ?><?= strtoupper(substr($u['name'],0,1)) ?><?php endif; ?>
        </div>
        <div style="flex:1;min-width:0;">
          <div style="font-weight:700;font-size:15px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?= h($u['name']) ?><?= $isMe ? ' <span style="color:var(--primary);font-size:12px;">(You)</span>' : '' ?></div>
          <div style="font-size:12px;color:#888;display:flex;align-items:center;gap:4px;margin-top:2px;">
            <i class="fa-solid <?= h($u['level_icon']??'fa-medal') ?>" style="color:<?= h($u['level_color']??'#CD7F32') ?>"></i> <?= h($u['level_name']??'Bronze') ?>
          </div>
        </div>
        <div style="font-size:20px;font-weight:900;color:var(--primary)"><?= formatAmount((float)$u['earned']) ?></div>
      </div>
    <?php endforeach; ?>
    <?php if ($myRank === null): ?>
      <div class="rank-card my-rank" style="margin-top:8px;">
        <div class="rank-num" style="color:#888;">—</div>
        <div class="earner-avatar"><?= strtoupper(substr($user['name'],0,1)) ?></div>
        <div style="flex:1;">
          <div style="font-weight:700;font-size:15px;"><?= h($user['name']) ?> <span style="color:var(--primary);font-size:12px;">(You)</span></div>
          <div style="font-size:12px;color:#888;">Not ranked yet</div>
        </div>
        <div style="font-size:20px;font-weight:900;color:var(--primary)"><?= formatAmount((float)$user['total_earned']) ?></div>
      </div>
    <?php endif; ?>
  </main>
  <nav class="bottom-nav">
    <a href="/dashboard.php" class="nav-item"><i class="fa-solid fa-house"></i>Home</a>
    <a href="/tasks.php" class="nav-item"><i class="fa-solid fa-list-check"></i>Tasks</a>
    <a href="/wallet.php" class="nav-item"><i class="fa-solid fa-wallet"></i>Wallet</a>
    <a href="/leaderboard.php" class="nav-item active"><i class="fa-solid fa-trophy"></i>Board</a>
    <a href="/profile.php" class="nav-item"><i class="fa-solid fa-user"></i>Profile</a>
  </nav>
</div>
<div id="toast-container"></div>
<script src="/assets/js/main.js"></script>
</body>
</html>
