<?php
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/includes/settings-loader.php';
require_once ROOT_PATH . '/includes/auth.php';

if (!empty($_SESSION['user_id'])) { redirect('/dashboard.php'); }

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    if (!$email || !$password) {
        $error = 'Please fill in all fields.';
    } else {
        $result = loginUser($email, $password);
        if ($result['success']) {
            if (!empty($_POST['remember'])) {
                setcookie('user_email', $email, time() + 86400 * 30, '/', '', false, true);
            }
            redirect('/dashboard.php');
        } else {
            $error = $result['message'];
        }
    }
}
$remEmail = $_COOKIE['user_email'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?= renderSeoMeta('login') ?>
<?= renderGoogleFont() ?>
<?= renderCssVars() ?>
<link rel="stylesheet" href="/assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<?= $_SETTINGS['custom_header_script'] ?? '' ?>
</head>
<body>
<div class="auth-page">
  <div class="auth-card">
    <div class="auth-logo">
      <?php if ($logo = getSetting('site_logo')): ?>
        <img src="<?= h($logo) ?>" alt="Logo" style="height:50px;margin:0 auto 8px;display:block;border-radius:10px;">
      <?php endif; ?>
      <div class="logo-text"><?= h(getSetting('site_name','EarnBD')) ?></div>
      <div style="font-size:13px;color:#888;margin-top:4px;"><?= h(getSetting('site_tagline','Earn Real Money Online')) ?></div>
    </div>
    <h2 class="auth-title">Welcome Back</h2>
    <p class="auth-subtitle">Sign in to your account</p>

    <?php if ($error): ?><div class="alert alert-error"><i class="fa-solid fa-circle-exclamation"></i> <?= h($error) ?></div><?php endif; ?>
    <?php if (!empty($_GET['banned'])): ?><div class="alert alert-error">Your account has been suspended.</div><?php endif; ?>
    <?php if (!empty($_GET['registered'])): ?><div class="alert alert-success"><i class="fa-solid fa-circle-check"></i> Account created! Please login.</div><?php endif; ?>

    <form method="post" action="/login.php">
      <?= csrfField() ?>
      <div class="form-group">
        <label class="form-label">Email Address</label>
        <div class="input-group">
          <i class="input-icon fa-solid fa-envelope"></i>
          <input type="email" name="email" class="form-control" placeholder="you@email.com" value="<?= h($remEmail) ?>" required autofocus>
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Password</label>
        <div class="input-group">
          <i class="input-icon fa-solid fa-lock"></i>
          <input type="password" name="password" class="form-control" placeholder="Enter password" required>
        </div>
      </div>
      <div class="form-group" style="display:flex;align-items:center;justify-content:space-between;">
        <label style="display:flex;align-items:center;gap:8px;font-size:14px;cursor:pointer;">
          <input type="checkbox" name="remember" <?= $remEmail ? 'checked' : '' ?>> Remember me
        </label>
      </div>
      <button type="submit" class="btn btn-primary btn-block">
        <i class="fa-solid fa-right-to-bracket"></i> Login
      </button>
    </form>
    <div class="auth-footer">
      Don't have an account? <a href="/register.php">Register Free</a>
    </div>
  </div>
</div>
<div id="toast-container"></div>
<script src="/assets/js/main.js"></script>
<?= $_SETTINGS['custom_footer_script'] ?? '' ?>
</body>
</html>
