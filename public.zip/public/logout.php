<?php
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/includes/settings-loader.php';
session_destroy();
header('Location: /login.php');
exit;
