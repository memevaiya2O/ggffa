<?php
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/includes/settings-loader.php';
$user = requireLogin();
$pdo  = getDB();

// Mark all as read
if (!empty($_POST['mark_read'])) {
    verifyCsrf();
    $pdo->prepare("UPDATE notifications SET is_read = TRUE WHERE user_id = :uid")->execute([':uid' => $user['id']]);
    redirect('/notifications.php');
}

$page   = max(1, (int)($_GET['page'] ?? 1));
$limit  = 20;
$offset = ($page - 1) * $limit;

$total = (int)$pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = :uid")->execute([':uid' => $user['id']]) && true
    ? $pdo->query("SELECT COUNT(*) FROM notifications WHERE user_id = {$user['id']}")->fetchColumn()
    : 0;

$stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = :uid ORDER BY created_at DESC LIMIT :limit OFFSET :offset");
$stmt->execute([':uid' => $user['id'], ':limit' => $limit, ':offset' => $offset]);
$notifications = $stmt->fetchAll();

$notifCount = getUnreadNotificationCount((int)$user['id']);

$typeIcons = [
    'task_approved'  => ['fa-check-circle','#00C896'],
    'task_rejected'  => ['fa-times-circle','#FF4757'],
    'withdraw'       => ['fa-money-bill-transfer','#FFA502'],
    'level_up'       => ['fa-arrow-trend-up','#9C27B0'],
    'badge_unlocked' => ['fa-trophy','#FFD700'],
    'bonus_credited' => ['fa-gift','#00C896'],
    'welcome'        => ['fa-star','#00C896'],
    'submission'     => ['fa-paper-plane','#00B4D8'],
    'broadcast'      => ['fa-bullhorn','#FF4757'],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?= renderSeoMeta() ?>
<?= renderGoogleFont() ?>
<?= renderCssVars() ?>
<link rel="stylesheet" href="/assets/css/style.css">
<link rel="stylesheet" href="/assets/css/dashboard.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="app-layout">
  <header class="app-header">
    <div class="app-header-left"><div class="user-name">Notifications <?php if ($notifCount): ?><span class="notif-badge" style="position:static;margin-left:6px;"><?= $notifCount ?></span><?php endif; ?></div></div>
    <div class="app-header-right">
      <?php if ($notifCount): ?>
        <form method="post" style="display:inline"><?= csrfField() ?><button type="submit" name="mark_read" value="1" style="font-size:12px;color:var(--primary);font-weight:700;background:none;border:none;cursor:pointer;">Mark All Read</button></form>
      <?php endif; ?>
    </div>
  </header>
  <main class="main-content">
    <?php if (!$notifications): ?>
      <div style="text-align:center;padding:60px 20px;color:#888;">
        <i class="fa-solid fa-bell-slash" style="font-size:48px;display:block;margin-bottom:16px;opacity:.3"></i>
        <p>No notifications yet</p>
      </div>
    <?php else: ?>
      <?php foreach ($notifications as $n): ?>
        <?php
          $icon   = $typeIcons[$n['type']] ?? ['fa-bell','#00C896'];
          $isRead = $n['is_read'];
        ?>
        <div class="notif-item <?= !$isRead ? 'unread' : '' ?>">
          <div class="notif-icon" style="background:<?= $icon[1] ?>22;color:<?= $icon[1] ?>">
            <i class="fa-solid <?= h($icon[0]) ?>"></i>
          </div>
          <div class="notif-body">
            <div class="notif-title"><?= h($n['title']) ?></div>
            <div class="notif-msg"><?= h($n['message']) ?></div>
            <div class="notif-time"><?= timeAgo($n['created_at']) ?></div>
          </div>
          <?php if (!$isRead): ?><div class="unread-dot"></div><?php endif; ?>
        </div>
      <?php endforeach; ?>
      <?= paginationLinks($total, $page, $limit, '/notifications.php') ?>
    <?php endif; ?>
  </main>
  <nav class="bottom-nav">
    <a href="/dashboard.php" class="nav-item"><i class="fa-solid fa-house"></i>Home</a>
    <a href="/tasks.php" class="nav-item"><i class="fa-solid fa-list-check"></i>Tasks</a>
    <a href="/wallet.php" class="nav-item"><i class="fa-solid fa-wallet"></i>Wallet</a>
    <a href="/leaderboard.php" class="nav-item"><i class="fa-solid fa-trophy"></i>Board</a>
    <a href="/profile.php" class="nav-item"><i class="fa-solid fa-user"></i>Profile</a>
  </nav>
</div>
<script src="/assets/js/main.js"></script>
</body>
</html>
