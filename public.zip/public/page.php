<?php
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/includes/settings-loader.php';

$slug = trim($_GET['slug'] ?? '');
if (!$slug) redirect('/');

$pdo  = getDB();
$stmt = $pdo->prepare("SELECT * FROM custom_pages WHERE slug = :s AND status = 'active'");
$stmt->execute([':s' => $slug]);
$page = $stmt->fetch();
if (!$page) { http_response_code(404); die('<h2 style="text-align:center;margin-top:80px;">Page not found</h2>'); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?= renderSeoMeta() ?>
<meta name="description" content="<?= h($page['meta_desc'] ?? '') ?>">
<title><?= h($page['meta_title'] ?: $page['title']) ?> — <?= h(getSetting('site_name')) ?></title>
<?= renderGoogleFont() ?>
<?= renderCssVars() ?>
<link rel="stylesheet" href="/assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<header class="public-header">
  <div class="site-logo">
    <?php if ($logo = getSetting('site_logo')): ?><img src="<?= h($logo) ?>" alt=""><?php endif; ?>
    <span><?= h(getSetting('site_name','EarnBD')) ?></span>
  </div>
  <div class="header-nav">
    <a href="/">Home</a>
    <?php if (!empty($_SESSION['user_id'])): ?>
      <a href="/dashboard.php" class="btn btn-primary btn-sm">Dashboard</a>
    <?php else: ?>
      <a href="/login.php" class="btn btn-outline btn-sm">Login</a>
      <a href="/register.php" class="btn btn-primary btn-sm">Register</a>
    <?php endif; ?>
  </div>
</header>
<div class="section container" style="max-width:800px;min-height:60vh;">
  <h1 style="margin-bottom:24px;"><?= h($page['title']) ?></h1>
  <div style="line-height:1.9;color:#444;font-size:16px;"><?= nl2br(h($page['content'] ?? '')) ?></div>
</div>
<?php require_once ROOT_PATH . '/includes/footer.php'; ?>
</body>
</html>
