<?php
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/includes/settings-loader.php';
require_once ROOT_PATH . '/includes/upload.php';
$user = requireLogin();
$pdo  = getDB();

$notifCount = getUnreadNotificationCount((int)$user['id']);
$error = $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'update_profile') {
        $name = trim($_POST['name'] ?? '');
        if (strlen($name) < 2) { $error = 'Name too short.'; }
        else {
            $avatar = $user['avatar'];
            if (!empty($_FILES['avatar']['name'])) {
                $up = handleUpload('avatar', 'uploads/avatars');
                if ($up['success']) $avatar = $up['path'];
                else $error = $up['message'];
            }
            if (!$error) {
                $pdo->prepare("UPDATE users SET name = :n, avatar = :a WHERE id = :id")
                    ->execute([':n' => $name, ':a' => $avatar, ':id' => $user['id']]);
                $success = 'Profile updated!';
                $user = getCurrentUser();
            }
        }
    } elseif ($action === 'change_password') {
        $current = $_POST['current_password'] ?? '';
        $new     = $_POST['new_password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';
        if (!password_verify($current, $user['password'])) $error = 'Current password is incorrect.';
        elseif (strlen($new) < 6) $error = 'New password must be at least 6 characters.';
        elseif ($new !== $confirm) $error = 'Passwords do not match.';
        else {
            $pdo->prepare("UPDATE users SET password = :p WHERE id = :id")
                ->execute([':p' => password_hash($new, PASSWORD_BCRYPT), ':id' => $user['id']]);
            $success = 'Password changed successfully!';
        }
    }
}

$tasksCompleted = (int)$pdo->query("SELECT COUNT(*) FROM submissions WHERE user_id={$user['id']} AND status='approved'")->fetchColumn();
$withdrawCount  = (int)$pdo->query("SELECT COUNT(*) FROM withdrawals WHERE user_id={$user['id']} AND status='paid'")->fetchColumn();
$refCount       = (int)$pdo->query("SELECT COUNT(*) FROM referrals WHERE referrer_id={$user['id']} AND level=1")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?= renderSeoMeta() ?>
<?= renderGoogleFont() ?>
<?= renderCssVars() ?>
<link rel="stylesheet" href="/assets/css/style.css">
<link rel="stylesheet" href="/assets/css/dashboard.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="app-layout">
  <header class="app-header">
    <div class="app-header-left"><div class="user-name">My Profile</div></div>
    <div class="app-header-right">
      <a href="/notifications.php" class="notif-btn"><i class="fa-solid fa-bell"></i><?php if ($notifCount): ?><span class="notif-badge"><?= $notifCount ?></span><?php endif; ?></a>
      <a href="/logout.php" style="color:var(--danger);font-size:22px;"><i class="fa-solid fa-right-from-bracket"></i></a>
    </div>
  </header>
  <main class="main-content">
    <?php if ($error): ?><div class="alert alert-error"><?= h($error) ?></div><?php endif; ?>
    <?php if ($success): ?><div class="alert alert-success"><?= h($success) ?></div><?php endif; ?>

    <div class="profile-header">
      <div class="profile-avatar-lg">
        <?php if ($user['avatar']): ?><img src="<?= h($user['avatar']) ?>" alt=""><?php else: ?><?= strtoupper(substr($user['name'],0,1)) ?><?php endif; ?>
      </div>
      <div class="profile-name"><?= h($user['name']) ?></div>
      <div class="profile-level">
        <i class="fa-solid <?= h($user['level_icon']??'fa-medal') ?>"></i> <?= h($user['level_name']??'Bronze') ?> Level
      </div>
      <div style="font-size:12px;color:rgba(255,255,255,.6);margin-top:6px;">Joined <?= date('M Y', strtotime($user['created_at'])) ?></div>
    </div>

    <div class="profile-info-grid">
      <div class="profile-info-item"><div class="label">Balance</div><div class="value"><?= formatAmount((float)$user['balance']) ?></div></div>
      <div class="profile-info-item"><div class="label">Total Earned</div><div class="value"><?= formatAmount((float)$user['total_earned']) ?></div></div>
      <div class="profile-info-item"><div class="label">Tasks Done</div><div class="value"><?= $tasksCompleted ?></div></div>
      <div class="profile-info-item"><div class="label">Referrals</div><div class="value"><?= $refCount ?></div></div>
      <div class="profile-info-item"><div class="label">Withdrawals</div><div class="value"><?= $withdrawCount ?></div></div>
      <div class="profile-info-item"><div class="label">Streak</div><div class="value"><?= $user['streak_days'] ?>🔥</div></div>
    </div>

    <!-- Quick Links -->
    <div style="display:flex;gap:10px;margin-bottom:20px;flex-wrap:wrap;">
      <a href="/referral.php" class="btn btn-outline btn-sm"><i class="fa-solid fa-user-plus"></i> Referral</a>
      <a href="/achievements.php" class="btn btn-outline btn-sm"><i class="fa-solid fa-trophy"></i> Badges</a>
      <a href="/spin.php" class="btn btn-outline btn-sm"><i class="fa-solid fa-circle-notch"></i> Spin</a>
    </div>

    <!-- Edit Profile -->
    <div class="card" style="margin-bottom:16px;">
      <h3 style="margin-bottom:16px;font-size:16px;"><i class="fa-solid fa-user-pen" style="color:var(--primary);margin-right:8px;"></i>Edit Profile</h3>
      <form method="post" enctype="multipart/form-data">
        <?= csrfField() ?>
        <input type="hidden" name="action" value="update_profile">
        <div class="form-group">
          <label class="form-label">Full Name</label>
          <input type="text" name="name" class="form-control" value="<?= h($user['name']) ?>" required>
        </div>
        <div class="form-group">
          <label class="form-label">Email</label>
          <input type="email" class="form-control" value="<?= h($user['email']) ?>" readonly style="opacity:.6">
        </div>
        <div class="form-group">
          <label class="form-label">Profile Photo</label>
          <input type="file" name="avatar" class="form-control" accept="image/*">
        </div>
        <button type="submit" class="btn btn-primary btn-block">Save Changes</button>
      </form>
    </div>

    <!-- Change Password -->
    <div class="card" style="margin-bottom:20px;">
      <h3 style="margin-bottom:16px;font-size:16px;"><i class="fa-solid fa-lock" style="color:var(--warning);margin-right:8px;"></i>Change Password</h3>
      <form method="post">
        <?= csrfField() ?>
        <input type="hidden" name="action" value="change_password">
        <div class="form-group">
          <label class="form-label">Current Password</label>
          <input type="password" name="current_password" class="form-control" placeholder="••••••••" required>
        </div>
        <div class="form-group">
          <label class="form-label">New Password</label>
          <input type="password" name="new_password" class="form-control" placeholder="Min 6 characters" required>
        </div>
        <div class="form-group">
          <label class="form-label">Confirm New Password</label>
          <input type="password" name="confirm_password" class="form-control" placeholder="Repeat new password" required>
        </div>
        <button type="submit" class="btn btn-outline btn-block">Update Password</button>
      </form>
    </div>

    <a href="/logout.php" class="btn btn-danger btn-block" style="margin-bottom:20px;">
      <i class="fa-solid fa-right-from-bracket"></i> Logout
    </a>
  </main>
  <nav class="bottom-nav">
    <a href="/dashboard.php" class="nav-item"><i class="fa-solid fa-house"></i>Home</a>
    <a href="/tasks.php" class="nav-item"><i class="fa-solid fa-list-check"></i>Tasks</a>
    <a href="/wallet.php" class="nav-item"><i class="fa-solid fa-wallet"></i>Wallet</a>
    <a href="/leaderboard.php" class="nav-item"><i class="fa-solid fa-trophy"></i>Board</a>
    <a href="/profile.php" class="nav-item active"><i class="fa-solid fa-user"></i>Profile</a>
  </nav>
</div>
<div id="toast-container"></div>
<script src="/assets/js/main.js"></script>
</body>
</html>
