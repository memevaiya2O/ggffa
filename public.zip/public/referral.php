<?php
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/includes/settings-loader.php';
$user = requireLogin();
$pdo  = getDB();

$notifCount = getUnreadNotificationCount((int)$user['id']);
$refLink = 'http' . (isset($_SERVER['HTTPS']) ? 's' : '') . '://' . $_SERVER['HTTP_HOST'] . '/register.php?ref=' . $user['referral_code'];

$refs = $pdo->prepare("SELECT u.name, u.avatar, u.created_at,
  (SELECT COUNT(*) FROM submissions WHERE user_id = u.id AND status='approved') as tasks_done,
  r.bonus, r.level
  FROM referrals r JOIN users u ON u.id = r.referred_id
  WHERE r.referrer_id = :uid ORDER BY r.created_at DESC");
$refs->execute([':uid' => $user['id']]);
$referrals = $refs->fetchAll();

$totalBonus = $pdo->prepare("SELECT COALESCE(SUM(bonus),0) FROM referrals WHERE referrer_id = :uid");
$totalBonus->execute([':uid' => $user['id']]);
$totalBonus = (float)$totalBonus->fetchColumn();
$l1Count = array_sum(array_map(fn($r) => $r['level'] == 1 ? 1 : 0, $referrals));
$l2Count = count($referrals) - $l1Count;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?= renderSeoMeta() ?>
<?= renderGoogleFont() ?>
<?= renderCssVars() ?>
<link rel="stylesheet" href="/assets/css/style.css">
<link rel="stylesheet" href="/assets/css/dashboard.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="app-layout">
  <header class="app-header">
    <div class="app-header-left"><div class="user-name">Referral Program</div></div>
    <div class="app-header-right">
      <a href="/notifications.php" class="notif-btn"><i class="fa-solid fa-bell"></i><?php if ($notifCount): ?><span class="notif-badge"><?= $notifCount ?></span><?php endif; ?></a>
    </div>
  </header>
  <main class="main-content">
    <!-- Referral Card -->
    <div class="balance-card" style="margin-bottom:20px;">
      <div class="balance-deco"><i class="fa-solid fa-user-group"></i></div>
      <div class="balance-label">Total Referral Earnings</div>
      <div class="balance-amount"><?= formatAmount($totalBonus) ?></div>
      <div class="balance-stats">
        <div class="balance-stat"><div class="label">Level 1 Refs</div><div class="value"><?= $l1Count ?></div></div>
        <div class="balance-stat"><div class="label">Level 2 Refs</div><div class="value"><?= $l2Count ?></div></div>
      </div>
    </div>

    <!-- Bonus Info -->
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:20px;">
      <div class="card" style="text-align:center;">
        <div style="font-size:28px;font-weight:900;color:var(--primary)"><?= formatAmount((float)getSetting('referral_l1_bonus','20')) ?></div>
        <div style="font-size:12px;color:#888;margin-top:4px;font-weight:600;">Level 1 Bonus</div>
        <div style="font-size:11px;color:#aaa;">Direct referral</div>
      </div>
      <div class="card" style="text-align:center;">
        <div style="font-size:28px;font-weight:900;color:var(--secondary)"><?= formatAmount((float)getSetting('referral_l2_bonus','5')) ?></div>
        <div style="font-size:12px;color:#888;margin-top:4px;font-weight:600;">Level 2 Bonus</div>
        <div style="font-size:11px;color:#aaa;">Indirect referral</div>
      </div>
    </div>

    <!-- Referral Link -->
    <div class="sec-header"><h3>Your Referral Link</h3></div>
    <div class="referral-link-box">
      <i class="fa-solid fa-link" style="color:var(--primary);flex-shrink:0;"></i>
      <input type="text" id="ref-link" value="<?= h($refLink) ?>" readonly onclick="this.select()">
      <button onclick="copyText(document.getElementById('ref-link').value)" class="btn btn-primary btn-sm">
        <i class="fa-solid fa-copy"></i> Copy
      </button>
    </div>
    <div class="share-btns">
      <a href="https://wa.me/?text=<?= urlencode('Join EarnBD and earn money! Use my referral: ' . $refLink) ?>" target="_blank" class="share-btn share-wa"><i class="fa-brands fa-whatsapp"></i>WhatsApp</a>
      <a href="https://t.me/share/url?url=<?= urlencode($refLink) ?>&text=<?= urlencode('Join EarnBD and earn money online!') ?>" target="_blank" class="share-btn share-tg"><i class="fa-brands fa-telegram"></i>Telegram</a>
      <a href="https://www.facebook.com/sharer/sharer.php?u=<?= urlencode($refLink) ?>" target="_blank" class="share-btn share-fb"><i class="fa-brands fa-facebook"></i>Facebook</a>
    </div>

    <!-- Referral Code -->
    <div class="card" style="margin-bottom:20px;display:flex;align-items:center;justify-content:space-between;">
      <div>
        <div style="font-size:12px;color:#888;font-weight:600;">Your Referral Code</div>
        <div style="font-size:24px;font-weight:900;letter-spacing:2px;color:var(--primary)"><?= h($user['referral_code']) ?></div>
      </div>
      <button onclick="copyText('<?= h($user['referral_code']) ?>')" class="btn btn-outline btn-sm"><i class="fa-solid fa-copy"></i> Copy</button>
    </div>

    <!-- Referred Users -->
    <?php if ($referrals): ?>
    <div class="sec-header"><h3>Referred Users</h3></div>
    <div class="card" style="padding:0;overflow:hidden;">
      <table class="ref-table">
        <thead><tr><th>User</th><th>Level</th><th>Tasks</th><th>Bonus</th></tr></thead>
        <tbody>
          <?php foreach ($referrals as $r): ?>
            <tr>
              <td>
                <div style="display:flex;align-items:center;gap:8px;">
                  <div class="earner-avatar" style="width:36px;height:36px;font-size:14px;"><?= strtoupper(substr($r['name'],0,1)) ?></div>
                  <div>
                    <div style="font-weight:700;font-size:13px;"><?= h($r['name']) ?></div>
                    <div style="font-size:11px;color:#aaa;"><?= date('M j, Y', strtotime($r['created_at'])) ?></div>
                  </div>
                </div>
              </td>
              <td><span class="badge badge-info">L<?= $r['level'] ?></span></td>
              <td><?= $r['tasks_done'] ?></td>
              <td style="color:var(--primary);font-weight:700;"><?= formatAmount((float)$r['bonus']) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php else: ?>
      <div style="text-align:center;padding:32px;color:#888;"><i class="fa-solid fa-user-plus" style="font-size:40px;display:block;margin-bottom:12px;opacity:.3"></i><p>No referrals yet. Share your link to start earning!</p></div>
    <?php endif; ?>
  </main>
  <nav class="bottom-nav">
    <a href="/dashboard.php" class="nav-item"><i class="fa-solid fa-house"></i>Home</a>
    <a href="/tasks.php" class="nav-item"><i class="fa-solid fa-list-check"></i>Tasks</a>
    <a href="/wallet.php" class="nav-item"><i class="fa-solid fa-wallet"></i>Wallet</a>
    <a href="/leaderboard.php" class="nav-item"><i class="fa-solid fa-trophy"></i>Board</a>
    <a href="/profile.php" class="nav-item active"><i class="fa-solid fa-user"></i>Profile</a>
  </nav>
</div>
<div id="toast-container"></div>
<script src="/assets/js/main.js"></script>
</body>
</html>
