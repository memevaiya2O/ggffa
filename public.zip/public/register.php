<?php
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/includes/settings-loader.php';
require_once ROOT_PATH . '/includes/auth.php';

if (!empty($_SESSION['user_id'])) { redirect('/dashboard.php'); }
if (getSetting('registration_open','1') === '0') { die('<h2 style="text-align:center;margin-top:80px;">Registration is currently closed.</h2>'); }

$error = '';
$captchaA = rand(1,9);
$captchaB = rand(1,9);
if (empty($_SESSION['captcha_a'])) { $_SESSION['captcha_a'] = $captchaA; $_SESSION['captcha_b'] = $captchaB; }
else { $captchaA = $_SESSION['captcha_a']; $captchaB = $_SESSION['captcha_b']; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $name    = trim($_POST['name'] ?? '');
    $email   = trim($_POST['email'] ?? '');
    $pass    = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';
    $ref     = trim($_POST['referral_code'] ?? '');
    $captcha = (int)($_POST['captcha'] ?? 0);

    if (!$name || !$email || !$pass || !$confirm) {
        $error = 'Please fill in all required fields.';
    } elseif (strlen($name) < 2) {
        $error = 'Name must be at least 2 characters.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email address.';
    } elseif (strlen($pass) < 6) {
        $error = 'Password must be at least 6 characters.';
    } elseif ($pass !== $confirm) {
        $error = 'Passwords do not match.';
    } elseif ($captcha !== ($_SESSION['captcha_a'] + $_SESSION['captcha_b'])) {
        $error = 'Incorrect CAPTCHA answer.';
        unset($_SESSION['captcha_a'], $_SESSION['captcha_b']);
    } else {
        $result = registerUser($name, $email, $pass, $ref ?: null);
        if ($result['success']) {
            unset($_SESSION['captcha_a'], $_SESSION['captcha_b']);
            $_SESSION['user_id'] = $result['user_id'];
            redirect('/dashboard.php?welcome=1');
        } else {
            $error = $result['message'];
        }
    }
    if ($error) { unset($_SESSION['captcha_a'], $_SESSION['captcha_b']); $_SESSION['captcha_a'] = rand(1,9); $_SESSION['captcha_b'] = rand(1,9); $captchaA = $_SESSION['captcha_a']; $captchaB = $_SESSION['captcha_b']; }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?= renderSeoMeta() ?>
<?= renderGoogleFont() ?>
<?= renderCssVars() ?>
<link rel="stylesheet" href="/assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<?= $_SETTINGS['custom_header_script'] ?? '' ?>
</head>
<body>
<div class="auth-page">
  <div class="auth-card" style="max-width:460px;">
    <div class="auth-logo">
      <div class="logo-text"><?= h(getSetting('site_name','EarnBD')) ?></div>
    </div>
    <h2 class="auth-title">Create Account</h2>
    <p class="auth-subtitle">Join thousands of earners today — it's free!</p>

    <?php if ($error): ?><div class="alert alert-error"><i class="fa-solid fa-circle-exclamation"></i> <?= h($error) ?></div><?php endif; ?>

    <form method="post" action="/register.php">
      <?= csrfField() ?>
      <div class="form-group">
        <label class="form-label">Full Name <span style="color:var(--danger)">*</span></label>
        <div class="input-group">
          <i class="input-icon fa-solid fa-user"></i>
          <input type="text" name="name" class="form-control" placeholder="Your full name" value="<?= h($_POST['name'] ?? '') ?>" required autofocus>
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Email Address <span style="color:var(--danger)">*</span></label>
        <div class="input-group">
          <i class="input-icon fa-solid fa-envelope"></i>
          <input type="email" name="email" class="form-control" placeholder="you@email.com" value="<?= h($_POST['email'] ?? '') ?>" required>
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Password <span style="color:var(--danger)">*</span></label>
        <div class="input-group">
          <i class="input-icon fa-solid fa-lock"></i>
          <input type="password" name="password" class="form-control" placeholder="Min 6 characters" required>
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Confirm Password <span style="color:var(--danger)">*</span></label>
        <div class="input-group">
          <i class="input-icon fa-solid fa-lock"></i>
          <input type="password" name="confirm_password" class="form-control" placeholder="Re-enter password" required>
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Referral Code <span style="color:#aaa;font-weight:400">(optional)</span></label>
        <div class="input-group">
          <i class="input-icon fa-solid fa-user-plus"></i>
          <input type="text" name="referral_code" class="form-control" placeholder="Enter referral code" value="<?= h($_GET['ref'] ?? $_POST['referral_code'] ?? '') ?>">
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Security Check <span style="color:var(--danger)">*</span></label>
        <div class="captcha-box">
          <span class="captcha-q">What is <?= $captchaA ?> + <?= $captchaB ?> ?</span>
          <input type="number" name="captcha" class="form-control" style="max-width:100px;text-align:center;font-size:18px;font-weight:700;" placeholder="?" required min="0">
        </div>
      </div>
      <button type="submit" class="btn btn-primary btn-block">
        <i class="fa-solid fa-user-plus"></i> Create Account
      </button>
      <p style="font-size:12px;color:#aaa;text-align:center;margin-top:12px;">By registering, you agree to our Terms &amp; Privacy Policy.</p>
    </form>
    <div class="auth-footer">
      Already have an account? <a href="/login.php">Login</a>
    </div>
  </div>
</div>
<div id="toast-container"></div>
<script src="/assets/js/main.js"></script>
<?= $_SETTINGS['custom_footer_script'] ?? '' ?>
</body>
</html>
