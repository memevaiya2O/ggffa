<?php
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/includes/settings-loader.php';
$user = requireLogin();
$pdo  = getDB();

$notifCount = getUnreadNotificationCount((int)$user['id']);
$today = date('Y-m-d');
$spunToday = (bool)$pdo->prepare("SELECT id FROM spin_history WHERE user_id = :uid AND spin_date = :d")->execute([':uid' => $user['id'], ':d' => $today]) &&
  $pdo->query("SELECT id FROM spin_history WHERE user_id = {$user['id']} AND spin_date = '$today'")->fetch();

$prizes = $pdo->query("SELECT * FROM spin_prizes WHERE status='active' ORDER BY id")->fetchAll();

// AJAX spin
if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    if ($spunToday) { echo json_encode(['success' => false, 'message' => 'Already spun today.']); exit; }

    // Select prize by probability
    $rand = mt_rand(1, 10000) / 100;
    $cumulative = 0;
    $winner = null;
    foreach ($prizes as $p) {
        $cumulative += (float)$p['probability'];
        if ($rand <= $cumulative) { $winner = $p; break; }
    }
    if (!$winner) $winner = $prizes[0];

    $pdo->prepare("INSERT INTO spin_history (user_id, prize_label, amount, spin_date) VALUES (:uid, :label, :amt, :d)")
        ->execute([':uid' => $user['id'], ':label' => $winner['label'], ':amt' => $winner['amount'], ':d' => $today]);

    if ((float)$winner['amount'] > 0) {
        creditUser((int)$user['id'], (float)$winner['amount'], 'spin_reward', 'Spin reward: ' . $winner['label']);
        createNotification((int)$user['id'], 'bonus_credited', 'Spin Win!', 'You won ' . formatAmount((float)$winner['amount']) . ' from the spin wheel!');
    }

    echo json_encode(['success' => true, 'prize_label' => $winner['label'], 'amount' => $winner['amount'], 'amount_formatted' => formatAmount((float)$winner['amount'])]);
    exit;
}

// History
$history = $pdo->prepare("SELECT * FROM spin_history WHERE user_id = :uid ORDER BY spin_date DESC LIMIT 10");
$history->execute([':uid' => $user['id']]);
$history = $history->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?= renderSeoMeta() ?>
<?= renderGoogleFont() ?>
<?= renderCssVars() ?>
<link rel="stylesheet" href="/assets/css/style.css">
<link rel="stylesheet" href="/assets/css/dashboard.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="app-layout">
  <header class="app-header">
    <div class="app-header-left"><div class="user-name">Daily Spin</div></div>
    <div class="app-header-right">
      <a href="/notifications.php" class="notif-btn"><i class="fa-solid fa-bell"></i><?php if ($notifCount): ?><span class="notif-badge"><?= $notifCount ?></span><?php endif; ?></a>
    </div>
  </header>
  <main class="main-content">
    <div class="spin-container">
      <?php if ($spunToday): ?>
        <div style="text-align:center;padding:40px 20px;">
          <div style="font-size:64px;margin-bottom:16px;">⏰</div>
          <h3>Already spun today!</h3>
          <p style="color:#888;margin-top:8px;">Come back tomorrow for another spin.</p>
          <?php
            $nextMidnight = new DateTime('tomorrow midnight');
          ?>
          <div style="margin-top:20px;font-size:28px;font-weight:900;color:var(--primary)" id="spin-wait-countdown" data-next="<?= $nextMidnight->format('c') ?>">--:--:--</div>
        </div>
      <?php else: ?>
        <div class="wheel-wrapper">
          <div class="wheel-pointer"></div>
          <canvas id="spin-wheel" width="300" height="300" data-prizes='<?= json_encode(array_map(fn($p) => ['label' => $p['label'], 'color' => $p['color']], $prizes)) ?>'></canvas>
          <div class="wheel-center">🍀</div>
        </div>
        <?= csrfField() ?>
        <button class="btn-spin" id="btn-spin">SPIN!</button>
        <p style="font-size:13px;color:#888;margin-top:12px;text-align:center;">Once per day • Prizes credited instantly</p>
      <?php endif; ?>
    </div>

    <!-- Spin Result Overlay -->
    <div class="spin-result-overlay">
      <div class="spin-result-box">
        <div class="spin-result-icon">🎉</div>
        <div style="font-size:20px;font-weight:700;margin-bottom:8px;">You Won!</div>
        <div class="spin-result-amount" id="spin-prize-amount"></div>
        <div class="spin-result-label" id="spin-prize-label"></div>
        <button class="btn btn-primary spin-result-close" style="margin-top:20px;width:100%;">Awesome! 🎊</button>
      </div>
    </div>

    <!-- Prize List -->
    <div class="sec-header" style="margin-top:24px;"><h3>Prize Pool</h3></div>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:10px;margin-bottom:20px;">
      <?php foreach ($prizes as $p): ?>
        <div style="background:<?= h($p['color']) ?>22;border:2px solid <?= h($p['color']) ?>44;border-radius:var(--radius);padding:14px;text-align:center;">
          <div style="font-size:20px;font-weight:900;color:<?= h($p['color']) ?>"><?= h($p['label']) ?></div>
          <div style="font-size:12px;color:#888;margin-top:4px;"><?= $p['probability'] ?>% chance</div>
        </div>
      <?php endforeach; ?>
    </div>

    <!-- Spin History -->
    <?php if ($history): ?>
    <div class="sec-header"><h3>My Spin History</h3></div>
    <?php foreach ($history as $h): ?>
      <div class="activity-item">
        <div class="activity-icon credit"><i class="fa-solid fa-circle-notch"></i></div>
        <div class="activity-info">
          <div class="activity-desc"><?= h($h['prize_label']) ?></div>
          <div class="activity-time"><?= date('M j, Y', strtotime($h['spin_date'])) ?></div>
        </div>
        <div class="activity-amount pos">+<?= formatAmount((float)$h['amount']) ?></div>
      </div>
    <?php endforeach; ?>
    <?php endif; ?>
  </main>
  <nav class="bottom-nav">
    <a href="/dashboard.php" class="nav-item"><i class="fa-solid fa-house"></i>Home</a>
    <a href="/tasks.php" class="nav-item"><i class="fa-solid fa-list-check"></i>Tasks</a>
    <a href="/wallet.php" class="nav-item"><i class="fa-solid fa-wallet"></i>Wallet</a>
    <a href="/leaderboard.php" class="nav-item"><i class="fa-solid fa-trophy"></i>Board</a>
    <a href="/profile.php" class="nav-item"><i class="fa-solid fa-user"></i>Profile</a>
  </nav>
</div>
<div id="toast-container"></div>
<script src="/assets/js/main.js"></script>
<script>
const wc = document.getElementById('spin-wait-countdown');
if (wc) {
  const next = new Date(wc.dataset.next);
  setInterval(() => {
    const diff = next - new Date();
    if (diff <= 0) { wc.textContent = 'Ready!'; return; }
    const h = Math.floor(diff/3600000), m = Math.floor((diff%3600000)/60000), s = Math.floor((diff%60000)/1000);
    wc.textContent = String(h).padStart(2,'0')+':'+String(m).padStart(2,'0')+':'+String(s).padStart(2,'0');
  }, 1000);
}
document.querySelector('.spin-result-close')?.addEventListener('click', () => {
  document.querySelector('.spin-result-overlay')?.classList.remove('show');
  window.location.reload();
});
</script>
</body>
</html>
