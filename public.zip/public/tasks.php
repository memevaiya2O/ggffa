<?php
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/includes/settings-loader.php';
$user = requireLogin();
$pdo  = getDB();

$notifCount = getUnreadNotificationCount((int)$user['id']);
$catId  = (int)($_GET['cat'] ?? 0);
$search = trim($_GET['search'] ?? '');
$page   = max(1, (int)($_GET['page'] ?? 1));
$limit  = 10;
$offset = ($page - 1) * $limit;

$categories = $pdo->query("SELECT * FROM task_categories WHERE status='active' ORDER BY sort_order")->fetchAll();

$params = [];
$where  = ["t.status = 'active'"];
if ($catId) { $where[] = "t.category_id = :cat"; $params[':cat'] = $catId; }
if ($search) { $where[] = "t.title ILIKE :s"; $params[':s'] = "%$search%"; }
if (!$user['can_access_vip']) { $where[] = "t.is_vip = FALSE"; }
$whereStr = implode(' AND ', $where);

$totalStmt = $pdo->prepare("SELECT COUNT(*) FROM tasks t WHERE $whereStr");
$totalStmt->execute($params);
$total = (int)$totalStmt->fetchColumn();

$params[':limit'] = $limit;
$params[':offset'] = $offset;
$stmt = $pdo->prepare("SELECT t.*, tc.name as cat_name, tc.icon as cat_icon, tc.color as cat_color,
  (SELECT COUNT(*) FROM submissions WHERE task_id = t.id AND status IN ('approved','pending')) as completion_count,
  (SELECT id FROM submissions WHERE task_id = t.id AND user_id = :uid1) as user_sub_id,
  (SELECT status FROM submissions WHERE task_id = t.id AND user_id = :uid2) as user_sub_status
  FROM tasks t LEFT JOIN task_categories tc ON tc.id = t.category_id WHERE $whereStr ORDER BY t.sort_order, t.created_at DESC LIMIT :limit OFFSET :offset");
$params[':uid1'] = $user['id'];
$params[':uid2'] = $user['id'];
$stmt->execute($params);
$tasks = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?= renderSeoMeta() ?>
<?= renderGoogleFont() ?>
<?= renderCssVars() ?>
<link rel="stylesheet" href="/assets/css/style.css">
<link rel="stylesheet" href="/assets/css/dashboard.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="app-layout">
  <header class="app-header">
    <div class="app-header-left">
      <div class="user-name">Tasks</div>
    </div>
    <div class="app-header-right">
      <a href="/notifications.php" class="notif-btn"><i class="fa-solid fa-bell"></i><?php if ($notifCount): ?><span class="notif-badge"><?= $notifCount ?></span><?php endif; ?></a>
    </div>
  </header>
  <main class="main-content">
    <!-- Category Tabs -->
    <div class="category-tabs">
      <a href="/tasks.php" class="cat-tab <?= !$catId ? 'active' : '' ?>"><i class="fa-solid fa-border-all"></i> All</a>
      <?php foreach ($categories as $c): ?>
        <a href="/tasks.php?cat=<?= $c['id'] ?>" class="cat-tab <?= $catId == $c['id'] ? 'active' : '' ?>">
          <i class="fa-solid <?= h($c['icon']) ?>" style="color:<?= h($c['color']) ?>"></i> <?= h($c['name']) ?>
        </a>
      <?php endforeach; ?>
    </div>

    <!-- Search -->
    <div class="search-box">
      <i class="fa-solid fa-magnifying-glass"></i>
      <input type="text" class="form-control" placeholder="Search tasks..." id="task-search" value="<?= h($search) ?>">
    </div>

    <!-- Task List -->
    <?php if (!$tasks): ?>
      <div style="text-align:center;padding:48px 20px;color:#888;"><i class="fa-solid fa-inbox" style="font-size:48px;display:block;margin-bottom:16px;opacity:.3"></i><p>No tasks available right now</p></div>
    <?php else: ?>
      <?php foreach ($tasks as $t): ?>
        <?php
          $isDone   = $t['user_sub_status'] === 'approved';
          $isPending = $t['user_sub_status'] === 'pending';
          $isLocked = $t['is_vip'] && !$user['can_access_vip'];
        ?>
        <a href="/task-detail.php?id=<?= $t['id'] ?>" class="task-card <?= $isDone ? 'completed' : '' ?> <?= $isLocked ? 'locked' : '' ?>" style="text-decoration:none;display:flex;">
          <div class="task-thumb" style="<?= $t['cat_color'] ? "background:linear-gradient(135deg,{$t['cat_color']}cc,{$t['cat_color']}88)" : '' ?>">
            <?php if ($t['thumbnail']): ?>
              <img src="<?= h($t['thumbnail']) ?>" alt="">
            <?php else: ?>
              <i class="fa-solid <?= h($t['cat_icon'] ?? 'fa-star') ?>"></i>
            <?php endif; ?>
          </div>
          <div class="task-info">
            <div class="task-title"><?= h($t['title']) ?></div>
            <div class="task-meta">
              <span class="task-reward-tag"><?= formatAmount((float)$t['reward']) ?></span>
              <span class="task-cat-badge"><i class="fa-solid <?= h($t['cat_icon'] ?? 'fa-tag') ?>"></i> <?= h($t['cat_name'] ?? 'General') ?></span>
            </div>
            <div class="task-ribbons">
              <?php if ($t['is_hot']): ?><span class="badge badge-hot">🔥 HOT</span><?php endif; ?>
              <?php if ($t['is_new']): ?><span class="badge badge-new">✨ NEW</span><?php endif; ?>
              <?php if ($t['is_vip']): ?><span class="badge badge-vip">👑 VIP</span><?php endif; ?>
              <?php if ($isDone): ?><span class="badge badge-success">✅ Done</span><?php endif; ?>
              <?php if ($isPending): ?><span class="badge badge-warning">⏳ Pending</span><?php endif; ?>
              <?php if ($isLocked): ?><span class="badge" style="background:rgba(0,0,0,.08);color:#888;"><i class="fa-solid fa-lock"></i> VIP Required</span><?php endif; ?>
            </div>
            <div class="task-progress" style="margin-top:6px;"><?= $t['completion_count'] ?>/<?= $t['max_total'] ?> completed</div>
          </div>
        </a>
      <?php endforeach; ?>
      <?= paginationLinks($total, $page, $limit, '/tasks.php?' . http_build_query(['cat' => $catId, 'search' => $search])) ?>
    <?php endif; ?>
  </main>
  <nav class="bottom-nav">
    <a href="/dashboard.php" class="nav-item"><i class="fa-solid fa-house"></i>Home</a>
    <a href="/tasks.php" class="nav-item active"><i class="fa-solid fa-list-check"></i>Tasks</a>
    <a href="/wallet.php" class="nav-item"><i class="fa-solid fa-wallet"></i>Wallet</a>
    <a href="/leaderboard.php" class="nav-item"><i class="fa-solid fa-trophy"></i>Board</a>
    <a href="/profile.php" class="nav-item"><i class="fa-solid fa-user"></i>Profile</a>
  </nav>
</div>
<div id="toast-container"></div>
<script src="/assets/js/main.js"></script>
<script>
document.getElementById('task-search').addEventListener('keydown', e => {
  if (e.key === 'Enter') {
    const url = new URL(window.location.href);
    url.searchParams.set('search', e.target.value);
    url.searchParams.delete('page');
    window.location.href = url.toString();
  }
});
</script>
</body>
</html>
