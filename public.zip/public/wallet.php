<?php
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/includes/settings-loader.php';
$user = requireLogin();
$pdo  = getDB();

$notifCount = getUnreadNotificationCount((int)$user['id']);
$type  = $_GET['type'] ?? 'all';
$page  = max(1, (int)($_GET['page'] ?? 1));
$limit = 15;
$offset = ($page - 1) * $limit;

$where = "user_id = :uid";
$params = [':uid' => $user['id']];
$validTypes = ['task_reward','referral_bonus','daily_bonus','spin_reward','withdrawal','level_up_bonus','admin_credit'];
if ($type !== 'all' && in_array($type, $validTypes)) {
    $where .= " AND type = :type";
    $params[':type'] = $type;
}

$totalStmt = $pdo->prepare("SELECT COUNT(*) FROM transactions WHERE $where");
$totalStmt->execute($params);
$total = (int)$totalStmt->fetchColumn();

$params[':limit'] = $limit;
$params[':offset'] = $offset;
$txStmt = $pdo->prepare("SELECT * FROM transactions WHERE $where ORDER BY created_at DESC LIMIT :limit OFFSET :offset");
$txStmt->execute($params);
$transactions = $txStmt->fetchAll();

// Breakdown by type for chart
$breakdown = $pdo->prepare("SELECT type, SUM(amount) as total FROM transactions WHERE user_id = :uid AND amount > 0 GROUP BY type");
$breakdown->execute([':uid' => $user['id']]);
$chartData = $breakdown->fetchAll();

// Pending
$pendingStmt = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM withdrawals WHERE user_id = :uid AND status = 'pending'");
$pendingStmt->execute([':uid' => $user['id']]);
$pendingAmt = (float)$pendingStmt->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?= renderSeoMeta() ?>
<?= renderGoogleFont() ?>
<?= renderCssVars() ?>
<link rel="stylesheet" href="/assets/css/style.css">
<link rel="stylesheet" href="/assets/css/dashboard.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4/dist/chart.umd.min.js"></script>
</head>
<body>
<div class="app-layout">
  <header class="app-header">
    <div class="app-header-left"><div class="user-name">Wallet</div></div>
    <div class="app-header-right">
      <a href="/notifications.php" class="notif-btn"><i class="fa-solid fa-bell"></i><?php if ($notifCount): ?><span class="notif-badge"><?= $notifCount ?></span><?php endif; ?></a>
    </div>
  </header>
  <main class="main-content">
    <!-- Summary -->
    <div class="wallet-summary">
      <div class="wallet-card"><div class="w-icon"><i class="fa-solid fa-coins"></i></div><div class="w-amount"><?= formatAmount((float)$user['balance']) ?></div><div class="w-label">Available</div></div>
      <div class="wallet-card"><div class="w-icon"><i class="fa-solid fa-arrow-trend-up"></i></div><div class="w-amount"><?= formatAmount((float)$user['total_earned']) ?></div><div class="w-label">Total Earned</div></div>
      <div class="wallet-card"><div class="w-icon"><i class="fa-solid fa-money-bill-transfer"></i></div><div class="w-amount"><?= formatAmount((float)$user['total_withdrawn']) ?></div><div class="w-label">Withdrawn</div></div>
      <div class="wallet-card pending"><div class="w-icon"><i class="fa-solid fa-clock"></i></div><div class="w-amount"><?= formatAmount($pendingAmt) ?></div><div class="w-label">Pending</div></div>
    </div>

    <!-- Chart -->
    <?php if ($chartData): ?>
    <div class="chart-container" style="margin-bottom:20px;">
      <canvas id="income-chart"></canvas>
    </div>
    <?php endif; ?>

    <!-- Filter Tabs -->
    <div class="filter-tabs">
      <?php
      $types = ['all' => 'All', 'task_reward' => 'Tasks', 'referral_bonus' => 'Referral', 'daily_bonus' => 'Daily', 'spin_reward' => 'Spin', 'withdrawal' => 'Withdraw'];
      foreach ($types as $k => $v):
      ?>
        <div class="filter-tab <?= $type === $k ? 'active' : '' ?>" data-type="<?= $k ?>"><?= $v ?></div>
      <?php endforeach; ?>
    </div>

    <!-- Transactions -->
    <?php if (!$transactions): ?>
      <div style="text-align:center;padding:48px 20px;color:#888;"><i class="fa-solid fa-inbox" style="font-size:48px;display:block;margin-bottom:16px;opacity:.3"></i><p>No transactions found</p></div>
    <?php else: ?>
      <div class="activity-list">
        <?php foreach ($transactions as $tx): ?>
          <?php $pos = $tx['amount'] > 0; ?>
          <div class="activity-item">
            <div class="activity-icon <?= $pos ? 'credit' : 'debit' ?>">
              <i class="fa-solid <?= getTransactionIcon($tx['type']) ?>"></i>
            </div>
            <div class="activity-info">
              <div class="activity-desc"><?= h($tx['description']) ?></div>
              <div class="activity-time"><?= date('M j, Y g:ia', strtotime($tx['created_at'])) ?></div>
            </div>
            <div class="activity-amount <?= $pos ? 'pos' : 'neg' ?>"><?= $pos ? '+' : '' ?><?= formatAmount(abs($tx['amount'])) ?></div>
          </div>
        <?php endforeach; ?>
      </div>
      <?= paginationLinks($total, $page, $limit, '/wallet.php?type=' . urlencode($type)) ?>
    <?php endif; ?>
  </main>
  <nav class="bottom-nav">
    <a href="/dashboard.php" class="nav-item"><i class="fa-solid fa-house"></i>Home</a>
    <a href="/tasks.php" class="nav-item"><i class="fa-solid fa-list-check"></i>Tasks</a>
    <a href="/wallet.php" class="nav-item active"><i class="fa-solid fa-wallet"></i>Wallet</a>
    <a href="/leaderboard.php" class="nav-item"><i class="fa-solid fa-trophy"></i>Board</a>
    <a href="/profile.php" class="nav-item"><i class="fa-solid fa-user"></i>Profile</a>
  </nav>
</div>
<div id="toast-container"></div>
<script src="/assets/js/main.js"></script>
<?php if ($chartData): ?>
<script>
const ctx = document.getElementById('income-chart').getContext('2d');
const data = <?= json_encode(array_values(array_map(fn($r) => (float)$r['total'], $chartData))) ?>;
const labels = <?= json_encode(array_values(array_map(fn($r) => ucwords(str_replace('_',' ',$r['type'])), $chartData))) ?>;
const colors = ['#00C896','#FFA502','#FF4757','#9C27B0','#00B4D8','#FFD700'];
new Chart(ctx, { type:'doughnut', data:{ labels, datasets:[{ data, backgroundColor:colors.slice(0,data.length), borderWidth:0 }] }, options:{ responsive:true, maintainAspectRatio:false, cutout:'60%', plugins:{ legend:{ position:'bottom', labels:{ font:{ size:12 } } } } } });
</script>
<?php endif; ?>
</body>
</html>
