<?php
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/includes/settings-loader.php';
$user = requireLogin();
$pdo  = getDB();

$notifCount = getUnreadNotificationCount((int)$user['id']);
$methods = $pdo->query("SELECT * FROM withdraw_methods WHERE status='active' ORDER BY id")->fetchAll();

$error = $success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $methodId = (int)($_POST['method_id'] ?? 0);
    $address  = trim($_POST['address'] ?? '');
    $amount   = (float)($_POST['amount'] ?? 0);

    $method = $pdo->prepare("SELECT * FROM withdraw_methods WHERE id = :id AND status = 'active'");
    $method->execute([':id' => $methodId]);
    $method = $method->fetch();

    $minGlobal = (float)getSetting('min_withdraw', '50');
    $minMethod = $method ? (float)$method['min_amount'] : $minGlobal;
    $minAmt    = max($minGlobal, $minMethod);

    if (!$method) $error = 'Invalid payment method.';
    elseif (!$address) $error = 'Please enter your account/wallet address.';
    elseif ($amount < $minAmt) $error = 'Minimum withdrawal is ' . formatAmount($minAmt) . '.';
    elseif ($amount > (float)$user['balance']) $error = 'Insufficient balance.';
    elseif ($amount > (float)$user['daily_withdraw_limit']) $error = 'Exceeds your daily limit of ' . formatAmount((float)$user['daily_withdraw_limit']) . '.';
    else {
        $dupCheck = $pdo->prepare("SELECT id FROM withdrawals WHERE user_id = :uid AND status = 'pending'");
        $dupCheck->execute([':uid' => $user['id']]);
        if ($dupCheck->fetch()) {
            $error = 'You already have a pending withdrawal request.';
        } else {
            $pdo->prepare("INSERT INTO withdrawals (user_id, method_id, address, amount) VALUES (:uid, :mid, :addr, :amt)")
                ->execute([':uid' => $user['id'], ':mid' => $methodId, ':addr' => $address, ':amt' => $amount]);
            $pdo->prepare("UPDATE users SET balance = balance - :a WHERE id = :id")->execute([':a' => $amount, ':id' => $user['id']]);
            addTransaction((int)$user['id'], 'withdrawal', -$amount, 'Withdrawal via ' . $method['name'] . ' to ' . $address);
            createNotification((int)$user['id'], 'withdraw', 'Withdrawal Requested', 'Your withdrawal of ' . formatAmount($amount) . ' via ' . $method['name'] . ' is pending.');
            $success = 'Withdrawal request submitted successfully!';
            $user = getCurrentUser();
        }
    }
}

// History
$histStmt = $pdo->prepare("SELECT w.*, wm.name as method_name, wm.icon as method_icon FROM withdrawals w LEFT JOIN withdraw_methods wm ON wm.id = w.method_id WHERE w.user_id = :uid ORDER BY w.created_at DESC LIMIT 20");
$histStmt->execute([':uid' => $user['id']]);
$history = $histStmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?= renderSeoMeta() ?>
<?= renderGoogleFont() ?>
<?= renderCssVars() ?>
<link rel="stylesheet" href="/assets/css/style.css">
<link rel="stylesheet" href="/assets/css/dashboard.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="app-layout">
  <header class="app-header">
    <div class="app-header-left"><div class="user-name">Withdraw</div></div>
    <div class="app-header-right">
      <a href="/notifications.php" class="notif-btn"><i class="fa-solid fa-bell"></i><?php if ($notifCount): ?><span class="notif-badge"><?= $notifCount ?></span><?php endif; ?></a>
    </div>
  </header>
  <main class="main-content">
    <?php if ($error): ?><div class="alert alert-error"><?= h($error) ?></div><?php endif; ?>
    <?php if ($success): ?><div class="alert alert-success"><?= h($success) ?></div><?php endif; ?>

    <!-- Balance -->
    <div class="balance-card" style="margin-bottom:20px;">
      <div class="balance-deco"><i class="fa-solid fa-money-bill"></i></div>
      <div class="balance-label">Available Balance</div>
      <div class="balance-amount"><?= formatAmount((float)$user['balance']) ?></div>
      <div style="position:relative;z-index:1;font-size:13px;color:rgba(255,255,255,.7);margin-top:8px;">Daily Limit: <?= formatAmount((float)$user['daily_withdraw_limit']) ?></div>
    </div>

    <h3 style="margin-bottom:14px;font-size:16px;font-weight:800;">Select Payment Method</h3>
    <div class="method-list">
      <?php foreach ($methods as $m): ?>
        <div class="method-card" data-id="<?= $m['id'] ?>" data-min="<?= $m['min_amount'] ?>">
          <i class="fa-solid <?= h($m['icon']) ?>"></i>
          <h4><?= h($m['name']) ?></h4>
          <p>Min: <?= formatAmount((float)$m['min_amount']) ?></p>
          <p style="font-size:11px;color:#aaa;"><?= h($m['processing_time']) ?></p>
        </div>
      <?php endforeach; ?>
    </div>

    <form method="post" action="/withdraw.php" id="withdraw-form">
      <?= csrfField() ?>
      <input type="hidden" name="method_id" id="method_id">
      <div class="form-group">
        <label class="form-label">Amount</label>
        <div class="input-group">
          <i class="input-icon fa-solid fa-coins"></i>
          <input type="number" name="amount" class="form-control" placeholder="Enter amount" step="0.01" min="1" max="<?= $user['balance'] ?>">
        </div>
        <p style="font-size:12px;color:#888;margin-top:6px;">Minimum: <strong id="min-amount-label">—</strong></p>
      </div>
      <div class="form-group">
        <label class="form-label">Account / Wallet Address</label>
        <div class="input-group">
          <i class="input-icon fa-solid fa-address-card"></i>
          <input type="text" name="address" class="form-control" placeholder="Enter your number or wallet address">
        </div>
      </div>
      <button type="submit" class="btn btn-primary btn-block btn-lg">
        <i class="fa-solid fa-paper-plane"></i> Submit Withdrawal
      </button>
    </form>

    <?php if ($history): ?>
    <h3 style="margin:24px 0 14px;font-size:16px;font-weight:800;">Withdrawal History</h3>
    <?php foreach ($history as $w): ?>
      <div class="withdraw-item">
        <div class="withdraw-icon"><i class="fa-solid <?= h($w['method_icon'] ?? 'fa-wallet') ?>"></i></div>
        <div class="withdraw-info">
          <div class="withdraw-method"><?= h($w['method_name'] ?? 'Unknown') ?></div>
          <div class="withdraw-addr"><?= h(substr($w['address'],0,20)) ?>...</div>
        </div>
        <div class="withdraw-right">
          <div class="withdraw-amount"><?= formatAmount((float)$w['amount']) ?></div>
          <span class="status-badge status-<?= h($w['status']) ?>"><?= ucfirst($w['status']) ?></span>
          <div class="withdraw-date"><?= date('M j, Y', strtotime($w['created_at'])) ?></div>
        </div>
      </div>
    <?php endforeach; ?>
    <?php endif; ?>
  </main>
  <nav class="bottom-nav">
    <a href="/dashboard.php" class="nav-item"><i class="fa-solid fa-house"></i>Home</a>
    <a href="/tasks.php" class="nav-item"><i class="fa-solid fa-list-check"></i>Tasks</a>
    <a href="/wallet.php" class="nav-item active"><i class="fa-solid fa-wallet"></i>Wallet</a>
    <a href="/leaderboard.php" class="nav-item"><i class="fa-solid fa-trophy"></i>Board</a>
    <a href="/profile.php" class="nav-item"><i class="fa-solid fa-user"></i>Profile</a>
  </nav>
</div>
<div id="toast-container"></div>
<script src="/assets/js/main.js"></script>
</body>
</html>
